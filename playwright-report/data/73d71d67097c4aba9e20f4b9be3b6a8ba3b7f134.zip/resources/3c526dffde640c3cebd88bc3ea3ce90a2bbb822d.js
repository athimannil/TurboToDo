import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/users/$userId.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=f71da48c";
import { Panel } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/index.ts";
import { UserDetails } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/index.ts?t=1785727715973";
import { useParams } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=f71da48c";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/users/$userId.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
var _s = $RefreshSig$();
const UserDetail = () => {
	_s();
	const { userId } = useParams({ from: "/users/$userId" });
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-6",
		children: [/* @__PURE__ */ _jsxDEV(Link, {
			to: "/users",
			className: "text-sm text-primary underline-offset-4 hover:underline",
			children: "← All users"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(Panel, {
			title: "User Details",
			description: "View and edit user details.",
			children: /* @__PURE__ */ _jsxDEV(UserDetails, { userId }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
};
_s(UserDetail, "r0rqsLfWJTH7w5cXk9h+Af0W8oI=", false, function() {
	return [useParams];
});
_c = UserDetail;
export default UserDetail;
var _c;
$RefreshReg$(_c, "UserDetail");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/users/$userId.tsx?t=1785727715973";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/users/$userId.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/users/$userId.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/users/$userId.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsYUFBYTtBQUN0QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGlCQUFpQjs7OztBQUUxQixNQUFNLG1CQUFtQjs7Q0FDdkIsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE1BQU0saUJBQWlCLENBQUM7Q0FFdkQsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsTUFBRDtHQUNFLElBQUc7R0FDSCxXQUFVO2FBQ1g7RUFFSzs7OztZQUVOLHdCQUFDLE9BQUQ7R0FBTyxPQUFNO0dBQWUsYUFBWTthQUN0Qyx3QkFBQyxhQUFELEVBQXFCLE9BQVM7Ozs7O0VBQ3pCOzs7O1VBQ0o7Ozs7OztBQUVUOzs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiJHVzZXJJZC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtcm91dGVyXCI7XG5pbXBvcnQgeyBQYW5lbCB9IGZyb20gXCJAcmVwby9zaGFyZWRcIjtcbmltcG9ydCB7IFVzZXJEZXRhaWxzIH0gZnJvbSBcIkByZXBvL3VzZXJzXCI7XG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXJvdXRlclwiO1xuXG5jb25zdCBVc2VyRGV0YWlsID0gKCkgPT4ge1xuICBjb25zdCB7IHVzZXJJZCB9ID0gdXNlUGFyYW1zKHsgZnJvbTogXCIvdXNlcnMvJHVzZXJJZFwiIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC02XCI+XG4gICAgICA8TGlua1xuICAgICAgICB0bz1cIi91c2Vyc1wiXG4gICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1wcmltYXJ5IHVuZGVybGluZS1vZmZzZXQtNCBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgPlxuICAgICAgICDihpAgQWxsIHVzZXJzXG4gICAgICA8L0xpbms+XG5cbiAgICAgIDxQYW5lbCB0aXRsZT1cIlVzZXIgRGV0YWlsc1wiIGRlc2NyaXB0aW9uPVwiVmlldyBhbmQgZWRpdCB1c2VyIGRldGFpbHMuXCI+XG4gICAgICAgIDxVc2VyRGV0YWlscyB1c2VySWQ9e3VzZXJJZH0gLz5cbiAgICAgIDwvUGFuZWw+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBVc2VyRGV0YWlsO1xuIl19