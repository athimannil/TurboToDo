import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Panel/Panel.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Panel/Panel.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
const Panel = ({ title, description, children }) => {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "rounded-lg border border-border bg-card p-5 shadow-sm self-start",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-base font-semibold tracking-tight text-foreground",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 7
			}, this),
			description && /* @__PURE__ */ _jsxDEV("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: description
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4",
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
};
_c = Panel;
export { Panel };
var _c;
$RefreshReg$(_c, "Panel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Panel/Panel.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Panel/Panel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Panel/Panel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Panel/Panel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFNQSxNQUFNLFNBQVMsRUFBRSxPQUFPLGFBQWEsZUFBMkI7Q0FDOUQsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1g7R0FDQzs7Ozs7R0FDSCxlQUNDLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXNDO0dBQWU7Ozs7O0dBRXBFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQVE7R0FBYzs7Ozs7RUFDOUI7Ozs7OztBQUViOztBQUVBLFNBQVMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUGFuZWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImludGVyZmFjZSBQYW5lbFByb3BzIHtcbiAgdGl0bGU6IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59XG5cbmNvbnN0IFBhbmVsID0gKHsgdGl0bGUsIGRlc2NyaXB0aW9uLCBjaGlsZHJlbiB9OiBQYW5lbFByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1jYXJkIHAtNSBzaGFkb3ctc20gc2VsZi1zdGFydFwiPlxuICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICB7dGl0bGV9XG4gICAgICA8L2gyPlxuICAgICAge2Rlc2NyaXB0aW9uICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntkZXNjcmlwdGlvbn08L3A+XG4gICAgICApfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+e2NoaWxkcmVufTwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG5cbmV4cG9ydCB7IFBhbmVsIH07XG4iXX0=