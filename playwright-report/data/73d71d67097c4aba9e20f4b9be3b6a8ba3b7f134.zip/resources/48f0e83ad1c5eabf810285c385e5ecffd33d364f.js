export { Panel } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Panel/Panel.tsx";

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBQYW5lbCB9IGZyb20gXCIuL1BhbmVsXCI7XG4iXX0=