import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=f71da48c";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=f71da48c";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=f71da48c";
//#region ../../node_modules/@tanstack/query-core/build/modern/subscribable.js
var Subscribable = class {
	constructor() {
		this.listeners = /* @__PURE__ */ new Set();
		this.subscribe = this.subscribe.bind(this);
	}
	subscribe(listener) {
		this.listeners.add(listener);
		this.onSubscribe();
		return () => {
			this.listeners.delete(listener);
			this.onUnsubscribe();
		};
	}
	hasListeners() {
		return this.listeners.size > 0;
	}
	onSubscribe() {}
	onUnsubscribe() {}
};
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/focusManager.js
var FocusManager = class extends Subscribable {
	#focused;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onFocus) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const listener = () => onFocus();
				window.addEventListener("visibilitychange", listener, false);
				return () => {
					window.removeEventListener("visibilitychange", listener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup((focused) => {
			if (typeof focused === "boolean") this.setFocused(focused);
			else this.onFocus();
		});
	}
	setFocused(focused) {
		if (this.#focused !== focused) {
			this.#focused = focused;
			this.onFocus();
		}
	}
	onFocus() {
		const isFocused = this.isFocused();
		this.listeners.forEach((listener) => {
			listener(isFocused);
		});
	}
	isFocused() {
		if (typeof this.#focused === "boolean") return this.#focused;
		return globalThis.document?.visibilityState !== "hidden";
	}
};
var focusManager = new FocusManager();
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/timeoutManager.js
var defaultTimeoutProvider = {
	setTimeout: (callback, delay) => setTimeout(callback, delay),
	clearTimeout: (timeoutId) => clearTimeout(timeoutId),
	setInterval: (callback, delay) => setInterval(callback, delay),
	clearInterval: (intervalId) => clearInterval(intervalId)
};
var TimeoutManager = class {
	#provider = defaultTimeoutProvider;
	#providerCalled = false;
	setTimeoutProvider(provider) {
		if (this.#providerCalled && provider !== this.#provider) console.error(`[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`, {
			previous: this.#provider,
			provider
		});
		this.#provider = provider;
		this.#providerCalled = false;
	}
	setTimeout(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setTimeout(callback, delay);
	}
	clearTimeout(timeoutId) {
		this.#provider.clearTimeout(timeoutId);
	}
	setInterval(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setInterval(callback, delay);
	}
	clearInterval(intervalId) {
		this.#provider.clearInterval(intervalId);
	}
};
var timeoutManager = new TimeoutManager();
function systemSetTimeoutZero(callback) {
	setTimeout(callback, 0);
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/utils.js
var isServer = typeof window === "undefined" || "Deno" in globalThis;
function noop() {}
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
function isValidTimeout(value) {
	return typeof value === "number" && value >= 0 && value !== Infinity;
}
function timeUntilStale(updatedAt, staleTime) {
	return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
function resolveStaleTime(staleTime, query) {
	return typeof staleTime === "function" ? staleTime(query) : staleTime;
}
function resolveQueryBoolean(option, query) {
	return typeof option === "function" ? option(query) : option;
}
function matchQuery(filters, query) {
	const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
	if (queryKey) {
		if (exact) {
			if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
		} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
	}
	if (type !== "all") {
		const isActive = query.isActive();
		if (type === "active" && !isActive) return false;
		if (type === "inactive" && isActive) return false;
	}
	if (typeof stale === "boolean" && query.isStale() !== stale) return false;
	if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
	if (predicate && !predicate(query)) return false;
	return true;
}
function matchMutation(filters, mutation) {
	const { exact, status, predicate, mutationKey } = filters;
	if (mutationKey) {
		if (!mutation.options.mutationKey) return false;
		if (exact) {
			if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
		} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
	}
	if (status && mutation.state.status !== status) return false;
	if (predicate && !predicate(mutation)) return false;
	return true;
}
function hashQueryKeyByOptions(queryKey, options) {
	return (options?.queryKeyHashFn || hashKey)(queryKey);
}
function hashKey(queryKey) {
	return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
		result[key] = val[key];
		return result;
	}, {}) : val);
}
function partialMatchKey(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (a && b && typeof a === "object" && typeof b === "object") {
		if (Array.isArray(a) && Array.isArray(b)) {
			for (let i = 0; i < b.length; i++) if (!partialMatchKey(a[i], b[i])) return false;
			return true;
		}
		const bKeys = Object.keys(b);
		for (const key of bKeys) if (!partialMatchKey(a[key], b[key])) return false;
		return true;
	}
	return false;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b, depth = 0) {
	if (a === b) return a;
	if (depth > 500) return b;
	const array = isPlainArray(a) && isPlainArray(b);
	if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
	const aSize = (array ? a : Object.keys(a)).length;
	const bItems = array ? b : Object.keys(b);
	const bSize = bItems.length;
	const copy = array ? new Array(bSize) : {};
	let equalItems = 0;
	for (let i = 0; i < bSize; i++) {
		const key = array ? i : bItems[i];
		const aItem = a[key];
		const bItem = b[key];
		if (aItem === bItem) {
			copy[key] = aItem;
			if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
			continue;
		}
		if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
			copy[key] = bItem;
			continue;
		}
		const v = replaceEqualDeep(aItem, bItem, depth + 1);
		copy[key] = v;
		if (v === aItem) equalItems++;
	}
	return aSize === bSize && equalItems === aSize ? a : copy;
}
function shallowEqualObjects(a, b) {
	if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
	for (const key in a) if (a[key] !== b[key]) return false;
	return true;
}
function isPlainArray(value) {
	return Array.isArray(value) && value.length === Object.keys(value).length;
}
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const ctor = o.constructor;
	if (ctor === void 0) return true;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot)) return false;
	if (!prot.hasOwnProperty("isPrototypeOf")) return false;
	if (Object.getPrototypeOf(o) !== Object.prototype) return false;
	return true;
}
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
function sleep(timeout) {
	return new Promise((resolve) => {
		timeoutManager.setTimeout(resolve, timeout);
	});
}
function replaceData(prevData, data, options) {
	if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
	else if (options.structuralSharing !== false) try {
		return replaceEqualDeep(prevData, data);
	} catch (error) {
		console.error(`Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options.queryHash}]: ${error}`);
		throw error;
	}
	return data;
}
function keepPreviousData(previousData) {
	return previousData;
}
function addToEnd(items, item, max = 0) {
	const newItems = [...items, item];
	return max && newItems.length > max ? newItems.slice(1) : newItems;
}
function addToStart(items, item, max = 0) {
	const newItems = [item, ...items];
	return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
}
var skipToken = /* @__PURE__ */ Symbol();
function ensureQueryFn(options, fetchOptions) {
	if (options.queryFn === skipToken) console.error(`Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '${options.queryHash}'`);
	if (!options.queryFn && fetchOptions?.initialPromise) return () => fetchOptions.initialPromise;
	if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
	return options.queryFn;
}
function shouldThrowError(throwOnError, params) {
	if (typeof throwOnError === "function") return throwOnError(...params);
	return !!throwOnError;
}
function addConsumeAwareSignal(object, getSignal, onCancelled) {
	let consumed = false;
	let signal;
	Object.defineProperty(object, "signal", {
		enumerable: true,
		get: () => {
			signal ??= getSignal();
			if (consumed) return signal;
			consumed = true;
			if (signal.aborted) onCancelled();
			else signal.addEventListener("abort", onCancelled, { once: true });
			return signal;
		}
	});
	return object;
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/environmentManager.js
var environmentManager = /* @__PURE__ */ (() => {
	let isServerFn = () => isServer;
	return {
		/**
		* Returns whether the current runtime should be treated as a server environment.
		*/
		isServer() {
			return isServerFn();
		},
		/**
		* Overrides the server check globally.
		*/
		setIsServer(isServerValue) {
			isServerFn = isServerValue;
		}
	};
})();
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/thenable.js
function pendingThenable() {
	let resolve;
	let reject;
	const thenable = new Promise((_resolve, _reject) => {
		resolve = _resolve;
		reject = _reject;
	});
	thenable.status = "pending";
	thenable.catch(() => {});
	function finalize(data) {
		Object.assign(thenable, data);
		delete thenable.resolve;
		delete thenable.reject;
	}
	thenable.resolve = (value) => {
		finalize({
			status: "fulfilled",
			value
		});
		resolve(value);
	};
	thenable.reject = (reason) => {
		finalize({
			status: "rejected",
			reason
		});
		reject(reason);
	};
	return thenable;
}
function tryResolveSync(promise) {
	let data;
	promise.then((result) => {
		data = result;
		return result;
	}, noop)?.catch(noop);
	if (data !== void 0) return { data };
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/hydration.js
function defaultTransformerFn(data) {
	return data;
}
function dehydrateMutation(mutation) {
	return {
		mutationKey: mutation.options.mutationKey,
		state: mutation.state,
		...mutation.options.scope && { scope: mutation.options.scope },
		...mutation.meta && { meta: mutation.meta }
	};
}
function dehydrateQuery(query, serializeData, shouldRedactErrors) {
	const dehydratePromise = () => {
		const promise = query.promise?.then(serializeData).catch((error) => {
			if (!shouldRedactErrors(error)) return Promise.reject(error);
			console.error(`A query that was dehydrated as pending ended up rejecting. [${query.queryHash}]: ${error}; The error will be redacted in production builds`);
			return Promise.reject(/* @__PURE__ */ new Error("redacted"));
		});
		promise?.catch(noop);
		return promise;
	};
	return {
		dehydratedAt: Date.now(),
		state: {
			...query.state,
			...query.state.data !== void 0 && { data: serializeData(query.state.data) }
		},
		queryKey: query.queryKey,
		queryHash: query.queryHash,
		...query.state.status === "pending" && { promise: dehydratePromise() },
		...query.meta && { meta: query.meta },
		...query.queryType && { queryType: query.queryType }
	};
}
function defaultShouldDehydrateMutation(mutation) {
	return mutation.state.isPaused;
}
function defaultShouldDehydrateQuery(query) {
	return query.state.status === "success";
}
function defaultShouldRedactErrors(_) {
	return true;
}
function dehydrate(client, options = {}) {
	const filterMutation = options.shouldDehydrateMutation ?? client.getDefaultOptions().dehydrate?.shouldDehydrateMutation ?? defaultShouldDehydrateMutation;
	const mutations = client.getMutationCache().getAll().flatMap((mutation) => filterMutation(mutation) ? [dehydrateMutation(mutation)] : []);
	const filterQuery = options.shouldDehydrateQuery ?? client.getDefaultOptions().dehydrate?.shouldDehydrateQuery ?? defaultShouldDehydrateQuery;
	const shouldRedactErrors = options.shouldRedactErrors ?? client.getDefaultOptions().dehydrate?.shouldRedactErrors ?? defaultShouldRedactErrors;
	const serializeData = options.serializeData ?? client.getDefaultOptions().dehydrate?.serializeData ?? defaultTransformerFn;
	return {
		mutations,
		queries: client.getQueryCache().getAll().flatMap((query) => filterQuery(query) ? [dehydrateQuery(query, serializeData, shouldRedactErrors)] : [])
	};
}
function hydrate(client, dehydratedState, options) {
	if (typeof dehydratedState !== "object" || dehydratedState === null) return;
	const mutationCache = client.getMutationCache();
	const queryCache = client.getQueryCache();
	const deserializeData = options?.defaultOptions?.deserializeData ?? client.getDefaultOptions().hydrate?.deserializeData ?? defaultTransformerFn;
	const mutations = dehydratedState.mutations || [];
	const queries = dehydratedState.queries || [];
	mutations.forEach(({ state, ...mutationOptions }) => {
		mutationCache.build(client, {
			...client.getDefaultOptions().hydrate?.mutations,
			...options?.defaultOptions?.mutations,
			...mutationOptions
		}, state);
	});
	queries.forEach(({ queryKey, state, queryHash, meta, promise, dehydratedAt, queryType }) => {
		const syncData = promise ? tryResolveSync(promise) : void 0;
		const rawData = state.data === void 0 ? syncData?.data : state.data;
		const data = rawData === void 0 ? rawData : deserializeData(rawData);
		let query = queryCache.get(queryHash);
		const existingQueryIsPending = query?.state.status === "pending";
		const existingQueryIsFetching = query?.state.fetchStatus === "fetching";
		if (query) {
			const hasNewerSyncData = syncData && dehydratedAt !== void 0 && dehydratedAt > query.state.dataUpdatedAt;
			if (state.dataUpdatedAt > query.state.dataUpdatedAt || hasNewerSyncData) {
				const { fetchStatus: _ignored, ...serializedState } = state;
				query.setState({
					...serializedState,
					data,
					...state.status === "pending" && data !== void 0 && {
						status: "success",
						dataUpdatedAt: dehydratedAt ?? Date.now(),
						...!existingQueryIsFetching && { fetchStatus: "idle" }
					}
				});
			}
		} else query = queryCache.build(client, {
			...client.getDefaultOptions().hydrate?.queries,
			...options?.defaultOptions?.queries,
			queryKey,
			queryHash,
			meta,
			_type: queryType
		}, {
			...state,
			data,
			fetchStatus: "idle",
			status: state.status === "pending" && data !== void 0 ? "success" : state.status,
			...state.status === "pending" && data !== void 0 && { dataUpdatedAt: dehydratedAt ?? Date.now() }
		});
		if (promise && !syncData && !existingQueryIsPending && !existingQueryIsFetching && (dehydratedAt === void 0 || dehydratedAt > query.state.dataUpdatedAt)) query.fetch(void 0, { initialPromise: Promise.resolve(promise).then(deserializeData) }).catch(noop);
	});
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/notifyManager.js
var defaultScheduler = systemSetTimeoutZero;
function createNotifyManager() {
	let queue = [];
	let transactions = 0;
	let notifyFn = (callback) => {
		callback();
	};
	let batchNotifyFn = (callback) => {
		callback();
	};
	let scheduleFn = defaultScheduler;
	const schedule = (callback) => {
		if (transactions) queue.push(callback);
		else scheduleFn(() => {
			notifyFn(callback);
		});
	};
	const flush = () => {
		const originalQueue = queue;
		queue = [];
		if (originalQueue.length) scheduleFn(() => {
			batchNotifyFn(() => {
				originalQueue.forEach((callback) => {
					notifyFn(callback);
				});
			});
		});
	};
	return {
		batch: (callback) => {
			let result;
			transactions++;
			try {
				result = callback();
			} finally {
				transactions--;
				if (!transactions) flush();
			}
			return result;
		},
		/**
		* All calls to the wrapped function will be batched.
		*/
		batchCalls: (callback) => {
			return (...args) => {
				schedule(() => {
					callback(...args);
				});
			};
		},
		schedule,
		/**
		* Use this method to set a custom notify function.
		* This can be used to for example wrap notifications with `React.act` while running tests.
		*/
		setNotifyFunction: (fn) => {
			notifyFn = fn;
		},
		/**
		* Use this method to set a custom function to batch notifications together into a single tick.
		* By default React Query will use the batch function provided by ReactDOM or React Native.
		*/
		setBatchNotifyFunction: (fn) => {
			batchNotifyFn = fn;
		},
		setScheduler: (fn) => {
			scheduleFn = fn;
		}
	};
}
var notifyManager = createNotifyManager();
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/onlineManager.js
var OnlineManager = class extends Subscribable {
	#online = true;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onOnline) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const onlineListener = () => onOnline(true);
				const offlineListener = () => onOnline(false);
				window.addEventListener("online", onlineListener, false);
				window.addEventListener("offline", offlineListener, false);
				return () => {
					window.removeEventListener("online", onlineListener);
					window.removeEventListener("offline", offlineListener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup(this.setOnline.bind(this));
	}
	setOnline(online) {
		if (this.#online !== online) {
			this.#online = online;
			this.listeners.forEach((listener) => {
				listener(online);
			});
		}
	}
	isOnline() {
		return this.#online;
	}
};
var onlineManager = new OnlineManager();
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/retryer.js
function defaultRetryDelay(failureCount) {
	return Math.min(1e3 * 2 ** failureCount, 3e4);
}
function canFetch(networkMode) {
	return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
}
var CancelledError = class extends Error {
	constructor(options) {
		super("CancelledError");
		this.revert = options?.revert;
		this.silent = options?.silent;
	}
};
function isCancelledError(value) {
	return value instanceof CancelledError;
}
function createRetryer(config) {
	let isRetryCancelled = false;
	let failureCount = 0;
	let continueFn;
	const thenable = pendingThenable();
	const isResolved = () => thenable.status !== "pending";
	const cancel = (cancelOptions) => {
		if (!isResolved()) {
			const error = new CancelledError(cancelOptions);
			reject(error);
			config.onCancel?.(error);
		}
	};
	const cancelRetry = () => {
		isRetryCancelled = true;
	};
	const continueRetry = () => {
		isRetryCancelled = false;
	};
	const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
	const canStart = () => canFetch(config.networkMode) && config.canRun();
	const resolve = (value) => {
		if (!isResolved()) {
			continueFn?.();
			thenable.resolve(value);
		}
	};
	const reject = (value) => {
		if (!isResolved()) {
			continueFn?.();
			thenable.reject(value);
		}
	};
	const pause = () => {
		return new Promise((continueResolve) => {
			continueFn = (value) => {
				if (isResolved() || canContinue()) continueResolve(value);
			};
			config.onPause?.();
		}).then(() => {
			continueFn = void 0;
			if (!isResolved()) config.onContinue?.();
		});
	};
	const run = () => {
		if (isResolved()) return;
		let promiseOrValue;
		const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
		try {
			promiseOrValue = initialPromise ?? config.fn();
		} catch (error) {
			promiseOrValue = Promise.reject(error);
		}
		Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
			if (isResolved()) return;
			const retry = config.retry ?? (environmentManager.isServer() ? 0 : 3);
			const retryDelay = config.retryDelay ?? defaultRetryDelay;
			const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
			const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
			if (isRetryCancelled || !shouldRetry) {
				reject(error);
				return;
			}
			failureCount++;
			config.onFail?.(failureCount, error);
			sleep(delay).then(() => {
				return canContinue() ? void 0 : pause();
			}).then(() => {
				if (isRetryCancelled) reject(error);
				else run();
			});
		});
	};
	return {
		promise: thenable,
		status: () => thenable.status,
		cancel,
		continue: () => {
			continueFn?.();
			return thenable;
		},
		cancelRetry,
		continueRetry,
		canStart,
		start: () => {
			if (canStart()) run();
			else pause().then(run);
			return thenable;
		}
	};
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/removable.js
var Removable = class {
	#gcTimeout;
	destroy() {
		this.clearGcTimeout();
	}
	scheduleGc() {
		this.clearGcTimeout();
		if (isValidTimeout(this.gcTime)) this.#gcTimeout = timeoutManager.setTimeout(() => {
			this.optionalRemove();
		}, this.gcTime);
	}
	updateGcTime(newGcTime) {
		this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (environmentManager.isServer() ? Infinity : 3e5));
	}
	clearGcTimeout() {
		if (this.#gcTimeout !== void 0) {
			timeoutManager.clearTimeout(this.#gcTimeout);
			this.#gcTimeout = void 0;
		}
	}
};
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
function infiniteQueryBehavior(pages) {
	return { onFetch: (context, query) => {
		const options = context.options;
		const direction = context.fetchOptions?.meta?.fetchMore?.direction;
		const oldPages = context.state.data?.pages || [];
		const oldPageParams = context.state.data?.pageParams || [];
		let result = {
			pages: [],
			pageParams: []
		};
		let currentPage = 0;
		const fetchFn = async () => {
			let cancelled = false;
			const addSignalProperty = (object) => {
				addConsumeAwareSignal(object, () => context.signal, () => cancelled = true);
			};
			const queryFn = ensureQueryFn(context.options, context.fetchOptions);
			const fetchPage = async (data, param, previous) => {
				if (cancelled) return Promise.reject(context.signal.reason);
				if (param == null && data.pages.length) return Promise.resolve(data);
				const createQueryFnContext = () => {
					const queryFnContext2 = {
						client: context.client,
						queryKey: context.queryKey,
						pageParam: param,
						direction: previous ? "backward" : "forward",
						meta: context.options.meta
					};
					addSignalProperty(queryFnContext2);
					return queryFnContext2;
				};
				const queryFnContext = createQueryFnContext();
				const page = await queryFn(queryFnContext);
				const { maxPages } = context.options;
				const addTo = previous ? addToStart : addToEnd;
				return {
					pages: addTo(data.pages, page, maxPages),
					pageParams: addTo(data.pageParams, param, maxPages)
				};
			};
			if (direction && oldPages.length) {
				const previous = direction === "backward";
				const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
				const oldData = {
					pages: oldPages,
					pageParams: oldPageParams
				};
				result = await fetchPage(oldData, pageParamFn(options, oldData), previous);
			} else {
				const remainingPages = pages ?? oldPages.length;
				do {
					const param = currentPage === 0 ? oldPageParams[0] ?? options.initialPageParam : getNextPageParam(options, result);
					if (currentPage > 0 && param == null) break;
					result = await fetchPage(result, param);
					currentPage++;
				} while (currentPage < remainingPages);
			}
			return result;
		};
		if (context.options.persister) context.fetchFn = () => {
			return context.options.persister?.(fetchFn, {
				client: context.client,
				queryKey: context.queryKey,
				meta: context.options.meta,
				signal: context.signal
			}, query);
		};
		else context.fetchFn = fetchFn;
	} };
}
function getNextPageParam(options, { pages, pageParams }) {
	const lastIndex = pages.length - 1;
	return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
}
function getPreviousPageParam(options, { pages, pageParams }) {
	return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
}
function hasNextPage(options, data) {
	if (!data) return false;
	return getNextPageParam(options, data) != null;
}
function hasPreviousPage(options, data) {
	if (!data || !options.getPreviousPageParam) return false;
	return getPreviousPageParam(options, data) != null;
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/query.js
var Query = class extends Removable {
	#queryType;
	#initialState;
	#revertState;
	#cache;
	#client;
	#retryer;
	#defaultOptions;
	#abortSignalConsumed;
	constructor(config) {
		super();
		this.#abortSignalConsumed = false;
		this.#defaultOptions = config.defaultOptions;
		this.setOptions(config.options);
		this.observers = [];
		this.#client = config.client;
		this.#cache = this.#client.getQueryCache();
		this.queryKey = config.queryKey;
		this.queryHash = config.queryHash;
		this.#initialState = getDefaultState$1(this.options);
		this.state = config.state ?? this.#initialState;
		this.scheduleGc();
	}
	get meta() {
		return this.options.meta;
	}
	get queryType() {
		return this.#queryType;
	}
	get promise() {
		return this.#retryer?.promise;
	}
	setOptions(options) {
		this.options = {
			...this.#defaultOptions,
			...options
		};
		if (options?._type) this.#queryType = options._type;
		this.updateGcTime(this.options.gcTime);
		if (this.state && this.state.data === void 0) {
			const defaultState = getDefaultState$1(this.options);
			if (defaultState.data !== void 0) {
				this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
				this.#initialState = defaultState;
			}
		}
	}
	optionalRemove() {
		if (!this.observers.length && this.state.fetchStatus === "idle") this.#cache.remove(this);
	}
	setData(newData, options) {
		const data = replaceData(this.state.data, newData, this.options);
		this.#dispatch({
			data,
			type: "success",
			dataUpdatedAt: options?.updatedAt,
			manual: options?.manual
		});
		return data;
	}
	setState(state) {
		this.#dispatch({
			type: "setState",
			state
		});
	}
	cancel(options) {
		const promise = this.#retryer?.promise;
		this.#retryer?.cancel(options);
		return promise ? promise.then(noop).catch(noop) : Promise.resolve();
	}
	destroy() {
		super.destroy();
		this.cancel({ silent: true });
	}
	get resetState() {
		return this.#initialState;
	}
	reset() {
		this.destroy();
		this.setState(this.resetState);
	}
	isActive() {
		return this.observers.some((observer) => resolveQueryBoolean(observer.options.enabled, this) !== false);
	}
	isDisabled() {
		if (this.getObserversCount() > 0) return !this.isActive();
		return this.options.queryFn === skipToken || !this.isFetched();
	}
	isFetched() {
		return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
	}
	isStatic() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveStaleTime(observer.options.staleTime, this) === "static");
		return false;
	}
	isStale() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
		return this.state.data === void 0 || this.state.isInvalidated;
	}
	isStaleByTime(staleTime = 0) {
		if (this.state.data === void 0) return true;
		if (staleTime === "static") return false;
		if (this.state.isInvalidated) return true;
		return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
	}
	onFocus() {
		this.observers.find((x) => x.shouldFetchOnWindowFocus())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	onOnline() {
		this.observers.find((x) => x.shouldFetchOnReconnect())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	addObserver(observer) {
		if (!this.observers.includes(observer)) {
			this.observers.push(observer);
			this.clearGcTimeout();
			this.#cache.notify({
				type: "observerAdded",
				query: this,
				observer
			});
		}
	}
	removeObserver(observer) {
		if (this.observers.includes(observer)) {
			this.observers = this.observers.filter((x) => x !== observer);
			if (!this.observers.length) {
				if (this.#retryer) if (this.#abortSignalConsumed || this.#isInitialPausedFetch()) this.#retryer.cancel({ revert: true });
				else this.#retryer.cancelRetry();
				this.scheduleGc();
			}
			this.#cache.notify({
				type: "observerRemoved",
				query: this,
				observer
			});
		}
	}
	getObserversCount() {
		return this.observers.length;
	}
	#isInitialPausedFetch() {
		return this.state.fetchStatus === "paused" && this.state.status === "pending";
	}
	invalidate() {
		if (!this.state.isInvalidated) this.#dispatch({ type: "invalidate" });
	}
	async fetch(options, fetchOptions) {
		if (this.state.fetchStatus !== "idle" && this.#retryer?.status() !== "rejected") {
			if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) this.cancel({ silent: true });
			else if (this.#retryer) {
				this.#retryer.continueRetry();
				return this.#retryer.promise;
			}
		}
		if (options) this.setOptions(options);
		if (!this.options.queryFn) {
			const observer = this.observers.find((x) => x.options.queryFn);
			if (observer) this.setOptions(observer.options);
		}
		if (!Array.isArray(this.options.queryKey)) console.error(`As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']`);
		const abortController = new AbortController();
		const addSignalProperty = (object) => {
			Object.defineProperty(object, "signal", {
				enumerable: true,
				get: () => {
					this.#abortSignalConsumed = true;
					return abortController.signal;
				}
			});
		};
		const fetchFn = () => {
			const queryFn = ensureQueryFn(this.options, fetchOptions);
			const createQueryFnContext = () => {
				const queryFnContext2 = {
					client: this.#client,
					queryKey: this.queryKey,
					meta: this.meta
				};
				addSignalProperty(queryFnContext2);
				return queryFnContext2;
			};
			const queryFnContext = createQueryFnContext();
			this.#abortSignalConsumed = false;
			if (this.options.persister) return this.options.persister(queryFn, queryFnContext, this);
			return queryFn(queryFnContext);
		};
		const createFetchContext = () => {
			const context2 = {
				fetchOptions,
				options: this.options,
				queryKey: this.queryKey,
				client: this.#client,
				state: this.state,
				fetchFn
			};
			addSignalProperty(context2);
			return context2;
		};
		const context = createFetchContext();
		(this.#queryType === "infinite" ? infiniteQueryBehavior(this.options.pages) : this.options.behavior)?.onFetch(context, this);
		this.#revertState = this.state;
		if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) this.#dispatch({
			type: "fetch",
			meta: context.fetchOptions?.meta
		});
		this.#retryer = createRetryer({
			initialPromise: fetchOptions?.initialPromise,
			fn: context.fetchFn,
			onCancel: (error) => {
				if (error instanceof CancelledError && error.revert) this.setState({
					...this.#revertState,
					fetchStatus: "idle"
				});
				abortController.abort();
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue: () => {
				this.#dispatch({ type: "continue" });
			},
			retry: context.options.retry,
			retryDelay: context.options.retryDelay,
			networkMode: context.options.networkMode,
			canRun: () => true
		});
		try {
			const data = await this.#retryer.start();
			if (data === void 0) {
				console.error(`Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ${this.queryHash}`);
				throw new Error(`${this.queryHash} data is undefined`);
			}
			this.setData(data);
			this.#cache.config.onSuccess?.(data, this);
			this.#cache.config.onSettled?.(data, this.state.error, this);
			return data;
		} catch (error) {
			if (error instanceof CancelledError) {
				if (error.silent) return this.#retryer.promise;
				else if (error.revert) {
					if (this.state.data === void 0) throw error;
					return this.state.data;
				}
			}
			this.#dispatch({
				type: "error",
				error
			});
			this.#cache.config.onError?.(error, this);
			this.#cache.config.onSettled?.(this.state.data, error, this);
			throw error;
		} finally {
			this.scheduleGc();
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					fetchFailureCount: action.failureCount,
					fetchFailureReason: action.error
				};
				case "pause": return {
					...state,
					fetchStatus: "paused"
				};
				case "continue": return {
					...state,
					fetchStatus: "fetching"
				};
				case "fetch": return {
					...state,
					...fetchState(state.data, this.options),
					fetchMeta: action.meta ?? null
				};
				case "success":
					const newState = {
						...state,
						...successState(action.data, action.dataUpdatedAt),
						dataUpdateCount: state.dataUpdateCount + 1,
						...!action.manual && {
							fetchStatus: "idle",
							fetchFailureCount: 0,
							fetchFailureReason: null
						}
					};
					this.#revertState = action.manual ? newState : void 0;
					return newState;
				case "error":
					const error = action.error;
					return {
						...state,
						error,
						errorUpdateCount: state.errorUpdateCount + 1,
						errorUpdatedAt: Date.now(),
						fetchFailureCount: state.fetchFailureCount + 1,
						fetchFailureReason: error,
						fetchStatus: "idle",
						status: "error",
						isInvalidated: true
					};
				case "invalidate": return {
					...state,
					isInvalidated: true
				};
				case "setState": return {
					...state,
					...action.state
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.observers.forEach((observer) => {
				observer.onQueryUpdate();
			});
			this.#cache.notify({
				query: this,
				type: "updated",
				action
			});
		});
	}
};
function fetchState(data, options) {
	return {
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
		...data === void 0 && {
			error: null,
			status: "pending"
		}
	};
}
function successState(data, dataUpdatedAt) {
	return {
		data,
		dataUpdatedAt: dataUpdatedAt ?? Date.now(),
		error: null,
		isInvalidated: false,
		status: "success"
	};
}
function getDefaultState$1(options) {
	const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
	const hasData = data !== void 0;
	const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
	return {
		data,
		dataUpdateCount: 0,
		dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
		error: null,
		errorUpdateCount: 0,
		errorUpdatedAt: 0,
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchMeta: null,
		isInvalidated: false,
		status: hasData ? "success" : "pending",
		fetchStatus: "idle"
	};
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/queryObserver.js
var QueryObserver = class extends Subscribable {
	constructor(client, options) {
		super();
		this.options = options;
		this.#client = client;
		this.#selectError = null;
		this.#currentThenable = pendingThenable();
		this.bindMethods();
		this.setOptions(options);
	}
	#client;
	#currentQuery = void 0;
	#currentQueryInitialState = void 0;
	#currentResult = void 0;
	#currentResultState;
	#currentResultOptions;
	#currentThenable;
	#selectError;
	#selectFn;
	#selectResult;
	#lastQueryWithDefinedData;
	#staleTimeoutId;
	#refetchIntervalId;
	#currentRefetchInterval;
	#trackedProps = /* @__PURE__ */ new Set();
	bindMethods() {
		this.refetch = this.refetch.bind(this);
	}
	onSubscribe() {
		if (this.listeners.size === 1) {
			this.#currentQuery.addObserver(this);
			if (shouldFetchOnMount(this.#currentQuery, this.options)) this.#executeFetch();
			else this.updateResult();
			this.#updateTimers();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.destroy();
	}
	shouldFetchOnReconnect() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnReconnect);
	}
	shouldFetchOnWindowFocus() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnWindowFocus);
	}
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#clearStaleTimeout();
		this.#clearRefetchInterval();
		this.#currentQuery.removeObserver(this);
	}
	setOptions(options) {
		const prevOptions = this.options;
		const prevQuery = this.#currentQuery;
		this.options = this.#client.defaultQueryOptions(options);
		if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryBoolean(this.options.enabled, this.#currentQuery) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
		this.#updateQuery();
		this.#currentQuery.setOptions(this.options);
		if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) this.#client.getQueryCache().notify({
			type: "observerOptionsUpdated",
			query: this.#currentQuery,
			observer: this
		});
		const mounted = this.hasListeners();
		if (mounted && shouldFetchOptionally(this.#currentQuery, prevQuery, this.options, prevOptions)) this.#executeFetch();
		this.updateResult();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryBoolean(this.options.enabled, this.#currentQuery) !== resolveQueryBoolean(prevOptions.enabled, this.#currentQuery) || resolveStaleTime(this.options.staleTime, this.#currentQuery) !== resolveStaleTime(prevOptions.staleTime, this.#currentQuery))) this.#updateStaleTimeout();
		const nextRefetchInterval = this.#computeRefetchInterval();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryBoolean(this.options.enabled, this.#currentQuery) !== resolveQueryBoolean(prevOptions.enabled, this.#currentQuery) || nextRefetchInterval !== this.#currentRefetchInterval)) this.#updateRefetchInterval(nextRefetchInterval);
	}
	getOptimisticResult(options) {
		const query = this.#client.getQueryCache().build(this.#client, options);
		const result = this.createResult(query, options);
		if (shouldAssignObserverCurrentProperties(this, result)) {
			this.#currentResult = result;
			this.#currentResultOptions = this.options;
			this.#currentResultState = this.#currentQuery.state;
		}
		return result;
	}
	getCurrentResult() {
		return this.#currentResult;
	}
	trackResult(result, onPropTracked) {
		return new Proxy(result, { get: (target, key) => {
			this.trackProp(key);
			onPropTracked?.(key);
			if (key === "promise") {
				this.trackProp("data");
				if (!this.options.experimental_prefetchInRender && this.#currentThenable.status === "pending") this.#currentThenable.reject(/* @__PURE__ */ new Error("experimental_prefetchInRender feature flag is not enabled"));
			}
			return Reflect.get(target, key);
		} });
	}
	trackProp(key) {
		this.#trackedProps.add(key);
	}
	getCurrentQuery() {
		return this.#currentQuery;
	}
	refetch({ ...options } = {}) {
		return this.fetch({ ...options });
	}
	fetchOptimistic(options) {
		const defaultedOptions = this.#client.defaultQueryOptions(options);
		const query = this.#client.getQueryCache().build(this.#client, defaultedOptions);
		return query.fetch().then(() => this.createResult(query, defaultedOptions));
	}
	fetch(fetchOptions) {
		return this.#executeFetch({
			...fetchOptions,
			cancelRefetch: fetchOptions.cancelRefetch ?? true
		}).then(() => {
			this.updateResult();
			return this.#currentResult;
		});
	}
	#executeFetch(fetchOptions) {
		this.#updateQuery();
		let promise = this.#currentQuery.fetch(this.options, fetchOptions);
		if (!fetchOptions?.throwOnError) promise = promise.catch(noop);
		return promise;
	}
	#updateStaleTimeout() {
		this.#clearStaleTimeout();
		const staleTime = resolveStaleTime(this.options.staleTime, this.#currentQuery);
		if (environmentManager.isServer() || this.#currentResult.isStale || !isValidTimeout(staleTime)) return;
		const timeout = timeUntilStale(this.#currentResult.dataUpdatedAt, staleTime) + 1;
		this.#staleTimeoutId = timeoutManager.setTimeout(() => {
			if (!this.#currentResult.isStale) this.updateResult();
		}, timeout);
	}
	#computeRefetchInterval() {
		return (typeof this.options.refetchInterval === "function" ? this.options.refetchInterval(this.#currentQuery) : this.options.refetchInterval) ?? false;
	}
	#updateRefetchInterval(nextInterval) {
		this.#clearRefetchInterval();
		this.#currentRefetchInterval = nextInterval;
		if (environmentManager.isServer() || resolveQueryBoolean(this.options.enabled, this.#currentQuery) === false || !isValidTimeout(this.#currentRefetchInterval) || this.#currentRefetchInterval === 0) return;
		this.#refetchIntervalId = timeoutManager.setInterval(() => {
			if (this.options.refetchIntervalInBackground || focusManager.isFocused()) this.#executeFetch();
		}, this.#currentRefetchInterval);
	}
	#updateTimers() {
		this.#updateStaleTimeout();
		this.#updateRefetchInterval(this.#computeRefetchInterval());
	}
	#clearStaleTimeout() {
		if (this.#staleTimeoutId !== void 0) {
			timeoutManager.clearTimeout(this.#staleTimeoutId);
			this.#staleTimeoutId = void 0;
		}
	}
	#clearRefetchInterval() {
		if (this.#refetchIntervalId !== void 0) {
			timeoutManager.clearInterval(this.#refetchIntervalId);
			this.#refetchIntervalId = void 0;
		}
	}
	createResult(query, options) {
		const prevQuery = this.#currentQuery;
		const prevOptions = this.options;
		const prevResult = this.#currentResult;
		const prevResultState = this.#currentResultState;
		const prevResultOptions = this.#currentResultOptions;
		const queryInitialState = query !== prevQuery ? query.state : this.#currentQueryInitialState;
		const { state } = query;
		let newState = { ...state };
		let isPlaceholderData = false;
		let data;
		if (options._optimisticResults) {
			const mounted = this.hasListeners();
			const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
			const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
			if (fetchOnMount || fetchOptionally) newState = {
				...newState,
				...fetchState(state.data, query.options)
			};
			if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
		}
		let { error, errorUpdatedAt, status } = newState;
		data = newState.data;
		let skipSelect = false;
		if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
			let placeholderData;
			if (prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData) {
				placeholderData = prevResult.data;
				skipSelect = true;
			} else placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(this.#lastQueryWithDefinedData?.state.data, this.#lastQueryWithDefinedData) : options.placeholderData;
			if (placeholderData !== void 0) {
				status = "success";
				data = replaceData(prevResult?.data, placeholderData, options);
				isPlaceholderData = true;
			}
		}
		if (options.select && data !== void 0 && !skipSelect) if (prevResult && data === prevResultState?.data && options.select === this.#selectFn) data = this.#selectResult;
		else try {
			this.#selectFn = options.select;
			data = options.select(data);
			data = replaceData(prevResult?.data, data, options);
			this.#selectResult = data;
			this.#selectError = null;
		} catch (selectError) {
			this.#selectError = selectError;
		}
		if (this.#selectError) {
			error = this.#selectError;
			data = this.#selectResult;
			errorUpdatedAt = Date.now();
			status = "error";
		}
		const isFetching = newState.fetchStatus === "fetching";
		const isPending = status === "pending";
		const isError = status === "error";
		const isLoading = isPending && isFetching;
		const hasData = data !== void 0;
		const nextResult = {
			status,
			fetchStatus: newState.fetchStatus,
			isPending,
			isSuccess: status === "success",
			isError,
			isInitialLoading: isLoading,
			isLoading,
			data,
			dataUpdatedAt: newState.dataUpdatedAt,
			error,
			errorUpdatedAt,
			failureCount: newState.fetchFailureCount,
			failureReason: newState.fetchFailureReason,
			errorUpdateCount: newState.errorUpdateCount,
			isFetched: query.isFetched(),
			isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
			isFetching,
			isRefetching: isFetching && !isPending,
			isLoadingError: isError && !hasData,
			isPaused: newState.fetchStatus === "paused",
			isPlaceholderData,
			isRefetchError: isError && hasData,
			isStale: isStale(query, options),
			refetch: this.refetch,
			promise: this.#currentThenable,
			isEnabled: resolveQueryBoolean(options.enabled, query) !== false
		};
		if (this.options.experimental_prefetchInRender) {
			const hasResultData = nextResult.data !== void 0;
			const isErrorWithoutData = nextResult.status === "error" && !hasResultData;
			const finalizeThenableIfPossible = (thenable) => {
				if (isErrorWithoutData) thenable.reject(nextResult.error);
				else if (hasResultData) thenable.resolve(nextResult.data);
			};
			const recreateThenable = () => {
				const pending = this.#currentThenable = nextResult.promise = pendingThenable();
				finalizeThenableIfPossible(pending);
			};
			const prevThenable = this.#currentThenable;
			switch (prevThenable.status) {
				case "pending":
					if (query.queryHash === prevQuery.queryHash) finalizeThenableIfPossible(prevThenable);
					break;
				case "fulfilled":
					if (isErrorWithoutData || nextResult.data !== prevThenable.value) recreateThenable();
					break;
				case "rejected": if (!isErrorWithoutData || nextResult.error !== prevThenable.reason) recreateThenable();
			}
		}
		return nextResult;
	}
	updateResult() {
		const prevResult = this.#currentResult;
		const nextResult = this.createResult(this.#currentQuery, this.options);
		this.#currentResultState = this.#currentQuery.state;
		this.#currentResultOptions = this.options;
		if (this.#currentResultState.data !== void 0) this.#lastQueryWithDefinedData = this.#currentQuery;
		if (shallowEqualObjects(nextResult, prevResult)) return;
		this.#currentResult = nextResult;
		const shouldNotifyListeners = () => {
			if (!prevResult) return true;
			const { notifyOnChangeProps } = this.options;
			const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
			if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !this.#trackedProps.size) return true;
			const includedProps = new Set(notifyOnChangePropsValue ?? this.#trackedProps);
			if (this.options.throwOnError) includedProps.add("error");
			return Object.keys(this.#currentResult).some((key) => {
				const typedKey = key;
				return this.#currentResult[typedKey] !== prevResult[typedKey] && includedProps.has(typedKey);
			});
		};
		this.#notify({ listeners: shouldNotifyListeners() });
	}
	#updateQuery() {
		const query = this.#client.getQueryCache().build(this.#client, this.options);
		if (query === this.#currentQuery) return;
		const prevQuery = this.#currentQuery;
		this.#currentQuery = query;
		this.#currentQueryInitialState = query.state;
		if (this.hasListeners()) {
			prevQuery?.removeObserver(this);
			query.addObserver(this);
		}
	}
	onQueryUpdate() {
		this.updateResult();
		if (this.hasListeners()) this.#updateTimers();
	}
	#notify(notifyOptions) {
		notifyManager.batch(() => {
			if (notifyOptions.listeners) this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
			this.#client.getQueryCache().notify({
				query: this.#currentQuery,
				type: "observerResultsUpdated"
			});
		});
	}
};
function shouldLoadOnMount(query, options) {
	return resolveQueryBoolean(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryBoolean(options.retryOnMount, query) === false);
}
function shouldFetchOnMount(query, options) {
	return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
function shouldFetchOn(query, options, field) {
	if (resolveQueryBoolean(options.enabled, query) !== false && resolveStaleTime(options.staleTime, query) !== "static") {
		const value = typeof field === "function" ? field(query) : field;
		return value === "always" || value !== false && isStale(query, options);
	}
	return false;
}
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
	return (query !== prevQuery || resolveQueryBoolean(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
}
function isStale(query, options) {
	return resolveQueryBoolean(options.enabled, query) !== false && query.isStaleByTime(resolveStaleTime(options.staleTime, query));
}
function shouldAssignObserverCurrentProperties(observer, optimisticResult) {
	if (!shallowEqualObjects(observer.getCurrentResult(), optimisticResult)) return true;
	return false;
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/infiniteQueryObserver.js
var InfiniteQueryObserver = class extends QueryObserver {
	constructor(client, options) {
		super(client, options);
	}
	bindMethods() {
		super.bindMethods();
		this.fetchNextPage = this.fetchNextPage.bind(this);
		this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
	}
	setOptions(options) {
		options._type = "infinite";
		super.setOptions(options);
	}
	getOptimisticResult(options) {
		options._type = "infinite";
		return super.getOptimisticResult(options);
	}
	fetchNextPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "forward" } }
		});
	}
	fetchPreviousPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "backward" } }
		});
	}
	createResult(query, options) {
		const { state } = query;
		const parentResult = super.createResult(query, options);
		const { isFetching, isRefetching, isError, isRefetchError } = parentResult;
		const fetchDirection = state.fetchMeta?.fetchMore?.direction;
		const isFetchNextPageError = isError && fetchDirection === "forward";
		const isFetchingNextPage = isFetching && fetchDirection === "forward";
		const isFetchPreviousPageError = isError && fetchDirection === "backward";
		const isFetchingPreviousPage = isFetching && fetchDirection === "backward";
		return {
			...parentResult,
			fetchNextPage: this.fetchNextPage,
			fetchPreviousPage: this.fetchPreviousPage,
			hasNextPage: hasNextPage(options, state.data),
			hasPreviousPage: hasPreviousPage(options, state.data),
			isFetchNextPageError,
			isFetchingNextPage,
			isFetchPreviousPageError,
			isFetchingPreviousPage,
			isRefetchError: isRefetchError && !isFetchNextPageError && !isFetchPreviousPageError,
			isRefetching: isRefetching && !isFetchingNextPage && !isFetchingPreviousPage
		};
	}
};
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/mutation.js
var Mutation = class extends Removable {
	#client;
	#observers;
	#mutationCache;
	#retryer;
	constructor(config) {
		super();
		this.#client = config.client;
		this.mutationId = config.mutationId;
		this.#mutationCache = config.mutationCache;
		this.#observers = [];
		this.state = config.state || getDefaultState();
		this.setOptions(config.options);
		this.scheduleGc();
	}
	setOptions(options) {
		this.options = options;
		this.updateGcTime(this.options.gcTime);
	}
	get meta() {
		return this.options.meta;
	}
	addObserver(observer) {
		if (!this.#observers.includes(observer)) {
			this.#observers.push(observer);
			this.clearGcTimeout();
			this.#mutationCache.notify({
				type: "observerAdded",
				mutation: this,
				observer
			});
		}
	}
	removeObserver(observer) {
		this.#observers = this.#observers.filter((x) => x !== observer);
		this.scheduleGc();
		this.#mutationCache.notify({
			type: "observerRemoved",
			mutation: this,
			observer
		});
	}
	optionalRemove() {
		if (!this.#observers.length) if (this.state.status === "pending") this.scheduleGc();
		else this.#mutationCache.remove(this);
	}
	continue() {
		return this.#retryer?.continue() ?? this.execute(this.state.variables);
	}
	async execute(variables) {
		const onContinue = () => {
			this.#dispatch({ type: "continue" });
		};
		const mutationFnContext = {
			client: this.#client,
			meta: this.options.meta,
			mutationKey: this.options.mutationKey
		};
		this.#retryer = createRetryer({
			fn: () => {
				if (!this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
				return this.options.mutationFn(variables, mutationFnContext);
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue,
			retry: this.options.retry ?? 0,
			retryDelay: this.options.retryDelay,
			networkMode: this.options.networkMode,
			canRun: () => this.#mutationCache.canRun(this)
		});
		const restored = this.state.status === "pending";
		const isPaused = !this.#retryer.canStart();
		try {
			if (restored) onContinue();
			else {
				this.#dispatch({
					type: "pending",
					variables,
					isPaused
				});
				if (this.#mutationCache.config.onMutate) await this.#mutationCache.config.onMutate(variables, this, mutationFnContext);
				const context = await this.options.onMutate?.(variables, mutationFnContext);
				if (context !== this.state.context) this.#dispatch({
					type: "pending",
					context,
					variables,
					isPaused
				});
			}
			const data = await this.#retryer.start();
			await this.#mutationCache.config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
			await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
			await this.#mutationCache.config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
			await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
			this.#dispatch({
				type: "success",
				data
			});
			return data;
		} catch (error) {
			try {
				await this.#mutationCache.config.onError?.(error, variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.#mutationCache.config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			this.#dispatch({
				type: "error",
				error
			});
			throw error;
		} finally {
			this.#mutationCache.runNext(this);
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					failureCount: action.failureCount,
					failureReason: action.error
				};
				case "pause": return {
					...state,
					isPaused: true
				};
				case "continue": return {
					...state,
					isPaused: false
				};
				case "pending": return {
					...state,
					context: action.context,
					data: void 0,
					failureCount: 0,
					failureReason: null,
					error: null,
					isPaused: action.isPaused,
					status: "pending",
					variables: action.variables,
					submittedAt: Date.now()
				};
				case "success": return {
					...state,
					data: action.data,
					failureCount: 0,
					failureReason: null,
					error: null,
					status: "success",
					isPaused: false
				};
				case "error": return {
					...state,
					data: void 0,
					error: action.error,
					failureCount: state.failureCount + 1,
					failureReason: action.error,
					isPaused: false,
					status: "error"
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.#observers.forEach((observer) => {
				observer.onMutationUpdate(action);
			});
			this.#mutationCache.notify({
				mutation: this,
				type: "updated",
				action
			});
		});
	}
};
function getDefaultState() {
	return {
		context: void 0,
		data: void 0,
		error: null,
		failureCount: 0,
		failureReason: null,
		isPaused: false,
		status: "idle",
		variables: void 0,
		submittedAt: 0
	};
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/mutationCache.js
var MutationCache = class extends Subscribable {
	constructor(config = {}) {
		super();
		this.config = config;
		this.#mutations = /* @__PURE__ */ new Set();
		this.#scopes = /* @__PURE__ */ new Map();
		this.#mutationId = 0;
	}
	#mutations;
	#scopes;
	#mutationId;
	build(client, options, state) {
		const mutation = new Mutation({
			client,
			mutationCache: this,
			mutationId: ++this.#mutationId,
			options: client.defaultMutationOptions(options),
			state
		});
		this.add(mutation);
		return mutation;
	}
	add(mutation) {
		this.#mutations.add(mutation);
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const scopedMutations = this.#scopes.get(scope);
			if (scopedMutations) scopedMutations.push(mutation);
			else this.#scopes.set(scope, [mutation]);
		}
		this.notify({
			type: "added",
			mutation
		});
	}
	remove(mutation) {
		if (this.#mutations.delete(mutation)) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const scopedMutations = this.#scopes.get(scope);
				if (scopedMutations) {
					if (scopedMutations.length > 1) {
						const index = scopedMutations.indexOf(mutation);
						if (index !== -1) scopedMutations.splice(index, 1);
					} else if (scopedMutations[0] === mutation) this.#scopes.delete(scope);
				}
			}
		}
		this.notify({
			type: "removed",
			mutation
		});
	}
	canRun(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const firstPendingMutation = this.#scopes.get(scope)?.find((m) => m.state.status === "pending");
			return !firstPendingMutation || firstPendingMutation === mutation;
		} else return true;
	}
	runNext(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") return (this.#scopes.get(scope)?.find((m) => m !== mutation && m.state.isPaused))?.continue() ?? Promise.resolve();
		else return Promise.resolve();
	}
	clear() {
		notifyManager.batch(() => {
			this.#mutations.forEach((mutation) => {
				this.notify({
					type: "removed",
					mutation
				});
			});
			this.#mutations.clear();
			this.#scopes.clear();
		});
	}
	getAll() {
		return Array.from(this.#mutations);
	}
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((mutation) => matchMutation(defaultedFilters, mutation));
	}
	findAll(filters = {}) {
		return this.getAll().filter((mutation) => matchMutation(filters, mutation));
	}
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	resumePausedMutations() {
		const pausedMutations = this.getAll().filter((x) => x.state.isPaused);
		return notifyManager.batch(() => Promise.all(pausedMutations.map((mutation) => mutation.continue().catch(noop))));
	}
};
function scopeFor(mutation) {
	return mutation.options.scope?.id;
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/mutationObserver.js
var MutationObserver = class extends Subscribable {
	#client;
	#currentResult = void 0;
	#currentMutation;
	#mutateOptions;
	constructor(client, options) {
		super();
		this.#client = client;
		this.setOptions(options);
		this.bindMethods();
		this.#updateResult();
	}
	bindMethods() {
		this.mutate = this.mutate.bind(this);
		this.reset = this.reset.bind(this);
	}
	setOptions(options) {
		const prevOptions = this.options;
		this.options = this.#client.defaultMutationOptions(options);
		if (!shallowEqualObjects(this.options, prevOptions)) this.#client.getMutationCache().notify({
			type: "observerOptionsUpdated",
			mutation: this.#currentMutation,
			observer: this
		});
		if (prevOptions?.mutationKey && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
		else if (this.#currentMutation?.state.status === "pending") this.#currentMutation.setOptions(this.options);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.#currentMutation?.removeObserver(this);
	}
	onMutationUpdate(action) {
		this.#updateResult();
		this.#notify(action);
	}
	getCurrentResult() {
		return this.#currentResult;
	}
	reset() {
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = void 0;
		this.#updateResult();
		this.#notify();
	}
	mutate(variables, options) {
		this.#mutateOptions = options;
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = this.#client.getMutationCache().build(this.#client, this.options);
		this.#currentMutation.addObserver(this);
		return this.#currentMutation.execute(variables);
	}
	#updateResult() {
		const state = this.#currentMutation?.state ?? getDefaultState();
		this.#currentResult = {
			...state,
			isPending: state.status === "pending",
			isSuccess: state.status === "success",
			isError: state.status === "error",
			isIdle: state.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		};
	}
	#notify(action) {
		notifyManager.batch(() => {
			if (this.#mutateOptions && this.hasListeners()) {
				const variables = this.#currentResult.variables;
				const onMutateResult = this.#currentResult.context;
				const context = {
					client: this.#client,
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if (action?.type === "success") {
					try {
						this.#mutateOptions.onSuccess?.(action.data, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(action.data, null, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				} else if (action?.type === "error") {
					try {
						this.#mutateOptions.onError?.(action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(void 0, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
		});
	}
};
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/queriesObserver.js
function difference(array1, array2) {
	const excludeSet = new Set(array2);
	return array1.filter((x) => !excludeSet.has(x));
}
function replaceAt(array, index, value) {
	const copy = array.slice(0);
	copy[index] = value;
	return copy;
}
var QueriesObserver = class extends Subscribable {
	#client;
	#result;
	#queries;
	#options;
	#observers;
	#combinedResult;
	#lastCombine;
	#lastResult;
	#lastQueryHashes;
	#observerMatches = [];
	constructor(client, queries, options) {
		super();
		this.#client = client;
		this.#options = options;
		this.#queries = [];
		this.#observers = [];
		this.#result = [];
		this.setQueries(queries);
	}
	onSubscribe() {
		if (this.listeners.size === 1) this.#observers.forEach((observer) => {
			observer.subscribe((result) => {
				this.#onUpdate(observer, result);
			});
		});
	}
	onUnsubscribe() {
		if (!this.listeners.size) this.destroy();
	}
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#observers.forEach((observer) => {
			observer.destroy();
		});
	}
	setQueries(queries, options) {
		this.#queries = queries;
		this.#options = options;
		{
			const queryHashes = queries.map((query) => this.#client.defaultQueryOptions(query).queryHash);
			if (new Set(queryHashes).size !== queryHashes.length) console.warn("[QueriesObserver]: Duplicate Queries found. This might result in unexpected behavior.");
		}
		notifyManager.batch(() => {
			const prevObservers = this.#observers;
			const newObserverMatches = this.#findMatchingObservers(this.#queries);
			newObserverMatches.forEach((match) => match.observer.setOptions(match.defaultedQueryOptions));
			const newObservers = newObserverMatches.map((match) => match.observer);
			const newResult = newObservers.map((observer) => observer.getCurrentResult());
			const hasLengthChange = prevObservers.length !== newObservers.length;
			const hasIndexChange = newObservers.some((observer, index) => observer !== prevObservers[index]);
			const hasStructuralChange = hasLengthChange || hasIndexChange;
			const hasResultChange = hasStructuralChange ? true : newResult.some((result, index) => {
				const prev = this.#result[index];
				return !prev || !shallowEqualObjects(result, prev);
			});
			if (!hasStructuralChange && !hasResultChange) return;
			if (hasStructuralChange) {
				this.#observerMatches = newObserverMatches;
				this.#observers = newObservers;
			}
			this.#result = newResult;
			if (!this.hasListeners()) return;
			if (hasStructuralChange) {
				difference(prevObservers, newObservers).forEach((observer) => {
					observer.destroy();
				});
				difference(newObservers, prevObservers).forEach((observer) => {
					observer.subscribe((result) => {
						this.#onUpdate(observer, result);
					});
				});
			}
			this.#notify();
		});
	}
	getCurrentResult() {
		return this.#result;
	}
	getQueries() {
		return this.#observers.map((observer) => observer.getCurrentQuery());
	}
	getObservers() {
		return this.#observers;
	}
	getOptimisticResult(queries, combine) {
		const matches = this.#findMatchingObservers(queries);
		const result = matches.map((match) => match.observer.getOptimisticResult(match.defaultedQueryOptions));
		const queryHashes = matches.map((match) => match.defaultedQueryOptions.queryHash);
		return [
			result,
			(r) => {
				return this.#combineResult(r ?? result, combine, queryHashes);
			},
			() => {
				return this.#trackResult(result, matches);
			}
		];
	}
	#trackResult(result, matches) {
		return matches.map((match, index) => {
			const observerResult = result[index];
			return !match.defaultedQueryOptions.notifyOnChangeProps ? match.observer.trackResult(observerResult, (accessedProp) => {
				matches.forEach((m) => {
					m.observer.trackProp(accessedProp);
				});
			}) : observerResult;
		});
	}
	#combineResult(input, combine, queryHashes) {
		if (combine) {
			const lastHashes = this.#lastQueryHashes;
			const queryHashesChanged = queryHashes !== void 0 && lastHashes !== void 0 && (lastHashes.length !== queryHashes.length || queryHashes.some((hash, i) => hash !== lastHashes[i]));
			if (!this.#combinedResult || this.#result !== this.#lastResult || queryHashesChanged || combine !== this.#lastCombine) {
				this.#lastCombine = combine;
				this.#lastResult = this.#result;
				if (queryHashes !== void 0) this.#lastQueryHashes = queryHashes;
				this.#combinedResult = replaceEqualDeep(this.#combinedResult, combine(input));
			}
			return this.#combinedResult;
		}
		return input;
	}
	#shouldSkipCombine() {
		return this.#options?.combine !== void 0 && this.#observers.some((observer, index) => {
			return observer.options.suspense && this.#result[index]?.data === void 0;
		});
	}
	#findMatchingObservers(queries) {
		const prevObserversMap = /* @__PURE__ */ new Map();
		this.#observers.forEach((observer) => {
			const key = observer.options.queryHash;
			if (!key) return;
			const previousObservers = prevObserversMap.get(key);
			if (previousObservers) previousObservers.push(observer);
			else prevObserversMap.set(key, [observer]);
		});
		const observers = [];
		queries.forEach((options) => {
			const defaultedOptions = this.#client.defaultQueryOptions(options);
			const observer = prevObserversMap.get(defaultedOptions.queryHash)?.shift() ?? new QueryObserver(this.#client, defaultedOptions);
			observers.push({
				defaultedQueryOptions: defaultedOptions,
				observer
			});
		});
		return observers;
	}
	#onUpdate(observer, result) {
		const index = this.#observers.indexOf(observer);
		if (index !== -1) {
			this.#result = replaceAt(this.#result, index, result);
			this.#notify();
		}
	}
	#notify() {
		if (this.hasListeners()) {
			const newTracked = this.#trackResult(this.#result, this.#observerMatches);
			const shouldSkipCombine = this.#shouldSkipCombine();
			const previousResult = this.#combinedResult;
			const newResult = shouldSkipCombine ? previousResult : this.#combineResult(newTracked, this.#options?.combine);
			if (shouldSkipCombine || previousResult !== newResult) notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(this.#result);
				});
			});
		}
	}
};
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/queryCache.js
var QueryCache = class extends Subscribable {
	constructor(config = {}) {
		super();
		this.config = config;
		this.#queries = /* @__PURE__ */ new Map();
	}
	#queries;
	build(client, options, state) {
		const queryKey = options.queryKey;
		const queryHash = options.queryHash ?? hashQueryKeyByOptions(queryKey, options);
		let query = this.get(queryHash);
		if (!query) {
			query = new Query({
				client,
				queryKey,
				queryHash,
				options: client.defaultQueryOptions(options),
				state,
				defaultOptions: client.getQueryDefaults(queryKey)
			});
			this.add(query);
		}
		return query;
	}
	add(query) {
		if (!this.#queries.has(query.queryHash)) {
			this.#queries.set(query.queryHash, query);
			this.notify({
				type: "added",
				query
			});
		}
	}
	remove(query) {
		const queryInMap = this.#queries.get(query.queryHash);
		if (queryInMap) {
			query.destroy();
			if (queryInMap === query) this.#queries.delete(query.queryHash);
			this.notify({
				type: "removed",
				query
			});
		}
	}
	clear() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				this.remove(query);
			});
		});
	}
	get(queryHash) {
		return this.#queries.get(queryHash);
	}
	getAll() {
		return [...this.#queries.values()];
	}
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((query) => matchQuery(defaultedFilters, query));
	}
	findAll(filters = {}) {
		const queries = this.getAll();
		return Object.keys(filters).length > 0 ? queries.filter((query) => matchQuery(filters, query)) : queries;
	}
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	onFocus() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onFocus();
			});
		});
	}
	onOnline() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onOnline();
			});
		});
	}
};
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/queryClient.js
var QueryClient = class {
	#queryCache;
	#mutationCache;
	#defaultOptions;
	#queryDefaults;
	#mutationDefaults;
	#mountCount;
	#unsubscribeFocus;
	#unsubscribeOnline;
	constructor(config = {}) {
		this.#queryCache = config.queryCache || new QueryCache();
		this.#mutationCache = config.mutationCache || new MutationCache();
		this.#defaultOptions = config.defaultOptions || {};
		this.#queryDefaults = /* @__PURE__ */ new Map();
		this.#mutationDefaults = /* @__PURE__ */ new Map();
		this.#mountCount = 0;
	}
	mount() {
		this.#mountCount++;
		if (this.#mountCount !== 1) return;
		this.#unsubscribeFocus = focusManager.subscribe(async (focused) => {
			if (focused) {
				await this.resumePausedMutations();
				this.#queryCache.onFocus();
			}
		});
		this.#unsubscribeOnline = onlineManager.subscribe(async (online) => {
			if (online) {
				await this.resumePausedMutations();
				this.#queryCache.onOnline();
			}
		});
	}
	unmount() {
		this.#mountCount--;
		if (this.#mountCount !== 0) return;
		this.#unsubscribeFocus?.();
		this.#unsubscribeFocus = void 0;
		this.#unsubscribeOnline?.();
		this.#unsubscribeOnline = void 0;
	}
	isFetching(filters) {
		return this.#queryCache.findAll({
			...filters,
			fetchStatus: "fetching"
		}).length;
	}
	isMutating(filters) {
		return this.#mutationCache.findAll({
			...filters,
			status: "pending"
		}).length;
	}
	/**
	* Imperative (non-reactive) way to retrieve data for a QueryKey.
	* Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
	*
	* Hint: Do not use this function inside a component, because it won't receive updates.
	* Use `useQuery` to create a `QueryObserver` that subscribes to changes.
	*/
	getQueryData(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state.data;
	}
	ensureQueryData(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		const query = this.#queryCache.build(this, defaultedOptions);
		const cachedData = query.state.data;
		if (cachedData === void 0) return this.fetchQuery(options);
		if (options.revalidateIfStale && query.isStaleByTime(resolveStaleTime(defaultedOptions.staleTime, query))) this.prefetchQuery(defaultedOptions);
		return Promise.resolve(cachedData);
	}
	getQueriesData(filters) {
		return this.#queryCache.findAll(filters).map(({ queryKey, state }) => {
			return [queryKey, state.data];
		});
	}
	setQueryData(queryKey, updater, options) {
		const defaultedOptions = this.defaultQueryOptions({ queryKey });
		const prevData = this.#queryCache.get(defaultedOptions.queryHash)?.state.data;
		const data = functionalUpdate(updater, prevData);
		if (data === void 0) return;
		return this.#queryCache.build(this, defaultedOptions).setData(data, {
			...options,
			manual: true
		});
	}
	setQueriesData(filters, updater, options) {
		return notifyManager.batch(() => this.#queryCache.findAll(filters).map(({ queryKey }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
	}
	getQueryState(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state;
	}
	removeQueries(filters) {
		const queryCache = this.#queryCache;
		notifyManager.batch(() => {
			queryCache.findAll(filters).forEach((query) => {
				queryCache.remove(query);
			});
		});
	}
	resetQueries(filters, options) {
		const queryCache = this.#queryCache;
		return notifyManager.batch(() => {
			queryCache.findAll(filters).forEach((query) => {
				query.reset();
			});
			return this.refetchQueries({
				type: "active",
				...filters
			}, options);
		});
	}
	cancelQueries(filters, cancelOptions = {}) {
		const defaultedCancelOptions = {
			revert: true,
			...cancelOptions
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).map((query) => query.cancel(defaultedCancelOptions)));
		return Promise.all(promises).then(noop).catch(noop);
	}
	invalidateQueries(filters, options = {}) {
		return notifyManager.batch(() => {
			this.#queryCache.findAll(filters).forEach((query) => {
				query.invalidate();
			});
			if (filters?.refetchType === "none") return Promise.resolve();
			return this.refetchQueries({
				...filters,
				type: filters?.refetchType ?? filters?.type ?? "active"
			}, options);
		});
	}
	refetchQueries(filters, options = {}) {
		const fetchOptions = {
			...options,
			cancelRefetch: options.cancelRefetch ?? true
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).filter((query) => !query.isDisabled() && !query.isStatic()).map((query) => {
			let promise = query.fetch(void 0, fetchOptions);
			if (!fetchOptions.throwOnError) promise = promise.catch(noop);
			return query.state.fetchStatus === "paused" ? Promise.resolve() : promise;
		}));
		return Promise.all(promises).then(noop);
	}
	fetchQuery(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		return query.isStaleByTime(resolveStaleTime(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
	}
	prefetchQuery(options) {
		return this.fetchQuery(options).then(noop).catch(noop);
	}
	fetchInfiniteQuery(options) {
		options._type = "infinite";
		return this.fetchQuery(options);
	}
	prefetchInfiniteQuery(options) {
		return this.fetchInfiniteQuery(options).then(noop).catch(noop);
	}
	ensureInfiniteQueryData(options) {
		options._type = "infinite";
		return this.ensureQueryData(options);
	}
	resumePausedMutations() {
		if (onlineManager.isOnline()) return this.#mutationCache.resumePausedMutations();
		return Promise.resolve();
	}
	getQueryCache() {
		return this.#queryCache;
	}
	getMutationCache() {
		return this.#mutationCache;
	}
	getDefaultOptions() {
		return this.#defaultOptions;
	}
	setDefaultOptions(options) {
		this.#defaultOptions = options;
	}
	setQueryDefaults(queryKey, options) {
		this.#queryDefaults.set(hashKey(queryKey), {
			queryKey,
			defaultOptions: options
		});
	}
	getQueryDefaults(queryKey) {
		const defaults = [...this.#queryDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(queryKey, queryDefault.queryKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	setMutationDefaults(mutationKey, options) {
		this.#mutationDefaults.set(hashKey(mutationKey), {
			mutationKey,
			defaultOptions: options
		});
	}
	getMutationDefaults(mutationKey) {
		const defaults = [...this.#mutationDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(mutationKey, queryDefault.mutationKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	defaultQueryOptions(options) {
		if (options._defaulted) return options;
		const defaultedOptions = {
			...this.#defaultOptions.queries,
			...this.getQueryDefaults(options.queryKey),
			...options,
			_defaulted: true
		};
		if (!defaultedOptions.queryHash) defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
		if (defaultedOptions.refetchOnReconnect === void 0) defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
		if (defaultedOptions.throwOnError === void 0) defaultedOptions.throwOnError = !!defaultedOptions.suspense;
		if (!defaultedOptions.networkMode && defaultedOptions.persister) defaultedOptions.networkMode = "offlineFirst";
		if (defaultedOptions.queryFn === skipToken) defaultedOptions.enabled = false;
		return defaultedOptions;
	}
	defaultMutationOptions(options) {
		if (options?._defaulted) return options;
		return {
			...this.#defaultOptions.mutations,
			...options?.mutationKey && this.getMutationDefaults(options.mutationKey),
			...options,
			_defaulted: true
		};
	}
	clear() {
		this.#queryCache.clear();
		this.#mutationCache.clear();
	}
};
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/streamedQuery.js
function streamedQuery({ streamFn, refetchMode = "reset", reducer = (items, chunk) => addToEnd(items, chunk), initialValue = [] }) {
	return async (context) => {
		const query = context.client.getQueryCache().find({
			queryKey: context.queryKey,
			exact: true
		});
		const isRefetch = !!query && query.isFetched();
		if (isRefetch && refetchMode === "reset") query.setState({
			...query.resetState,
			fetchStatus: "fetching"
		});
		let result = initialValue;
		let cancelled = false;
		const stream = await streamFn(addConsumeAwareSignal({
			client: context.client,
			meta: context.meta,
			queryKey: context.queryKey,
			pageParam: context.pageParam,
			direction: context.direction
		}, () => context.signal, () => cancelled = true));
		const isReplaceRefetch = isRefetch && refetchMode === "replace";
		for await (const chunk of stream) {
			if (cancelled) break;
			if (isReplaceRefetch) result = reducer(result, chunk);
			else context.client.setQueryData(context.queryKey, (prev) => reducer(prev === void 0 ? initialValue : prev, chunk));
		}
		if (isReplaceRefetch && !cancelled) context.client.setQueryData(context.queryKey, result);
		return context.client.getQueryData(context.queryKey) ?? initialValue;
	};
}
//#endregion
//#region ../../node_modules/@tanstack/query-core/build/modern/types.js
var dataTagSymbol = /* @__PURE__ */ Symbol("dataTagSymbol");
var dataTagErrorSymbol = /* @__PURE__ */ Symbol("dataTagErrorSymbol");
var unsetMarker = /* @__PURE__ */ Symbol("unsetMarker");
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var QueryClientContext = import_react.createContext(void 0);
var useQueryClient = (queryClient) => {
	const client = import_react.useContext(QueryClientContext);
	if (queryClient) return queryClient;
	if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
	return client;
};
var QueryClientProvider = ({ client, children }) => {
	import_react.useEffect(() => {
		client.mount();
		return () => {
			client.unmount();
		};
	}, [client]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
		value: client,
		children
	});
};
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
var IsRestoringContext = import_react.createContext(false);
var useIsRestoring = () => import_react.useContext(IsRestoringContext);
var IsRestoringProvider = IsRestoringContext.Provider;
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
function createValue() {
	let isReset = false;
	return {
		clearReset: () => {
			isReset = false;
		},
		reset: () => {
			isReset = true;
		},
		isReset: () => {
			return isReset;
		}
	};
}
var QueryErrorResetBoundaryContext = import_react.createContext(createValue());
var useQueryErrorResetBoundary = () => import_react.useContext(QueryErrorResetBoundaryContext);
var QueryErrorResetBoundary = ({ children }) => {
	const [value] = import_react.useState(() => createValue());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryErrorResetBoundaryContext.Provider, {
		value,
		children: typeof children === "function" ? children(value) : children
	});
};
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
	const throwOnError = query?.state.error && typeof options.throwOnError === "function" ? shouldThrowError(options.throwOnError, [query.state.error, query]) : options.throwOnError;
	if (options.suspense || options.experimental_prefetchInRender || throwOnError) {
		if (!errorResetBoundary.isReset()) options.retryOnMount = false;
	}
};
var useClearResetErrorBoundary = (errorResetBoundary) => {
	import_react.useEffect(() => {
		errorResetBoundary.clearReset();
	}, [errorResetBoundary]);
};
var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
	return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
};
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/suspense.js
var defaultThrowOnError = (_error, query) => query.state.data === void 0;
var ensureSuspenseTimers = (defaultedOptions) => {
	if (defaultedOptions.suspense) {
		const MIN_SUSPENSE_TIME_MS = 1e3;
		const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
		const originalStaleTime = defaultedOptions.staleTime;
		defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
		if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
	}
};
var willFetch = (result, isRestoring) => result.isLoading && result.isFetching && !isRestoring;
var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
	errorResetBoundary.clearReset();
});
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useQueries.js
function useQueries({ queries, ...options }, queryClient) {
	const client = useQueryClient(queryClient);
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const defaultedQueries = import_react.useMemo(() => queries.map((opts) => {
		const defaultedOptions = client.defaultQueryOptions(opts);
		defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : "optimistic";
		return defaultedOptions;
	}), [
		queries,
		client,
		isRestoring
	]);
	defaultedQueries.forEach((queryOptions) => {
		ensureSuspenseTimers(queryOptions);
		const query = client.getQueryCache().get(queryOptions.queryHash);
		ensurePreventErrorBoundaryRetry(queryOptions, errorResetBoundary, query);
	});
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new QueriesObserver(client, defaultedQueries, options));
	const [optimisticResult, getCombinedResult, trackResult] = observer.getOptimisticResult(defaultedQueries, options.combine);
	const shouldSubscribe = !isRestoring && options.subscribed !== false;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setQueries(defaultedQueries, options);
	}, [
		defaultedQueries,
		options,
		observer
	]);
	const suspensePromises = optimisticResult.some((result, index) => shouldSuspend(defaultedQueries[index], result)) ? optimisticResult.flatMap((result, index) => {
		const opts = defaultedQueries[index];
		if (opts && shouldSuspend(opts, result)) return fetchOptimistic(opts, new QueryObserver(client, opts), errorResetBoundary);
		return [];
	}) : [];
	if (suspensePromises.length > 0) throw Promise.all(suspensePromises);
	const firstSingleResultWhichShouldThrow = optimisticResult.find((result, index) => {
		const query = defaultedQueries[index];
		return query && getHasError({
			result,
			errorResetBoundary,
			throwOnError: query.throwOnError,
			query: client.getQueryCache().get(query.queryHash),
			suspense: query.suspense
		});
	});
	if (firstSingleResultWhichShouldThrow?.error) throw firstSingleResultWhichShouldThrow.error;
	return getCombinedResult(trackResult());
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
function useBaseQuery(options, Observer, queryClient) {
	if (typeof options !== "object" || Array.isArray(options)) throw new Error("Bad argument type. Starting with v5, only the \"Object\" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object");
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const client = useQueryClient(queryClient);
	const defaultedOptions = client.defaultQueryOptions(options);
	client.getDefaultOptions().queries?._experimental_beforeQuery?.(defaultedOptions);
	const query = client.getQueryCache().get(defaultedOptions.queryHash);
	if (!defaultedOptions.queryFn) console.error(`[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`);
	const subscribed = options.subscribed !== false;
	defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
	ensureSuspenseTimers(defaultedOptions);
	ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
	useClearResetErrorBoundary(errorResetBoundary);
	const isNewCacheEntry = !client.getQueryCache().get(defaultedOptions.queryHash);
	const [observer] = import_react.useState(() => new Observer(client, defaultedOptions));
	const result = observer.getOptimisticResult(defaultedOptions);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => {
		const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
		observer.updateResult();
		return unsubscribe;
	}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setOptions(defaultedOptions);
	}, [defaultedOptions, observer]);
	if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
	if (getHasError({
		result,
		errorResetBoundary,
		throwOnError: defaultedOptions.throwOnError,
		query,
		suspense: defaultedOptions.suspense
	})) throw result.error;
	client.getDefaultOptions().queries?._experimental_afterQuery?.(defaultedOptions, result);
	if (defaultedOptions.experimental_prefetchInRender && !environmentManager.isServer() && willFetch(result, isRestoring)) (isNewCacheEntry ? fetchOptimistic(defaultedOptions, observer, errorResetBoundary) : query?.promise)?.catch(noop).finally(() => {
		observer.updateResult();
	});
	return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useQuery.js
function useQuery(options, queryClient) {
	return useBaseQuery(options, QueryObserver, queryClient);
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useSuspenseQuery.js
function useSuspenseQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, QueryObserver, queryClient);
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useSuspenseInfiniteQuery.js
function useSuspenseInfiniteQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseInfiniteQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError
	}, InfiniteQueryObserver, queryClient);
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useSuspenseQueries.js
function useSuspenseQueries(options, queryClient) {
	return useQueries({
		...options,
		queries: options.queries.map((query) => {
			if (query.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQueries");
			return {
				...query,
				suspense: true,
				throwOnError: defaultThrowOnError,
				enabled: true,
				placeholderData: void 0
			};
		})
	}, queryClient);
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/usePrefetchQuery.js
function usePrefetchQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.prefetchQuery(options);
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/usePrefetchInfiniteQuery.js
function usePrefetchInfiniteQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.prefetchInfiniteQuery(options);
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/queryOptions.js
function queryOptions(options) {
	return options;
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/infiniteQueryOptions.js
function infiniteQueryOptions(options) {
	return options;
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/HydrationBoundary.js
var HydrationBoundary = ({ children, options = {}, state, queryClient }) => {
	const client = useQueryClient(queryClient);
	const optionsRef = import_react.useRef(options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	const hydrationQueue = import_react.useMemo(() => {
		if (state) {
			if (typeof state !== "object") return;
			const queryCache = client.getQueryCache();
			const queries = state.queries || [];
			const newQueries = [];
			const existingQueries = [];
			for (const dehydratedQuery of queries) {
				const existingQuery = queryCache.get(dehydratedQuery.queryHash);
				if (!existingQuery) newQueries.push(dehydratedQuery);
				else if (dehydratedQuery.state.dataUpdatedAt > existingQuery.state.dataUpdatedAt || dehydratedQuery.promise && existingQuery.state.status !== "pending" && existingQuery.state.fetchStatus !== "fetching" && dehydratedQuery.dehydratedAt !== void 0 && dehydratedQuery.dehydratedAt > existingQuery.state.dataUpdatedAt) existingQueries.push(dehydratedQuery);
			}
			if (newQueries.length > 0) hydrate(client, { queries: newQueries }, optionsRef.current);
			if (existingQueries.length > 0) return existingQueries;
		}
	}, [client, state]);
	import_react.useEffect(() => {
		if (hydrationQueue) hydrate(client, { queries: hydrationQueue }, optionsRef.current);
	}, [client, hydrationQueue]);
	return children;
};
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useIsFetching.js
function useIsFetching(filters, queryClient) {
	const client = useQueryClient(queryClient);
	const queryCache = client.getQueryCache();
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => queryCache.subscribe(notifyManager.batchCalls(onStoreChange)), [queryCache]), () => client.isFetching(filters), () => client.isFetching(filters));
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useMutationState.js
function useIsMutating(filters, queryClient) {
	const client = useQueryClient(queryClient);
	return useMutationState({ filters: {
		...filters,
		status: "pending"
	} }, client).length;
}
function getResult(mutationCache, options) {
	return mutationCache.findAll(options.filters).map((mutation) => options.select ? options.select(mutation) : mutation.state);
}
function useMutationState(options = {}, queryClient) {
	const mutationCache = useQueryClient(queryClient).getMutationCache();
	const optionsRef = import_react.useRef(options);
	const result = import_react.useRef(null);
	if (result.current === null) result.current = getResult(mutationCache, options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => mutationCache.subscribe(() => {
		const nextResult = replaceEqualDeep(result.current, getResult(mutationCache, optionsRef.current));
		if (result.current !== nextResult) {
			result.current = nextResult;
			notifyManager.schedule(onStoreChange);
		}
	}), [mutationCache]), () => result.current, () => result.current);
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useMutation.js
function useMutation(options, queryClient) {
	const client = useQueryClient(queryClient);
	const [observer] = import_react.useState(() => new MutationObserver(client, options));
	import_react.useEffect(() => {
		observer.setOptions(options);
	}, [observer, options]);
	const result = import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const mutate = import_react.useCallback((variables, mutateOptions) => {
		observer.mutate(variables, mutateOptions).catch(noop);
	}, [observer]);
	if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
	return {
		...result,
		mutate,
		mutateAsync: result.mutate
	};
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/mutationOptions.js
function mutationOptions(options) {
	return options;
}
//#endregion
//#region ../../node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js
function useInfiniteQuery(options, queryClient) {
	return useBaseQuery(options, InfiniteQueryObserver, queryClient);
}
//#endregion
export { CancelledError, HydrationBoundary, InfiniteQueryObserver, IsRestoringProvider, Mutation, MutationCache, MutationObserver, QueriesObserver, Query, QueryCache, QueryClient, QueryClientContext, QueryClientProvider, QueryErrorResetBoundary, QueryObserver, dataTagErrorSymbol, dataTagSymbol, defaultScheduler, defaultShouldDehydrateMutation, defaultShouldDehydrateQuery, dehydrate, environmentManager, streamedQuery as experimental_streamedQuery, focusManager, hashKey, hydrate, infiniteQueryOptions, isCancelledError, isServer, keepPreviousData, matchMutation, matchQuery, mutationOptions, noop, notifyManager, onlineManager, partialMatchKey, queryOptions, replaceEqualDeep, shouldThrowError, skipToken, timeoutManager, unsetMarker, useInfiniteQuery, useIsFetching, useIsMutating, useIsRestoring, useMutation, useMutationState, usePrefetchInfiniteQuery, usePrefetchQuery, useQueries, useQuery, useQueryClient, useQueryErrorResetBoundary, useSuspenseInfiniteQuery, useSuspenseQueries, useSuspenseQuery };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHRhbnN0YWNrX3JlYWN0LXF1ZXJ5LmpzIiwibmFtZXMiOlsiI3NldHVwIiwiI2NsZWFudXAiLCIjZm9jdXNlZCIsIiNwcm92aWRlckNhbGxlZCIsIiNwcm92aWRlciIsIiNzZXR1cCIsIiNjbGVhbnVwIiwiI29ubGluZSIsIiNnY1RpbWVvdXQiLCIjYWJvcnRTaWduYWxDb25zdW1lZCIsIiNkZWZhdWx0T3B0aW9ucyIsIiNjbGllbnQiLCIjY2FjaGUiLCIjaW5pdGlhbFN0YXRlIiwiZ2V0RGVmYXVsdFN0YXRlIiwiI3F1ZXJ5VHlwZSIsIiNyZXRyeWVyIiwiI2Rpc3BhdGNoIiwiI2lzSW5pdGlhbFBhdXNlZEZldGNoIiwiI3JldmVydFN0YXRlIiwiI2NsaWVudCIsIiNzZWxlY3RFcnJvciIsIiNjdXJyZW50VGhlbmFibGUiLCIjY3VycmVudFF1ZXJ5IiwiI2V4ZWN1dGVGZXRjaCIsIiN1cGRhdGVUaW1lcnMiLCIjY2xlYXJTdGFsZVRpbWVvdXQiLCIjY2xlYXJSZWZldGNoSW50ZXJ2YWwiLCIjdXBkYXRlUXVlcnkiLCIjdXBkYXRlU3RhbGVUaW1lb3V0IiwiI2NvbXB1dGVSZWZldGNoSW50ZXJ2YWwiLCIjY3VycmVudFJlZmV0Y2hJbnRlcnZhbCIsIiN1cGRhdGVSZWZldGNoSW50ZXJ2YWwiLCIjY3VycmVudFJlc3VsdCIsIiNjdXJyZW50UmVzdWx0T3B0aW9ucyIsIiNjdXJyZW50UmVzdWx0U3RhdGUiLCIjdHJhY2tlZFByb3BzIiwiI3N0YWxlVGltZW91dElkIiwiI3JlZmV0Y2hJbnRlcnZhbElkIiwiI2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSIsIiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGEiLCIjc2VsZWN0Rm4iLCIjc2VsZWN0UmVzdWx0IiwiI25vdGlmeSIsIiNjbGllbnQiLCIjbXV0YXRpb25DYWNoZSIsIiNvYnNlcnZlcnMiLCIjcmV0cnllciIsIiNkaXNwYXRjaCIsIiNtdXRhdGlvbnMiLCIjc2NvcGVzIiwiI211dGF0aW9uSWQiLCIjY2xpZW50IiwiI3VwZGF0ZVJlc3VsdCIsIiNjdXJyZW50TXV0YXRpb24iLCIjbm90aWZ5IiwiI2N1cnJlbnRSZXN1bHQiLCIjbXV0YXRlT3B0aW9ucyIsIiNjbGllbnQiLCIjb3B0aW9ucyIsIiNxdWVyaWVzIiwiI29ic2VydmVycyIsIiNyZXN1bHQiLCIjb25VcGRhdGUiLCIjZmluZE1hdGNoaW5nT2JzZXJ2ZXJzIiwiI29ic2VydmVyTWF0Y2hlcyIsIiNub3RpZnkiLCIjY29tYmluZVJlc3VsdCIsIiN0cmFja1Jlc3VsdCIsIiNsYXN0UXVlcnlIYXNoZXMiLCIjY29tYmluZWRSZXN1bHQiLCIjbGFzdFJlc3VsdCIsIiNsYXN0Q29tYmluZSIsIiNzaG91bGRTa2lwQ29tYmluZSIsIiNxdWVyaWVzIiwiI3F1ZXJ5Q2FjaGUiLCIjbXV0YXRpb25DYWNoZSIsIiNkZWZhdWx0T3B0aW9ucyIsIiNxdWVyeURlZmF1bHRzIiwiI211dGF0aW9uRGVmYXVsdHMiLCIjbW91bnRDb3VudCIsIiN1bnN1YnNjcmliZUZvY3VzIiwiI3Vuc3Vic2NyaWJlT25saW5lIl0sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdWJzY3JpYmFibGUuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2ZvY3VzTWFuYWdlci5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vdGltZW91dE1hbmFnZXIuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3V0aWxzLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9lbnZpcm9ubWVudE1hbmFnZXIuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3RoZW5hYmxlLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9oeWRyYXRpb24uanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL25vdGlmeU1hbmFnZXIuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL29ubGluZU1hbmFnZXIuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3JldHJ5ZXIuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3JlbW92YWJsZS5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyeS5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcXVlcnlPYnNlcnZlci5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9ic2VydmVyLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9tdXRhdGlvbi5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vbXV0YXRpb25DYWNoZS5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vbXV0YXRpb25PYnNlcnZlci5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcXVlcmllc09ic2VydmVyLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyeUNhY2hlLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyeUNsaWVudC5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vc3RyZWFtZWRRdWVyeS5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vdHlwZXMuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vSXNSZXN0b3JpbmdQcm92aWRlci5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vZXJyb3JCb3VuZGFyeVV0aWxzLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vc3VzcGVuc2UuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VRdWVyaWVzLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlQmFzZVF1ZXJ5LmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlUXVlcnkuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VTdXNwZW5zZVF1ZXJ5LmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlU3VzcGVuc2VRdWVyaWVzLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlUHJlZmV0Y2hRdWVyeS5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVByZWZldGNoSW5maW5pdGVRdWVyeS5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3F1ZXJ5T3B0aW9ucy5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2luZmluaXRlUXVlcnlPcHRpb25zLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vSHlkcmF0aW9uQm91bmRhcnkuanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VJc0ZldGNoaW5nLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlTXV0YXRpb25TdGF0ZS5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vbXV0YXRpb25PcHRpb25zLmpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlSW5maW5pdGVRdWVyeS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvc3Vic2NyaWJhYmxlLnRzXG52YXIgU3Vic2NyaWJhYmxlID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmxpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgdGhpcy5zdWJzY3JpYmUgPSB0aGlzLnN1YnNjcmliZS5iaW5kKHRoaXMpO1xuICB9XG4gIHN1YnNjcmliZShsaXN0ZW5lcikge1xuICAgIHRoaXMubGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7XG4gICAgdGhpcy5vblN1YnNjcmliZSgpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB0aGlzLmxpc3RlbmVycy5kZWxldGUobGlzdGVuZXIpO1xuICAgICAgdGhpcy5vblVuc3Vic2NyaWJlKCk7XG4gICAgfTtcbiAgfVxuICBoYXNMaXN0ZW5lcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMubGlzdGVuZXJzLnNpemUgPiAwO1xuICB9XG4gIG9uU3Vic2NyaWJlKCkge1xuICB9XG4gIG9uVW5zdWJzY3JpYmUoKSB7XG4gIH1cbn07XG5leHBvcnQge1xuICBTdWJzY3JpYmFibGVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdWJzY3JpYmFibGUuanMubWFwIiwiLy8gc3JjL2ZvY3VzTWFuYWdlci50c1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG52YXIgRm9jdXNNYW5hZ2VyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuICAjZm9jdXNlZDtcbiAgI2NsZWFudXA7XG4gICNzZXR1cDtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLiNzZXR1cCA9IChvbkZvY3VzKSA9PiB7XG4gICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcikge1xuICAgICAgICBjb25zdCBsaXN0ZW5lciA9ICgpID0+IG9uRm9jdXMoKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsIGxpc3RlbmVyLCBmYWxzZSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsIGxpc3RlbmVyKTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9O1xuICB9XG4gIG9uU3Vic2NyaWJlKCkge1xuICAgIGlmICghdGhpcy4jY2xlYW51cCkge1xuICAgICAgdGhpcy5zZXRFdmVudExpc3RlbmVyKHRoaXMuI3NldHVwKTtcbiAgICB9XG4gIH1cbiAgb25VbnN1YnNjcmliZSgpIHtcbiAgICBpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcbiAgICAgIHRoaXMuI2NsZWFudXA/LigpO1xuICAgICAgdGhpcy4jY2xlYW51cCA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbiAgc2V0RXZlbnRMaXN0ZW5lcihzZXR1cCkge1xuICAgIHRoaXMuI3NldHVwID0gc2V0dXA7XG4gICAgdGhpcy4jY2xlYW51cD8uKCk7XG4gICAgdGhpcy4jY2xlYW51cCA9IHNldHVwKChmb2N1c2VkKSA9PiB7XG4gICAgICBpZiAodHlwZW9mIGZvY3VzZWQgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgICAgIHRoaXMuc2V0Rm9jdXNlZChmb2N1c2VkKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMub25Gb2N1cygpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHNldEZvY3VzZWQoZm9jdXNlZCkge1xuICAgIGNvbnN0IGNoYW5nZWQgPSB0aGlzLiNmb2N1c2VkICE9PSBmb2N1c2VkO1xuICAgIGlmIChjaGFuZ2VkKSB7XG4gICAgICB0aGlzLiNmb2N1c2VkID0gZm9jdXNlZDtcbiAgICAgIHRoaXMub25Gb2N1cygpO1xuICAgIH1cbiAgfVxuICBvbkZvY3VzKCkge1xuICAgIGNvbnN0IGlzRm9jdXNlZCA9IHRoaXMuaXNGb2N1c2VkKCk7XG4gICAgdGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcbiAgICAgIGxpc3RlbmVyKGlzRm9jdXNlZCk7XG4gICAgfSk7XG4gIH1cbiAgaXNGb2N1c2VkKCkge1xuICAgIGlmICh0eXBlb2YgdGhpcy4jZm9jdXNlZCA9PT0gXCJib29sZWFuXCIpIHtcbiAgICAgIHJldHVybiB0aGlzLiNmb2N1c2VkO1xuICAgIH1cbiAgICByZXR1cm4gZ2xvYmFsVGhpcy5kb2N1bWVudD8udmlzaWJpbGl0eVN0YXRlICE9PSBcImhpZGRlblwiO1xuICB9XG59O1xudmFyIGZvY3VzTWFuYWdlciA9IG5ldyBGb2N1c01hbmFnZXIoKTtcbmV4cG9ydCB7XG4gIEZvY3VzTWFuYWdlcixcbiAgZm9jdXNNYW5hZ2VyXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Zm9jdXNNYW5hZ2VyLmpzLm1hcCIsIi8vIHNyYy90aW1lb3V0TWFuYWdlci50c1xudmFyIGRlZmF1bHRUaW1lb3V0UHJvdmlkZXIgPSB7XG4gIC8vIFdlIG5lZWQgdGhlIHdyYXBwZXIgZnVuY3Rpb24gc3ludGF4IGJlbG93IGluc3RlYWQgb2YgZGlyZWN0IHJlZmVyZW5jZXMgdG9cbiAgLy8gZ2xvYmFsIHNldFRpbWVvdXQgZXRjLlxuICAvL1xuICAvLyBCQUQ6IGBzZXRUaW1lb3V0OiBzZXRUaW1lb3V0YFxuICAvLyBHT09EOiBgc2V0VGltZW91dDogKGNiLCBkZWxheSkgPT4gc2V0VGltZW91dChjYiwgZGVsYXkpYFxuICAvL1xuICAvLyBJZiB3ZSB1c2UgZGlyZWN0IHJlZmVyZW5jZXMgaGVyZSwgdGhlbiBhbnl0aGluZyB0aGF0IHdhbnRzIHRvIHNweSBvbiBvclxuICAvLyByZXBsYWNlIHRoZSBnbG9iYWwgc2V0VGltZW91dCAobGlrZSB0ZXN0cykgd29uJ3Qgd29yayBzaW5jZSB3ZSdsbCBhbHJlYWR5XG4gIC8vIGhhdmUgYSBoYXJkIHJlZmVyZW5jZSB0byB0aGUgb3JpZ2luYWwgaW1wbGVtZW50YXRpb24gYXQgdGhlIHRpbWUgd2hlbiB0aGlzXG4gIC8vIGZpbGUgd2FzIGltcG9ydGVkLlxuICBzZXRUaW1lb3V0OiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSksXG4gIGNsZWFyVGltZW91dDogKHRpbWVvdXRJZCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCksXG4gIHNldEludGVydmFsOiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRJbnRlcnZhbChjYWxsYmFjaywgZGVsYXkpLFxuICBjbGVhckludGVydmFsOiAoaW50ZXJ2YWxJZCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxufTtcbnZhciBUaW1lb3V0TWFuYWdlciA9IGNsYXNzIHtcbiAgLy8gV2UgY2Fubm90IGhhdmUgVGltZW91dE1hbmFnZXI8VD4gYXMgd2UgbXVzdCBpbnN0YW50aWF0ZSBpdCB3aXRoIGEgY29uY3JldGVcbiAgLy8gdHlwZSBhdCBhcHAgYm9vdDsgYW5kIGlmIHdlIGxlYXZlIHRoYXQgdHlwZSwgdGhlbiBhbnkgbmV3IHRpbWVyIHByb3ZpZGVyXG4gIC8vIHdvdWxkIG5lZWQgdG8gc3VwcG9ydCB0aGUgZGVmYXVsdCBwcm92aWRlcidzIGNvbmNyZXRlIHRpbWVyIElELCB3aGljaCBpc1xuICAvLyBpbmZlYXNpYmxlIGFjcm9zcyBlbnZpcm9ubWVudHMuXG4gIC8vXG4gIC8vIFdlIHNldHRsZSBmb3IgdHlwZSBzYWZldHkgZm9yIHRoZSBUaW1lb3V0UHJvdmlkZXIgdHlwZSwgYW5kIGFjY2VwdCB0aGF0XG4gIC8vIHRoaXMgY2xhc3MgaXMgdW5zYWZlIGludGVybmFsbHkgdG8gYWxsb3cgZm9yIGV4dGVuc2lvbi5cbiAgI3Byb3ZpZGVyID0gZGVmYXVsdFRpbWVvdXRQcm92aWRlcjtcbiAgI3Byb3ZpZGVyQ2FsbGVkID0gZmFsc2U7XG4gIHNldFRpbWVvdXRQcm92aWRlcihwcm92aWRlcikge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIGlmICh0aGlzLiNwcm92aWRlckNhbGxlZCAmJiBwcm92aWRlciAhPT0gdGhpcy4jcHJvdmlkZXIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBgW3RpbWVvdXRNYW5hZ2VyXTogU3dpdGNoaW5nIHByb3ZpZGVyIGFmdGVyIGNhbGxzIHRvIHByZXZpb3VzIHByb3ZpZGVyIG1pZ2h0IHJlc3VsdCBpbiB1bmV4cGVjdGVkIGJlaGF2aW9yLmAsXG4gICAgICAgICAgeyBwcmV2aW91czogdGhpcy4jcHJvdmlkZXIsIHByb3ZpZGVyIH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy4jcHJvdmlkZXIgPSBwcm92aWRlcjtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICB0aGlzLiNwcm92aWRlckNhbGxlZCA9IGZhbHNlO1xuICAgIH1cbiAgfVxuICBzZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSkge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIHRoaXMuI3Byb3ZpZGVyQ2FsbGVkID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuI3Byb3ZpZGVyLnNldFRpbWVvdXQoY2FsbGJhY2ssIGRlbGF5KTtcbiAgfVxuICBjbGVhclRpbWVvdXQodGltZW91dElkKSB7XG4gICAgdGhpcy4jcHJvdmlkZXIuY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gIH1cbiAgc2V0SW50ZXJ2YWwoY2FsbGJhY2ssIGRlbGF5KSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgdGhpcy4jcHJvdmlkZXJDYWxsZWQgPSB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy4jcHJvdmlkZXIuc2V0SW50ZXJ2YWwoY2FsbGJhY2ssIGRlbGF5KTtcbiAgfVxuICBjbGVhckludGVydmFsKGludGVydmFsSWQpIHtcbiAgICB0aGlzLiNwcm92aWRlci5jbGVhckludGVydmFsKGludGVydmFsSWQpO1xuICB9XG59O1xudmFyIHRpbWVvdXRNYW5hZ2VyID0gbmV3IFRpbWVvdXRNYW5hZ2VyKCk7XG5mdW5jdGlvbiBzeXN0ZW1TZXRUaW1lb3V0WmVybyhjYWxsYmFjaykge1xuICBzZXRUaW1lb3V0KGNhbGxiYWNrLCAwKTtcbn1cbmV4cG9ydCB7XG4gIFRpbWVvdXRNYW5hZ2VyLFxuICBkZWZhdWx0VGltZW91dFByb3ZpZGVyLFxuICBzeXN0ZW1TZXRUaW1lb3V0WmVybyxcbiAgdGltZW91dE1hbmFnZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD10aW1lb3V0TWFuYWdlci5qcy5tYXAiLCIvLyBzcmMvdXRpbHMudHNcbmltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbnZhciBpc1NlcnZlciA9IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIgfHwgXCJEZW5vXCIgaW4gZ2xvYmFsVGhpcztcbmZ1bmN0aW9uIG5vb3AoKSB7XG59XG5mdW5jdGlvbiBmdW5jdGlvbmFsVXBkYXRlKHVwZGF0ZXIsIGlucHV0KSB7XG4gIHJldHVybiB0eXBlb2YgdXBkYXRlciA9PT0gXCJmdW5jdGlvblwiID8gdXBkYXRlcihpbnB1dCkgOiB1cGRhdGVyO1xufVxuZnVuY3Rpb24gaXNWYWxpZFRpbWVvdXQodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIiAmJiB2YWx1ZSA+PSAwICYmIHZhbHVlICE9PSBJbmZpbml0eTtcbn1cbmZ1bmN0aW9uIHRpbWVVbnRpbFN0YWxlKHVwZGF0ZWRBdCwgc3RhbGVUaW1lKSB7XG4gIHJldHVybiBNYXRoLm1heCh1cGRhdGVkQXQgKyAoc3RhbGVUaW1lIHx8IDApIC0gRGF0ZS5ub3coKSwgMCk7XG59XG5mdW5jdGlvbiByZXNvbHZlU3RhbGVUaW1lKHN0YWxlVGltZSwgcXVlcnkpIHtcbiAgcmV0dXJuIHR5cGVvZiBzdGFsZVRpbWUgPT09IFwiZnVuY3Rpb25cIiA/IHN0YWxlVGltZShxdWVyeSkgOiBzdGFsZVRpbWU7XG59XG5mdW5jdGlvbiByZXNvbHZlUXVlcnlCb29sZWFuKG9wdGlvbiwgcXVlcnkpIHtcbiAgcmV0dXJuIHR5cGVvZiBvcHRpb24gPT09IFwiZnVuY3Rpb25cIiA/IG9wdGlvbihxdWVyeSkgOiBvcHRpb247XG59XG5mdW5jdGlvbiBtYXRjaFF1ZXJ5KGZpbHRlcnMsIHF1ZXJ5KSB7XG4gIGNvbnN0IHtcbiAgICB0eXBlID0gXCJhbGxcIixcbiAgICBleGFjdCxcbiAgICBmZXRjaFN0YXR1cyxcbiAgICBwcmVkaWNhdGUsXG4gICAgcXVlcnlLZXksXG4gICAgc3RhbGVcbiAgfSA9IGZpbHRlcnM7XG4gIGlmIChxdWVyeUtleSkge1xuICAgIGlmIChleGFjdCkge1xuICAgICAgaWYgKHF1ZXJ5LnF1ZXJ5SGFzaCAhPT0gaGFzaFF1ZXJ5S2V5QnlPcHRpb25zKHF1ZXJ5S2V5LCBxdWVyeS5vcHRpb25zKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KHF1ZXJ5LnF1ZXJ5S2V5LCBxdWVyeUtleSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgaWYgKHR5cGUgIT09IFwiYWxsXCIpIHtcbiAgICBjb25zdCBpc0FjdGl2ZSA9IHF1ZXJ5LmlzQWN0aXZlKCk7XG4gICAgaWYgKHR5cGUgPT09IFwiYWN0aXZlXCIgJiYgIWlzQWN0aXZlKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICh0eXBlID09PSBcImluYWN0aXZlXCIgJiYgaXNBY3RpdmUpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgaWYgKHR5cGVvZiBzdGFsZSA9PT0gXCJib29sZWFuXCIgJiYgcXVlcnkuaXNTdGFsZSgpICE9PSBzdGFsZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoZmV0Y2hTdGF0dXMgJiYgZmV0Y2hTdGF0dXMgIT09IHF1ZXJ5LnN0YXRlLmZldGNoU3RhdHVzKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChwcmVkaWNhdGUgJiYgIXByZWRpY2F0ZShxdWVyeSkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBtYXRjaE11dGF0aW9uKGZpbHRlcnMsIG11dGF0aW9uKSB7XG4gIGNvbnN0IHsgZXhhY3QsIHN0YXR1cywgcHJlZGljYXRlLCBtdXRhdGlvbktleSB9ID0gZmlsdGVycztcbiAgaWYgKG11dGF0aW9uS2V5KSB7XG4gICAgaWYgKCFtdXRhdGlvbi5vcHRpb25zLm11dGF0aW9uS2V5KSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmIChleGFjdCkge1xuICAgICAgaWYgKGhhc2hLZXkobXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkgIT09IGhhc2hLZXkobXV0YXRpb25LZXkpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCFwYXJ0aWFsTWF0Y2hLZXkobXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSwgbXV0YXRpb25LZXkpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIGlmIChzdGF0dXMgJiYgbXV0YXRpb24uc3RhdGUuc3RhdHVzICE9PSBzdGF0dXMpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKHByZWRpY2F0ZSAmJiAhcHJlZGljYXRlKG11dGF0aW9uKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgb3B0aW9ucykge1xuICBjb25zdCBoYXNoRm4gPSBvcHRpb25zPy5xdWVyeUtleUhhc2hGbiB8fCBoYXNoS2V5O1xuICByZXR1cm4gaGFzaEZuKHF1ZXJ5S2V5KTtcbn1cbmZ1bmN0aW9uIGhhc2hLZXkocXVlcnlLZXkpIHtcbiAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KFxuICAgIHF1ZXJ5S2V5LFxuICAgIChfLCB2YWwpID0+IGlzUGxhaW5PYmplY3QodmFsKSA/IE9iamVjdC5rZXlzKHZhbCkuc29ydCgpLnJlZHVjZSgocmVzdWx0LCBrZXkpID0+IHtcbiAgICAgIHJlc3VsdFtrZXldID0gdmFsW2tleV07XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0sIHt9KSA6IHZhbFxuICApO1xufVxuZnVuY3Rpb24gcGFydGlhbE1hdGNoS2V5KGEsIGIpIHtcbiAgaWYgKGEgPT09IGIpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAodHlwZW9mIGEgIT09IHR5cGVvZiBiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChhICYmIGIgJiYgdHlwZW9mIGEgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIGIgPT09IFwib2JqZWN0XCIpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShhKSAmJiBBcnJheS5pc0FycmF5KGIpKSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaWYgKCFwYXJ0aWFsTWF0Y2hLZXkoYVtpXSwgYltpXSkpIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBjb25zdCBiS2V5cyA9IE9iamVjdC5rZXlzKGIpO1xuICAgIGZvciAoY29uc3Qga2V5IG9mIGJLZXlzKSB7XG4gICAgICBpZiAoIXBhcnRpYWxNYXRjaEtleShhW2tleV0sIGJba2V5XSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG52YXIgaGFzT3duID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbmZ1bmN0aW9uIHJlcGxhY2VFcXVhbERlZXAoYSwgYiwgZGVwdGggPSAwKSB7XG4gIGlmIChhID09PSBiKSB7XG4gICAgcmV0dXJuIGE7XG4gIH1cbiAgaWYgKGRlcHRoID4gNTAwKSByZXR1cm4gYjtcbiAgY29uc3QgYXJyYXkgPSBpc1BsYWluQXJyYXkoYSkgJiYgaXNQbGFpbkFycmF5KGIpO1xuICBpZiAoIWFycmF5ICYmICEoaXNQbGFpbk9iamVjdChhKSAmJiBpc1BsYWluT2JqZWN0KGIpKSkgcmV0dXJuIGI7XG4gIGNvbnN0IGFJdGVtcyA9IGFycmF5ID8gYSA6IE9iamVjdC5rZXlzKGEpO1xuICBjb25zdCBhU2l6ZSA9IGFJdGVtcy5sZW5ndGg7XG4gIGNvbnN0IGJJdGVtcyA9IGFycmF5ID8gYiA6IE9iamVjdC5rZXlzKGIpO1xuICBjb25zdCBiU2l6ZSA9IGJJdGVtcy5sZW5ndGg7XG4gIGNvbnN0IGNvcHkgPSBhcnJheSA/IG5ldyBBcnJheShiU2l6ZSkgOiB7fTtcbiAgbGV0IGVxdWFsSXRlbXMgPSAwO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGJTaXplOyBpKyspIHtcbiAgICBjb25zdCBrZXkgPSBhcnJheSA/IGkgOiBiSXRlbXNbaV07XG4gICAgY29uc3QgYUl0ZW0gPSBhW2tleV07XG4gICAgY29uc3QgYkl0ZW0gPSBiW2tleV07XG4gICAgaWYgKGFJdGVtID09PSBiSXRlbSkge1xuICAgICAgY29weVtrZXldID0gYUl0ZW07XG4gICAgICBpZiAoYXJyYXkgPyBpIDwgYVNpemUgOiBoYXNPd24uY2FsbChhLCBrZXkpKSBlcXVhbEl0ZW1zKys7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGFJdGVtID09PSBudWxsIHx8IGJJdGVtID09PSBudWxsIHx8IHR5cGVvZiBhSXRlbSAhPT0gXCJvYmplY3RcIiB8fCB0eXBlb2YgYkl0ZW0gIT09IFwib2JqZWN0XCIpIHtcbiAgICAgIGNvcHlba2V5XSA9IGJJdGVtO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IHYgPSByZXBsYWNlRXF1YWxEZWVwKGFJdGVtLCBiSXRlbSwgZGVwdGggKyAxKTtcbiAgICBjb3B5W2tleV0gPSB2O1xuICAgIGlmICh2ID09PSBhSXRlbSkgZXF1YWxJdGVtcysrO1xuICB9XG4gIHJldHVybiBhU2l6ZSA9PT0gYlNpemUgJiYgZXF1YWxJdGVtcyA9PT0gYVNpemUgPyBhIDogY29weTtcbn1cbmZ1bmN0aW9uIHNoYWxsb3dFcXVhbE9iamVjdHMoYSwgYikge1xuICBpZiAoIWIgfHwgT2JqZWN0LmtleXMoYSkubGVuZ3RoICE9PSBPYmplY3Qua2V5cyhiKS5sZW5ndGgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZm9yIChjb25zdCBrZXkgaW4gYSkge1xuICAgIGlmIChhW2tleV0gIT09IGJba2V5XSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGlzUGxhaW5BcnJheSh2YWx1ZSkge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSkgJiYgdmFsdWUubGVuZ3RoID09PSBPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoO1xufVxuZnVuY3Rpb24gaXNQbGFpbk9iamVjdChvKSB7XG4gIGlmICghaGFzT2JqZWN0UHJvdG90eXBlKG8pKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGNvbnN0IGN0b3IgPSBvLmNvbnN0cnVjdG9yO1xuICBpZiAoY3RvciA9PT0gdm9pZCAwKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgY29uc3QgcHJvdCA9IGN0b3IucHJvdG90eXBlO1xuICBpZiAoIWhhc09iamVjdFByb3RvdHlwZShwcm90KSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoIXByb3QuaGFzT3duUHJvcGVydHkoXCJpc1Byb3RvdHlwZU9mXCIpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChPYmplY3QuZ2V0UHJvdG90eXBlT2YobykgIT09IE9iamVjdC5wcm90b3R5cGUpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBoYXNPYmplY3RQcm90b3R5cGUobykge1xuICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG8pID09PSBcIltvYmplY3QgT2JqZWN0XVwiO1xufVxuZnVuY3Rpb24gc2xlZXAodGltZW91dCkge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KHJlc29sdmUsIHRpbWVvdXQpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHJlcGxhY2VEYXRhKHByZXZEYXRhLCBkYXRhLCBvcHRpb25zKSB7XG4gIGlmICh0eXBlb2Ygb3B0aW9ucy5zdHJ1Y3R1cmFsU2hhcmluZyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIG9wdGlvbnMuc3RydWN0dXJhbFNoYXJpbmcocHJldkRhdGEsIGRhdGEpO1xuICB9IGVsc2UgaWYgKG9wdGlvbnMuc3RydWN0dXJhbFNoYXJpbmcgIT09IGZhbHNlKSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIHJlcGxhY2VFcXVhbERlZXAocHJldkRhdGEsIGRhdGEpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBgU3RydWN0dXJhbCBzaGFyaW5nIHJlcXVpcmVzIGRhdGEgdG8gYmUgSlNPTiBzZXJpYWxpemFibGUuIFRvIGZpeCB0aGlzLCB0dXJuIG9mZiBzdHJ1Y3R1cmFsU2hhcmluZyBvciByZXR1cm4gSlNPTi1zZXJpYWxpemFibGUgZGF0YSBmcm9tIHlvdXIgcXVlcnlGbi4gWyR7b3B0aW9ucy5xdWVyeUhhc2h9XTogJHtlcnJvcn1gXG4gICAgICAgICk7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVwbGFjZUVxdWFsRGVlcChwcmV2RGF0YSwgZGF0YSk7XG4gIH1cbiAgcmV0dXJuIGRhdGE7XG59XG5mdW5jdGlvbiBrZWVwUHJldmlvdXNEYXRhKHByZXZpb3VzRGF0YSkge1xuICByZXR1cm4gcHJldmlvdXNEYXRhO1xufVxuZnVuY3Rpb24gYWRkVG9FbmQoaXRlbXMsIGl0ZW0sIG1heCA9IDApIHtcbiAgY29uc3QgbmV3SXRlbXMgPSBbLi4uaXRlbXMsIGl0ZW1dO1xuICByZXR1cm4gbWF4ICYmIG5ld0l0ZW1zLmxlbmd0aCA+IG1heCA/IG5ld0l0ZW1zLnNsaWNlKDEpIDogbmV3SXRlbXM7XG59XG5mdW5jdGlvbiBhZGRUb1N0YXJ0KGl0ZW1zLCBpdGVtLCBtYXggPSAwKSB7XG4gIGNvbnN0IG5ld0l0ZW1zID0gW2l0ZW0sIC4uLml0ZW1zXTtcbiAgcmV0dXJuIG1heCAmJiBuZXdJdGVtcy5sZW5ndGggPiBtYXggPyBuZXdJdGVtcy5zbGljZSgwLCAtMSkgOiBuZXdJdGVtcztcbn1cbnZhciBza2lwVG9rZW4gPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKCk7XG5mdW5jdGlvbiBlbnN1cmVRdWVyeUZuKG9wdGlvbnMsIGZldGNoT3B0aW9ucykge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgaWYgKG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgQXR0ZW1wdGVkIHRvIGludm9rZSBxdWVyeUZuIHdoZW4gc2V0IHRvIHNraXBUb2tlbi4gVGhpcyBpcyBsaWtlbHkgYSBjb25maWd1cmF0aW9uIGVycm9yLiBRdWVyeSBoYXNoOiAnJHtvcHRpb25zLnF1ZXJ5SGFzaH0nYFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgaWYgKCFvcHRpb25zLnF1ZXJ5Rm4gJiYgZmV0Y2hPcHRpb25zPy5pbml0aWFsUHJvbWlzZSkge1xuICAgIHJldHVybiAoKSA9PiBmZXRjaE9wdGlvbnMuaW5pdGlhbFByb21pc2U7XG4gIH1cbiAgaWYgKCFvcHRpb25zLnF1ZXJ5Rm4gfHwgb3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIHtcbiAgICByZXR1cm4gKCkgPT4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKGBNaXNzaW5nIHF1ZXJ5Rm46ICcke29wdGlvbnMucXVlcnlIYXNofSdgKSk7XG4gIH1cbiAgcmV0dXJuIG9wdGlvbnMucXVlcnlGbjtcbn1cbmZ1bmN0aW9uIHNob3VsZFRocm93RXJyb3IodGhyb3dPbkVycm9yLCBwYXJhbXMpIHtcbiAgaWYgKHR5cGVvZiB0aHJvd09uRXJyb3IgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHJldHVybiB0aHJvd09uRXJyb3IoLi4ucGFyYW1zKTtcbiAgfVxuICByZXR1cm4gISF0aHJvd09uRXJyb3I7XG59XG5mdW5jdGlvbiBhZGRDb25zdW1lQXdhcmVTaWduYWwob2JqZWN0LCBnZXRTaWduYWwsIG9uQ2FuY2VsbGVkKSB7XG4gIGxldCBjb25zdW1lZCA9IGZhbHNlO1xuICBsZXQgc2lnbmFsO1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqZWN0LCBcInNpZ25hbFwiLCB7XG4gICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICBnZXQ6ICgpID0+IHtcbiAgICAgIHNpZ25hbCA/Pz0gZ2V0U2lnbmFsKCk7XG4gICAgICBpZiAoY29uc3VtZWQpIHtcbiAgICAgICAgcmV0dXJuIHNpZ25hbDtcbiAgICAgIH1cbiAgICAgIGNvbnN1bWVkID0gdHJ1ZTtcbiAgICAgIGlmIChzaWduYWwuYWJvcnRlZCkge1xuICAgICAgICBvbkNhbmNlbGxlZCgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBvbkNhbmNlbGxlZCwgeyBvbmNlOiB0cnVlIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHNpZ25hbDtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gb2JqZWN0O1xufVxuZXhwb3J0IHtcbiAgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLFxuICBhZGRUb0VuZCxcbiAgYWRkVG9TdGFydCxcbiAgZW5zdXJlUXVlcnlGbixcbiAgZnVuY3Rpb25hbFVwZGF0ZSxcbiAgaGFzaEtleSxcbiAgaGFzaFF1ZXJ5S2V5QnlPcHRpb25zLFxuICBpc1BsYWluQXJyYXksXG4gIGlzUGxhaW5PYmplY3QsXG4gIGlzU2VydmVyLFxuICBpc1ZhbGlkVGltZW91dCxcbiAga2VlcFByZXZpb3VzRGF0YSxcbiAgbWF0Y2hNdXRhdGlvbixcbiAgbWF0Y2hRdWVyeSxcbiAgbm9vcCxcbiAgcGFydGlhbE1hdGNoS2V5LFxuICByZXBsYWNlRGF0YSxcbiAgcmVwbGFjZUVxdWFsRGVlcCxcbiAgcmVzb2x2ZVF1ZXJ5Qm9vbGVhbixcbiAgcmVzb2x2ZVN0YWxlVGltZSxcbiAgc2hhbGxvd0VxdWFsT2JqZWN0cyxcbiAgc2hvdWxkVGhyb3dFcnJvcixcbiAgc2tpcFRva2VuLFxuICBzbGVlcCxcbiAgdGltZVVudGlsU3RhbGVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11dGlscy5qcy5tYXAiLCIvLyBzcmMvZW52aXJvbm1lbnRNYW5hZ2VyLnRzXG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG52YXIgZW52aXJvbm1lbnRNYW5hZ2VyID0gLyogQF9fUFVSRV9fICovICgoKSA9PiB7XG4gIGxldCBpc1NlcnZlckZuID0gKCkgPT4gaXNTZXJ2ZXI7XG4gIHJldHVybiB7XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB3aGV0aGVyIHRoZSBjdXJyZW50IHJ1bnRpbWUgc2hvdWxkIGJlIHRyZWF0ZWQgYXMgYSBzZXJ2ZXIgZW52aXJvbm1lbnQuXG4gICAgICovXG4gICAgaXNTZXJ2ZXIoKSB7XG4gICAgICByZXR1cm4gaXNTZXJ2ZXJGbigpO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogT3ZlcnJpZGVzIHRoZSBzZXJ2ZXIgY2hlY2sgZ2xvYmFsbHkuXG4gICAgICovXG4gICAgc2V0SXNTZXJ2ZXIoaXNTZXJ2ZXJWYWx1ZSkge1xuICAgICAgaXNTZXJ2ZXJGbiA9IGlzU2VydmVyVmFsdWU7XG4gICAgfVxuICB9O1xufSkoKTtcbmV4cG9ydCB7XG4gIGVudmlyb25tZW50TWFuYWdlclxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVudmlyb25tZW50TWFuYWdlci5qcy5tYXAiLCIvLyBzcmMvdGhlbmFibGUudHNcbmltcG9ydCB7IG5vb3AgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuZnVuY3Rpb24gcGVuZGluZ1RoZW5hYmxlKCkge1xuICBsZXQgcmVzb2x2ZTtcbiAgbGV0IHJlamVjdDtcbiAgY29uc3QgdGhlbmFibGUgPSBuZXcgUHJvbWlzZSgoX3Jlc29sdmUsIF9yZWplY3QpID0+IHtcbiAgICByZXNvbHZlID0gX3Jlc29sdmU7XG4gICAgcmVqZWN0ID0gX3JlamVjdDtcbiAgfSk7XG4gIHRoZW5hYmxlLnN0YXR1cyA9IFwicGVuZGluZ1wiO1xuICB0aGVuYWJsZS5jYXRjaCgoKSA9PiB7XG4gIH0pO1xuICBmdW5jdGlvbiBmaW5hbGl6ZShkYXRhKSB7XG4gICAgT2JqZWN0LmFzc2lnbih0aGVuYWJsZSwgZGF0YSk7XG4gICAgZGVsZXRlIHRoZW5hYmxlLnJlc29sdmU7XG4gICAgZGVsZXRlIHRoZW5hYmxlLnJlamVjdDtcbiAgfVxuICB0aGVuYWJsZS5yZXNvbHZlID0gKHZhbHVlKSA9PiB7XG4gICAgZmluYWxpemUoe1xuICAgICAgc3RhdHVzOiBcImZ1bGZpbGxlZFwiLFxuICAgICAgdmFsdWVcbiAgICB9KTtcbiAgICByZXNvbHZlKHZhbHVlKTtcbiAgfTtcbiAgdGhlbmFibGUucmVqZWN0ID0gKHJlYXNvbikgPT4ge1xuICAgIGZpbmFsaXplKHtcbiAgICAgIHN0YXR1czogXCJyZWplY3RlZFwiLFxuICAgICAgcmVhc29uXG4gICAgfSk7XG4gICAgcmVqZWN0KHJlYXNvbik7XG4gIH07XG4gIHJldHVybiB0aGVuYWJsZTtcbn1cbmZ1bmN0aW9uIHRyeVJlc29sdmVTeW5jKHByb21pc2UpIHtcbiAgbGV0IGRhdGE7XG4gIHByb21pc2UudGhlbigocmVzdWx0KSA9PiB7XG4gICAgZGF0YSA9IHJlc3VsdDtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9LCBub29wKT8uY2F0Y2gobm9vcCk7XG4gIGlmIChkYXRhICE9PSB2b2lkIDApIHtcbiAgICByZXR1cm4geyBkYXRhIH07XG4gIH1cbiAgcmV0dXJuIHZvaWQgMDtcbn1cbmV4cG9ydCB7XG4gIHBlbmRpbmdUaGVuYWJsZSxcbiAgdHJ5UmVzb2x2ZVN5bmNcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD10aGVuYWJsZS5qcy5tYXAiLCIvLyBzcmMvaHlkcmF0aW9uLnRzXG5pbXBvcnQgeyB0cnlSZXNvbHZlU3luYyB9IGZyb20gXCIuL3RoZW5hYmxlLmpzXCI7XG5pbXBvcnQgeyBub29wIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmZ1bmN0aW9uIGRlZmF1bHRUcmFuc2Zvcm1lckZuKGRhdGEpIHtcbiAgcmV0dXJuIGRhdGE7XG59XG5mdW5jdGlvbiBkZWh5ZHJhdGVNdXRhdGlvbihtdXRhdGlvbikge1xuICByZXR1cm4ge1xuICAgIG11dGF0aW9uS2V5OiBtdXRhdGlvbi5vcHRpb25zLm11dGF0aW9uS2V5LFxuICAgIHN0YXRlOiBtdXRhdGlvbi5zdGF0ZSxcbiAgICAuLi5tdXRhdGlvbi5vcHRpb25zLnNjb3BlICYmIHsgc2NvcGU6IG11dGF0aW9uLm9wdGlvbnMuc2NvcGUgfSxcbiAgICAuLi5tdXRhdGlvbi5tZXRhICYmIHsgbWV0YTogbXV0YXRpb24ubWV0YSB9XG4gIH07XG59XG5mdW5jdGlvbiBkZWh5ZHJhdGVRdWVyeShxdWVyeSwgc2VyaWFsaXplRGF0YSwgc2hvdWxkUmVkYWN0RXJyb3JzKSB7XG4gIGNvbnN0IGRlaHlkcmF0ZVByb21pc2UgPSAoKSA9PiB7XG4gICAgY29uc3QgcHJvbWlzZSA9IHF1ZXJ5LnByb21pc2U/LnRoZW4oc2VyaWFsaXplRGF0YSkuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICBpZiAoIXNob3VsZFJlZGFjdEVycm9ycyhlcnJvcikpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICAgIH1cbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBgQSBxdWVyeSB0aGF0IHdhcyBkZWh5ZHJhdGVkIGFzIHBlbmRpbmcgZW5kZWQgdXAgcmVqZWN0aW5nLiBbJHtxdWVyeS5xdWVyeUhhc2h9XTogJHtlcnJvcn07IFRoZSBlcnJvciB3aWxsIGJlIHJlZGFjdGVkIGluIHByb2R1Y3Rpb24gYnVpbGRzYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcInJlZGFjdGVkXCIpKTtcbiAgICB9KTtcbiAgICBwcm9taXNlPy5jYXRjaChub29wKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbiAgfTtcbiAgcmV0dXJuIHtcbiAgICBkZWh5ZHJhdGVkQXQ6IERhdGUubm93KCksXG4gICAgc3RhdGU6IHtcbiAgICAgIC4uLnF1ZXJ5LnN0YXRlLFxuICAgICAgLi4ucXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwICYmIHtcbiAgICAgICAgZGF0YTogc2VyaWFsaXplRGF0YShxdWVyeS5zdGF0ZS5kYXRhKVxuICAgICAgfVxuICAgIH0sXG4gICAgcXVlcnlLZXk6IHF1ZXJ5LnF1ZXJ5S2V5LFxuICAgIHF1ZXJ5SGFzaDogcXVlcnkucXVlcnlIYXNoLFxuICAgIC4uLnF1ZXJ5LnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYge1xuICAgICAgcHJvbWlzZTogZGVoeWRyYXRlUHJvbWlzZSgpXG4gICAgfSxcbiAgICAuLi5xdWVyeS5tZXRhICYmIHsgbWV0YTogcXVlcnkubWV0YSB9LFxuICAgIC4uLnF1ZXJ5LnF1ZXJ5VHlwZSAmJiB7IHF1ZXJ5VHlwZTogcXVlcnkucXVlcnlUeXBlIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGRlZmF1bHRTaG91bGREZWh5ZHJhdGVNdXRhdGlvbihtdXRhdGlvbikge1xuICByZXR1cm4gbXV0YXRpb24uc3RhdGUuaXNQYXVzZWQ7XG59XG5mdW5jdGlvbiBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnkocXVlcnkpIHtcbiAgcmV0dXJuIHF1ZXJ5LnN0YXRlLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCI7XG59XG5mdW5jdGlvbiBkZWZhdWx0U2hvdWxkUmVkYWN0RXJyb3JzKF8pIHtcbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBkZWh5ZHJhdGUoY2xpZW50LCBvcHRpb25zID0ge30pIHtcbiAgY29uc3QgZmlsdGVyTXV0YXRpb24gPSBvcHRpb25zLnNob3VsZERlaHlkcmF0ZU11dGF0aW9uID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2hvdWxkRGVoeWRyYXRlTXV0YXRpb24gPz8gZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uO1xuICBjb25zdCBtdXRhdGlvbnMgPSBjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpLmdldEFsbCgpLmZsYXRNYXAoXG4gICAgKG11dGF0aW9uKSA9PiBmaWx0ZXJNdXRhdGlvbihtdXRhdGlvbikgPyBbZGVoeWRyYXRlTXV0YXRpb24obXV0YXRpb24pXSA6IFtdXG4gICk7XG4gIGNvbnN0IGZpbHRlclF1ZXJ5ID0gb3B0aW9ucy5zaG91bGREZWh5ZHJhdGVRdWVyeSA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5kZWh5ZHJhdGU/LnNob3VsZERlaHlkcmF0ZVF1ZXJ5ID8/IGRlZmF1bHRTaG91bGREZWh5ZHJhdGVRdWVyeTtcbiAgY29uc3Qgc2hvdWxkUmVkYWN0RXJyb3JzID0gb3B0aW9ucy5zaG91bGRSZWRhY3RFcnJvcnMgPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuZGVoeWRyYXRlPy5zaG91bGRSZWRhY3RFcnJvcnMgPz8gZGVmYXVsdFNob3VsZFJlZGFjdEVycm9ycztcbiAgY29uc3Qgc2VyaWFsaXplRGF0YSA9IG9wdGlvbnMuc2VyaWFsaXplRGF0YSA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5kZWh5ZHJhdGU/LnNlcmlhbGl6ZURhdGEgPz8gZGVmYXVsdFRyYW5zZm9ybWVyRm47XG4gIGNvbnN0IHF1ZXJpZXMgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldEFsbCgpLmZsYXRNYXAoXG4gICAgKHF1ZXJ5KSA9PiBmaWx0ZXJRdWVyeShxdWVyeSkgPyBbZGVoeWRyYXRlUXVlcnkocXVlcnksIHNlcmlhbGl6ZURhdGEsIHNob3VsZFJlZGFjdEVycm9ycyldIDogW11cbiAgKTtcbiAgcmV0dXJuIHsgbXV0YXRpb25zLCBxdWVyaWVzIH07XG59XG5mdW5jdGlvbiBoeWRyYXRlKGNsaWVudCwgZGVoeWRyYXRlZFN0YXRlLCBvcHRpb25zKSB7XG4gIGlmICh0eXBlb2YgZGVoeWRyYXRlZFN0YXRlICE9PSBcIm9iamVjdFwiIHx8IGRlaHlkcmF0ZWRTdGF0ZSA9PT0gbnVsbCkge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBtdXRhdGlvbkNhY2hlID0gY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKTtcbiAgY29uc3QgcXVlcnlDYWNoZSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCk7XG4gIGNvbnN0IGRlc2VyaWFsaXplRGF0YSA9IG9wdGlvbnM/LmRlZmF1bHRPcHRpb25zPy5kZXNlcmlhbGl6ZURhdGEgPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuaHlkcmF0ZT8uZGVzZXJpYWxpemVEYXRhID8/IGRlZmF1bHRUcmFuc2Zvcm1lckZuO1xuICBjb25zdCBtdXRhdGlvbnMgPSBkZWh5ZHJhdGVkU3RhdGUubXV0YXRpb25zIHx8IFtdO1xuICBjb25zdCBxdWVyaWVzID0gZGVoeWRyYXRlZFN0YXRlLnF1ZXJpZXMgfHwgW107XG4gIG11dGF0aW9ucy5mb3JFYWNoKCh7IHN0YXRlLCAuLi5tdXRhdGlvbk9wdGlvbnMgfSkgPT4ge1xuICAgIG11dGF0aW9uQ2FjaGUuYnVpbGQoXG4gICAgICBjbGllbnQsXG4gICAgICB7XG4gICAgICAgIC4uLmNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmh5ZHJhdGU/Lm11dGF0aW9ucyxcbiAgICAgICAgLi4ub3B0aW9ucz8uZGVmYXVsdE9wdGlvbnM/Lm11dGF0aW9ucyxcbiAgICAgICAgLi4ubXV0YXRpb25PcHRpb25zXG4gICAgICB9LFxuICAgICAgc3RhdGVcbiAgICApO1xuICB9KTtcbiAgcXVlcmllcy5mb3JFYWNoKFxuICAgICh7XG4gICAgICBxdWVyeUtleSxcbiAgICAgIHN0YXRlLFxuICAgICAgcXVlcnlIYXNoLFxuICAgICAgbWV0YSxcbiAgICAgIHByb21pc2UsXG4gICAgICBkZWh5ZHJhdGVkQXQsXG4gICAgICBxdWVyeVR5cGVcbiAgICB9KSA9PiB7XG4gICAgICBjb25zdCBzeW5jRGF0YSA9IHByb21pc2UgPyB0cnlSZXNvbHZlU3luYyhwcm9taXNlKSA6IHZvaWQgMDtcbiAgICAgIGNvbnN0IHJhd0RhdGEgPSBzdGF0ZS5kYXRhID09PSB2b2lkIDAgPyBzeW5jRGF0YT8uZGF0YSA6IHN0YXRlLmRhdGE7XG4gICAgICBjb25zdCBkYXRhID0gcmF3RGF0YSA9PT0gdm9pZCAwID8gcmF3RGF0YSA6IGRlc2VyaWFsaXplRGF0YShyYXdEYXRhKTtcbiAgICAgIGxldCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZ2V0KHF1ZXJ5SGFzaCk7XG4gICAgICBjb25zdCBleGlzdGluZ1F1ZXJ5SXNQZW5kaW5nID0gcXVlcnk/LnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG4gICAgICBjb25zdCBleGlzdGluZ1F1ZXJ5SXNGZXRjaGluZyA9IHF1ZXJ5Py5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJmZXRjaGluZ1wiO1xuICAgICAgaWYgKHF1ZXJ5KSB7XG4gICAgICAgIGNvbnN0IGhhc05ld2VyU3luY0RhdGEgPSBzeW5jRGF0YSAmJiAvLyBXZSBvbmx5IG5lZWQgdGhpcyB1bmRlZmluZWQgY2hlY2sgdG8gaGFuZGxlIG9sZGVyIGRlaHlkcmF0aW9uXG4gICAgICAgIC8vIHBheWxvYWRzIHRoYXQgbWlnaHQgbm90IGhhdmUgZGVoeWRyYXRlZEF0XG4gICAgICAgIGRlaHlkcmF0ZWRBdCAhPT0gdm9pZCAwICYmIGRlaHlkcmF0ZWRBdCA+IHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQ7XG4gICAgICAgIGlmIChzdGF0ZS5kYXRhVXBkYXRlZEF0ID4gcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCB8fCBoYXNOZXdlclN5bmNEYXRhKSB7XG4gICAgICAgICAgY29uc3QgeyBmZXRjaFN0YXR1czogX2lnbm9yZWQsIC4uLnNlcmlhbGl6ZWRTdGF0ZSB9ID0gc3RhdGU7XG4gICAgICAgICAgcXVlcnkuc2V0U3RhdGUoe1xuICAgICAgICAgICAgLi4uc2VyaWFsaXplZFN0YXRlLFxuICAgICAgICAgICAgZGF0YSxcbiAgICAgICAgICAgIC8vIElmIHRoZSBxdWVyeSB3YXMgcGVuZGluZyBhdCB0aGUgbW9tZW50IG9mIGRlaHlkcmF0aW9uLCBidXQgcmVzb2x2ZWQgdG8gaGF2ZSBkYXRhXG4gICAgICAgICAgICAvLyBiZWZvcmUgaHlkcmF0aW9uLCB3ZSBjYW4gYXNzdW1lIHRoZSBxdWVyeSBzaG91bGQgYmUgaHlkcmF0ZWQgYXMgc3VjY2Vzc2Z1bC5cbiAgICAgICAgICAgIC8vXG4gICAgICAgICAgICAvLyBTaW5jZSB5b3UgY2FuIG9wdCBpbnRvIGRlaHlkcmF0aW5nIGZhaWxlZCBxdWVyaWVzLCBhbmQgdGhvc2UgY2FuIGhhdmUgZGF0YSBmcm9tXG4gICAgICAgICAgICAvLyBwcmV2aW91cyBzdWNjZXNzZnVsIGZldGNoZXMsIHdlIG1ha2Ugc3VyZSB3ZSBvbmx5IGRvIHRoaXMgZm9yIHBlbmRpbmcgcXVlcmllcy5cbiAgICAgICAgICAgIC4uLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgZGF0YSAhPT0gdm9pZCAwICYmIHtcbiAgICAgICAgICAgICAgc3RhdHVzOiBcInN1Y2Nlc3NcIixcbiAgICAgICAgICAgICAgZGF0YVVwZGF0ZWRBdDogZGVoeWRyYXRlZEF0ID8/IERhdGUubm93KCksXG4gICAgICAgICAgICAgIC8vIFByZXNlcnZlIGV4aXN0aW5nIGZldGNoU3RhdHVzIGlmIHRoZSBleGlzdGluZyBxdWVyeSBpcyBhY3RpdmVseSBmZXRjaGluZy5cbiAgICAgICAgICAgICAgLi4uIWV4aXN0aW5nUXVlcnlJc0ZldGNoaW5nICYmIHtcbiAgICAgICAgICAgICAgICBmZXRjaFN0YXR1czogXCJpZGxlXCJcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBxdWVyeSA9IHF1ZXJ5Q2FjaGUuYnVpbGQoXG4gICAgICAgICAgY2xpZW50LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIC4uLmNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmh5ZHJhdGU/LnF1ZXJpZXMsXG4gICAgICAgICAgICAuLi5vcHRpb25zPy5kZWZhdWx0T3B0aW9ucz8ucXVlcmllcyxcbiAgICAgICAgICAgIHF1ZXJ5S2V5LFxuICAgICAgICAgICAgcXVlcnlIYXNoLFxuICAgICAgICAgICAgbWV0YSxcbiAgICAgICAgICAgIF90eXBlOiBxdWVyeVR5cGVcbiAgICAgICAgICB9LFxuICAgICAgICAgIC8vIFJlc2V0IGZldGNoIHN0YXR1cyB0byBpZGxlIHRvIGF2b2lkXG4gICAgICAgICAgLy8gcXVlcnkgYmVpbmcgc3R1Y2sgaW4gZmV0Y2hpbmcgc3RhdGUgdXBvbiBoeWRyYXRpb25cbiAgICAgICAgICB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIGRhdGEsXG4gICAgICAgICAgICBmZXRjaFN0YXR1czogXCJpZGxlXCIsXG4gICAgICAgICAgICAvLyBMaWtlIGFib3ZlLCBpZiB0aGUgcXVlcnkgd2FzIHBlbmRpbmcgYXQgdGhlIG1vbWVudCBvZiBkZWh5ZHJhdGlvbiBidXQgaGFzIGRhdGEsXG4gICAgICAgICAgICAvLyB3ZSBjYW4gYXNzdW1lIGl0IHNob3VsZCBiZSBoeWRyYXRlZCBhcyBzdWNjZXNzZnVsLlxuICAgICAgICAgICAgc3RhdHVzOiBzdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIGRhdGEgIT09IHZvaWQgMCA/IFwic3VjY2Vzc1wiIDogc3RhdGUuc3RhdHVzLFxuICAgICAgICAgICAgLi4uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiBkYXRhICE9PSB2b2lkIDAgJiYge1xuICAgICAgICAgICAgICBkYXRhVXBkYXRlZEF0OiBkZWh5ZHJhdGVkQXQgPz8gRGF0ZS5ub3coKVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChwcm9taXNlICYmIC8vIElmIHRoZSBkYXRhIHdhcyBzeW5jaHJvbm91c2x5IGF2YWlsYWJsZSwgdGhlcmUgaXMgbm8gbmVlZCB0byBzZXQgdXBcbiAgICAgIC8vIGEgcmV0cnllciBhbmQgdGh1cyBubyByZWFzb24gdG8gY2FsbCBmZXRjaFxuICAgICAgIXN5bmNEYXRhICYmICFleGlzdGluZ1F1ZXJ5SXNQZW5kaW5nICYmICFleGlzdGluZ1F1ZXJ5SXNGZXRjaGluZyAmJiAvLyBPbmx5IGh5ZHJhdGUgaWYgZGVoeWRyYXRpb24gaXMgbmV3ZXIgdGhhbiBhbnkgZXhpc3RpbmcgZGF0YSxcbiAgICAgIC8vIHRoaXMgaXMgYWx3YXlzIHRydWUgZm9yIG5ldyBxdWVyaWVzXG4gICAgICAoZGVoeWRyYXRlZEF0ID09PSB2b2lkIDAgfHwgZGVoeWRyYXRlZEF0ID4gcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCkpIHtcbiAgICAgICAgcXVlcnkuZmV0Y2godm9pZCAwLCB7XG4gICAgICAgICAgLy8gUlNDIHRyYW5zZm9ybWVkIHByb21pc2VzIGFyZSBub3QgdGhlbmFibGVcbiAgICAgICAgICBpbml0aWFsUHJvbWlzZTogUHJvbWlzZS5yZXNvbHZlKHByb21pc2UpLnRoZW4oZGVzZXJpYWxpemVEYXRhKVxuICAgICAgICB9KS5jYXRjaChub29wKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG59XG5leHBvcnQge1xuICBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlTXV0YXRpb24sXG4gIGRlZmF1bHRTaG91bGREZWh5ZHJhdGVRdWVyeSxcbiAgZGVoeWRyYXRlLFxuICBoeWRyYXRlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aHlkcmF0aW9uLmpzLm1hcCIsIi8vIHNyYy9ub3RpZnlNYW5hZ2VyLnRzXG5pbXBvcnQgeyBzeXN0ZW1TZXRUaW1lb3V0WmVybyB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG52YXIgZGVmYXVsdFNjaGVkdWxlciA9IHN5c3RlbVNldFRpbWVvdXRaZXJvO1xuZnVuY3Rpb24gY3JlYXRlTm90aWZ5TWFuYWdlcigpIHtcbiAgbGV0IHF1ZXVlID0gW107XG4gIGxldCB0cmFuc2FjdGlvbnMgPSAwO1xuICBsZXQgbm90aWZ5Rm4gPSAoY2FsbGJhY2spID0+IHtcbiAgICBjYWxsYmFjaygpO1xuICB9O1xuICBsZXQgYmF0Y2hOb3RpZnlGbiA9IChjYWxsYmFjaykgPT4ge1xuICAgIGNhbGxiYWNrKCk7XG4gIH07XG4gIGxldCBzY2hlZHVsZUZuID0gZGVmYXVsdFNjaGVkdWxlcjtcbiAgY29uc3Qgc2NoZWR1bGUgPSAoY2FsbGJhY2spID0+IHtcbiAgICBpZiAodHJhbnNhY3Rpb25zKSB7XG4gICAgICBxdWV1ZS5wdXNoKGNhbGxiYWNrKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2NoZWR1bGVGbigoKSA9PiB7XG4gICAgICAgIG5vdGlmeUZuKGNhbGxiYWNrKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgZmx1c2ggPSAoKSA9PiB7XG4gICAgY29uc3Qgb3JpZ2luYWxRdWV1ZSA9IHF1ZXVlO1xuICAgIHF1ZXVlID0gW107XG4gICAgaWYgKG9yaWdpbmFsUXVldWUubGVuZ3RoKSB7XG4gICAgICBzY2hlZHVsZUZuKCgpID0+IHtcbiAgICAgICAgYmF0Y2hOb3RpZnlGbigoKSA9PiB7XG4gICAgICAgICAgb3JpZ2luYWxRdWV1ZS5mb3JFYWNoKChjYWxsYmFjaykgPT4ge1xuICAgICAgICAgICAgbm90aWZ5Rm4oY2FsbGJhY2spO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIHtcbiAgICBiYXRjaDogKGNhbGxiYWNrKSA9PiB7XG4gICAgICBsZXQgcmVzdWx0O1xuICAgICAgdHJhbnNhY3Rpb25zKys7XG4gICAgICB0cnkge1xuICAgICAgICByZXN1bHQgPSBjYWxsYmFjaygpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgdHJhbnNhY3Rpb25zLS07XG4gICAgICAgIGlmICghdHJhbnNhY3Rpb25zKSB7XG4gICAgICAgICAgZmx1c2goKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIEFsbCBjYWxscyB0byB0aGUgd3JhcHBlZCBmdW5jdGlvbiB3aWxsIGJlIGJhdGNoZWQuXG4gICAgICovXG4gICAgYmF0Y2hDYWxsczogKGNhbGxiYWNrKSA9PiB7XG4gICAgICByZXR1cm4gKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgc2NoZWR1bGUoKCkgPT4ge1xuICAgICAgICAgIGNhbGxiYWNrKC4uLmFyZ3MpO1xuICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgfSxcbiAgICBzY2hlZHVsZSxcbiAgICAvKipcbiAgICAgKiBVc2UgdGhpcyBtZXRob2QgdG8gc2V0IGEgY3VzdG9tIG5vdGlmeSBmdW5jdGlvbi5cbiAgICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGZvciBleGFtcGxlIHdyYXAgbm90aWZpY2F0aW9ucyB3aXRoIGBSZWFjdC5hY3RgIHdoaWxlIHJ1bm5pbmcgdGVzdHMuXG4gICAgICovXG4gICAgc2V0Tm90aWZ5RnVuY3Rpb246IChmbikgPT4ge1xuICAgICAgbm90aWZ5Rm4gPSBmbjtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIFVzZSB0aGlzIG1ldGhvZCB0byBzZXQgYSBjdXN0b20gZnVuY3Rpb24gdG8gYmF0Y2ggbm90aWZpY2F0aW9ucyB0b2dldGhlciBpbnRvIGEgc2luZ2xlIHRpY2suXG4gICAgICogQnkgZGVmYXVsdCBSZWFjdCBRdWVyeSB3aWxsIHVzZSB0aGUgYmF0Y2ggZnVuY3Rpb24gcHJvdmlkZWQgYnkgUmVhY3RET00gb3IgUmVhY3QgTmF0aXZlLlxuICAgICAqL1xuICAgIHNldEJhdGNoTm90aWZ5RnVuY3Rpb246IChmbikgPT4ge1xuICAgICAgYmF0Y2hOb3RpZnlGbiA9IGZuO1xuICAgIH0sXG4gICAgc2V0U2NoZWR1bGVyOiAoZm4pID0+IHtcbiAgICAgIHNjaGVkdWxlRm4gPSBmbjtcbiAgICB9XG4gIH07XG59XG52YXIgbm90aWZ5TWFuYWdlciA9IGNyZWF0ZU5vdGlmeU1hbmFnZXIoKTtcbmV4cG9ydCB7XG4gIGNyZWF0ZU5vdGlmeU1hbmFnZXIsXG4gIGRlZmF1bHRTY2hlZHVsZXIsXG4gIG5vdGlmeU1hbmFnZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1ub3RpZnlNYW5hZ2VyLmpzLm1hcCIsIi8vIHNyYy9vbmxpbmVNYW5hZ2VyLnRzXG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbnZhciBPbmxpbmVNYW5hZ2VyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuICAjb25saW5lID0gdHJ1ZTtcbiAgI2NsZWFudXA7XG4gICNzZXR1cDtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLiNzZXR1cCA9IChvbk9ubGluZSkgPT4ge1xuICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIpIHtcbiAgICAgICAgY29uc3Qgb25saW5lTGlzdGVuZXIgPSAoKSA9PiBvbk9ubGluZSh0cnVlKTtcbiAgICAgICAgY29uc3Qgb2ZmbGluZUxpc3RlbmVyID0gKCkgPT4gb25PbmxpbmUoZmFsc2UpO1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm9ubGluZVwiLCBvbmxpbmVMaXN0ZW5lciwgZmFsc2UpO1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm9mZmxpbmVcIiwgb2ZmbGluZUxpc3RlbmVyLCBmYWxzZSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJvbmxpbmVcIiwgb25saW5lTGlzdGVuZXIpO1xuICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwib2ZmbGluZVwiLCBvZmZsaW5lTGlzdGVuZXIpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH07XG4gIH1cbiAgb25TdWJzY3JpYmUoKSB7XG4gICAgaWYgKCF0aGlzLiNjbGVhbnVwKSB7XG4gICAgICB0aGlzLnNldEV2ZW50TGlzdGVuZXIodGhpcy4jc2V0dXApO1xuICAgIH1cbiAgfVxuICBvblVuc3Vic2NyaWJlKCkge1xuICAgIGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuICAgICAgdGhpcy4jY2xlYW51cD8uKCk7XG4gICAgICB0aGlzLiNjbGVhbnVwID0gdm9pZCAwO1xuICAgIH1cbiAgfVxuICBzZXRFdmVudExpc3RlbmVyKHNldHVwKSB7XG4gICAgdGhpcy4jc2V0dXAgPSBzZXR1cDtcbiAgICB0aGlzLiNjbGVhbnVwPy4oKTtcbiAgICB0aGlzLiNjbGVhbnVwID0gc2V0dXAodGhpcy5zZXRPbmxpbmUuYmluZCh0aGlzKSk7XG4gIH1cbiAgc2V0T25saW5lKG9ubGluZSkge1xuICAgIGNvbnN0IGNoYW5nZWQgPSB0aGlzLiNvbmxpbmUgIT09IG9ubGluZTtcbiAgICBpZiAoY2hhbmdlZCkge1xuICAgICAgdGhpcy4jb25saW5lID0gb25saW5lO1xuICAgICAgdGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcbiAgICAgICAgbGlzdGVuZXIob25saW5lKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBpc09ubGluZSgpIHtcbiAgICByZXR1cm4gdGhpcy4jb25saW5lO1xuICB9XG59O1xudmFyIG9ubGluZU1hbmFnZXIgPSBuZXcgT25saW5lTWFuYWdlcigpO1xuZXhwb3J0IHtcbiAgT25saW5lTWFuYWdlcixcbiAgb25saW5lTWFuYWdlclxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW9ubGluZU1hbmFnZXIuanMubWFwIiwiLy8gc3JjL3JldHJ5ZXIudHNcbmltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gXCIuL2ZvY3VzTWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgb25saW5lTWFuYWdlciB9IGZyb20gXCIuL29ubGluZU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IHBlbmRpbmdUaGVuYWJsZSB9IGZyb20gXCIuL3RoZW5hYmxlLmpzXCI7XG5pbXBvcnQgeyBlbnZpcm9ubWVudE1hbmFnZXIgfSBmcm9tIFwiLi9lbnZpcm9ubWVudE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IHNsZWVwIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmZ1bmN0aW9uIGRlZmF1bHRSZXRyeURlbGF5KGZhaWx1cmVDb3VudCkge1xuICByZXR1cm4gTWF0aC5taW4oMWUzICogMiAqKiBmYWlsdXJlQ291bnQsIDNlNCk7XG59XG5mdW5jdGlvbiBjYW5GZXRjaChuZXR3b3JrTW9kZSkge1xuICByZXR1cm4gKG5ldHdvcmtNb2RlID8/IFwib25saW5lXCIpID09PSBcIm9ubGluZVwiID8gb25saW5lTWFuYWdlci5pc09ubGluZSgpIDogdHJ1ZTtcbn1cbnZhciBDYW5jZWxsZWRFcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgc3VwZXIoXCJDYW5jZWxsZWRFcnJvclwiKTtcbiAgICB0aGlzLnJldmVydCA9IG9wdGlvbnM/LnJldmVydDtcbiAgICB0aGlzLnNpbGVudCA9IG9wdGlvbnM/LnNpbGVudDtcbiAgfVxufTtcbmZ1bmN0aW9uIGlzQ2FuY2VsbGVkRXJyb3IodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3I7XG59XG5mdW5jdGlvbiBjcmVhdGVSZXRyeWVyKGNvbmZpZykge1xuICBsZXQgaXNSZXRyeUNhbmNlbGxlZCA9IGZhbHNlO1xuICBsZXQgZmFpbHVyZUNvdW50ID0gMDtcbiAgbGV0IGNvbnRpbnVlRm47XG4gIGNvbnN0IHRoZW5hYmxlID0gcGVuZGluZ1RoZW5hYmxlKCk7XG4gIGNvbnN0IGlzUmVzb2x2ZWQgPSAoKSA9PiB0aGVuYWJsZS5zdGF0dXMgIT09IFwicGVuZGluZ1wiO1xuICBjb25zdCBjYW5jZWwgPSAoY2FuY2VsT3B0aW9ucykgPT4ge1xuICAgIGlmICghaXNSZXNvbHZlZCgpKSB7XG4gICAgICBjb25zdCBlcnJvciA9IG5ldyBDYW5jZWxsZWRFcnJvcihjYW5jZWxPcHRpb25zKTtcbiAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICBjb25maWcub25DYW5jZWw/LihlcnJvcik7XG4gICAgfVxuICB9O1xuICBjb25zdCBjYW5jZWxSZXRyeSA9ICgpID0+IHtcbiAgICBpc1JldHJ5Q2FuY2VsbGVkID0gdHJ1ZTtcbiAgfTtcbiAgY29uc3QgY29udGludWVSZXRyeSA9ICgpID0+IHtcbiAgICBpc1JldHJ5Q2FuY2VsbGVkID0gZmFsc2U7XG4gIH07XG4gIGNvbnN0IGNhbkNvbnRpbnVlID0gKCkgPT4gZm9jdXNNYW5hZ2VyLmlzRm9jdXNlZCgpICYmIChjb25maWcubmV0d29ya01vZGUgPT09IFwiYWx3YXlzXCIgfHwgb25saW5lTWFuYWdlci5pc09ubGluZSgpKSAmJiBjb25maWcuY2FuUnVuKCk7XG4gIGNvbnN0IGNhblN0YXJ0ID0gKCkgPT4gY2FuRmV0Y2goY29uZmlnLm5ldHdvcmtNb2RlKSAmJiBjb25maWcuY2FuUnVuKCk7XG4gIGNvbnN0IHJlc29sdmUgPSAodmFsdWUpID0+IHtcbiAgICBpZiAoIWlzUmVzb2x2ZWQoKSkge1xuICAgICAgY29udGludWVGbj8uKCk7XG4gICAgICB0aGVuYWJsZS5yZXNvbHZlKHZhbHVlKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHJlamVjdCA9ICh2YWx1ZSkgPT4ge1xuICAgIGlmICghaXNSZXNvbHZlZCgpKSB7XG4gICAgICBjb250aW51ZUZuPy4oKTtcbiAgICAgIHRoZW5hYmxlLnJlamVjdCh2YWx1ZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCBwYXVzZSA9ICgpID0+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKGNvbnRpbnVlUmVzb2x2ZSkgPT4ge1xuICAgICAgY29udGludWVGbiA9ICh2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoaXNSZXNvbHZlZCgpIHx8IGNhbkNvbnRpbnVlKCkpIHtcbiAgICAgICAgICBjb250aW51ZVJlc29sdmUodmFsdWUpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgY29uZmlnLm9uUGF1c2U/LigpO1xuICAgIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgY29udGludWVGbiA9IHZvaWQgMDtcbiAgICAgIGlmICghaXNSZXNvbHZlZCgpKSB7XG4gICAgICAgIGNvbmZpZy5vbkNvbnRpbnVlPy4oKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcbiAgY29uc3QgcnVuID0gKCkgPT4ge1xuICAgIGlmIChpc1Jlc29sdmVkKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgbGV0IHByb21pc2VPclZhbHVlO1xuICAgIGNvbnN0IGluaXRpYWxQcm9taXNlID0gZmFpbHVyZUNvdW50ID09PSAwID8gY29uZmlnLmluaXRpYWxQcm9taXNlIDogdm9pZCAwO1xuICAgIHRyeSB7XG4gICAgICBwcm9taXNlT3JWYWx1ZSA9IGluaXRpYWxQcm9taXNlID8/IGNvbmZpZy5mbigpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBwcm9taXNlT3JWYWx1ZSA9IFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICB9XG4gICAgUHJvbWlzZS5yZXNvbHZlKHByb21pc2VPclZhbHVlKS50aGVuKHJlc29sdmUpLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgaWYgKGlzUmVzb2x2ZWQoKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCByZXRyeSA9IGNvbmZpZy5yZXRyeSA/PyAoZW52aXJvbm1lbnRNYW5hZ2VyLmlzU2VydmVyKCkgPyAwIDogMyk7XG4gICAgICBjb25zdCByZXRyeURlbGF5ID0gY29uZmlnLnJldHJ5RGVsYXkgPz8gZGVmYXVsdFJldHJ5RGVsYXk7XG4gICAgICBjb25zdCBkZWxheSA9IHR5cGVvZiByZXRyeURlbGF5ID09PSBcImZ1bmN0aW9uXCIgPyByZXRyeURlbGF5KGZhaWx1cmVDb3VudCwgZXJyb3IpIDogcmV0cnlEZWxheTtcbiAgICAgIGNvbnN0IHNob3VsZFJldHJ5ID0gcmV0cnkgPT09IHRydWUgfHwgdHlwZW9mIHJldHJ5ID09PSBcIm51bWJlclwiICYmIGZhaWx1cmVDb3VudCA8IHJldHJ5IHx8IHR5cGVvZiByZXRyeSA9PT0gXCJmdW5jdGlvblwiICYmIHJldHJ5KGZhaWx1cmVDb3VudCwgZXJyb3IpO1xuICAgICAgaWYgKGlzUmV0cnlDYW5jZWxsZWQgfHwgIXNob3VsZFJldHJ5KSB7XG4gICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGZhaWx1cmVDb3VudCsrO1xuICAgICAgY29uZmlnLm9uRmFpbD8uKGZhaWx1cmVDb3VudCwgZXJyb3IpO1xuICAgICAgc2xlZXAoZGVsYXkpLnRoZW4oKCkgPT4ge1xuICAgICAgICByZXR1cm4gY2FuQ29udGludWUoKSA/IHZvaWQgMCA6IHBhdXNlKCk7XG4gICAgICB9KS50aGVuKCgpID0+IHtcbiAgICAgICAgaWYgKGlzUmV0cnlDYW5jZWxsZWQpIHtcbiAgICAgICAgICByZWplY3QoZXJyb3IpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJ1bigpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfTtcbiAgcmV0dXJuIHtcbiAgICBwcm9taXNlOiB0aGVuYWJsZSxcbiAgICBzdGF0dXM6ICgpID0+IHRoZW5hYmxlLnN0YXR1cyxcbiAgICBjYW5jZWwsXG4gICAgY29udGludWU6ICgpID0+IHtcbiAgICAgIGNvbnRpbnVlRm4/LigpO1xuICAgICAgcmV0dXJuIHRoZW5hYmxlO1xuICAgIH0sXG4gICAgY2FuY2VsUmV0cnksXG4gICAgY29udGludWVSZXRyeSxcbiAgICBjYW5TdGFydCxcbiAgICBzdGFydDogKCkgPT4ge1xuICAgICAgaWYgKGNhblN0YXJ0KCkpIHtcbiAgICAgICAgcnVuKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXVzZSgpLnRoZW4ocnVuKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGVuYWJsZTtcbiAgICB9XG4gIH07XG59XG5leHBvcnQge1xuICBDYW5jZWxsZWRFcnJvcixcbiAgY2FuRmV0Y2gsXG4gIGNyZWF0ZVJldHJ5ZXIsXG4gIGlzQ2FuY2VsbGVkRXJyb3Jcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZXRyeWVyLmpzLm1hcCIsIi8vIHNyYy9yZW1vdmFibGUudHNcbmltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGVudmlyb25tZW50TWFuYWdlciB9IGZyb20gXCIuL2Vudmlyb25tZW50TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgaXNWYWxpZFRpbWVvdXQgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xudmFyIFJlbW92YWJsZSA9IGNsYXNzIHtcbiAgI2djVGltZW91dDtcbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG4gIH1cbiAgc2NoZWR1bGVHYygpIHtcbiAgICB0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG4gICAgaWYgKGlzVmFsaWRUaW1lb3V0KHRoaXMuZ2NUaW1lKSkge1xuICAgICAgdGhpcy4jZ2NUaW1lb3V0ID0gdGltZW91dE1hbmFnZXIuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHRoaXMub3B0aW9uYWxSZW1vdmUoKTtcbiAgICAgIH0sIHRoaXMuZ2NUaW1lKTtcbiAgICB9XG4gIH1cbiAgdXBkYXRlR2NUaW1lKG5ld0djVGltZSkge1xuICAgIHRoaXMuZ2NUaW1lID0gTWF0aC5tYXgoXG4gICAgICB0aGlzLmdjVGltZSB8fCAwLFxuICAgICAgbmV3R2NUaW1lID8/IChlbnZpcm9ubWVudE1hbmFnZXIuaXNTZXJ2ZXIoKSA/IEluZmluaXR5IDogNSAqIDYwICogMWUzKVxuICAgICk7XG4gIH1cbiAgY2xlYXJHY1RpbWVvdXQoKSB7XG4gICAgaWYgKHRoaXMuI2djVGltZW91dCAhPT0gdm9pZCAwKSB7XG4gICAgICB0aW1lb3V0TWFuYWdlci5jbGVhclRpbWVvdXQodGhpcy4jZ2NUaW1lb3V0KTtcbiAgICAgIHRoaXMuI2djVGltZW91dCA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbn07XG5leHBvcnQge1xuICBSZW1vdmFibGVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZW1vdmFibGUuanMubWFwIiwiLy8gc3JjL2luZmluaXRlUXVlcnlCZWhhdmlvci50c1xuaW1wb3J0IHtcbiAgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLFxuICBhZGRUb0VuZCxcbiAgYWRkVG9TdGFydCxcbiAgZW5zdXJlUXVlcnlGblxufSBmcm9tIFwiLi91dGlscy5qc1wiO1xuZnVuY3Rpb24gaW5maW5pdGVRdWVyeUJlaGF2aW9yKHBhZ2VzKSB7XG4gIHJldHVybiB7XG4gICAgb25GZXRjaDogKGNvbnRleHQsIHF1ZXJ5KSA9PiB7XG4gICAgICBjb25zdCBvcHRpb25zID0gY29udGV4dC5vcHRpb25zO1xuICAgICAgY29uc3QgZGlyZWN0aW9uID0gY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGE/LmZldGNoTW9yZT8uZGlyZWN0aW9uO1xuICAgICAgY29uc3Qgb2xkUGFnZXMgPSBjb250ZXh0LnN0YXRlLmRhdGE/LnBhZ2VzIHx8IFtdO1xuICAgICAgY29uc3Qgb2xkUGFnZVBhcmFtcyA9IGNvbnRleHQuc3RhdGUuZGF0YT8ucGFnZVBhcmFtcyB8fCBbXTtcbiAgICAgIGxldCByZXN1bHQgPSB7IHBhZ2VzOiBbXSwgcGFnZVBhcmFtczogW10gfTtcbiAgICAgIGxldCBjdXJyZW50UGFnZSA9IDA7XG4gICAgICBjb25zdCBmZXRjaEZuID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IGFkZFNpZ25hbFByb3BlcnR5ID0gKG9iamVjdCkgPT4ge1xuICAgICAgICAgIGFkZENvbnN1bWVBd2FyZVNpZ25hbChcbiAgICAgICAgICAgIG9iamVjdCxcbiAgICAgICAgICAgICgpID0+IGNvbnRleHQuc2lnbmFsLFxuICAgICAgICAgICAgKCkgPT4gY2FuY2VsbGVkID0gdHJ1ZVxuICAgICAgICAgICk7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHF1ZXJ5Rm4gPSBlbnN1cmVRdWVyeUZuKGNvbnRleHQub3B0aW9ucywgY29udGV4dC5mZXRjaE9wdGlvbnMpO1xuICAgICAgICBjb25zdCBmZXRjaFBhZ2UgPSBhc3luYyAoZGF0YSwgcGFyYW0sIHByZXZpb3VzKSA9PiB7XG4gICAgICAgICAgaWYgKGNhbmNlbGxlZCkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGNvbnRleHQuc2lnbmFsLnJlYXNvbik7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChwYXJhbSA9PSBudWxsICYmIGRhdGEucGFnZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGRhdGEpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBjcmVhdGVRdWVyeUZuQ29udGV4dCA9ICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHF1ZXJ5Rm5Db250ZXh0MiA9IHtcbiAgICAgICAgICAgICAgY2xpZW50OiBjb250ZXh0LmNsaWVudCxcbiAgICAgICAgICAgICAgcXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG4gICAgICAgICAgICAgIHBhZ2VQYXJhbTogcGFyYW0sXG4gICAgICAgICAgICAgIGRpcmVjdGlvbjogcHJldmlvdXMgPyBcImJhY2t3YXJkXCIgOiBcImZvcndhcmRcIixcbiAgICAgICAgICAgICAgbWV0YTogY29udGV4dC5vcHRpb25zLm1ldGFcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBhZGRTaWduYWxQcm9wZXJ0eShxdWVyeUZuQ29udGV4dDIpO1xuICAgICAgICAgICAgcmV0dXJuIHF1ZXJ5Rm5Db250ZXh0MjtcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IHF1ZXJ5Rm5Db250ZXh0ID0gY3JlYXRlUXVlcnlGbkNvbnRleHQoKTtcbiAgICAgICAgICBjb25zdCBwYWdlID0gYXdhaXQgcXVlcnlGbihxdWVyeUZuQ29udGV4dCk7XG4gICAgICAgICAgY29uc3QgeyBtYXhQYWdlcyB9ID0gY29udGV4dC5vcHRpb25zO1xuICAgICAgICAgIGNvbnN0IGFkZFRvID0gcHJldmlvdXMgPyBhZGRUb1N0YXJ0IDogYWRkVG9FbmQ7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHBhZ2VzOiBhZGRUbyhkYXRhLnBhZ2VzLCBwYWdlLCBtYXhQYWdlcyksXG4gICAgICAgICAgICBwYWdlUGFyYW1zOiBhZGRUbyhkYXRhLnBhZ2VQYXJhbXMsIHBhcmFtLCBtYXhQYWdlcylcbiAgICAgICAgICB9O1xuICAgICAgICB9O1xuICAgICAgICBpZiAoZGlyZWN0aW9uICYmIG9sZFBhZ2VzLmxlbmd0aCkge1xuICAgICAgICAgIGNvbnN0IHByZXZpb3VzID0gZGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG4gICAgICAgICAgY29uc3QgcGFnZVBhcmFtRm4gPSBwcmV2aW91cyA/IGdldFByZXZpb3VzUGFnZVBhcmFtIDogZ2V0TmV4dFBhZ2VQYXJhbTtcbiAgICAgICAgICBjb25zdCBvbGREYXRhID0ge1xuICAgICAgICAgICAgcGFnZXM6IG9sZFBhZ2VzLFxuICAgICAgICAgICAgcGFnZVBhcmFtczogb2xkUGFnZVBhcmFtc1xuICAgICAgICAgIH07XG4gICAgICAgICAgY29uc3QgcGFyYW0gPSBwYWdlUGFyYW1GbihvcHRpb25zLCBvbGREYXRhKTtcbiAgICAgICAgICByZXN1bHQgPSBhd2FpdCBmZXRjaFBhZ2Uob2xkRGF0YSwgcGFyYW0sIHByZXZpb3VzKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCByZW1haW5pbmdQYWdlcyA9IHBhZ2VzID8/IG9sZFBhZ2VzLmxlbmd0aDtcbiAgICAgICAgICBkbyB7XG4gICAgICAgICAgICBjb25zdCBwYXJhbSA9IGN1cnJlbnRQYWdlID09PSAwID8gb2xkUGFnZVBhcmFtc1swXSA/PyBvcHRpb25zLmluaXRpYWxQYWdlUGFyYW0gOiBnZXROZXh0UGFnZVBhcmFtKG9wdGlvbnMsIHJlc3VsdCk7XG4gICAgICAgICAgICBpZiAoY3VycmVudFBhZ2UgPiAwICYmIHBhcmFtID09IG51bGwpIHtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBmZXRjaFBhZ2UocmVzdWx0LCBwYXJhbSk7XG4gICAgICAgICAgICBjdXJyZW50UGFnZSsrO1xuICAgICAgICAgIH0gd2hpbGUgKGN1cnJlbnRQYWdlIDwgcmVtYWluaW5nUGFnZXMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9O1xuICAgICAgaWYgKGNvbnRleHQub3B0aW9ucy5wZXJzaXN0ZXIpIHtcbiAgICAgICAgY29udGV4dC5mZXRjaEZuID0gKCkgPT4ge1xuICAgICAgICAgIHJldHVybiBjb250ZXh0Lm9wdGlvbnMucGVyc2lzdGVyPy4oXG4gICAgICAgICAgICBmZXRjaEZuLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBjbGllbnQ6IGNvbnRleHQuY2xpZW50LFxuICAgICAgICAgICAgICBxdWVyeUtleTogY29udGV4dC5xdWVyeUtleSxcbiAgICAgICAgICAgICAgbWV0YTogY29udGV4dC5vcHRpb25zLm1ldGEsXG4gICAgICAgICAgICAgIHNpZ25hbDogY29udGV4dC5zaWduYWxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeVxuICAgICAgICAgICk7XG4gICAgICAgIH07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb250ZXh0LmZldGNoRm4gPSBmZXRjaEZuO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGdldE5leHRQYWdlUGFyYW0ob3B0aW9ucywgeyBwYWdlcywgcGFnZVBhcmFtcyB9KSB7XG4gIGNvbnN0IGxhc3RJbmRleCA9IHBhZ2VzLmxlbmd0aCAtIDE7XG4gIHJldHVybiBwYWdlcy5sZW5ndGggPiAwID8gb3B0aW9ucy5nZXROZXh0UGFnZVBhcmFtKFxuICAgIHBhZ2VzW2xhc3RJbmRleF0sXG4gICAgcGFnZXMsXG4gICAgcGFnZVBhcmFtc1tsYXN0SW5kZXhdLFxuICAgIHBhZ2VQYXJhbXNcbiAgKSA6IHZvaWQgMDtcbn1cbmZ1bmN0aW9uIGdldFByZXZpb3VzUGFnZVBhcmFtKG9wdGlvbnMsIHsgcGFnZXMsIHBhZ2VQYXJhbXMgfSkge1xuICByZXR1cm4gcGFnZXMubGVuZ3RoID4gMCA/IG9wdGlvbnMuZ2V0UHJldmlvdXNQYWdlUGFyYW0/LihwYWdlc1swXSwgcGFnZXMsIHBhZ2VQYXJhbXNbMF0sIHBhZ2VQYXJhbXMpIDogdm9pZCAwO1xufVxuZnVuY3Rpb24gaGFzTmV4dFBhZ2Uob3B0aW9ucywgZGF0YSkge1xuICBpZiAoIWRhdGEpIHJldHVybiBmYWxzZTtcbiAgcmV0dXJuIGdldE5leHRQYWdlUGFyYW0ob3B0aW9ucywgZGF0YSkgIT0gbnVsbDtcbn1cbmZ1bmN0aW9uIGhhc1ByZXZpb3VzUGFnZShvcHRpb25zLCBkYXRhKSB7XG4gIGlmICghZGF0YSB8fCAhb3B0aW9ucy5nZXRQcmV2aW91c1BhZ2VQYXJhbSkgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gZ2V0UHJldmlvdXNQYWdlUGFyYW0ob3B0aW9ucywgZGF0YSkgIT0gbnVsbDtcbn1cbmV4cG9ydCB7XG4gIGhhc05leHRQYWdlLFxuICBoYXNQcmV2aW91c1BhZ2UsXG4gIGluZmluaXRlUXVlcnlCZWhhdmlvclxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZmluaXRlUXVlcnlCZWhhdmlvci5qcy5tYXAiLCIvLyBzcmMvcXVlcnkudHNcbmltcG9ydCB7XG4gIGVuc3VyZVF1ZXJ5Rm4sXG4gIG5vb3AsXG4gIHJlcGxhY2VEYXRhLFxuICByZXNvbHZlUXVlcnlCb29sZWFuLFxuICByZXNvbHZlU3RhbGVUaW1lLFxuICBza2lwVG9rZW4sXG4gIHRpbWVVbnRpbFN0YWxlXG59IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgQ2FuY2VsbGVkRXJyb3IsIGNhbkZldGNoLCBjcmVhdGVSZXRyeWVyIH0gZnJvbSBcIi4vcmV0cnllci5qc1wiO1xuaW1wb3J0IHsgUmVtb3ZhYmxlIH0gZnJvbSBcIi4vcmVtb3ZhYmxlLmpzXCI7XG5pbXBvcnQgeyBpbmZpbml0ZVF1ZXJ5QmVoYXZpb3IgfSBmcm9tIFwiLi9pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IuanNcIjtcbnZhciBRdWVyeSA9IGNsYXNzIGV4dGVuZHMgUmVtb3ZhYmxlIHtcbiAgI3F1ZXJ5VHlwZTtcbiAgI2luaXRpYWxTdGF0ZTtcbiAgI3JldmVydFN0YXRlO1xuICAjY2FjaGU7XG4gICNjbGllbnQ7XG4gICNyZXRyeWVyO1xuICAjZGVmYXVsdE9wdGlvbnM7XG4gICNhYm9ydFNpZ25hbENvbnN1bWVkO1xuICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuI2Fib3J0U2lnbmFsQ29uc3VtZWQgPSBmYWxzZTtcbiAgICB0aGlzLiNkZWZhdWx0T3B0aW9ucyA9IGNvbmZpZy5kZWZhdWx0T3B0aW9ucztcbiAgICB0aGlzLnNldE9wdGlvbnMoY29uZmlnLm9wdGlvbnMpO1xuICAgIHRoaXMub2JzZXJ2ZXJzID0gW107XG4gICAgdGhpcy4jY2xpZW50ID0gY29uZmlnLmNsaWVudDtcbiAgICB0aGlzLiNjYWNoZSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCk7XG4gICAgdGhpcy5xdWVyeUtleSA9IGNvbmZpZy5xdWVyeUtleTtcbiAgICB0aGlzLnF1ZXJ5SGFzaCA9IGNvbmZpZy5xdWVyeUhhc2g7XG4gICAgdGhpcy4jaW5pdGlhbFN0YXRlID0gZ2V0RGVmYXVsdFN0YXRlKHRoaXMub3B0aW9ucyk7XG4gICAgdGhpcy5zdGF0ZSA9IGNvbmZpZy5zdGF0ZSA/PyB0aGlzLiNpbml0aWFsU3RhdGU7XG4gICAgdGhpcy5zY2hlZHVsZUdjKCk7XG4gIH1cbiAgZ2V0IG1ldGEoKSB7XG4gICAgcmV0dXJuIHRoaXMub3B0aW9ucy5tZXRhO1xuICB9XG4gIGdldCBxdWVyeVR5cGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuI3F1ZXJ5VHlwZTtcbiAgfVxuICBnZXQgcHJvbWlzZSgpIHtcbiAgICByZXR1cm4gdGhpcy4jcmV0cnllcj8ucHJvbWlzZTtcbiAgfVxuICBzZXRPcHRpb25zKG9wdGlvbnMpIHtcbiAgICB0aGlzLm9wdGlvbnMgPSB7IC4uLnRoaXMuI2RlZmF1bHRPcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgaWYgKG9wdGlvbnM/Ll90eXBlKSB7XG4gICAgICB0aGlzLiNxdWVyeVR5cGUgPSBvcHRpb25zLl90eXBlO1xuICAgIH1cbiAgICB0aGlzLnVwZGF0ZUdjVGltZSh0aGlzLm9wdGlvbnMuZ2NUaW1lKTtcbiAgICBpZiAodGhpcy5zdGF0ZSAmJiB0aGlzLnN0YXRlLmRhdGEgPT09IHZvaWQgMCkge1xuICAgICAgY29uc3QgZGVmYXVsdFN0YXRlID0gZ2V0RGVmYXVsdFN0YXRlKHRoaXMub3B0aW9ucyk7XG4gICAgICBpZiAoZGVmYXVsdFN0YXRlLmRhdGEgIT09IHZvaWQgMCkge1xuICAgICAgICB0aGlzLnNldFN0YXRlKFxuICAgICAgICAgIHN1Y2Nlc3NTdGF0ZShkZWZhdWx0U3RhdGUuZGF0YSwgZGVmYXVsdFN0YXRlLmRhdGFVcGRhdGVkQXQpXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMuI2luaXRpYWxTdGF0ZSA9IGRlZmF1bHRTdGF0ZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgb3B0aW9uYWxSZW1vdmUoKSB7XG4gICAgaWYgKCF0aGlzLm9ic2VydmVycy5sZW5ndGggJiYgdGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJpZGxlXCIpIHtcbiAgICAgIHRoaXMuI2NhY2hlLnJlbW92ZSh0aGlzKTtcbiAgICB9XG4gIH1cbiAgc2V0RGF0YShuZXdEYXRhLCBvcHRpb25zKSB7XG4gICAgY29uc3QgZGF0YSA9IHJlcGxhY2VEYXRhKHRoaXMuc3RhdGUuZGF0YSwgbmV3RGF0YSwgdGhpcy5vcHRpb25zKTtcbiAgICB0aGlzLiNkaXNwYXRjaCh7XG4gICAgICBkYXRhLFxuICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXG4gICAgICBkYXRhVXBkYXRlZEF0OiBvcHRpb25zPy51cGRhdGVkQXQsXG4gICAgICBtYW51YWw6IG9wdGlvbnM/Lm1hbnVhbFxuICAgIH0pO1xuICAgIHJldHVybiBkYXRhO1xuICB9XG4gIHNldFN0YXRlKHN0YXRlKSB7XG4gICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcInNldFN0YXRlXCIsIHN0YXRlIH0pO1xuICB9XG4gIGNhbmNlbChvcHRpb25zKSB7XG4gICAgY29uc3QgcHJvbWlzZSA9IHRoaXMuI3JldHJ5ZXI/LnByb21pc2U7XG4gICAgdGhpcy4jcmV0cnllcj8uY2FuY2VsKG9wdGlvbnMpO1xuICAgIHJldHVybiBwcm9taXNlID8gcHJvbWlzZS50aGVuKG5vb3ApLmNhdGNoKG5vb3ApIDogUHJvbWlzZS5yZXNvbHZlKCk7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICBzdXBlci5kZXN0cm95KCk7XG4gICAgdGhpcy5jYW5jZWwoeyBzaWxlbnQ6IHRydWUgfSk7XG4gIH1cbiAgZ2V0IHJlc2V0U3RhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuI2luaXRpYWxTdGF0ZTtcbiAgfVxuICByZXNldCgpIHtcbiAgICB0aGlzLmRlc3Ryb3koKTtcbiAgICB0aGlzLnNldFN0YXRlKHRoaXMucmVzZXRTdGF0ZSk7XG4gIH1cbiAgaXNBY3RpdmUoKSB7XG4gICAgcmV0dXJuIHRoaXMub2JzZXJ2ZXJzLnNvbWUoXG4gICAgICAob2JzZXJ2ZXIpID0+IHJlc29sdmVRdWVyeUJvb2xlYW4ob2JzZXJ2ZXIub3B0aW9ucy5lbmFibGVkLCB0aGlzKSAhPT0gZmFsc2VcbiAgICApO1xuICB9XG4gIGlzRGlzYWJsZWQoKSB7XG4gICAgaWYgKHRoaXMuZ2V0T2JzZXJ2ZXJzQ291bnQoKSA+IDApIHtcbiAgICAgIHJldHVybiAhdGhpcy5pc0FjdGl2ZSgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5vcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbiB8fCAhdGhpcy5pc0ZldGNoZWQoKTtcbiAgfVxuICBpc0ZldGNoZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdGUuZGF0YVVwZGF0ZUNvdW50ICsgdGhpcy5zdGF0ZS5lcnJvclVwZGF0ZUNvdW50ID4gMDtcbiAgfVxuICBpc1N0YXRpYygpIHtcbiAgICBpZiAodGhpcy5nZXRPYnNlcnZlcnNDb3VudCgpID4gMCkge1xuICAgICAgcmV0dXJuIHRoaXMub2JzZXJ2ZXJzLnNvbWUoXG4gICAgICAgIChvYnNlcnZlcikgPT4gcmVzb2x2ZVN0YWxlVGltZShvYnNlcnZlci5vcHRpb25zLnN0YWxlVGltZSwgdGhpcykgPT09IFwic3RhdGljXCJcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpc1N0YWxlKCkge1xuICAgIGlmICh0aGlzLmdldE9ic2VydmVyc0NvdW50KCkgPiAwKSB7XG4gICAgICByZXR1cm4gdGhpcy5vYnNlcnZlcnMuc29tZShcbiAgICAgICAgKG9ic2VydmVyKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCkuaXNTdGFsZVxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuc3RhdGUuZGF0YSA9PT0gdm9pZCAwIHx8IHRoaXMuc3RhdGUuaXNJbnZhbGlkYXRlZDtcbiAgfVxuICBpc1N0YWxlQnlUaW1lKHN0YWxlVGltZSA9IDApIHtcbiAgICBpZiAodGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoc3RhbGVUaW1lID09PSBcInN0YXRpY1wiKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICh0aGlzLnN0YXRlLmlzSW52YWxpZGF0ZWQpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gIXRpbWVVbnRpbFN0YWxlKHRoaXMuc3RhdGUuZGF0YVVwZGF0ZWRBdCwgc3RhbGVUaW1lKTtcbiAgfVxuICBvbkZvY3VzKCkge1xuICAgIGNvbnN0IG9ic2VydmVyID0gdGhpcy5vYnNlcnZlcnMuZmluZCgoeCkgPT4geC5zaG91bGRGZXRjaE9uV2luZG93Rm9jdXMoKSk7XG4gICAgb2JzZXJ2ZXI/LnJlZmV0Y2goeyBjYW5jZWxSZWZldGNoOiBmYWxzZSB9KTtcbiAgICB0aGlzLiNyZXRyeWVyPy5jb250aW51ZSgpO1xuICB9XG4gIG9uT25saW5lKCkge1xuICAgIGNvbnN0IG9ic2VydmVyID0gdGhpcy5vYnNlcnZlcnMuZmluZCgoeCkgPT4geC5zaG91bGRGZXRjaE9uUmVjb25uZWN0KCkpO1xuICAgIG9ic2VydmVyPy5yZWZldGNoKHsgY2FuY2VsUmVmZXRjaDogZmFsc2UgfSk7XG4gICAgdGhpcy4jcmV0cnllcj8uY29udGludWUoKTtcbiAgfVxuICBhZGRPYnNlcnZlcihvYnNlcnZlcikge1xuICAgIGlmICghdGhpcy5vYnNlcnZlcnMuaW5jbHVkZXMob2JzZXJ2ZXIpKSB7XG4gICAgICB0aGlzLm9ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcbiAgICAgIHRoaXMuY2xlYXJHY1RpbWVvdXQoKTtcbiAgICAgIHRoaXMuI2NhY2hlLm5vdGlmeSh7IHR5cGU6IFwib2JzZXJ2ZXJBZGRlZFwiLCBxdWVyeTogdGhpcywgb2JzZXJ2ZXIgfSk7XG4gICAgfVxuICB9XG4gIHJlbW92ZU9ic2VydmVyKG9ic2VydmVyKSB7XG4gICAgaWYgKHRoaXMub2JzZXJ2ZXJzLmluY2x1ZGVzKG9ic2VydmVyKSkge1xuICAgICAgdGhpcy5vYnNlcnZlcnMgPSB0aGlzLm9ic2VydmVycy5maWx0ZXIoKHgpID0+IHggIT09IG9ic2VydmVyKTtcbiAgICAgIGlmICghdGhpcy5vYnNlcnZlcnMubGVuZ3RoKSB7XG4gICAgICAgIGlmICh0aGlzLiNyZXRyeWVyKSB7XG4gICAgICAgICAgaWYgKHRoaXMuI2Fib3J0U2lnbmFsQ29uc3VtZWQgfHwgdGhpcy4jaXNJbml0aWFsUGF1c2VkRmV0Y2goKSkge1xuICAgICAgICAgICAgdGhpcy4jcmV0cnllci5jYW5jZWwoeyByZXZlcnQ6IHRydWUgfSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuI3JldHJ5ZXIuY2FuY2VsUmV0cnkoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zY2hlZHVsZUdjKCk7XG4gICAgICB9XG4gICAgICB0aGlzLiNjYWNoZS5ub3RpZnkoeyB0eXBlOiBcIm9ic2VydmVyUmVtb3ZlZFwiLCBxdWVyeTogdGhpcywgb2JzZXJ2ZXIgfSk7XG4gICAgfVxuICB9XG4gIGdldE9ic2VydmVyc0NvdW50KCkge1xuICAgIHJldHVybiB0aGlzLm9ic2VydmVycy5sZW5ndGg7XG4gIH1cbiAgI2lzSW5pdGlhbFBhdXNlZEZldGNoKCkge1xuICAgIHJldHVybiB0aGlzLnN0YXRlLmZldGNoU3RhdHVzID09PSBcInBhdXNlZFwiICYmIHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIjtcbiAgfVxuICBpbnZhbGlkYXRlKCkge1xuICAgIGlmICghdGhpcy5zdGF0ZS5pc0ludmFsaWRhdGVkKSB7XG4gICAgICB0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiaW52YWxpZGF0ZVwiIH0pO1xuICAgIH1cbiAgfVxuICBhc3luYyBmZXRjaChvcHRpb25zLCBmZXRjaE9wdGlvbnMpIHtcbiAgICBpZiAodGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyAhPT0gXCJpZGxlXCIgJiYgLy8gSWYgdGhlIHByb21pc2UgaW4gdGhlIHJldHJ5ZXIgaXMgYWxyZWFkeSByZWplY3RlZCwgd2UgaGF2ZSB0byBkZWZpbml0ZWx5XG4gICAgLy8gcmUtc3RhcnQgdGhlIGZldGNoOyB0aGVyZSBpcyBhIGNoYW5jZSB0aGF0IHRoZSBxdWVyeSBpcyBzdGlsbCBpbiBhXG4gICAgLy8gcGVuZGluZyBzdGF0ZSB3aGVuIHRoYXQgaGFwcGVuc1xuICAgIHRoaXMuI3JldHJ5ZXI/LnN0YXR1cygpICE9PSBcInJlamVjdGVkXCIpIHtcbiAgICAgIGlmICh0aGlzLnN0YXRlLmRhdGEgIT09IHZvaWQgMCAmJiBmZXRjaE9wdGlvbnM/LmNhbmNlbFJlZmV0Y2gpIHtcbiAgICAgICAgdGhpcy5jYW5jZWwoeyBzaWxlbnQ6IHRydWUgfSk7XG4gICAgICB9IGVsc2UgaWYgKHRoaXMuI3JldHJ5ZXIpIHtcbiAgICAgICAgdGhpcy4jcmV0cnllci5jb250aW51ZVJldHJ5KCk7XG4gICAgICAgIHJldHVybiB0aGlzLiNyZXRyeWVyLnByb21pc2U7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChvcHRpb25zKSB7XG4gICAgICB0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG4gICAgfVxuICAgIGlmICghdGhpcy5vcHRpb25zLnF1ZXJ5Rm4pIHtcbiAgICAgIGNvbnN0IG9ic2VydmVyID0gdGhpcy5vYnNlcnZlcnMuZmluZCgoeCkgPT4geC5vcHRpb25zLnF1ZXJ5Rm4pO1xuICAgICAgaWYgKG9ic2VydmVyKSB7XG4gICAgICAgIHRoaXMuc2V0T3B0aW9ucyhvYnNlcnZlci5vcHRpb25zKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHRoaXMub3B0aW9ucy5xdWVyeUtleSkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBgQXMgb2YgdjQsIHF1ZXJ5S2V5IG5lZWRzIHRvIGJlIGFuIEFycmF5LiBJZiB5b3UgYXJlIHVzaW5nIGEgc3RyaW5nIGxpa2UgJ3JlcG9EYXRhJywgcGxlYXNlIGNoYW5nZSBpdCB0byBhbiBBcnJheSwgZS5nLiBbJ3JlcG9EYXRhJ11gXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBjb25zdCBhZGRTaWduYWxQcm9wZXJ0eSA9IChvYmplY3QpID0+IHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmplY3QsIFwic2lnbmFsXCIsIHtcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgZ2V0OiAoKSA9PiB7XG4gICAgICAgICAgdGhpcy4jYWJvcnRTaWduYWxDb25zdW1lZCA9IHRydWU7XG4gICAgICAgICAgcmV0dXJuIGFib3J0Q29udHJvbGxlci5zaWduYWw7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgZmV0Y2hGbiA9ICgpID0+IHtcbiAgICAgIGNvbnN0IHF1ZXJ5Rm4gPSBlbnN1cmVRdWVyeUZuKHRoaXMub3B0aW9ucywgZmV0Y2hPcHRpb25zKTtcbiAgICAgIGNvbnN0IGNyZWF0ZVF1ZXJ5Rm5Db250ZXh0ID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBxdWVyeUZuQ29udGV4dDIgPSB7XG4gICAgICAgICAgY2xpZW50OiB0aGlzLiNjbGllbnQsXG4gICAgICAgICAgcXVlcnlLZXk6IHRoaXMucXVlcnlLZXksXG4gICAgICAgICAgbWV0YTogdGhpcy5tZXRhXG4gICAgICAgIH07XG4gICAgICAgIGFkZFNpZ25hbFByb3BlcnR5KHF1ZXJ5Rm5Db250ZXh0Mik7XG4gICAgICAgIHJldHVybiBxdWVyeUZuQ29udGV4dDI7XG4gICAgICB9O1xuICAgICAgY29uc3QgcXVlcnlGbkNvbnRleHQgPSBjcmVhdGVRdWVyeUZuQ29udGV4dCgpO1xuICAgICAgdGhpcy4jYWJvcnRTaWduYWxDb25zdW1lZCA9IGZhbHNlO1xuICAgICAgaWYgKHRoaXMub3B0aW9ucy5wZXJzaXN0ZXIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMub3B0aW9ucy5wZXJzaXN0ZXIoXG4gICAgICAgICAgcXVlcnlGbixcbiAgICAgICAgICBxdWVyeUZuQ29udGV4dCxcbiAgICAgICAgICB0aGlzXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcXVlcnlGbihxdWVyeUZuQ29udGV4dCk7XG4gICAgfTtcbiAgICBjb25zdCBjcmVhdGVGZXRjaENvbnRleHQgPSAoKSA9PiB7XG4gICAgICBjb25zdCBjb250ZXh0MiA9IHtcbiAgICAgICAgZmV0Y2hPcHRpb25zLFxuICAgICAgICBvcHRpb25zOiB0aGlzLm9wdGlvbnMsXG4gICAgICAgIHF1ZXJ5S2V5OiB0aGlzLnF1ZXJ5S2V5LFxuICAgICAgICBjbGllbnQ6IHRoaXMuI2NsaWVudCxcbiAgICAgICAgc3RhdGU6IHRoaXMuc3RhdGUsXG4gICAgICAgIGZldGNoRm5cbiAgICAgIH07XG4gICAgICBhZGRTaWduYWxQcm9wZXJ0eShjb250ZXh0Mik7XG4gICAgICByZXR1cm4gY29udGV4dDI7XG4gICAgfTtcbiAgICBjb25zdCBjb250ZXh0ID0gY3JlYXRlRmV0Y2hDb250ZXh0KCk7XG4gICAgY29uc3QgYmVoYXZpb3IgPSB0aGlzLiNxdWVyeVR5cGUgPT09IFwiaW5maW5pdGVcIiA/IGluZmluaXRlUXVlcnlCZWhhdmlvcihcbiAgICAgIHRoaXMub3B0aW9ucy5wYWdlc1xuICAgICkgOiB0aGlzLm9wdGlvbnMuYmVoYXZpb3I7XG4gICAgYmVoYXZpb3I/Lm9uRmV0Y2goY29udGV4dCwgdGhpcyk7XG4gICAgdGhpcy4jcmV2ZXJ0U3RhdGUgPSB0aGlzLnN0YXRlO1xuICAgIGlmICh0aGlzLnN0YXRlLmZldGNoU3RhdHVzID09PSBcImlkbGVcIiB8fCB0aGlzLnN0YXRlLmZldGNoTWV0YSAhPT0gY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGEpIHtcbiAgICAgIHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJmZXRjaFwiLCBtZXRhOiBjb250ZXh0LmZldGNoT3B0aW9ucz8ubWV0YSB9KTtcbiAgICB9XG4gICAgdGhpcy4jcmV0cnllciA9IGNyZWF0ZVJldHJ5ZXIoe1xuICAgICAgaW5pdGlhbFByb21pc2U6IGZldGNoT3B0aW9ucz8uaW5pdGlhbFByb21pc2UsXG4gICAgICBmbjogY29udGV4dC5mZXRjaEZuLFxuICAgICAgb25DYW5jZWw6IChlcnJvcikgPT4ge1xuICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYW5jZWxsZWRFcnJvciAmJiBlcnJvci5yZXZlcnQpIHtcbiAgICAgICAgICB0aGlzLnNldFN0YXRlKHtcbiAgICAgICAgICAgIC4uLnRoaXMuI3JldmVydFN0YXRlLFxuICAgICAgICAgICAgZmV0Y2hTdGF0dXM6IFwiaWRsZVwiXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgYWJvcnRDb250cm9sbGVyLmFib3J0KCk7XG4gICAgICB9LFxuICAgICAgb25GYWlsOiAoZmFpbHVyZUNvdW50LCBlcnJvcikgPT4ge1xuICAgICAgICB0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiZmFpbGVkXCIsIGZhaWx1cmVDb3VudCwgZXJyb3IgfSk7XG4gICAgICB9LFxuICAgICAgb25QYXVzZTogKCkgPT4ge1xuICAgICAgICB0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwicGF1c2VcIiB9KTtcbiAgICAgIH0sXG4gICAgICBvbkNvbnRpbnVlOiAoKSA9PiB7XG4gICAgICAgIHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJjb250aW51ZVwiIH0pO1xuICAgICAgfSxcbiAgICAgIHJldHJ5OiBjb250ZXh0Lm9wdGlvbnMucmV0cnksXG4gICAgICByZXRyeURlbGF5OiBjb250ZXh0Lm9wdGlvbnMucmV0cnlEZWxheSxcbiAgICAgIG5ldHdvcmtNb2RlOiBjb250ZXh0Lm9wdGlvbnMubmV0d29ya01vZGUsXG4gICAgICBjYW5SdW46ICgpID0+IHRydWVcbiAgICB9KTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHRoaXMuI3JldHJ5ZXIuc3RhcnQoKTtcbiAgICAgIGlmIChkYXRhID09PSB2b2lkIDApIHtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgICBgUXVlcnkgZGF0YSBjYW5ub3QgYmUgdW5kZWZpbmVkLiBQbGVhc2UgbWFrZSBzdXJlIHRvIHJldHVybiBhIHZhbHVlIG90aGVyIHRoYW4gdW5kZWZpbmVkIGZyb20geW91ciBxdWVyeSBmdW5jdGlvbi4gQWZmZWN0ZWQgcXVlcnkga2V5OiAke3RoaXMucXVlcnlIYXNofWBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLnF1ZXJ5SGFzaH0gZGF0YSBpcyB1bmRlZmluZWRgKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuc2V0RGF0YShkYXRhKTtcbiAgICAgIHRoaXMuI2NhY2hlLmNvbmZpZy5vblN1Y2Nlc3M/LihkYXRhLCB0aGlzKTtcbiAgICAgIHRoaXMuI2NhY2hlLmNvbmZpZy5vblNldHRsZWQ/LihcbiAgICAgICAgZGF0YSxcbiAgICAgICAgdGhpcy5zdGF0ZS5lcnJvcixcbiAgICAgICAgdGhpc1xuICAgICAgKTtcbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYW5jZWxsZWRFcnJvcikge1xuICAgICAgICBpZiAoZXJyb3Iuc2lsZW50KSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuI3JldHJ5ZXIucHJvbWlzZTtcbiAgICAgICAgfSBlbHNlIGlmIChlcnJvci5yZXZlcnQpIHtcbiAgICAgICAgICBpZiAodGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHtcbiAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdGhpcy5zdGF0ZS5kYXRhO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLiNkaXNwYXRjaCh7XG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcbiAgICAgICAgZXJyb3JcbiAgICAgIH0pO1xuICAgICAgdGhpcy4jY2FjaGUuY29uZmlnLm9uRXJyb3I/LihcbiAgICAgICAgZXJyb3IsXG4gICAgICAgIHRoaXNcbiAgICAgICk7XG4gICAgICB0aGlzLiNjYWNoZS5jb25maWcub25TZXR0bGVkPy4oXG4gICAgICAgIHRoaXMuc3RhdGUuZGF0YSxcbiAgICAgICAgZXJyb3IsXG4gICAgICAgIHRoaXNcbiAgICAgICk7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5zY2hlZHVsZUdjKCk7XG4gICAgfVxuICB9XG4gICNkaXNwYXRjaChhY3Rpb24pIHtcbiAgICBjb25zdCByZWR1Y2VyID0gKHN0YXRlKSA9PiB7XG4gICAgICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG4gICAgICAgIGNhc2UgXCJmYWlsZWRcIjpcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICBmZXRjaEZhaWx1cmVDb3VudDogYWN0aW9uLmZhaWx1cmVDb3VudCxcbiAgICAgICAgICAgIGZldGNoRmFpbHVyZVJlYXNvbjogYWN0aW9uLmVycm9yXG4gICAgICAgICAgfTtcbiAgICAgICAgY2FzZSBcInBhdXNlXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgZmV0Y2hTdGF0dXM6IFwicGF1c2VkXCJcbiAgICAgICAgICB9O1xuICAgICAgICBjYXNlIFwiY29udGludWVcIjpcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICBmZXRjaFN0YXR1czogXCJmZXRjaGluZ1wiXG4gICAgICAgICAgfTtcbiAgICAgICAgY2FzZSBcImZldGNoXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgLi4uZmV0Y2hTdGF0ZShzdGF0ZS5kYXRhLCB0aGlzLm9wdGlvbnMpLFxuICAgICAgICAgICAgZmV0Y2hNZXRhOiBhY3Rpb24ubWV0YSA/PyBudWxsXG4gICAgICAgICAgfTtcbiAgICAgICAgY2FzZSBcInN1Y2Nlc3NcIjpcbiAgICAgICAgICBjb25zdCBuZXdTdGF0ZSA9IHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgLi4uc3VjY2Vzc1N0YXRlKGFjdGlvbi5kYXRhLCBhY3Rpb24uZGF0YVVwZGF0ZWRBdCksXG4gICAgICAgICAgICBkYXRhVXBkYXRlQ291bnQ6IHN0YXRlLmRhdGFVcGRhdGVDb3VudCArIDEsXG4gICAgICAgICAgICAuLi4hYWN0aW9uLm1hbnVhbCAmJiB7XG4gICAgICAgICAgICAgIGZldGNoU3RhdHVzOiBcImlkbGVcIixcbiAgICAgICAgICAgICAgZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG4gICAgICAgICAgICAgIGZldGNoRmFpbHVyZVJlYXNvbjogbnVsbFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgICAgdGhpcy4jcmV2ZXJ0U3RhdGUgPSBhY3Rpb24ubWFudWFsID8gbmV3U3RhdGUgOiB2b2lkIDA7XG4gICAgICAgICAgcmV0dXJuIG5ld1N0YXRlO1xuICAgICAgICBjYXNlIFwiZXJyb3JcIjpcbiAgICAgICAgICBjb25zdCBlcnJvciA9IGFjdGlvbi5lcnJvcjtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICBlcnJvcixcbiAgICAgICAgICAgIGVycm9yVXBkYXRlQ291bnQ6IHN0YXRlLmVycm9yVXBkYXRlQ291bnQgKyAxLFxuICAgICAgICAgICAgZXJyb3JVcGRhdGVkQXQ6IERhdGUubm93KCksXG4gICAgICAgICAgICBmZXRjaEZhaWx1cmVDb3VudDogc3RhdGUuZmV0Y2hGYWlsdXJlQ291bnQgKyAxLFxuICAgICAgICAgICAgZmV0Y2hGYWlsdXJlUmVhc29uOiBlcnJvcixcbiAgICAgICAgICAgIGZldGNoU3RhdHVzOiBcImlkbGVcIixcbiAgICAgICAgICAgIHN0YXR1czogXCJlcnJvclwiLFxuICAgICAgICAgICAgLy8gZmxhZyBleGlzdGluZyBkYXRhIGFzIGludmFsaWRhdGVkIGlmIHdlIGdldCBhIGJhY2tncm91bmQgZXJyb3JcbiAgICAgICAgICAgIC8vIG5vdGUgdGhhdCBcIm5vIGRhdGFcIiBhbHdheXMgbWVhbnMgc3RhbGUgc28gd2UgY2FuIHNldCB1bmNvbmRpdGlvbmFsbHkgaGVyZVxuICAgICAgICAgICAgaXNJbnZhbGlkYXRlZDogdHJ1ZVxuICAgICAgICAgIH07XG4gICAgICAgIGNhc2UgXCJpbnZhbGlkYXRlXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgaXNJbnZhbGlkYXRlZDogdHJ1ZVxuICAgICAgICAgIH07XG4gICAgICAgIGNhc2UgXCJzZXRTdGF0ZVwiOlxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIC4uLmFjdGlvbi5zdGF0ZVxuICAgICAgICAgIH07XG4gICAgICB9XG4gICAgfTtcbiAgICB0aGlzLnN0YXRlID0gcmVkdWNlcih0aGlzLnN0YXRlKTtcbiAgICBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHRoaXMub2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG4gICAgICAgIG9ic2VydmVyLm9uUXVlcnlVcGRhdGUoKTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy4jY2FjaGUubm90aWZ5KHsgcXVlcnk6IHRoaXMsIHR5cGU6IFwidXBkYXRlZFwiLCBhY3Rpb24gfSk7XG4gICAgfSk7XG4gIH1cbn07XG5mdW5jdGlvbiBmZXRjaFN0YXRlKGRhdGEsIG9wdGlvbnMpIHtcbiAgcmV0dXJuIHtcbiAgICBmZXRjaEZhaWx1cmVDb3VudDogMCxcbiAgICBmZXRjaEZhaWx1cmVSZWFzb246IG51bGwsXG4gICAgZmV0Y2hTdGF0dXM6IGNhbkZldGNoKG9wdGlvbnMubmV0d29ya01vZGUpID8gXCJmZXRjaGluZ1wiIDogXCJwYXVzZWRcIixcbiAgICAuLi5kYXRhID09PSB2b2lkIDAgJiYge1xuICAgICAgZXJyb3I6IG51bGwsXG4gICAgICBzdGF0dXM6IFwicGVuZGluZ1wiXG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gc3VjY2Vzc1N0YXRlKGRhdGEsIGRhdGFVcGRhdGVkQXQpIHtcbiAgcmV0dXJuIHtcbiAgICBkYXRhLFxuICAgIGRhdGFVcGRhdGVkQXQ6IGRhdGFVcGRhdGVkQXQgPz8gRGF0ZS5ub3coKSxcbiAgICBlcnJvcjogbnVsbCxcbiAgICBpc0ludmFsaWRhdGVkOiBmYWxzZSxcbiAgICBzdGF0dXM6IFwic3VjY2Vzc1wiXG4gIH07XG59XG5mdW5jdGlvbiBnZXREZWZhdWx0U3RhdGUob3B0aW9ucykge1xuICBjb25zdCBkYXRhID0gdHlwZW9mIG9wdGlvbnMuaW5pdGlhbERhdGEgPT09IFwiZnVuY3Rpb25cIiA/IG9wdGlvbnMuaW5pdGlhbERhdGEoKSA6IG9wdGlvbnMuaW5pdGlhbERhdGE7XG4gIGNvbnN0IGhhc0RhdGEgPSBkYXRhICE9PSB2b2lkIDA7XG4gIGNvbnN0IGluaXRpYWxEYXRhVXBkYXRlZEF0ID0gaGFzRGF0YSA/IHR5cGVvZiBvcHRpb25zLmluaXRpYWxEYXRhVXBkYXRlZEF0ID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLmluaXRpYWxEYXRhVXBkYXRlZEF0KCkgOiBvcHRpb25zLmluaXRpYWxEYXRhVXBkYXRlZEF0IDogMDtcbiAgcmV0dXJuIHtcbiAgICBkYXRhLFxuICAgIGRhdGFVcGRhdGVDb3VudDogMCxcbiAgICBkYXRhVXBkYXRlZEF0OiBoYXNEYXRhID8gaW5pdGlhbERhdGFVcGRhdGVkQXQgPz8gRGF0ZS5ub3coKSA6IDAsXG4gICAgZXJyb3I6IG51bGwsXG4gICAgZXJyb3JVcGRhdGVDb3VudDogMCxcbiAgICBlcnJvclVwZGF0ZWRBdDogMCxcbiAgICBmZXRjaEZhaWx1cmVDb3VudDogMCxcbiAgICBmZXRjaEZhaWx1cmVSZWFzb246IG51bGwsXG4gICAgZmV0Y2hNZXRhOiBudWxsLFxuICAgIGlzSW52YWxpZGF0ZWQ6IGZhbHNlLFxuICAgIHN0YXR1czogaGFzRGF0YSA/IFwic3VjY2Vzc1wiIDogXCJwZW5kaW5nXCIsXG4gICAgZmV0Y2hTdGF0dXM6IFwiaWRsZVwiXG4gIH07XG59XG5leHBvcnQge1xuICBRdWVyeSxcbiAgZmV0Y2hTdGF0ZVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5LmpzLm1hcCIsIi8vIHNyYy9xdWVyeU9ic2VydmVyLnRzXG5pbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tIFwiLi9mb2N1c01hbmFnZXIuanNcIjtcbmltcG9ydCB7IGVudmlyb25tZW50TWFuYWdlciB9IGZyb20gXCIuL2Vudmlyb25tZW50TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGZldGNoU3RhdGUgfSBmcm9tIFwiLi9xdWVyeS5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBwZW5kaW5nVGhlbmFibGUgfSBmcm9tIFwiLi90aGVuYWJsZS5qc1wiO1xuaW1wb3J0IHtcbiAgaXNWYWxpZFRpbWVvdXQsXG4gIG5vb3AsXG4gIHJlcGxhY2VEYXRhLFxuICByZXNvbHZlUXVlcnlCb29sZWFuLFxuICByZXNvbHZlU3RhbGVUaW1lLFxuICBzaGFsbG93RXF1YWxPYmplY3RzLFxuICB0aW1lVW50aWxTdGFsZVxufSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgdGltZW91dE1hbmFnZXIgfSBmcm9tIFwiLi90aW1lb3V0TWFuYWdlci5qc1wiO1xudmFyIFF1ZXJ5T2JzZXJ2ZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG4gIGNvbnN0cnVjdG9yKGNsaWVudCwgb3B0aW9ucykge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG4gICAgdGhpcy4jc2VsZWN0RXJyb3IgPSBudWxsO1xuICAgIHRoaXMuI2N1cnJlbnRUaGVuYWJsZSA9IHBlbmRpbmdUaGVuYWJsZSgpO1xuICAgIHRoaXMuYmluZE1ldGhvZHMoKTtcbiAgICB0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG4gIH1cbiAgI2NsaWVudDtcbiAgI2N1cnJlbnRRdWVyeSA9IHZvaWQgMDtcbiAgI2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSA9IHZvaWQgMDtcbiAgI2N1cnJlbnRSZXN1bHQgPSB2b2lkIDA7XG4gICNjdXJyZW50UmVzdWx0U3RhdGU7XG4gICNjdXJyZW50UmVzdWx0T3B0aW9ucztcbiAgI2N1cnJlbnRUaGVuYWJsZTtcbiAgI3NlbGVjdEVycm9yO1xuICAjc2VsZWN0Rm47XG4gICNzZWxlY3RSZXN1bHQ7XG4gIC8vIFRoaXMgcHJvcGVydHkga2VlcHMgdHJhY2sgb2YgdGhlIGxhc3QgcXVlcnkgd2l0aCBkZWZpbmVkIGRhdGEuXG4gIC8vIEl0IHdpbGwgYmUgdXNlZCB0byBwYXNzIHRoZSBwcmV2aW91cyBkYXRhIGFuZCBxdWVyeSB0byB0aGUgcGxhY2Vob2xkZXIgZnVuY3Rpb24gYmV0d2VlbiByZW5kZXJzLlxuICAjbGFzdFF1ZXJ5V2l0aERlZmluZWREYXRhO1xuICAjc3RhbGVUaW1lb3V0SWQ7XG4gICNyZWZldGNoSW50ZXJ2YWxJZDtcbiAgI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWw7XG4gICN0cmFja2VkUHJvcHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICBiaW5kTWV0aG9kcygpIHtcbiAgICB0aGlzLnJlZmV0Y2ggPSB0aGlzLnJlZmV0Y2guYmluZCh0aGlzKTtcbiAgfVxuICBvblN1YnNjcmliZSgpIHtcbiAgICBpZiAodGhpcy5saXN0ZW5lcnMuc2l6ZSA9PT0gMSkge1xuICAgICAgdGhpcy4jY3VycmVudFF1ZXJ5LmFkZE9ic2VydmVyKHRoaXMpO1xuICAgICAgaWYgKHNob3VsZEZldGNoT25Nb3VudCh0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucykpIHtcbiAgICAgICAgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuICAgICAgfVxuICAgICAgdGhpcy4jdXBkYXRlVGltZXJzKCk7XG4gICAgfVxuICB9XG4gIG9uVW5zdWJzY3JpYmUoKSB7XG4gICAgaWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB7XG4gICAgICB0aGlzLmRlc3Ryb3koKTtcbiAgICB9XG4gIH1cbiAgc2hvdWxkRmV0Y2hPblJlY29ubmVjdCgpIHtcbiAgICByZXR1cm4gc2hvdWxkRmV0Y2hPbihcbiAgICAgIHRoaXMuI2N1cnJlbnRRdWVyeSxcbiAgICAgIHRoaXMub3B0aW9ucyxcbiAgICAgIHRoaXMub3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3RcbiAgICApO1xuICB9XG4gIHNob3VsZEZldGNoT25XaW5kb3dGb2N1cygpIHtcbiAgICByZXR1cm4gc2hvdWxkRmV0Y2hPbihcbiAgICAgIHRoaXMuI2N1cnJlbnRRdWVyeSxcbiAgICAgIHRoaXMub3B0aW9ucyxcbiAgICAgIHRoaXMub3B0aW9ucy5yZWZldGNoT25XaW5kb3dGb2N1c1xuICAgICk7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLmxpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgdGhpcy4jY2xlYXJTdGFsZVRpbWVvdXQoKTtcbiAgICB0aGlzLiNjbGVhclJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgIHRoaXMuI2N1cnJlbnRRdWVyeS5yZW1vdmVPYnNlcnZlcih0aGlzKTtcbiAgfVxuICBzZXRPcHRpb25zKG9wdGlvbnMpIHtcbiAgICBjb25zdCBwcmV2T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcbiAgICBjb25zdCBwcmV2UXVlcnkgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG4gICAgdGhpcy5vcHRpb25zID0gdGhpcy4jY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5lbmFibGVkICE9PSB2b2lkIDAgJiYgdHlwZW9mIHRoaXMub3B0aW9ucy5lbmFibGVkICE9PSBcImJvb2xlYW5cIiAmJiB0eXBlb2YgdGhpcy5vcHRpb25zLmVuYWJsZWQgIT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgcmVzb2x2ZVF1ZXJ5Qm9vbGVhbih0aGlzLm9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gXCJib29sZWFuXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgXCJFeHBlY3RlZCBlbmFibGVkIHRvIGJlIGEgYm9vbGVhbiBvciBhIGNhbGxiYWNrIHRoYXQgcmV0dXJucyBhIGJvb2xlYW5cIlxuICAgICAgKTtcbiAgICB9XG4gICAgdGhpcy4jdXBkYXRlUXVlcnkoKTtcbiAgICB0aGlzLiNjdXJyZW50UXVlcnkuc2V0T3B0aW9ucyh0aGlzLm9wdGlvbnMpO1xuICAgIGlmIChwcmV2T3B0aW9ucy5fZGVmYXVsdGVkICYmICFzaGFsbG93RXF1YWxPYmplY3RzKHRoaXMub3B0aW9ucywgcHJldk9wdGlvbnMpKSB7XG4gICAgICB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLm5vdGlmeSh7XG4gICAgICAgIHR5cGU6IFwib2JzZXJ2ZXJPcHRpb25zVXBkYXRlZFwiLFxuICAgICAgICBxdWVyeTogdGhpcy4jY3VycmVudFF1ZXJ5LFxuICAgICAgICBvYnNlcnZlcjogdGhpc1xuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IG1vdW50ZWQgPSB0aGlzLmhhc0xpc3RlbmVycygpO1xuICAgIGlmIChtb3VudGVkICYmIHNob3VsZEZldGNoT3B0aW9uYWxseShcbiAgICAgIHRoaXMuI2N1cnJlbnRRdWVyeSxcbiAgICAgIHByZXZRdWVyeSxcbiAgICAgIHRoaXMub3B0aW9ucyxcbiAgICAgIHByZXZPcHRpb25zXG4gICAgKSkge1xuICAgICAgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG4gICAgfVxuICAgIHRoaXMudXBkYXRlUmVzdWx0KCk7XG4gICAgaWYgKG1vdW50ZWQgJiYgKHRoaXMuI2N1cnJlbnRRdWVyeSAhPT0gcHJldlF1ZXJ5IHx8IHJlc29sdmVRdWVyeUJvb2xlYW4odGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVRdWVyeUJvb2xlYW4ocHJldk9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSB8fCByZXNvbHZlU3RhbGVUaW1lKHRoaXMub3B0aW9ucy5zdGFsZVRpbWUsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVTdGFsZVRpbWUocHJldk9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzLiNjdXJyZW50UXVlcnkpKSkge1xuICAgICAgdGhpcy4jdXBkYXRlU3RhbGVUaW1lb3V0KCk7XG4gICAgfVxuICAgIGNvbnN0IG5leHRSZWZldGNoSW50ZXJ2YWwgPSB0aGlzLiNjb21wdXRlUmVmZXRjaEludGVydmFsKCk7XG4gICAgaWYgKG1vdW50ZWQgJiYgKHRoaXMuI2N1cnJlbnRRdWVyeSAhPT0gcHJldlF1ZXJ5IHx8IHJlc29sdmVRdWVyeUJvb2xlYW4odGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVRdWVyeUJvb2xlYW4ocHJldk9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSB8fCBuZXh0UmVmZXRjaEludGVydmFsICE9PSB0aGlzLiNjdXJyZW50UmVmZXRjaEludGVydmFsKSkge1xuICAgICAgdGhpcy4jdXBkYXRlUmVmZXRjaEludGVydmFsKG5leHRSZWZldGNoSW50ZXJ2YWwpO1xuICAgIH1cbiAgfVxuICBnZXRPcHRpbWlzdGljUmVzdWx0KG9wdGlvbnMpIHtcbiAgICBjb25zdCBxdWVyeSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuYnVpbGQodGhpcy4jY2xpZW50LCBvcHRpb25zKTtcbiAgICBjb25zdCByZXN1bHQgPSB0aGlzLmNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucyk7XG4gICAgaWYgKHNob3VsZEFzc2lnbk9ic2VydmVyQ3VycmVudFByb3BlcnRpZXModGhpcywgcmVzdWx0KSkge1xuICAgICAgdGhpcy4jY3VycmVudFJlc3VsdCA9IHJlc3VsdDtcbiAgICAgIHRoaXMuI2N1cnJlbnRSZXN1bHRPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuICAgICAgdGhpcy4jY3VycmVudFJlc3VsdFN0YXRlID0gdGhpcy4jY3VycmVudFF1ZXJ5LnN0YXRlO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGdldEN1cnJlbnRSZXN1bHQoKSB7XG4gICAgcmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG4gIH1cbiAgdHJhY2tSZXN1bHQocmVzdWx0LCBvblByb3BUcmFja2VkKSB7XG4gICAgcmV0dXJuIG5ldyBQcm94eShyZXN1bHQsIHtcbiAgICAgIGdldDogKHRhcmdldCwga2V5KSA9PiB7XG4gICAgICAgIHRoaXMudHJhY2tQcm9wKGtleSk7XG4gICAgICAgIG9uUHJvcFRyYWNrZWQ/LihrZXkpO1xuICAgICAgICBpZiAoa2V5ID09PSBcInByb21pc2VcIikge1xuICAgICAgICAgIHRoaXMudHJhY2tQcm9wKFwiZGF0YVwiKTtcbiAgICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5leHBlcmltZW50YWxfcHJlZmV0Y2hJblJlbmRlciAmJiB0aGlzLiNjdXJyZW50VGhlbmFibGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuICAgICAgICAgICAgdGhpcy4jY3VycmVudFRoZW5hYmxlLnJlamVjdChcbiAgICAgICAgICAgICAgbmV3IEVycm9yKFxuICAgICAgICAgICAgICAgIFwiZXhwZXJpbWVudGFsX3ByZWZldGNoSW5SZW5kZXIgZmVhdHVyZSBmbGFnIGlzIG5vdCBlbmFibGVkXCJcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldCwga2V5KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICB0cmFja1Byb3Aoa2V5KSB7XG4gICAgdGhpcy4jdHJhY2tlZFByb3BzLmFkZChrZXkpO1xuICB9XG4gIGdldEN1cnJlbnRRdWVyeSgpIHtcbiAgICByZXR1cm4gdGhpcy4jY3VycmVudFF1ZXJ5O1xuICB9XG4gIHJlZmV0Y2goeyAuLi5vcHRpb25zIH0gPSB7fSkge1xuICAgIHJldHVybiB0aGlzLmZldGNoKHtcbiAgICAgIC4uLm9wdGlvbnNcbiAgICB9KTtcbiAgfVxuICBmZXRjaE9wdGltaXN0aWMob3B0aW9ucykge1xuICAgIGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcbiAgICBjb25zdCBxdWVyeSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuYnVpbGQodGhpcy4jY2xpZW50LCBkZWZhdWx0ZWRPcHRpb25zKTtcbiAgICByZXR1cm4gcXVlcnkuZmV0Y2goKS50aGVuKCgpID0+IHRoaXMuY3JlYXRlUmVzdWx0KHF1ZXJ5LCBkZWZhdWx0ZWRPcHRpb25zKSk7XG4gIH1cbiAgZmV0Y2goZmV0Y2hPcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuI2V4ZWN1dGVGZXRjaCh7XG4gICAgICAuLi5mZXRjaE9wdGlvbnMsXG4gICAgICBjYW5jZWxSZWZldGNoOiBmZXRjaE9wdGlvbnMuY2FuY2VsUmVmZXRjaCA/PyB0cnVlXG4gICAgfSkudGhlbigoKSA9PiB7XG4gICAgICB0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuICAgICAgcmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG4gICAgfSk7XG4gIH1cbiAgI2V4ZWN1dGVGZXRjaChmZXRjaE9wdGlvbnMpIHtcbiAgICB0aGlzLiN1cGRhdGVRdWVyeSgpO1xuICAgIGxldCBwcm9taXNlID0gdGhpcy4jY3VycmVudFF1ZXJ5LmZldGNoKFxuICAgICAgdGhpcy5vcHRpb25zLFxuICAgICAgZmV0Y2hPcHRpb25zXG4gICAgKTtcbiAgICBpZiAoIWZldGNoT3B0aW9ucz8udGhyb3dPbkVycm9yKSB7XG4gICAgICBwcm9taXNlID0gcHJvbWlzZS5jYXRjaChub29wKTtcbiAgICB9XG4gICAgcmV0dXJuIHByb21pc2U7XG4gIH1cbiAgI3VwZGF0ZVN0YWxlVGltZW91dCgpIHtcbiAgICB0aGlzLiNjbGVhclN0YWxlVGltZW91dCgpO1xuICAgIGNvbnN0IHN0YWxlVGltZSA9IHJlc29sdmVTdGFsZVRpbWUoXG4gICAgICB0aGlzLm9wdGlvbnMuc3RhbGVUaW1lLFxuICAgICAgdGhpcy4jY3VycmVudFF1ZXJ5XG4gICAgKTtcbiAgICBpZiAoZW52aXJvbm1lbnRNYW5hZ2VyLmlzU2VydmVyKCkgfHwgdGhpcy4jY3VycmVudFJlc3VsdC5pc1N0YWxlIHx8ICFpc1ZhbGlkVGltZW91dChzdGFsZVRpbWUpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRpbWUgPSB0aW1lVW50aWxTdGFsZSh0aGlzLiNjdXJyZW50UmVzdWx0LmRhdGFVcGRhdGVkQXQsIHN0YWxlVGltZSk7XG4gICAgY29uc3QgdGltZW91dCA9IHRpbWUgKyAxO1xuICAgIHRoaXMuI3N0YWxlVGltZW91dElkID0gdGltZW91dE1hbmFnZXIuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBpZiAoIXRoaXMuI2N1cnJlbnRSZXN1bHQuaXNTdGFsZSkge1xuICAgICAgICB0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuICAgICAgfVxuICAgIH0sIHRpbWVvdXQpO1xuICB9XG4gICNjb21wdXRlUmVmZXRjaEludGVydmFsKCkge1xuICAgIHJldHVybiAodHlwZW9mIHRoaXMub3B0aW9ucy5yZWZldGNoSW50ZXJ2YWwgPT09IFwiZnVuY3Rpb25cIiA/IHRoaXMub3B0aW9ucy5yZWZldGNoSW50ZXJ2YWwodGhpcy4jY3VycmVudFF1ZXJ5KSA6IHRoaXMub3B0aW9ucy5yZWZldGNoSW50ZXJ2YWwpID8/IGZhbHNlO1xuICB9XG4gICN1cGRhdGVSZWZldGNoSW50ZXJ2YWwobmV4dEludGVydmFsKSB7XG4gICAgdGhpcy4jY2xlYXJSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICB0aGlzLiNjdXJyZW50UmVmZXRjaEludGVydmFsID0gbmV4dEludGVydmFsO1xuICAgIGlmIChlbnZpcm9ubWVudE1hbmFnZXIuaXNTZXJ2ZXIoKSB8fCByZXNvbHZlUXVlcnlCb29sZWFuKHRoaXMub3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpID09PSBmYWxzZSB8fCAhaXNWYWxpZFRpbWVvdXQodGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCkgfHwgdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKCgpID0+IHtcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMucmVmZXRjaEludGVydmFsSW5CYWNrZ3JvdW5kIHx8IGZvY3VzTWFuYWdlci5pc0ZvY3VzZWQoKSkge1xuICAgICAgICB0aGlzLiNleGVjdXRlRmV0Y2goKTtcbiAgICAgIH1cbiAgICB9LCB0aGlzLiNjdXJyZW50UmVmZXRjaEludGVydmFsKTtcbiAgfVxuICAjdXBkYXRlVGltZXJzKCkge1xuICAgIHRoaXMuI3VwZGF0ZVN0YWxlVGltZW91dCgpO1xuICAgIHRoaXMuI3VwZGF0ZVJlZmV0Y2hJbnRlcnZhbCh0aGlzLiNjb21wdXRlUmVmZXRjaEludGVydmFsKCkpO1xuICB9XG4gICNjbGVhclN0YWxlVGltZW91dCgpIHtcbiAgICBpZiAodGhpcy4jc3RhbGVUaW1lb3V0SWQgIT09IHZvaWQgMCkge1xuICAgICAgdGltZW91dE1hbmFnZXIuY2xlYXJUaW1lb3V0KHRoaXMuI3N0YWxlVGltZW91dElkKTtcbiAgICAgIHRoaXMuI3N0YWxlVGltZW91dElkID0gdm9pZCAwO1xuICAgIH1cbiAgfVxuICAjY2xlYXJSZWZldGNoSW50ZXJ2YWwoKSB7XG4gICAgaWYgKHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkICE9PSB2b2lkIDApIHtcbiAgICAgIHRpbWVvdXRNYW5hZ2VyLmNsZWFySW50ZXJ2YWwodGhpcy4jcmVmZXRjaEludGVydmFsSWQpO1xuICAgICAgdGhpcy4jcmVmZXRjaEludGVydmFsSWQgPSB2b2lkIDA7XG4gICAgfVxuICB9XG4gIGNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucykge1xuICAgIGNvbnN0IHByZXZRdWVyeSA9IHRoaXMuI2N1cnJlbnRRdWVyeTtcbiAgICBjb25zdCBwcmV2T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcbiAgICBjb25zdCBwcmV2UmVzdWx0ID0gdGhpcy4jY3VycmVudFJlc3VsdDtcbiAgICBjb25zdCBwcmV2UmVzdWx0U3RhdGUgPSB0aGlzLiNjdXJyZW50UmVzdWx0U3RhdGU7XG4gICAgY29uc3QgcHJldlJlc3VsdE9wdGlvbnMgPSB0aGlzLiNjdXJyZW50UmVzdWx0T3B0aW9ucztcbiAgICBjb25zdCBxdWVyeUNoYW5nZSA9IHF1ZXJ5ICE9PSBwcmV2UXVlcnk7XG4gICAgY29uc3QgcXVlcnlJbml0aWFsU3RhdGUgPSBxdWVyeUNoYW5nZSA/IHF1ZXJ5LnN0YXRlIDogdGhpcy4jY3VycmVudFF1ZXJ5SW5pdGlhbFN0YXRlO1xuICAgIGNvbnN0IHsgc3RhdGUgfSA9IHF1ZXJ5O1xuICAgIGxldCBuZXdTdGF0ZSA9IHsgLi4uc3RhdGUgfTtcbiAgICBsZXQgaXNQbGFjZWhvbGRlckRhdGEgPSBmYWxzZTtcbiAgICBsZXQgZGF0YTtcbiAgICBpZiAob3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMpIHtcbiAgICAgIGNvbnN0IG1vdW50ZWQgPSB0aGlzLmhhc0xpc3RlbmVycygpO1xuICAgICAgY29uc3QgZmV0Y2hPbk1vdW50ID0gIW1vdW50ZWQgJiYgc2hvdWxkRmV0Y2hPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKTtcbiAgICAgIGNvbnN0IGZldGNoT3B0aW9uYWxseSA9IG1vdW50ZWQgJiYgc2hvdWxkRmV0Y2hPcHRpb25hbGx5KHF1ZXJ5LCBwcmV2UXVlcnksIG9wdGlvbnMsIHByZXZPcHRpb25zKTtcbiAgICAgIGlmIChmZXRjaE9uTW91bnQgfHwgZmV0Y2hPcHRpb25hbGx5KSB7XG4gICAgICAgIG5ld1N0YXRlID0ge1xuICAgICAgICAgIC4uLm5ld1N0YXRlLFxuICAgICAgICAgIC4uLmZldGNoU3RhdGUoc3RhdGUuZGF0YSwgcXVlcnkub3B0aW9ucylcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlmIChvcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cyA9PT0gXCJpc1Jlc3RvcmluZ1wiKSB7XG4gICAgICAgIG5ld1N0YXRlLmZldGNoU3RhdHVzID0gXCJpZGxlXCI7XG4gICAgICB9XG4gICAgfVxuICAgIGxldCB7IGVycm9yLCBlcnJvclVwZGF0ZWRBdCwgc3RhdHVzIH0gPSBuZXdTdGF0ZTtcbiAgICBkYXRhID0gbmV3U3RhdGUuZGF0YTtcbiAgICBsZXQgc2tpcFNlbGVjdCA9IGZhbHNlO1xuICAgIGlmIChvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSAhPT0gdm9pZCAwICYmIGRhdGEgPT09IHZvaWQgMCAmJiBzdGF0dXMgPT09IFwicGVuZGluZ1wiKSB7XG4gICAgICBsZXQgcGxhY2Vob2xkZXJEYXRhO1xuICAgICAgaWYgKHByZXZSZXN1bHQ/LmlzUGxhY2Vob2xkZXJEYXRhICYmIG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhID09PSBwcmV2UmVzdWx0T3B0aW9ucz8ucGxhY2Vob2xkZXJEYXRhKSB7XG4gICAgICAgIHBsYWNlaG9sZGVyRGF0YSA9IHByZXZSZXN1bHQuZGF0YTtcbiAgICAgICAgc2tpcFNlbGVjdCA9IHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwbGFjZWhvbGRlckRhdGEgPSB0eXBlb2Ygb3B0aW9ucy5wbGFjZWhvbGRlckRhdGEgPT09IFwiZnVuY3Rpb25cIiA/IG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhKFxuICAgICAgICAgIHRoaXMuI2xhc3RRdWVyeVdpdGhEZWZpbmVkRGF0YT8uc3RhdGUuZGF0YSxcbiAgICAgICAgICB0aGlzLiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGFcbiAgICAgICAgKSA6IG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhO1xuICAgICAgfVxuICAgICAgaWYgKHBsYWNlaG9sZGVyRGF0YSAhPT0gdm9pZCAwKSB7XG4gICAgICAgIHN0YXR1cyA9IFwic3VjY2Vzc1wiO1xuICAgICAgICBkYXRhID0gcmVwbGFjZURhdGEoXG4gICAgICAgICAgcHJldlJlc3VsdD8uZGF0YSxcbiAgICAgICAgICBwbGFjZWhvbGRlckRhdGEsXG4gICAgICAgICAgb3B0aW9uc1xuICAgICAgICApO1xuICAgICAgICBpc1BsYWNlaG9sZGVyRGF0YSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChvcHRpb25zLnNlbGVjdCAmJiBkYXRhICE9PSB2b2lkIDAgJiYgIXNraXBTZWxlY3QpIHtcbiAgICAgIGlmIChwcmV2UmVzdWx0ICYmIGRhdGEgPT09IHByZXZSZXN1bHRTdGF0ZT8uZGF0YSAmJiBvcHRpb25zLnNlbGVjdCA9PT0gdGhpcy4jc2VsZWN0Rm4pIHtcbiAgICAgICAgZGF0YSA9IHRoaXMuI3NlbGVjdFJlc3VsdDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgdGhpcy4jc2VsZWN0Rm4gPSBvcHRpb25zLnNlbGVjdDtcbiAgICAgICAgICBkYXRhID0gb3B0aW9ucy5zZWxlY3QoZGF0YSk7XG4gICAgICAgICAgZGF0YSA9IHJlcGxhY2VEYXRhKHByZXZSZXN1bHQ/LmRhdGEsIGRhdGEsIG9wdGlvbnMpO1xuICAgICAgICAgIHRoaXMuI3NlbGVjdFJlc3VsdCA9IGRhdGE7XG4gICAgICAgICAgdGhpcy4jc2VsZWN0RXJyb3IgPSBudWxsO1xuICAgICAgICB9IGNhdGNoIChzZWxlY3RFcnJvcikge1xuICAgICAgICAgIHRoaXMuI3NlbGVjdEVycm9yID0gc2VsZWN0RXJyb3I7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHRoaXMuI3NlbGVjdEVycm9yKSB7XG4gICAgICBlcnJvciA9IHRoaXMuI3NlbGVjdEVycm9yO1xuICAgICAgZGF0YSA9IHRoaXMuI3NlbGVjdFJlc3VsdDtcbiAgICAgIGVycm9yVXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcbiAgICAgIHN0YXR1cyA9IFwiZXJyb3JcIjtcbiAgICB9XG4gICAgY29uc3QgaXNGZXRjaGluZyA9IG5ld1N0YXRlLmZldGNoU3RhdHVzID09PSBcImZldGNoaW5nXCI7XG4gICAgY29uc3QgaXNQZW5kaW5nID0gc3RhdHVzID09PSBcInBlbmRpbmdcIjtcbiAgICBjb25zdCBpc0Vycm9yID0gc3RhdHVzID09PSBcImVycm9yXCI7XG4gICAgY29uc3QgaXNMb2FkaW5nID0gaXNQZW5kaW5nICYmIGlzRmV0Y2hpbmc7XG4gICAgY29uc3QgaGFzRGF0YSA9IGRhdGEgIT09IHZvaWQgMDtcbiAgICBjb25zdCByZXN1bHQgPSB7XG4gICAgICBzdGF0dXMsXG4gICAgICBmZXRjaFN0YXR1czogbmV3U3RhdGUuZmV0Y2hTdGF0dXMsXG4gICAgICBpc1BlbmRpbmcsXG4gICAgICBpc1N1Y2Nlc3M6IHN0YXR1cyA9PT0gXCJzdWNjZXNzXCIsXG4gICAgICBpc0Vycm9yLFxuICAgICAgaXNJbml0aWFsTG9hZGluZzogaXNMb2FkaW5nLFxuICAgICAgaXNMb2FkaW5nLFxuICAgICAgZGF0YSxcbiAgICAgIGRhdGFVcGRhdGVkQXQ6IG5ld1N0YXRlLmRhdGFVcGRhdGVkQXQsXG4gICAgICBlcnJvcixcbiAgICAgIGVycm9yVXBkYXRlZEF0LFxuICAgICAgZmFpbHVyZUNvdW50OiBuZXdTdGF0ZS5mZXRjaEZhaWx1cmVDb3VudCxcbiAgICAgIGZhaWx1cmVSZWFzb246IG5ld1N0YXRlLmZldGNoRmFpbHVyZVJlYXNvbixcbiAgICAgIGVycm9yVXBkYXRlQ291bnQ6IG5ld1N0YXRlLmVycm9yVXBkYXRlQ291bnQsXG4gICAgICBpc0ZldGNoZWQ6IHF1ZXJ5LmlzRmV0Y2hlZCgpLFxuICAgICAgaXNGZXRjaGVkQWZ0ZXJNb3VudDogbmV3U3RhdGUuZGF0YVVwZGF0ZUNvdW50ID4gcXVlcnlJbml0aWFsU3RhdGUuZGF0YVVwZGF0ZUNvdW50IHx8IG5ld1N0YXRlLmVycm9yVXBkYXRlQ291bnQgPiBxdWVyeUluaXRpYWxTdGF0ZS5lcnJvclVwZGF0ZUNvdW50LFxuICAgICAgaXNGZXRjaGluZyxcbiAgICAgIGlzUmVmZXRjaGluZzogaXNGZXRjaGluZyAmJiAhaXNQZW5kaW5nLFxuICAgICAgaXNMb2FkaW5nRXJyb3I6IGlzRXJyb3IgJiYgIWhhc0RhdGEsXG4gICAgICBpc1BhdXNlZDogbmV3U3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwicGF1c2VkXCIsXG4gICAgICBpc1BsYWNlaG9sZGVyRGF0YSxcbiAgICAgIGlzUmVmZXRjaEVycm9yOiBpc0Vycm9yICYmIGhhc0RhdGEsXG4gICAgICBpc1N0YWxlOiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKSxcbiAgICAgIHJlZmV0Y2g6IHRoaXMucmVmZXRjaCxcbiAgICAgIHByb21pc2U6IHRoaXMuI2N1cnJlbnRUaGVuYWJsZSxcbiAgICAgIGlzRW5hYmxlZDogcmVzb2x2ZVF1ZXJ5Qm9vbGVhbihvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2VcbiAgICB9O1xuICAgIGNvbnN0IG5leHRSZXN1bHQgPSByZXN1bHQ7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5leHBlcmltZW50YWxfcHJlZmV0Y2hJblJlbmRlcikge1xuICAgICAgY29uc3QgaGFzUmVzdWx0RGF0YSA9IG5leHRSZXN1bHQuZGF0YSAhPT0gdm9pZCAwO1xuICAgICAgY29uc3QgaXNFcnJvcldpdGhvdXREYXRhID0gbmV4dFJlc3VsdC5zdGF0dXMgPT09IFwiZXJyb3JcIiAmJiAhaGFzUmVzdWx0RGF0YTtcbiAgICAgIGNvbnN0IGZpbmFsaXplVGhlbmFibGVJZlBvc3NpYmxlID0gKHRoZW5hYmxlKSA9PiB7XG4gICAgICAgIGlmIChpc0Vycm9yV2l0aG91dERhdGEpIHtcbiAgICAgICAgICB0aGVuYWJsZS5yZWplY3QobmV4dFJlc3VsdC5lcnJvcik7XG4gICAgICAgIH0gZWxzZSBpZiAoaGFzUmVzdWx0RGF0YSkge1xuICAgICAgICAgIHRoZW5hYmxlLnJlc29sdmUobmV4dFJlc3VsdC5kYXRhKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IHJlY3JlYXRlVGhlbmFibGUgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHBlbmRpbmcgPSB0aGlzLiNjdXJyZW50VGhlbmFibGUgPSBuZXh0UmVzdWx0LnByb21pc2UgPSBwZW5kaW5nVGhlbmFibGUoKTtcbiAgICAgICAgZmluYWxpemVUaGVuYWJsZUlmUG9zc2libGUocGVuZGluZyk7XG4gICAgICB9O1xuICAgICAgY29uc3QgcHJldlRoZW5hYmxlID0gdGhpcy4jY3VycmVudFRoZW5hYmxlO1xuICAgICAgc3dpdGNoIChwcmV2VGhlbmFibGUuc3RhdHVzKSB7XG4gICAgICAgIGNhc2UgXCJwZW5kaW5nXCI6XG4gICAgICAgICAgaWYgKHF1ZXJ5LnF1ZXJ5SGFzaCA9PT0gcHJldlF1ZXJ5LnF1ZXJ5SGFzaCkge1xuICAgICAgICAgICAgZmluYWxpemVUaGVuYWJsZUlmUG9zc2libGUocHJldlRoZW5hYmxlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJmdWxmaWxsZWRcIjpcbiAgICAgICAgICBpZiAoaXNFcnJvcldpdGhvdXREYXRhIHx8IG5leHRSZXN1bHQuZGF0YSAhPT0gcHJldlRoZW5hYmxlLnZhbHVlKSB7XG4gICAgICAgICAgICByZWNyZWF0ZVRoZW5hYmxlKCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwicmVqZWN0ZWRcIjpcbiAgICAgICAgICBpZiAoIWlzRXJyb3JXaXRob3V0RGF0YSB8fCBuZXh0UmVzdWx0LmVycm9yICE9PSBwcmV2VGhlbmFibGUucmVhc29uKSB7XG4gICAgICAgICAgICByZWNyZWF0ZVRoZW5hYmxlKCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbmV4dFJlc3VsdDtcbiAgfVxuICB1cGRhdGVSZXN1bHQoKSB7XG4gICAgY29uc3QgcHJldlJlc3VsdCA9IHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG4gICAgY29uc3QgbmV4dFJlc3VsdCA9IHRoaXMuY3JlYXRlUmVzdWx0KHRoaXMuI2N1cnJlbnRRdWVyeSwgdGhpcy5vcHRpb25zKTtcbiAgICB0aGlzLiNjdXJyZW50UmVzdWx0U3RhdGUgPSB0aGlzLiNjdXJyZW50UXVlcnkuc3RhdGU7XG4gICAgdGhpcy4jY3VycmVudFJlc3VsdE9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG4gICAgaWYgKHRoaXMuI2N1cnJlbnRSZXN1bHRTdGF0ZS5kYXRhICE9PSB2b2lkIDApIHtcbiAgICAgIHRoaXMuI2xhc3RRdWVyeVdpdGhEZWZpbmVkRGF0YSA9IHRoaXMuI2N1cnJlbnRRdWVyeTtcbiAgICB9XG4gICAgaWYgKHNoYWxsb3dFcXVhbE9iamVjdHMobmV4dFJlc3VsdCwgcHJldlJlc3VsdCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy4jY3VycmVudFJlc3VsdCA9IG5leHRSZXN1bHQ7XG4gICAgY29uc3Qgc2hvdWxkTm90aWZ5TGlzdGVuZXJzID0gKCkgPT4ge1xuICAgICAgaWYgKCFwcmV2UmVzdWx0KSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgeyBub3RpZnlPbkNoYW5nZVByb3BzIH0gPSB0aGlzLm9wdGlvbnM7XG4gICAgICBjb25zdCBub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgPSB0eXBlb2Ygbm90aWZ5T25DaGFuZ2VQcm9wcyA9PT0gXCJmdW5jdGlvblwiID8gbm90aWZ5T25DaGFuZ2VQcm9wcygpIDogbm90aWZ5T25DaGFuZ2VQcm9wcztcbiAgICAgIGlmIChub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgPT09IFwiYWxsXCIgfHwgIW5vdGlmeU9uQ2hhbmdlUHJvcHNWYWx1ZSAmJiAhdGhpcy4jdHJhY2tlZFByb3BzLnNpemUpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBjb25zdCBpbmNsdWRlZFByb3BzID0gbmV3IFNldChcbiAgICAgICAgbm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlID8/IHRoaXMuI3RyYWNrZWRQcm9wc1xuICAgICAgKTtcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMudGhyb3dPbkVycm9yKSB7XG4gICAgICAgIGluY2x1ZGVkUHJvcHMuYWRkKFwiZXJyb3JcIik7XG4gICAgICB9XG4gICAgICByZXR1cm4gT2JqZWN0LmtleXModGhpcy4jY3VycmVudFJlc3VsdCkuc29tZSgoa2V5KSA9PiB7XG4gICAgICAgIGNvbnN0IHR5cGVkS2V5ID0ga2V5O1xuICAgICAgICBjb25zdCBjaGFuZ2VkID0gdGhpcy4jY3VycmVudFJlc3VsdFt0eXBlZEtleV0gIT09IHByZXZSZXN1bHRbdHlwZWRLZXldO1xuICAgICAgICByZXR1cm4gY2hhbmdlZCAmJiBpbmNsdWRlZFByb3BzLmhhcyh0eXBlZEtleSk7XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHRoaXMuI25vdGlmeSh7IGxpc3RlbmVyczogc2hvdWxkTm90aWZ5TGlzdGVuZXJzKCkgfSk7XG4gIH1cbiAgI3VwZGF0ZVF1ZXJ5KCkge1xuICAgIGNvbnN0IHF1ZXJ5ID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIHRoaXMub3B0aW9ucyk7XG4gICAgaWYgKHF1ZXJ5ID09PSB0aGlzLiNjdXJyZW50UXVlcnkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcHJldlF1ZXJ5ID0gdGhpcy4jY3VycmVudFF1ZXJ5O1xuICAgIHRoaXMuI2N1cnJlbnRRdWVyeSA9IHF1ZXJ5O1xuICAgIHRoaXMuI2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSA9IHF1ZXJ5LnN0YXRlO1xuICAgIGlmICh0aGlzLmhhc0xpc3RlbmVycygpKSB7XG4gICAgICBwcmV2UXVlcnk/LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuICAgICAgcXVlcnkuYWRkT2JzZXJ2ZXIodGhpcyk7XG4gICAgfVxuICB9XG4gIG9uUXVlcnlVcGRhdGUoKSB7XG4gICAgdGhpcy51cGRhdGVSZXN1bHQoKTtcbiAgICBpZiAodGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuICAgICAgdGhpcy4jdXBkYXRlVGltZXJzKCk7XG4gICAgfVxuICB9XG4gICNub3RpZnkobm90aWZ5T3B0aW9ucykge1xuICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgaWYgKG5vdGlmeU9wdGlvbnMubGlzdGVuZXJzKSB7XG4gICAgICAgIHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG4gICAgICAgICAgbGlzdGVuZXIodGhpcy4jY3VycmVudFJlc3VsdCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5ub3RpZnkoe1xuICAgICAgICBxdWVyeTogdGhpcy4jY3VycmVudFF1ZXJ5LFxuICAgICAgICB0eXBlOiBcIm9ic2VydmVyUmVzdWx0c1VwZGF0ZWRcIlxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbn07XG5mdW5jdGlvbiBzaG91bGRMb2FkT25Nb3VudChxdWVyeSwgb3B0aW9ucykge1xuICByZXR1cm4gcmVzb2x2ZVF1ZXJ5Qm9vbGVhbihvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2UgJiYgcXVlcnkuc3RhdGUuZGF0YSA9PT0gdm9pZCAwICYmICEocXVlcnkuc3RhdGUuc3RhdHVzID09PSBcImVycm9yXCIgJiYgcmVzb2x2ZVF1ZXJ5Qm9vbGVhbihvcHRpb25zLnJldHJ5T25Nb3VudCwgcXVlcnkpID09PSBmYWxzZSk7XG59XG5mdW5jdGlvbiBzaG91bGRGZXRjaE9uTW91bnQocXVlcnksIG9wdGlvbnMpIHtcbiAgcmV0dXJuIHNob3VsZExvYWRPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKSB8fCBxdWVyeS5zdGF0ZS5kYXRhICE9PSB2b2lkIDAgJiYgc2hvdWxkRmV0Y2hPbihxdWVyeSwgb3B0aW9ucywgb3B0aW9ucy5yZWZldGNoT25Nb3VudCk7XG59XG5mdW5jdGlvbiBzaG91bGRGZXRjaE9uKHF1ZXJ5LCBvcHRpb25zLCBmaWVsZCkge1xuICBpZiAocmVzb2x2ZVF1ZXJ5Qm9vbGVhbihvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2UgJiYgcmVzb2x2ZVN0YWxlVGltZShvcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpICE9PSBcInN0YXRpY1wiKSB7XG4gICAgY29uc3QgdmFsdWUgPSB0eXBlb2YgZmllbGQgPT09IFwiZnVuY3Rpb25cIiA/IGZpZWxkKHF1ZXJ5KSA6IGZpZWxkO1xuICAgIHJldHVybiB2YWx1ZSA9PT0gXCJhbHdheXNcIiB8fCB2YWx1ZSAhPT0gZmFsc2UgJiYgaXNTdGFsZShxdWVyeSwgb3B0aW9ucyk7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZnVuY3Rpb24gc2hvdWxkRmV0Y2hPcHRpb25hbGx5KHF1ZXJ5LCBwcmV2UXVlcnksIG9wdGlvbnMsIHByZXZPcHRpb25zKSB7XG4gIHJldHVybiAocXVlcnkgIT09IHByZXZRdWVyeSB8fCByZXNvbHZlUXVlcnlCb29sZWFuKHByZXZPcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSA9PT0gZmFsc2UpICYmICghb3B0aW9ucy5zdXNwZW5zZSB8fCBxdWVyeS5zdGF0ZS5zdGF0dXMgIT09IFwiZXJyb3JcIikgJiYgaXNTdGFsZShxdWVyeSwgb3B0aW9ucyk7XG59XG5mdW5jdGlvbiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKSB7XG4gIHJldHVybiByZXNvbHZlUXVlcnlCb29sZWFuKG9wdGlvbnMuZW5hYmxlZCwgcXVlcnkpICE9PSBmYWxzZSAmJiBxdWVyeS5pc1N0YWxlQnlUaW1lKHJlc29sdmVTdGFsZVRpbWUob3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSk7XG59XG5mdW5jdGlvbiBzaG91bGRBc3NpZ25PYnNlcnZlckN1cnJlbnRQcm9wZXJ0aWVzKG9ic2VydmVyLCBvcHRpbWlzdGljUmVzdWx0KSB7XG4gIGlmICghc2hhbGxvd0VxdWFsT2JqZWN0cyhvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCksIG9wdGltaXN0aWNSZXN1bHQpKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZXhwb3J0IHtcbiAgUXVlcnlPYnNlcnZlclxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5T2JzZXJ2ZXIuanMubWFwIiwiLy8gc3JjL2luZmluaXRlUXVlcnlPYnNlcnZlci50c1xuaW1wb3J0IHsgUXVlcnlPYnNlcnZlciB9IGZyb20gXCIuL3F1ZXJ5T2JzZXJ2ZXIuanNcIjtcbmltcG9ydCB7IGhhc05leHRQYWdlLCBoYXNQcmV2aW91c1BhZ2UgfSBmcm9tIFwiLi9pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IuanNcIjtcbnZhciBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgPSBjbGFzcyBleHRlbmRzIFF1ZXJ5T2JzZXJ2ZXIge1xuICBjb25zdHJ1Y3RvcihjbGllbnQsIG9wdGlvbnMpIHtcbiAgICBzdXBlcihjbGllbnQsIG9wdGlvbnMpO1xuICB9XG4gIGJpbmRNZXRob2RzKCkge1xuICAgIHN1cGVyLmJpbmRNZXRob2RzKCk7XG4gICAgdGhpcy5mZXRjaE5leHRQYWdlID0gdGhpcy5mZXRjaE5leHRQYWdlLmJpbmQodGhpcyk7XG4gICAgdGhpcy5mZXRjaFByZXZpb3VzUGFnZSA9IHRoaXMuZmV0Y2hQcmV2aW91c1BhZ2UuYmluZCh0aGlzKTtcbiAgfVxuICBzZXRPcHRpb25zKG9wdGlvbnMpIHtcbiAgICBvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuICAgIHN1cGVyLnNldE9wdGlvbnMob3B0aW9ucyk7XG4gIH1cbiAgZ2V0T3B0aW1pc3RpY1Jlc3VsdChvcHRpb25zKSB7XG4gICAgb3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcbiAgICByZXR1cm4gc3VwZXIuZ2V0T3B0aW1pc3RpY1Jlc3VsdChvcHRpb25zKTtcbiAgfVxuICBmZXRjaE5leHRQYWdlKG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5mZXRjaCh7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgbWV0YToge1xuICAgICAgICBmZXRjaE1vcmU6IHsgZGlyZWN0aW9uOiBcImZvcndhcmRcIiB9XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgZmV0Y2hQcmV2aW91c1BhZ2Uob3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLmZldGNoKHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBtZXRhOiB7XG4gICAgICAgIGZldGNoTW9yZTogeyBkaXJlY3Rpb246IFwiYmFja3dhcmRcIiB9XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgY3JlYXRlUmVzdWx0KHF1ZXJ5LCBvcHRpb25zKSB7XG4gICAgY29uc3QgeyBzdGF0ZSB9ID0gcXVlcnk7XG4gICAgY29uc3QgcGFyZW50UmVzdWx0ID0gc3VwZXIuY3JlYXRlUmVzdWx0KHF1ZXJ5LCBvcHRpb25zKTtcbiAgICBjb25zdCB7IGlzRmV0Y2hpbmcsIGlzUmVmZXRjaGluZywgaXNFcnJvciwgaXNSZWZldGNoRXJyb3IgfSA9IHBhcmVudFJlc3VsdDtcbiAgICBjb25zdCBmZXRjaERpcmVjdGlvbiA9IHN0YXRlLmZldGNoTWV0YT8uZmV0Y2hNb3JlPy5kaXJlY3Rpb247XG4gICAgY29uc3QgaXNGZXRjaE5leHRQYWdlRXJyb3IgPSBpc0Vycm9yICYmIGZldGNoRGlyZWN0aW9uID09PSBcImZvcndhcmRcIjtcbiAgICBjb25zdCBpc0ZldGNoaW5nTmV4dFBhZ2UgPSBpc0ZldGNoaW5nICYmIGZldGNoRGlyZWN0aW9uID09PSBcImZvcndhcmRcIjtcbiAgICBjb25zdCBpc0ZldGNoUHJldmlvdXNQYWdlRXJyb3IgPSBpc0Vycm9yICYmIGZldGNoRGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG4gICAgY29uc3QgaXNGZXRjaGluZ1ByZXZpb3VzUGFnZSA9IGlzRmV0Y2hpbmcgJiYgZmV0Y2hEaXJlY3Rpb24gPT09IFwiYmFja3dhcmRcIjtcbiAgICBjb25zdCByZXN1bHQgPSB7XG4gICAgICAuLi5wYXJlbnRSZXN1bHQsXG4gICAgICBmZXRjaE5leHRQYWdlOiB0aGlzLmZldGNoTmV4dFBhZ2UsXG4gICAgICBmZXRjaFByZXZpb3VzUGFnZTogdGhpcy5mZXRjaFByZXZpb3VzUGFnZSxcbiAgICAgIGhhc05leHRQYWdlOiBoYXNOZXh0UGFnZShvcHRpb25zLCBzdGF0ZS5kYXRhKSxcbiAgICAgIGhhc1ByZXZpb3VzUGFnZTogaGFzUHJldmlvdXNQYWdlKG9wdGlvbnMsIHN0YXRlLmRhdGEpLFxuICAgICAgaXNGZXRjaE5leHRQYWdlRXJyb3IsXG4gICAgICBpc0ZldGNoaW5nTmV4dFBhZ2UsXG4gICAgICBpc0ZldGNoUHJldmlvdXNQYWdlRXJyb3IsXG4gICAgICBpc0ZldGNoaW5nUHJldmlvdXNQYWdlLFxuICAgICAgaXNSZWZldGNoRXJyb3I6IGlzUmVmZXRjaEVycm9yICYmICFpc0ZldGNoTmV4dFBhZ2VFcnJvciAmJiAhaXNGZXRjaFByZXZpb3VzUGFnZUVycm9yLFxuICAgICAgaXNSZWZldGNoaW5nOiBpc1JlZmV0Y2hpbmcgJiYgIWlzRmV0Y2hpbmdOZXh0UGFnZSAmJiAhaXNGZXRjaGluZ1ByZXZpb3VzUGFnZVxuICAgIH07XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxufTtcbmV4cG9ydCB7XG4gIEluZmluaXRlUXVlcnlPYnNlcnZlclxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZmluaXRlUXVlcnlPYnNlcnZlci5qcy5tYXAiLCIvLyBzcmMvbXV0YXRpb24udHNcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBSZW1vdmFibGUgfSBmcm9tIFwiLi9yZW1vdmFibGUuanNcIjtcbmltcG9ydCB7IGNyZWF0ZVJldHJ5ZXIgfSBmcm9tIFwiLi9yZXRyeWVyLmpzXCI7XG52YXIgTXV0YXRpb24gPSBjbGFzcyBleHRlbmRzIFJlbW92YWJsZSB7XG4gICNjbGllbnQ7XG4gICNvYnNlcnZlcnM7XG4gICNtdXRhdGlvbkNhY2hlO1xuICAjcmV0cnllcjtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLiNjbGllbnQgPSBjb25maWcuY2xpZW50O1xuICAgIHRoaXMubXV0YXRpb25JZCA9IGNvbmZpZy5tdXRhdGlvbklkO1xuICAgIHRoaXMuI211dGF0aW9uQ2FjaGUgPSBjb25maWcubXV0YXRpb25DYWNoZTtcbiAgICB0aGlzLiNvYnNlcnZlcnMgPSBbXTtcbiAgICB0aGlzLnN0YXRlID0gY29uZmlnLnN0YXRlIHx8IGdldERlZmF1bHRTdGF0ZSgpO1xuICAgIHRoaXMuc2V0T3B0aW9ucyhjb25maWcub3B0aW9ucyk7XG4gICAgdGhpcy5zY2hlZHVsZUdjKCk7XG4gIH1cbiAgc2V0T3B0aW9ucyhvcHRpb25zKSB7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLnVwZGF0ZUdjVGltZSh0aGlzLm9wdGlvbnMuZ2NUaW1lKTtcbiAgfVxuICBnZXQgbWV0YSgpIHtcbiAgICByZXR1cm4gdGhpcy5vcHRpb25zLm1ldGE7XG4gIH1cbiAgYWRkT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcbiAgICBpZiAoIXRoaXMuI29ic2VydmVycy5pbmNsdWRlcyhvYnNlcnZlcikpIHtcbiAgICAgIHRoaXMuI29ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcbiAgICAgIHRoaXMuY2xlYXJHY1RpbWVvdXQoKTtcbiAgICAgIHRoaXMuI211dGF0aW9uQ2FjaGUubm90aWZ5KHtcbiAgICAgICAgdHlwZTogXCJvYnNlcnZlckFkZGVkXCIsXG4gICAgICAgIG11dGF0aW9uOiB0aGlzLFxuICAgICAgICBvYnNlcnZlclxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJlbW92ZU9ic2VydmVyKG9ic2VydmVyKSB7XG4gICAgdGhpcy4jb2JzZXJ2ZXJzID0gdGhpcy4jb2JzZXJ2ZXJzLmZpbHRlcigoeCkgPT4geCAhPT0gb2JzZXJ2ZXIpO1xuICAgIHRoaXMuc2NoZWR1bGVHYygpO1xuICAgIHRoaXMuI211dGF0aW9uQ2FjaGUubm90aWZ5KHtcbiAgICAgIHR5cGU6IFwib2JzZXJ2ZXJSZW1vdmVkXCIsXG4gICAgICBtdXRhdGlvbjogdGhpcyxcbiAgICAgIG9ic2VydmVyXG4gICAgfSk7XG4gIH1cbiAgb3B0aW9uYWxSZW1vdmUoKSB7XG4gICAgaWYgKCF0aGlzLiNvYnNlcnZlcnMubGVuZ3RoKSB7XG4gICAgICBpZiAodGhpcy5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiKSB7XG4gICAgICAgIHRoaXMuc2NoZWR1bGVHYygpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy4jbXV0YXRpb25DYWNoZS5yZW1vdmUodGhpcyk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbnRpbnVlKCkge1xuICAgIHJldHVybiB0aGlzLiNyZXRyeWVyPy5jb250aW51ZSgpID8/IC8vIGNvbnRpbnVpbmcgYSBtdXRhdGlvbiBhc3N1bWVzIHRoYXQgdmFyaWFibGVzIGFyZSBzZXQsIG11dGF0aW9uIG11c3QgaGF2ZSBiZWVuIGRlaHlkcmF0ZWQgYmVmb3JlXG4gICAgdGhpcy5leGVjdXRlKHRoaXMuc3RhdGUudmFyaWFibGVzKTtcbiAgfVxuICBhc3luYyBleGVjdXRlKHZhcmlhYmxlcykge1xuICAgIGNvbnN0IG9uQ29udGludWUgPSAoKSA9PiB7XG4gICAgICB0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiY29udGludWVcIiB9KTtcbiAgICB9O1xuICAgIGNvbnN0IG11dGF0aW9uRm5Db250ZXh0ID0ge1xuICAgICAgY2xpZW50OiB0aGlzLiNjbGllbnQsXG4gICAgICBtZXRhOiB0aGlzLm9wdGlvbnMubWV0YSxcbiAgICAgIG11dGF0aW9uS2V5OiB0aGlzLm9wdGlvbnMubXV0YXRpb25LZXlcbiAgICB9O1xuICAgIHRoaXMuI3JldHJ5ZXIgPSBjcmVhdGVSZXRyeWVyKHtcbiAgICAgIGZuOiAoKSA9PiB7XG4gICAgICAgIGlmICghdGhpcy5vcHRpb25zLm11dGF0aW9uRm4pIHtcbiAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKFwiTm8gbXV0YXRpb25GbiBmb3VuZFwiKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMub3B0aW9ucy5tdXRhdGlvbkZuKHZhcmlhYmxlcywgbXV0YXRpb25GbkNvbnRleHQpO1xuICAgICAgfSxcbiAgICAgIG9uRmFpbDogKGZhaWx1cmVDb3VudCwgZXJyb3IpID0+IHtcbiAgICAgICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcImZhaWxlZFwiLCBmYWlsdXJlQ291bnQsIGVycm9yIH0pO1xuICAgICAgfSxcbiAgICAgIG9uUGF1c2U6ICgpID0+IHtcbiAgICAgICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcInBhdXNlXCIgfSk7XG4gICAgICB9LFxuICAgICAgb25Db250aW51ZSxcbiAgICAgIHJldHJ5OiB0aGlzLm9wdGlvbnMucmV0cnkgPz8gMCxcbiAgICAgIHJldHJ5RGVsYXk6IHRoaXMub3B0aW9ucy5yZXRyeURlbGF5LFxuICAgICAgbmV0d29ya01vZGU6IHRoaXMub3B0aW9ucy5uZXR3b3JrTW9kZSxcbiAgICAgIGNhblJ1bjogKCkgPT4gdGhpcy4jbXV0YXRpb25DYWNoZS5jYW5SdW4odGhpcylcbiAgICB9KTtcbiAgICBjb25zdCByZXN0b3JlZCA9IHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIjtcbiAgICBjb25zdCBpc1BhdXNlZCA9ICF0aGlzLiNyZXRyeWVyLmNhblN0YXJ0KCk7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChyZXN0b3JlZCkge1xuICAgICAgICBvbkNvbnRpbnVlKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwicGVuZGluZ1wiLCB2YXJpYWJsZXMsIGlzUGF1c2VkIH0pO1xuICAgICAgICBpZiAodGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25NdXRhdGUpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vbk11dGF0ZShcbiAgICAgICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICBtdXRhdGlvbkZuQ29udGV4dFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY29udGV4dCA9IGF3YWl0IHRoaXMub3B0aW9ucy5vbk11dGF0ZT8uKFxuICAgICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgICBtdXRhdGlvbkZuQ29udGV4dFxuICAgICAgICApO1xuICAgICAgICBpZiAoY29udGV4dCAhPT0gdGhpcy5zdGF0ZS5jb250ZXh0KSB7XG4gICAgICAgICAgdGhpcy4jZGlzcGF0Y2goe1xuICAgICAgICAgICAgdHlwZTogXCJwZW5kaW5nXCIsXG4gICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICAgICAgaXNQYXVzZWRcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHRoaXMuI3JldHJ5ZXIuc3RhcnQoKTtcbiAgICAgIGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uU3VjY2Vzcz8uKFxuICAgICAgICBkYXRhLFxuICAgICAgICB2YXJpYWJsZXMsXG4gICAgICAgIHRoaXMuc3RhdGUuY29udGV4dCxcbiAgICAgICAgdGhpcyxcbiAgICAgICAgbXV0YXRpb25GbkNvbnRleHRcbiAgICAgICk7XG4gICAgICBhd2FpdCB0aGlzLm9wdGlvbnMub25TdWNjZXNzPy4oXG4gICAgICAgIGRhdGEsXG4gICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgdGhpcy5zdGF0ZS5jb250ZXh0LFxuICAgICAgICBtdXRhdGlvbkZuQ29udGV4dFxuICAgICAgKTtcbiAgICAgIGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uU2V0dGxlZD8uKFxuICAgICAgICBkYXRhLFxuICAgICAgICBudWxsLFxuICAgICAgICB0aGlzLnN0YXRlLnZhcmlhYmxlcyxcbiAgICAgICAgdGhpcy5zdGF0ZS5jb250ZXh0LFxuICAgICAgICB0aGlzLFxuICAgICAgICBtdXRhdGlvbkZuQ29udGV4dFxuICAgICAgKTtcbiAgICAgIGF3YWl0IHRoaXMub3B0aW9ucy5vblNldHRsZWQ/LihcbiAgICAgICAgZGF0YSxcbiAgICAgICAgbnVsbCxcbiAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICB0aGlzLnN0YXRlLmNvbnRleHQsXG4gICAgICAgIG11dGF0aW9uRm5Db250ZXh0XG4gICAgICApO1xuICAgICAgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcInN1Y2Nlc3NcIiwgZGF0YSB9KTtcbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vbkVycm9yPy4oXG4gICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICAgIHRoaXMuc3RhdGUuY29udGV4dCxcbiAgICAgICAgICB0aGlzLFxuICAgICAgICAgIG11dGF0aW9uRm5Db250ZXh0XG4gICAgICAgICk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHZvaWQgUHJvbWlzZS5yZWplY3QoZSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLm9wdGlvbnMub25FcnJvcj8uKFxuICAgICAgICAgIGVycm9yLFxuICAgICAgICAgIHZhcmlhYmxlcyxcbiAgICAgICAgICB0aGlzLnN0YXRlLmNvbnRleHQsXG4gICAgICAgICAgbXV0YXRpb25GbkNvbnRleHRcbiAgICAgICAgKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdm9pZCBQcm9taXNlLnJlamVjdChlKTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uU2V0dGxlZD8uKFxuICAgICAgICAgIHZvaWQgMCxcbiAgICAgICAgICBlcnJvcixcbiAgICAgICAgICB0aGlzLnN0YXRlLnZhcmlhYmxlcyxcbiAgICAgICAgICB0aGlzLnN0YXRlLmNvbnRleHQsXG4gICAgICAgICAgdGhpcyxcbiAgICAgICAgICBtdXRhdGlvbkZuQ29udGV4dFxuICAgICAgICApO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB2b2lkIFByb21pc2UucmVqZWN0KGUpO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5vcHRpb25zLm9uU2V0dGxlZD8uKFxuICAgICAgICAgIHZvaWQgMCxcbiAgICAgICAgICBlcnJvcixcbiAgICAgICAgICB2YXJpYWJsZXMsXG4gICAgICAgICAgdGhpcy5zdGF0ZS5jb250ZXh0LFxuICAgICAgICAgIG11dGF0aW9uRm5Db250ZXh0XG4gICAgICAgICk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHZvaWQgUHJvbWlzZS5yZWplY3QoZSk7XG4gICAgICB9XG4gICAgICB0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiZXJyb3JcIiwgZXJyb3IgfSk7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy4jbXV0YXRpb25DYWNoZS5ydW5OZXh0KHRoaXMpO1xuICAgIH1cbiAgfVxuICAjZGlzcGF0Y2goYWN0aW9uKSB7XG4gICAgY29uc3QgcmVkdWNlciA9IChzdGF0ZSkgPT4ge1xuICAgICAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xuICAgICAgICBjYXNlIFwiZmFpbGVkXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgZmFpbHVyZUNvdW50OiBhY3Rpb24uZmFpbHVyZUNvdW50LFxuICAgICAgICAgICAgZmFpbHVyZVJlYXNvbjogYWN0aW9uLmVycm9yXG4gICAgICAgICAgfTtcbiAgICAgICAgY2FzZSBcInBhdXNlXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgaXNQYXVzZWQ6IHRydWVcbiAgICAgICAgICB9O1xuICAgICAgICBjYXNlIFwiY29udGludWVcIjpcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICBpc1BhdXNlZDogZmFsc2VcbiAgICAgICAgICB9O1xuICAgICAgICBjYXNlIFwicGVuZGluZ1wiOlxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIGNvbnRleHQ6IGFjdGlvbi5jb250ZXh0LFxuICAgICAgICAgICAgZGF0YTogdm9pZCAwLFxuICAgICAgICAgICAgZmFpbHVyZUNvdW50OiAwLFxuICAgICAgICAgICAgZmFpbHVyZVJlYXNvbjogbnVsbCxcbiAgICAgICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICAgICAgaXNQYXVzZWQ6IGFjdGlvbi5pc1BhdXNlZCxcbiAgICAgICAgICAgIHN0YXR1czogXCJwZW5kaW5nXCIsXG4gICAgICAgICAgICB2YXJpYWJsZXM6IGFjdGlvbi52YXJpYWJsZXMsXG4gICAgICAgICAgICBzdWJtaXR0ZWRBdDogRGF0ZS5ub3coKVxuICAgICAgICAgIH07XG4gICAgICAgIGNhc2UgXCJzdWNjZXNzXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgZGF0YTogYWN0aW9uLmRhdGEsXG4gICAgICAgICAgICBmYWlsdXJlQ291bnQ6IDAsXG4gICAgICAgICAgICBmYWlsdXJlUmVhc29uOiBudWxsLFxuICAgICAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgICAgICBzdGF0dXM6IFwic3VjY2Vzc1wiLFxuICAgICAgICAgICAgaXNQYXVzZWQ6IGZhbHNlXG4gICAgICAgICAgfTtcbiAgICAgICAgY2FzZSBcImVycm9yXCI6XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgZGF0YTogdm9pZCAwLFxuICAgICAgICAgICAgZXJyb3I6IGFjdGlvbi5lcnJvcixcbiAgICAgICAgICAgIGZhaWx1cmVDb3VudDogc3RhdGUuZmFpbHVyZUNvdW50ICsgMSxcbiAgICAgICAgICAgIGZhaWx1cmVSZWFzb246IGFjdGlvbi5lcnJvcixcbiAgICAgICAgICAgIGlzUGF1c2VkOiBmYWxzZSxcbiAgICAgICAgICAgIHN0YXR1czogXCJlcnJvclwiXG4gICAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHRoaXMuc3RhdGUgPSByZWR1Y2VyKHRoaXMuc3RhdGUpO1xuICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgdGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG4gICAgICAgIG9ic2VydmVyLm9uTXV0YXRpb25VcGRhdGUoYWN0aW9uKTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy4jbXV0YXRpb25DYWNoZS5ub3RpZnkoe1xuICAgICAgICBtdXRhdGlvbjogdGhpcyxcbiAgICAgICAgdHlwZTogXCJ1cGRhdGVkXCIsXG4gICAgICAgIGFjdGlvblxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbn07XG5mdW5jdGlvbiBnZXREZWZhdWx0U3RhdGUoKSB7XG4gIHJldHVybiB7XG4gICAgY29udGV4dDogdm9pZCAwLFxuICAgIGRhdGE6IHZvaWQgMCxcbiAgICBlcnJvcjogbnVsbCxcbiAgICBmYWlsdXJlQ291bnQ6IDAsXG4gICAgZmFpbHVyZVJlYXNvbjogbnVsbCxcbiAgICBpc1BhdXNlZDogZmFsc2UsXG4gICAgc3RhdHVzOiBcImlkbGVcIixcbiAgICB2YXJpYWJsZXM6IHZvaWQgMCxcbiAgICBzdWJtaXR0ZWRBdDogMFxuICB9O1xufVxuZXhwb3J0IHtcbiAgTXV0YXRpb24sXG4gIGdldERlZmF1bHRTdGF0ZVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW11dGF0aW9uLmpzLm1hcCIsIi8vIHNyYy9tdXRhdGlvbkNhY2hlLnRzXG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgTXV0YXRpb24gfSBmcm9tIFwiLi9tdXRhdGlvbi5qc1wiO1xuaW1wb3J0IHsgbWF0Y2hNdXRhdGlvbiwgbm9vcCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbnZhciBNdXRhdGlvbkNhY2hlID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuICBjb25zdHJ1Y3Rvcihjb25maWcgPSB7fSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5jb25maWcgPSBjb25maWc7XG4gICAgdGhpcy4jbXV0YXRpb25zID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgICB0aGlzLiNzY29wZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIHRoaXMuI211dGF0aW9uSWQgPSAwO1xuICB9XG4gICNtdXRhdGlvbnM7XG4gICNzY29wZXM7XG4gICNtdXRhdGlvbklkO1xuICBidWlsZChjbGllbnQsIG9wdGlvbnMsIHN0YXRlKSB7XG4gICAgY29uc3QgbXV0YXRpb24gPSBuZXcgTXV0YXRpb24oe1xuICAgICAgY2xpZW50LFxuICAgICAgbXV0YXRpb25DYWNoZTogdGhpcyxcbiAgICAgIG11dGF0aW9uSWQ6ICsrdGhpcy4jbXV0YXRpb25JZCxcbiAgICAgIG9wdGlvbnM6IGNsaWVudC5kZWZhdWx0TXV0YXRpb25PcHRpb25zKG9wdGlvbnMpLFxuICAgICAgc3RhdGVcbiAgICB9KTtcbiAgICB0aGlzLmFkZChtdXRhdGlvbik7XG4gICAgcmV0dXJuIG11dGF0aW9uO1xuICB9XG4gIGFkZChtdXRhdGlvbikge1xuICAgIHRoaXMuI211dGF0aW9ucy5hZGQobXV0YXRpb24pO1xuICAgIGNvbnN0IHNjb3BlID0gc2NvcGVGb3IobXV0YXRpb24pO1xuICAgIGlmICh0eXBlb2Ygc2NvcGUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIGNvbnN0IHNjb3BlZE11dGF0aW9ucyA9IHRoaXMuI3Njb3Blcy5nZXQoc2NvcGUpO1xuICAgICAgaWYgKHNjb3BlZE11dGF0aW9ucykge1xuICAgICAgICBzY29wZWRNdXRhdGlvbnMucHVzaChtdXRhdGlvbik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLiNzY29wZXMuc2V0KHNjb3BlLCBbbXV0YXRpb25dKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5ub3RpZnkoeyB0eXBlOiBcImFkZGVkXCIsIG11dGF0aW9uIH0pO1xuICB9XG4gIHJlbW92ZShtdXRhdGlvbikge1xuICAgIGlmICh0aGlzLiNtdXRhdGlvbnMuZGVsZXRlKG11dGF0aW9uKSkge1xuICAgICAgY29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG4gICAgICBpZiAodHlwZW9mIHNjb3BlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIGNvbnN0IHNjb3BlZE11dGF0aW9ucyA9IHRoaXMuI3Njb3Blcy5nZXQoc2NvcGUpO1xuICAgICAgICBpZiAoc2NvcGVkTXV0YXRpb25zKSB7XG4gICAgICAgICAgaWYgKHNjb3BlZE11dGF0aW9ucy5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IHNjb3BlZE11dGF0aW9ucy5pbmRleE9mKG11dGF0aW9uKTtcbiAgICAgICAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgc2NvcGVkTXV0YXRpb25zLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmIChzY29wZWRNdXRhdGlvbnNbMF0gPT09IG11dGF0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLiNzY29wZXMuZGVsZXRlKHNjb3BlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5ub3RpZnkoeyB0eXBlOiBcInJlbW92ZWRcIiwgbXV0YXRpb24gfSk7XG4gIH1cbiAgY2FuUnVuKG11dGF0aW9uKSB7XG4gICAgY29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG4gICAgaWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgY29uc3QgbXV0YXRpb25zV2l0aFNhbWVTY29wZSA9IHRoaXMuI3Njb3Blcy5nZXQoc2NvcGUpO1xuICAgICAgY29uc3QgZmlyc3RQZW5kaW5nTXV0YXRpb24gPSBtdXRhdGlvbnNXaXRoU2FtZVNjb3BlPy5maW5kKFxuICAgICAgICAobSkgPT4gbS5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiXG4gICAgICApO1xuICAgICAgcmV0dXJuICFmaXJzdFBlbmRpbmdNdXRhdGlvbiB8fCBmaXJzdFBlbmRpbmdNdXRhdGlvbiA9PT0gbXV0YXRpb247XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfVxuICBydW5OZXh0KG11dGF0aW9uKSB7XG4gICAgY29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG4gICAgaWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgY29uc3QgZm91bmRNdXRhdGlvbiA9IHRoaXMuI3Njb3Blcy5nZXQoc2NvcGUpPy5maW5kKChtKSA9PiBtICE9PSBtdXRhdGlvbiAmJiBtLnN0YXRlLmlzUGF1c2VkKTtcbiAgICAgIHJldHVybiBmb3VuZE11dGF0aW9uPy5jb250aW51ZSgpID8/IFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfVxuICB9XG4gIGNsZWFyKCkge1xuICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgdGhpcy4jbXV0YXRpb25zLmZvckVhY2goKG11dGF0aW9uKSA9PiB7XG4gICAgICAgIHRoaXMubm90aWZ5KHsgdHlwZTogXCJyZW1vdmVkXCIsIG11dGF0aW9uIH0pO1xuICAgICAgfSk7XG4gICAgICB0aGlzLiNtdXRhdGlvbnMuY2xlYXIoKTtcbiAgICAgIHRoaXMuI3Njb3Blcy5jbGVhcigpO1xuICAgIH0pO1xuICB9XG4gIGdldEFsbCgpIHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbSh0aGlzLiNtdXRhdGlvbnMpO1xuICB9XG4gIGZpbmQoZmlsdGVycykge1xuICAgIGNvbnN0IGRlZmF1bHRlZEZpbHRlcnMgPSB7IGV4YWN0OiB0cnVlLCAuLi5maWx0ZXJzIH07XG4gICAgcmV0dXJuIHRoaXMuZ2V0QWxsKCkuZmluZChcbiAgICAgIChtdXRhdGlvbikgPT4gbWF0Y2hNdXRhdGlvbihkZWZhdWx0ZWRGaWx0ZXJzLCBtdXRhdGlvbilcbiAgICApO1xuICB9XG4gIGZpbmRBbGwoZmlsdGVycyA9IHt9KSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0QWxsKCkuZmlsdGVyKChtdXRhdGlvbikgPT4gbWF0Y2hNdXRhdGlvbihmaWx0ZXJzLCBtdXRhdGlvbikpO1xuICB9XG4gIG5vdGlmeShldmVudCkge1xuICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgdGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcbiAgICAgICAgbGlzdGVuZXIoZXZlbnQpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgcmVzdW1lUGF1c2VkTXV0YXRpb25zKCkge1xuICAgIGNvbnN0IHBhdXNlZE11dGF0aW9ucyA9IHRoaXMuZ2V0QWxsKCkuZmlsdGVyKCh4KSA9PiB4LnN0YXRlLmlzUGF1c2VkKTtcbiAgICByZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaChcbiAgICAgICgpID0+IFByb21pc2UuYWxsKFxuICAgICAgICBwYXVzZWRNdXRhdGlvbnMubWFwKChtdXRhdGlvbikgPT4gbXV0YXRpb24uY29udGludWUoKS5jYXRjaChub29wKSlcbiAgICAgIClcbiAgICApO1xuICB9XG59O1xuZnVuY3Rpb24gc2NvcGVGb3IobXV0YXRpb24pIHtcbiAgcmV0dXJuIG11dGF0aW9uLm9wdGlvbnMuc2NvcGU/LmlkO1xufVxuZXhwb3J0IHtcbiAgTXV0YXRpb25DYWNoZVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW11dGF0aW9uQ2FjaGUuanMubWFwIiwiLy8gc3JjL211dGF0aW9uT2JzZXJ2ZXIudHNcbmltcG9ydCB7IGdldERlZmF1bHRTdGF0ZSB9IGZyb20gXCIuL211dGF0aW9uLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBoYXNoS2V5LCBzaGFsbG93RXF1YWxPYmplY3RzIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbnZhciBNdXRhdGlvbk9ic2VydmVyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuICAjY2xpZW50O1xuICAjY3VycmVudFJlc3VsdCA9IHZvaWQgMDtcbiAgI2N1cnJlbnRNdXRhdGlvbjtcbiAgI211dGF0ZU9wdGlvbnM7XG4gIGNvbnN0cnVjdG9yKGNsaWVudCwgb3B0aW9ucykge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy4jY2xpZW50ID0gY2xpZW50O1xuICAgIHRoaXMuc2V0T3B0aW9ucyhvcHRpb25zKTtcbiAgICB0aGlzLmJpbmRNZXRob2RzKCk7XG4gICAgdGhpcy4jdXBkYXRlUmVzdWx0KCk7XG4gIH1cbiAgYmluZE1ldGhvZHMoKSB7XG4gICAgdGhpcy5tdXRhdGUgPSB0aGlzLm11dGF0ZS5iaW5kKHRoaXMpO1xuICAgIHRoaXMucmVzZXQgPSB0aGlzLnJlc2V0LmJpbmQodGhpcyk7XG4gIH1cbiAgc2V0T3B0aW9ucyhvcHRpb25zKSB7XG4gICAgY29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG4gICAgdGhpcy5vcHRpb25zID0gdGhpcy4jY2xpZW50LmRlZmF1bHRNdXRhdGlvbk9wdGlvbnMob3B0aW9ucyk7XG4gICAgaWYgKCFzaGFsbG93RXF1YWxPYmplY3RzKHRoaXMub3B0aW9ucywgcHJldk9wdGlvbnMpKSB7XG4gICAgICB0aGlzLiNjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpLm5vdGlmeSh7XG4gICAgICAgIHR5cGU6IFwib2JzZXJ2ZXJPcHRpb25zVXBkYXRlZFwiLFxuICAgICAgICBtdXRhdGlvbjogdGhpcy4jY3VycmVudE11dGF0aW9uLFxuICAgICAgICBvYnNlcnZlcjogdGhpc1xuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChwcmV2T3B0aW9ucz8ubXV0YXRpb25LZXkgJiYgdGhpcy5vcHRpb25zLm11dGF0aW9uS2V5ICYmIGhhc2hLZXkocHJldk9wdGlvbnMubXV0YXRpb25LZXkpICE9PSBoYXNoS2V5KHRoaXMub3B0aW9ucy5tdXRhdGlvbktleSkpIHtcbiAgICAgIHRoaXMucmVzZXQoKTtcbiAgICB9IGVsc2UgaWYgKHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuICAgICAgdGhpcy4jY3VycmVudE11dGF0aW9uLnNldE9wdGlvbnModGhpcy5vcHRpb25zKTtcbiAgICB9XG4gIH1cbiAgb25VbnN1YnNjcmliZSgpIHtcbiAgICBpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcbiAgICAgIHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8ucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG4gICAgfVxuICB9XG4gIG9uTXV0YXRpb25VcGRhdGUoYWN0aW9uKSB7XG4gICAgdGhpcy4jdXBkYXRlUmVzdWx0KCk7XG4gICAgdGhpcy4jbm90aWZ5KGFjdGlvbik7XG4gIH1cbiAgZ2V0Q3VycmVudFJlc3VsdCgpIHtcbiAgICByZXR1cm4gdGhpcy4jY3VycmVudFJlc3VsdDtcbiAgfVxuICByZXNldCgpIHtcbiAgICB0aGlzLiNjdXJyZW50TXV0YXRpb24/LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuICAgIHRoaXMuI2N1cnJlbnRNdXRhdGlvbiA9IHZvaWQgMDtcbiAgICB0aGlzLiN1cGRhdGVSZXN1bHQoKTtcbiAgICB0aGlzLiNub3RpZnkoKTtcbiAgfVxuICBtdXRhdGUodmFyaWFibGVzLCBvcHRpb25zKSB7XG4gICAgdGhpcy4jbXV0YXRlT3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy4jY3VycmVudE11dGF0aW9uPy5yZW1vdmVPYnNlcnZlcih0aGlzKTtcbiAgICB0aGlzLiNjdXJyZW50TXV0YXRpb24gPSB0aGlzLiNjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpLmJ1aWxkKHRoaXMuI2NsaWVudCwgdGhpcy5vcHRpb25zKTtcbiAgICB0aGlzLiNjdXJyZW50TXV0YXRpb24uYWRkT2JzZXJ2ZXIodGhpcyk7XG4gICAgcmV0dXJuIHRoaXMuI2N1cnJlbnRNdXRhdGlvbi5leGVjdXRlKHZhcmlhYmxlcyk7XG4gIH1cbiAgI3VwZGF0ZVJlc3VsdCgpIHtcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8uc3RhdGUgPz8gZ2V0RGVmYXVsdFN0YXRlKCk7XG4gICAgdGhpcy4jY3VycmVudFJlc3VsdCA9IHtcbiAgICAgIC4uLnN0YXRlLFxuICAgICAgaXNQZW5kaW5nOiBzdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiLFxuICAgICAgaXNTdWNjZXNzOiBzdGF0ZS5zdGF0dXMgPT09IFwic3VjY2Vzc1wiLFxuICAgICAgaXNFcnJvcjogc3RhdGUuc3RhdHVzID09PSBcImVycm9yXCIsXG4gICAgICBpc0lkbGU6IHN0YXRlLnN0YXR1cyA9PT0gXCJpZGxlXCIsXG4gICAgICBtdXRhdGU6IHRoaXMubXV0YXRlLFxuICAgICAgcmVzZXQ6IHRoaXMucmVzZXRcbiAgICB9O1xuICB9XG4gICNub3RpZnkoYWN0aW9uKSB7XG4gICAgbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG4gICAgICBpZiAodGhpcy4jbXV0YXRlT3B0aW9ucyAmJiB0aGlzLmhhc0xpc3RlbmVycygpKSB7XG4gICAgICAgIGNvbnN0IHZhcmlhYmxlcyA9IHRoaXMuI2N1cnJlbnRSZXN1bHQudmFyaWFibGVzO1xuICAgICAgICBjb25zdCBvbk11dGF0ZVJlc3VsdCA9IHRoaXMuI2N1cnJlbnRSZXN1bHQuY29udGV4dDtcbiAgICAgICAgY29uc3QgY29udGV4dCA9IHtcbiAgICAgICAgICBjbGllbnQ6IHRoaXMuI2NsaWVudCxcbiAgICAgICAgICBtZXRhOiB0aGlzLm9wdGlvbnMubWV0YSxcbiAgICAgICAgICBtdXRhdGlvbktleTogdGhpcy5vcHRpb25zLm11dGF0aW9uS2V5XG4gICAgICAgIH07XG4gICAgICAgIGlmIChhY3Rpb24/LnR5cGUgPT09IFwic3VjY2Vzc1wiKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMuI211dGF0ZU9wdGlvbnMub25TdWNjZXNzPy4oXG4gICAgICAgICAgICAgIGFjdGlvbi5kYXRhLFxuICAgICAgICAgICAgICB2YXJpYWJsZXMsXG4gICAgICAgICAgICAgIG9uTXV0YXRlUmVzdWx0LFxuICAgICAgICAgICAgICBjb250ZXh0XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIHZvaWQgUHJvbWlzZS5yZWplY3QoZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICB0aGlzLiNtdXRhdGVPcHRpb25zLm9uU2V0dGxlZD8uKFxuICAgICAgICAgICAgICBhY3Rpb24uZGF0YSxcbiAgICAgICAgICAgICAgbnVsbCxcbiAgICAgICAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICAgICAgICBvbk11dGF0ZVJlc3VsdCxcbiAgICAgICAgICAgICAgY29udGV4dFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICB2b2lkIFByb21pc2UucmVqZWN0KGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChhY3Rpb24/LnR5cGUgPT09IFwiZXJyb3JcIikge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICB0aGlzLiNtdXRhdGVPcHRpb25zLm9uRXJyb3I/LihcbiAgICAgICAgICAgICAgYWN0aW9uLmVycm9yLFxuICAgICAgICAgICAgICB2YXJpYWJsZXMsXG4gICAgICAgICAgICAgIG9uTXV0YXRlUmVzdWx0LFxuICAgICAgICAgICAgICBjb250ZXh0XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIHZvaWQgUHJvbWlzZS5yZWplY3QoZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICB0aGlzLiNtdXRhdGVPcHRpb25zLm9uU2V0dGxlZD8uKFxuICAgICAgICAgICAgICB2b2lkIDAsXG4gICAgICAgICAgICAgIGFjdGlvbi5lcnJvcixcbiAgICAgICAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICAgICAgICBvbk11dGF0ZVJlc3VsdCxcbiAgICAgICAgICAgICAgY29udGV4dFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICB2b2lkIFByb21pc2UucmVqZWN0KGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcbiAgICAgICAgbGlzdGVuZXIodGhpcy4jY3VycmVudFJlc3VsdCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxufTtcbmV4cG9ydCB7XG4gIE11dGF0aW9uT2JzZXJ2ZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdXRhdGlvbk9ic2VydmVyLmpzLm1hcCIsIi8vIHNyYy9xdWVyaWVzT2JzZXJ2ZXIudHNcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBRdWVyeU9ic2VydmVyIH0gZnJvbSBcIi4vcXVlcnlPYnNlcnZlci5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyByZXBsYWNlRXF1YWxEZWVwLCBzaGFsbG93RXF1YWxPYmplY3RzIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmZ1bmN0aW9uIGRpZmZlcmVuY2UoYXJyYXkxLCBhcnJheTIpIHtcbiAgY29uc3QgZXhjbHVkZVNldCA9IG5ldyBTZXQoYXJyYXkyKTtcbiAgcmV0dXJuIGFycmF5MS5maWx0ZXIoKHgpID0+ICFleGNsdWRlU2V0Lmhhcyh4KSk7XG59XG5mdW5jdGlvbiByZXBsYWNlQXQoYXJyYXksIGluZGV4LCB2YWx1ZSkge1xuICBjb25zdCBjb3B5ID0gYXJyYXkuc2xpY2UoMCk7XG4gIGNvcHlbaW5kZXhdID0gdmFsdWU7XG4gIHJldHVybiBjb3B5O1xufVxudmFyIFF1ZXJpZXNPYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcbiAgI2NsaWVudDtcbiAgI3Jlc3VsdDtcbiAgI3F1ZXJpZXM7XG4gICNvcHRpb25zO1xuICAjb2JzZXJ2ZXJzO1xuICAjY29tYmluZWRSZXN1bHQ7XG4gICNsYXN0Q29tYmluZTtcbiAgI2xhc3RSZXN1bHQ7XG4gICNsYXN0UXVlcnlIYXNoZXM7XG4gICNvYnNlcnZlck1hdGNoZXMgPSBbXTtcbiAgY29uc3RydWN0b3IoY2xpZW50LCBxdWVyaWVzLCBvcHRpb25zKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG4gICAgdGhpcy4jb3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy4jcXVlcmllcyA9IFtdO1xuICAgIHRoaXMuI29ic2VydmVycyA9IFtdO1xuICAgIHRoaXMuI3Jlc3VsdCA9IFtdO1xuICAgIHRoaXMuc2V0UXVlcmllcyhxdWVyaWVzKTtcbiAgfVxuICBvblN1YnNjcmliZSgpIHtcbiAgICBpZiAodGhpcy5saXN0ZW5lcnMuc2l6ZSA9PT0gMSkge1xuICAgICAgdGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG4gICAgICAgIG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiB7XG4gICAgICAgICAgdGhpcy4jb25VcGRhdGUob2JzZXJ2ZXIsIHJlc3VsdCk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIG9uVW5zdWJzY3JpYmUoKSB7XG4gICAgaWYgKCF0aGlzLmxpc3RlbmVycy5zaXplKSB7XG4gICAgICB0aGlzLmRlc3Ryb3koKTtcbiAgICB9XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLmxpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgdGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG4gICAgICBvYnNlcnZlci5kZXN0cm95KCk7XG4gICAgfSk7XG4gIH1cbiAgc2V0UXVlcmllcyhxdWVyaWVzLCBvcHRpb25zKSB7XG4gICAgdGhpcy4jcXVlcmllcyA9IHF1ZXJpZXM7XG4gICAgdGhpcy4jb3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgY29uc3QgcXVlcnlIYXNoZXMgPSBxdWVyaWVzLm1hcChcbiAgICAgICAgKHF1ZXJ5KSA9PiB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhxdWVyeSkucXVlcnlIYXNoXG4gICAgICApO1xuICAgICAgaWYgKG5ldyBTZXQocXVlcnlIYXNoZXMpLnNpemUgIT09IHF1ZXJ5SGFzaGVzLmxlbmd0aCkge1xuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgXCJbUXVlcmllc09ic2VydmVyXTogRHVwbGljYXRlIFF1ZXJpZXMgZm91bmQuIFRoaXMgbWlnaHQgcmVzdWx0IGluIHVuZXhwZWN0ZWQgYmVoYXZpb3IuXCJcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG4gICAgICBjb25zdCBwcmV2T2JzZXJ2ZXJzID0gdGhpcy4jb2JzZXJ2ZXJzO1xuICAgICAgY29uc3QgbmV3T2JzZXJ2ZXJNYXRjaGVzID0gdGhpcy4jZmluZE1hdGNoaW5nT2JzZXJ2ZXJzKHRoaXMuI3F1ZXJpZXMpO1xuICAgICAgbmV3T2JzZXJ2ZXJNYXRjaGVzLmZvckVhY2goXG4gICAgICAgIChtYXRjaCkgPT4gbWF0Y2gub2JzZXJ2ZXIuc2V0T3B0aW9ucyhtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMpXG4gICAgICApO1xuICAgICAgY29uc3QgbmV3T2JzZXJ2ZXJzID0gbmV3T2JzZXJ2ZXJNYXRjaGVzLm1hcCgobWF0Y2gpID0+IG1hdGNoLm9ic2VydmVyKTtcbiAgICAgIGNvbnN0IG5ld1Jlc3VsdCA9IG5ld09ic2VydmVycy5tYXAoXG4gICAgICAgIChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpXG4gICAgICApO1xuICAgICAgY29uc3QgaGFzTGVuZ3RoQ2hhbmdlID0gcHJldk9ic2VydmVycy5sZW5ndGggIT09IG5ld09ic2VydmVycy5sZW5ndGg7XG4gICAgICBjb25zdCBoYXNJbmRleENoYW5nZSA9IG5ld09ic2VydmVycy5zb21lKFxuICAgICAgICAob2JzZXJ2ZXIsIGluZGV4KSA9PiBvYnNlcnZlciAhPT0gcHJldk9ic2VydmVyc1tpbmRleF1cbiAgICAgICk7XG4gICAgICBjb25zdCBoYXNTdHJ1Y3R1cmFsQ2hhbmdlID0gaGFzTGVuZ3RoQ2hhbmdlIHx8IGhhc0luZGV4Q2hhbmdlO1xuICAgICAgY29uc3QgaGFzUmVzdWx0Q2hhbmdlID0gaGFzU3RydWN0dXJhbENoYW5nZSA/IHRydWUgOiBuZXdSZXN1bHQuc29tZSgocmVzdWx0LCBpbmRleCkgPT4ge1xuICAgICAgICBjb25zdCBwcmV2ID0gdGhpcy4jcmVzdWx0W2luZGV4XTtcbiAgICAgICAgcmV0dXJuICFwcmV2IHx8ICFzaGFsbG93RXF1YWxPYmplY3RzKHJlc3VsdCwgcHJldik7XG4gICAgICB9KTtcbiAgICAgIGlmICghaGFzU3RydWN0dXJhbENoYW5nZSAmJiAhaGFzUmVzdWx0Q2hhbmdlKSByZXR1cm47XG4gICAgICBpZiAoaGFzU3RydWN0dXJhbENoYW5nZSkge1xuICAgICAgICB0aGlzLiNvYnNlcnZlck1hdGNoZXMgPSBuZXdPYnNlcnZlck1hdGNoZXM7XG4gICAgICAgIHRoaXMuI29ic2VydmVycyA9IG5ld09ic2VydmVycztcbiAgICAgIH1cbiAgICAgIHRoaXMuI3Jlc3VsdCA9IG5ld1Jlc3VsdDtcbiAgICAgIGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkgcmV0dXJuO1xuICAgICAgaWYgKGhhc1N0cnVjdHVyYWxDaGFuZ2UpIHtcbiAgICAgICAgZGlmZmVyZW5jZShwcmV2T2JzZXJ2ZXJzLCBuZXdPYnNlcnZlcnMpLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG4gICAgICAgICAgb2JzZXJ2ZXIuZGVzdHJveSgpO1xuICAgICAgICB9KTtcbiAgICAgICAgZGlmZmVyZW5jZShuZXdPYnNlcnZlcnMsIHByZXZPYnNlcnZlcnMpLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG4gICAgICAgICAgb2JzZXJ2ZXIuc3Vic2NyaWJlKChyZXN1bHQpID0+IHtcbiAgICAgICAgICAgIHRoaXMuI29uVXBkYXRlKG9ic2VydmVyLCByZXN1bHQpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHRoaXMuI25vdGlmeSgpO1xuICAgIH0pO1xuICB9XG4gIGdldEN1cnJlbnRSZXN1bHQoKSB7XG4gICAgcmV0dXJuIHRoaXMuI3Jlc3VsdDtcbiAgfVxuICBnZXRRdWVyaWVzKCkge1xuICAgIHJldHVybiB0aGlzLiNvYnNlcnZlcnMubWFwKChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFF1ZXJ5KCkpO1xuICB9XG4gIGdldE9ic2VydmVycygpIHtcbiAgICByZXR1cm4gdGhpcy4jb2JzZXJ2ZXJzO1xuICB9XG4gIGdldE9wdGltaXN0aWNSZXN1bHQocXVlcmllcywgY29tYmluZSkge1xuICAgIGNvbnN0IG1hdGNoZXMgPSB0aGlzLiNmaW5kTWF0Y2hpbmdPYnNlcnZlcnMocXVlcmllcyk7XG4gICAgY29uc3QgcmVzdWx0ID0gbWF0Y2hlcy5tYXAoXG4gICAgICAobWF0Y2gpID0+IG1hdGNoLm9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQobWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zKVxuICAgICk7XG4gICAgY29uc3QgcXVlcnlIYXNoZXMgPSBtYXRjaGVzLm1hcChcbiAgICAgIChtYXRjaCkgPT4gbWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zLnF1ZXJ5SGFzaFxuICAgICk7XG4gICAgcmV0dXJuIFtcbiAgICAgIHJlc3VsdCxcbiAgICAgIChyKSA9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLiNjb21iaW5lUmVzdWx0KHIgPz8gcmVzdWx0LCBjb21iaW5lLCBxdWVyeUhhc2hlcyk7XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy4jdHJhY2tSZXN1bHQocmVzdWx0LCBtYXRjaGVzKTtcbiAgICAgIH1cbiAgICBdO1xuICB9XG4gICN0cmFja1Jlc3VsdChyZXN1bHQsIG1hdGNoZXMpIHtcbiAgICByZXR1cm4gbWF0Y2hlcy5tYXAoKG1hdGNoLCBpbmRleCkgPT4ge1xuICAgICAgY29uc3Qgb2JzZXJ2ZXJSZXN1bHQgPSByZXN1bHRbaW5kZXhdO1xuICAgICAgcmV0dXJuICFtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMubm90aWZ5T25DaGFuZ2VQcm9wcyA/IG1hdGNoLm9ic2VydmVyLnRyYWNrUmVzdWx0KG9ic2VydmVyUmVzdWx0LCAoYWNjZXNzZWRQcm9wKSA9PiB7XG4gICAgICAgIG1hdGNoZXMuZm9yRWFjaCgobSkgPT4ge1xuICAgICAgICAgIG0ub2JzZXJ2ZXIudHJhY2tQcm9wKGFjY2Vzc2VkUHJvcCk7XG4gICAgICAgIH0pO1xuICAgICAgfSkgOiBvYnNlcnZlclJlc3VsdDtcbiAgICB9KTtcbiAgfVxuICAjY29tYmluZVJlc3VsdChpbnB1dCwgY29tYmluZSwgcXVlcnlIYXNoZXMpIHtcbiAgICBpZiAoY29tYmluZSkge1xuICAgICAgY29uc3QgbGFzdEhhc2hlcyA9IHRoaXMuI2xhc3RRdWVyeUhhc2hlcztcbiAgICAgIGNvbnN0IHF1ZXJ5SGFzaGVzQ2hhbmdlZCA9IHF1ZXJ5SGFzaGVzICE9PSB2b2lkIDAgJiYgbGFzdEhhc2hlcyAhPT0gdm9pZCAwICYmIChsYXN0SGFzaGVzLmxlbmd0aCAhPT0gcXVlcnlIYXNoZXMubGVuZ3RoIHx8IHF1ZXJ5SGFzaGVzLnNvbWUoKGhhc2gsIGkpID0+IGhhc2ggIT09IGxhc3RIYXNoZXNbaV0pKTtcbiAgICAgIGlmICghdGhpcy4jY29tYmluZWRSZXN1bHQgfHwgdGhpcy4jcmVzdWx0ICE9PSB0aGlzLiNsYXN0UmVzdWx0IHx8IHF1ZXJ5SGFzaGVzQ2hhbmdlZCB8fCBjb21iaW5lICE9PSB0aGlzLiNsYXN0Q29tYmluZSkge1xuICAgICAgICB0aGlzLiNsYXN0Q29tYmluZSA9IGNvbWJpbmU7XG4gICAgICAgIHRoaXMuI2xhc3RSZXN1bHQgPSB0aGlzLiNyZXN1bHQ7XG4gICAgICAgIGlmIChxdWVyeUhhc2hlcyAhPT0gdm9pZCAwKSB7XG4gICAgICAgICAgdGhpcy4jbGFzdFF1ZXJ5SGFzaGVzID0gcXVlcnlIYXNoZXM7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy4jY29tYmluZWRSZXN1bHQgPSByZXBsYWNlRXF1YWxEZWVwKFxuICAgICAgICAgIHRoaXMuI2NvbWJpbmVkUmVzdWx0LFxuICAgICAgICAgIGNvbWJpbmUoaW5wdXQpXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy4jY29tYmluZWRSZXN1bHQ7XG4gICAgfVxuICAgIHJldHVybiBpbnB1dDtcbiAgfVxuICAjc2hvdWxkU2tpcENvbWJpbmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuI29wdGlvbnM/LmNvbWJpbmUgIT09IHZvaWQgMCAmJiB0aGlzLiNvYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIsIGluZGV4KSA9PiB7XG4gICAgICByZXR1cm4gb2JzZXJ2ZXIub3B0aW9ucy5zdXNwZW5zZSAmJiB0aGlzLiNyZXN1bHRbaW5kZXhdPy5kYXRhID09PSB2b2lkIDA7XG4gICAgfSk7XG4gIH1cbiAgI2ZpbmRNYXRjaGluZ09ic2VydmVycyhxdWVyaWVzKSB7XG4gICAgY29uc3QgcHJldk9ic2VydmVyc01hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgdGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG4gICAgICBjb25zdCBrZXkgPSBvYnNlcnZlci5vcHRpb25zLnF1ZXJ5SGFzaDtcbiAgICAgIGlmICgha2V5KSByZXR1cm47XG4gICAgICBjb25zdCBwcmV2aW91c09ic2VydmVycyA9IHByZXZPYnNlcnZlcnNNYXAuZ2V0KGtleSk7XG4gICAgICBpZiAocHJldmlvdXNPYnNlcnZlcnMpIHtcbiAgICAgICAgcHJldmlvdXNPYnNlcnZlcnMucHVzaChvYnNlcnZlcik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwcmV2T2JzZXJ2ZXJzTWFwLnNldChrZXksIFtvYnNlcnZlcl0pO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGNvbnN0IG9ic2VydmVycyA9IFtdO1xuICAgIHF1ZXJpZXMuZm9yRWFjaCgob3B0aW9ucykgPT4ge1xuICAgICAgY29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuICAgICAgY29uc3QgbWF0Y2ggPSBwcmV2T2JzZXJ2ZXJzTWFwLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk/LnNoaWZ0KCk7XG4gICAgICBjb25zdCBvYnNlcnZlciA9IG1hdGNoID8/IG5ldyBRdWVyeU9ic2VydmVyKHRoaXMuI2NsaWVudCwgZGVmYXVsdGVkT3B0aW9ucyk7XG4gICAgICBvYnNlcnZlcnMucHVzaCh7XG4gICAgICAgIGRlZmF1bHRlZFF1ZXJ5T3B0aW9uczogZGVmYXVsdGVkT3B0aW9ucyxcbiAgICAgICAgb2JzZXJ2ZXJcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHJldHVybiBvYnNlcnZlcnM7XG4gIH1cbiAgI29uVXBkYXRlKG9ic2VydmVyLCByZXN1bHQpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuI29ic2VydmVycy5pbmRleE9mKG9ic2VydmVyKTtcbiAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICB0aGlzLiNyZXN1bHQgPSByZXBsYWNlQXQodGhpcy4jcmVzdWx0LCBpbmRleCwgcmVzdWx0KTtcbiAgICAgIHRoaXMuI25vdGlmeSgpO1xuICAgIH1cbiAgfVxuICAjbm90aWZ5KCkge1xuICAgIGlmICh0aGlzLmhhc0xpc3RlbmVycygpKSB7XG4gICAgICBjb25zdCBuZXdUcmFja2VkID0gdGhpcy4jdHJhY2tSZXN1bHQodGhpcy4jcmVzdWx0LCB0aGlzLiNvYnNlcnZlck1hdGNoZXMpO1xuICAgICAgY29uc3Qgc2hvdWxkU2tpcENvbWJpbmUgPSB0aGlzLiNzaG91bGRTa2lwQ29tYmluZSgpO1xuICAgICAgY29uc3QgcHJldmlvdXNSZXN1bHQgPSB0aGlzLiNjb21iaW5lZFJlc3VsdDtcbiAgICAgIGNvbnN0IG5ld1Jlc3VsdCA9IHNob3VsZFNraXBDb21iaW5lID8gcHJldmlvdXNSZXN1bHQgOiB0aGlzLiNjb21iaW5lUmVzdWx0KG5ld1RyYWNrZWQsIHRoaXMuI29wdGlvbnM/LmNvbWJpbmUpO1xuICAgICAgaWYgKHNob3VsZFNraXBDb21iaW5lIHx8IHByZXZpb3VzUmVzdWx0ICE9PSBuZXdSZXN1bHQpIHtcbiAgICAgICAgbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG4gICAgICAgICAgdGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcbiAgICAgICAgICAgIGxpc3RlbmVyKHRoaXMuI3Jlc3VsdCk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxufTtcbmV4cG9ydCB7XG4gIFF1ZXJpZXNPYnNlcnZlclxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJpZXNPYnNlcnZlci5qcy5tYXAiLCIvLyBzcmMvcXVlcnlDYWNoZS50c1xuaW1wb3J0IHsgaGFzaFF1ZXJ5S2V5QnlPcHRpb25zLCBtYXRjaFF1ZXJ5IH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IFF1ZXJ5IH0gZnJvbSBcIi4vcXVlcnkuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbnZhciBRdWVyeUNhY2hlID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuICBjb25zdHJ1Y3Rvcihjb25maWcgPSB7fSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5jb25maWcgPSBjb25maWc7XG4gICAgdGhpcy4jcXVlcmllcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIH1cbiAgI3F1ZXJpZXM7XG4gIGJ1aWxkKGNsaWVudCwgb3B0aW9ucywgc3RhdGUpIHtcbiAgICBjb25zdCBxdWVyeUtleSA9IG9wdGlvbnMucXVlcnlLZXk7XG4gICAgY29uc3QgcXVlcnlIYXNoID0gb3B0aW9ucy5xdWVyeUhhc2ggPz8gaGFzaFF1ZXJ5S2V5QnlPcHRpb25zKHF1ZXJ5S2V5LCBvcHRpb25zKTtcbiAgICBsZXQgcXVlcnkgPSB0aGlzLmdldChxdWVyeUhhc2gpO1xuICAgIGlmICghcXVlcnkpIHtcbiAgICAgIHF1ZXJ5ID0gbmV3IFF1ZXJ5KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBxdWVyeUtleSxcbiAgICAgICAgcXVlcnlIYXNoLFxuICAgICAgICBvcHRpb25zOiBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKSxcbiAgICAgICAgc3RhdGUsXG4gICAgICAgIGRlZmF1bHRPcHRpb25zOiBjbGllbnQuZ2V0UXVlcnlEZWZhdWx0cyhxdWVyeUtleSlcbiAgICAgIH0pO1xuICAgICAgdGhpcy5hZGQocXVlcnkpO1xuICAgIH1cbiAgICByZXR1cm4gcXVlcnk7XG4gIH1cbiAgYWRkKHF1ZXJ5KSB7XG4gICAgaWYgKCF0aGlzLiNxdWVyaWVzLmhhcyhxdWVyeS5xdWVyeUhhc2gpKSB7XG4gICAgICB0aGlzLiNxdWVyaWVzLnNldChxdWVyeS5xdWVyeUhhc2gsIHF1ZXJ5KTtcbiAgICAgIHRoaXMubm90aWZ5KHtcbiAgICAgICAgdHlwZTogXCJhZGRlZFwiLFxuICAgICAgICBxdWVyeVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJlbW92ZShxdWVyeSkge1xuICAgIGNvbnN0IHF1ZXJ5SW5NYXAgPSB0aGlzLiNxdWVyaWVzLmdldChxdWVyeS5xdWVyeUhhc2gpO1xuICAgIGlmIChxdWVyeUluTWFwKSB7XG4gICAgICBxdWVyeS5kZXN0cm95KCk7XG4gICAgICBpZiAocXVlcnlJbk1hcCA9PT0gcXVlcnkpIHtcbiAgICAgICAgdGhpcy4jcXVlcmllcy5kZWxldGUocXVlcnkucXVlcnlIYXNoKTtcbiAgICAgIH1cbiAgICAgIHRoaXMubm90aWZ5KHsgdHlwZTogXCJyZW1vdmVkXCIsIHF1ZXJ5IH0pO1xuICAgIH1cbiAgfVxuICBjbGVhcigpIHtcbiAgICBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcbiAgICAgICAgdGhpcy5yZW1vdmUocXVlcnkpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgZ2V0KHF1ZXJ5SGFzaCkge1xuICAgIHJldHVybiB0aGlzLiNxdWVyaWVzLmdldChxdWVyeUhhc2gpO1xuICB9XG4gIGdldEFsbCgpIHtcbiAgICByZXR1cm4gWy4uLnRoaXMuI3F1ZXJpZXMudmFsdWVzKCldO1xuICB9XG4gIGZpbmQoZmlsdGVycykge1xuICAgIGNvbnN0IGRlZmF1bHRlZEZpbHRlcnMgPSB7IGV4YWN0OiB0cnVlLCAuLi5maWx0ZXJzIH07XG4gICAgcmV0dXJuIHRoaXMuZ2V0QWxsKCkuZmluZChcbiAgICAgIChxdWVyeSkgPT4gbWF0Y2hRdWVyeShkZWZhdWx0ZWRGaWx0ZXJzLCBxdWVyeSlcbiAgICApO1xuICB9XG4gIGZpbmRBbGwoZmlsdGVycyA9IHt9KSB7XG4gICAgY29uc3QgcXVlcmllcyA9IHRoaXMuZ2V0QWxsKCk7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKGZpbHRlcnMpLmxlbmd0aCA+IDAgPyBxdWVyaWVzLmZpbHRlcigocXVlcnkpID0+IG1hdGNoUXVlcnkoZmlsdGVycywgcXVlcnkpKSA6IHF1ZXJpZXM7XG4gIH1cbiAgbm90aWZ5KGV2ZW50KSB7XG4gICAgbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG4gICAgICB0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuICAgICAgICBsaXN0ZW5lcihldmVudCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuICBvbkZvY3VzKCkge1xuICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgdGhpcy5nZXRBbGwoKS5mb3JFYWNoKChxdWVyeSkgPT4ge1xuICAgICAgICBxdWVyeS5vbkZvY3VzKCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuICBvbk9ubGluZSgpIHtcbiAgICBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcbiAgICAgICAgcXVlcnkub25PbmxpbmUoKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG59O1xuZXhwb3J0IHtcbiAgUXVlcnlDYWNoZVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5Q2FjaGUuanMubWFwIiwiLy8gc3JjL3F1ZXJ5Q2xpZW50LnRzXG5pbXBvcnQge1xuICBmdW5jdGlvbmFsVXBkYXRlLFxuICBoYXNoS2V5LFxuICBoYXNoUXVlcnlLZXlCeU9wdGlvbnMsXG4gIG5vb3AsXG4gIHBhcnRpYWxNYXRjaEtleSxcbiAgcmVzb2x2ZVN0YWxlVGltZSxcbiAgc2tpcFRva2VuXG59IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBRdWVyeUNhY2hlIH0gZnJvbSBcIi4vcXVlcnlDYWNoZS5qc1wiO1xuaW1wb3J0IHsgTXV0YXRpb25DYWNoZSB9IGZyb20gXCIuL211dGF0aW9uQ2FjaGUuanNcIjtcbmltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gXCIuL2ZvY3VzTWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgb25saW5lTWFuYWdlciB9IGZyb20gXCIuL29ubGluZU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG52YXIgUXVlcnlDbGllbnQgPSBjbGFzcyB7XG4gICNxdWVyeUNhY2hlO1xuICAjbXV0YXRpb25DYWNoZTtcbiAgI2RlZmF1bHRPcHRpb25zO1xuICAjcXVlcnlEZWZhdWx0cztcbiAgI211dGF0aW9uRGVmYXVsdHM7XG4gICNtb3VudENvdW50O1xuICAjdW5zdWJzY3JpYmVGb2N1cztcbiAgI3Vuc3Vic2NyaWJlT25saW5lO1xuICBjb25zdHJ1Y3Rvcihjb25maWcgPSB7fSkge1xuICAgIHRoaXMuI3F1ZXJ5Q2FjaGUgPSBjb25maWcucXVlcnlDYWNoZSB8fCBuZXcgUXVlcnlDYWNoZSgpO1xuICAgIHRoaXMuI211dGF0aW9uQ2FjaGUgPSBjb25maWcubXV0YXRpb25DYWNoZSB8fCBuZXcgTXV0YXRpb25DYWNoZSgpO1xuICAgIHRoaXMuI2RlZmF1bHRPcHRpb25zID0gY29uZmlnLmRlZmF1bHRPcHRpb25zIHx8IHt9O1xuICAgIHRoaXMuI3F1ZXJ5RGVmYXVsdHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIHRoaXMuI211dGF0aW9uRGVmYXVsdHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIHRoaXMuI21vdW50Q291bnQgPSAwO1xuICB9XG4gIG1vdW50KCkge1xuICAgIHRoaXMuI21vdW50Q291bnQrKztcbiAgICBpZiAodGhpcy4jbW91bnRDb3VudCAhPT0gMSkgcmV0dXJuO1xuICAgIHRoaXMuI3Vuc3Vic2NyaWJlRm9jdXMgPSBmb2N1c01hbmFnZXIuc3Vic2NyaWJlKGFzeW5jIChmb2N1c2VkKSA9PiB7XG4gICAgICBpZiAoZm9jdXNlZCkge1xuICAgICAgICBhd2FpdCB0aGlzLnJlc3VtZVBhdXNlZE11dGF0aW9ucygpO1xuICAgICAgICB0aGlzLiNxdWVyeUNhY2hlLm9uRm9jdXMoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLiN1bnN1YnNjcmliZU9ubGluZSA9IG9ubGluZU1hbmFnZXIuc3Vic2NyaWJlKGFzeW5jIChvbmxpbmUpID0+IHtcbiAgICAgIGlmIChvbmxpbmUpIHtcbiAgICAgICAgYXdhaXQgdGhpcy5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKTtcbiAgICAgICAgdGhpcy4jcXVlcnlDYWNoZS5vbk9ubGluZSgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHVubW91bnQoKSB7XG4gICAgdGhpcy4jbW91bnRDb3VudC0tO1xuICAgIGlmICh0aGlzLiNtb3VudENvdW50ICE9PSAwKSByZXR1cm47XG4gICAgdGhpcy4jdW5zdWJzY3JpYmVGb2N1cz8uKCk7XG4gICAgdGhpcy4jdW5zdWJzY3JpYmVGb2N1cyA9IHZvaWQgMDtcbiAgICB0aGlzLiN1bnN1YnNjcmliZU9ubGluZT8uKCk7XG4gICAgdGhpcy4jdW5zdWJzY3JpYmVPbmxpbmUgPSB2b2lkIDA7XG4gIH1cbiAgaXNGZXRjaGluZyhmaWx0ZXJzKSB7XG4gICAgcmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbCh7IC4uLmZpbHRlcnMsIGZldGNoU3RhdHVzOiBcImZldGNoaW5nXCIgfSkubGVuZ3RoO1xuICB9XG4gIGlzTXV0YXRpbmcoZmlsdGVycykge1xuICAgIHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlLmZpbmRBbGwoeyAuLi5maWx0ZXJzLCBzdGF0dXM6IFwicGVuZGluZ1wiIH0pLmxlbmd0aDtcbiAgfVxuICAvKipcbiAgICogSW1wZXJhdGl2ZSAobm9uLXJlYWN0aXZlKSB3YXkgdG8gcmV0cmlldmUgZGF0YSBmb3IgYSBRdWVyeUtleS5cbiAgICogU2hvdWxkIG9ubHkgYmUgdXNlZCBpbiBjYWxsYmFja3Mgb3IgZnVuY3Rpb25zIHdoZXJlIHJlYWRpbmcgdGhlIGxhdGVzdCBkYXRhIGlzIG5lY2Vzc2FyeSwgZS5nLiBmb3Igb3B0aW1pc3RpYyB1cGRhdGVzLlxuICAgKlxuICAgKiBIaW50OiBEbyBub3QgdXNlIHRoaXMgZnVuY3Rpb24gaW5zaWRlIGEgY29tcG9uZW50LCBiZWNhdXNlIGl0IHdvbid0IHJlY2VpdmUgdXBkYXRlcy5cbiAgICogVXNlIGB1c2VRdWVyeWAgdG8gY3JlYXRlIGEgYFF1ZXJ5T2JzZXJ2ZXJgIHRoYXQgc3Vic2NyaWJlcyB0byBjaGFuZ2VzLlxuICAgKi9cbiAgZ2V0UXVlcnlEYXRhKHF1ZXJ5S2V5KSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMuZGVmYXVsdFF1ZXJ5T3B0aW9ucyh7IHF1ZXJ5S2V5IH0pO1xuICAgIHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmdldChvcHRpb25zLnF1ZXJ5SGFzaCk/LnN0YXRlLmRhdGE7XG4gIH1cbiAgZW5zdXJlUXVlcnlEYXRhKG9wdGlvbnMpIHtcbiAgICBjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuICAgIGNvbnN0IHF1ZXJ5ID0gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKTtcbiAgICBjb25zdCBjYWNoZWREYXRhID0gcXVlcnkuc3RhdGUuZGF0YTtcbiAgICBpZiAoY2FjaGVkRGF0YSA9PT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gdGhpcy5mZXRjaFF1ZXJ5KG9wdGlvbnMpO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5yZXZhbGlkYXRlSWZTdGFsZSAmJiBxdWVyeS5pc1N0YWxlQnlUaW1lKHJlc29sdmVTdGFsZVRpbWUoZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSkpIHtcbiAgICAgIHZvaWQgdGhpcy5wcmVmZXRjaFF1ZXJ5KGRlZmF1bHRlZE9wdGlvbnMpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGNhY2hlZERhdGEpO1xuICB9XG4gIGdldFF1ZXJpZXNEYXRhKGZpbHRlcnMpIHtcbiAgICByZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLm1hcCgoeyBxdWVyeUtleSwgc3RhdGUgfSkgPT4ge1xuICAgICAgY29uc3QgZGF0YSA9IHN0YXRlLmRhdGE7XG4gICAgICByZXR1cm4gW3F1ZXJ5S2V5LCBkYXRhXTtcbiAgICB9KTtcbiAgfVxuICBzZXRRdWVyeURhdGEocXVlcnlLZXksIHVwZGF0ZXIsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKHsgcXVlcnlLZXkgfSk7XG4gICAgY29uc3QgcXVlcnkgPSB0aGlzLiNxdWVyeUNhY2hlLmdldChcbiAgICAgIGRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoXG4gICAgKTtcbiAgICBjb25zdCBwcmV2RGF0YSA9IHF1ZXJ5Py5zdGF0ZS5kYXRhO1xuICAgIGNvbnN0IGRhdGEgPSBmdW5jdGlvbmFsVXBkYXRlKHVwZGF0ZXIsIHByZXZEYXRhKTtcbiAgICBpZiAoZGF0YSA9PT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gdm9pZCAwO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKS5zZXREYXRhKGRhdGEsIHsgLi4ub3B0aW9ucywgbWFudWFsOiB0cnVlIH0pO1xuICB9XG4gIHNldFF1ZXJpZXNEYXRhKGZpbHRlcnMsIHVwZGF0ZXIsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaChcbiAgICAgICgpID0+IHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5tYXAoKHsgcXVlcnlLZXkgfSkgPT4gW1xuICAgICAgICBxdWVyeUtleSxcbiAgICAgICAgdGhpcy5zZXRRdWVyeURhdGEocXVlcnlLZXksIHVwZGF0ZXIsIG9wdGlvbnMpXG4gICAgICBdKVxuICAgICk7XG4gIH1cbiAgZ2V0UXVlcnlTdGF0ZShxdWVyeUtleSkge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMoeyBxdWVyeUtleSB9KTtcbiAgICByZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5nZXQoXG4gICAgICBvcHRpb25zLnF1ZXJ5SGFzaFxuICAgICk/LnN0YXRlO1xuICB9XG4gIHJlbW92ZVF1ZXJpZXMoZmlsdGVycykge1xuICAgIGNvbnN0IHF1ZXJ5Q2FjaGUgPSB0aGlzLiNxdWVyeUNhY2hlO1xuICAgIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG4gICAgICAgIHF1ZXJ5Q2FjaGUucmVtb3ZlKHF1ZXJ5KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIHJlc2V0UXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zKSB7XG4gICAgY29uc3QgcXVlcnlDYWNoZSA9IHRoaXMuI3F1ZXJ5Q2FjaGU7XG4gICAgcmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuICAgICAgcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG4gICAgICAgIHF1ZXJ5LnJlc2V0KCk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB0aGlzLnJlZmV0Y2hRdWVyaWVzKFxuICAgICAgICB7XG4gICAgICAgICAgdHlwZTogXCJhY3RpdmVcIixcbiAgICAgICAgICAuLi5maWx0ZXJzXG4gICAgICAgIH0sXG4gICAgICAgIG9wdGlvbnNcbiAgICAgICk7XG4gICAgfSk7XG4gIH1cbiAgY2FuY2VsUXVlcmllcyhmaWx0ZXJzLCBjYW5jZWxPcHRpb25zID0ge30pIHtcbiAgICBjb25zdCBkZWZhdWx0ZWRDYW5jZWxPcHRpb25zID0geyByZXZlcnQ6IHRydWUsIC4uLmNhbmNlbE9wdGlvbnMgfTtcbiAgICBjb25zdCBwcm9taXNlcyA9IG5vdGlmeU1hbmFnZXIuYmF0Y2goXG4gICAgICAoKSA9PiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykubWFwKChxdWVyeSkgPT4gcXVlcnkuY2FuY2VsKGRlZmF1bHRlZENhbmNlbE9wdGlvbnMpKVxuICAgICk7XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzKS50aGVuKG5vb3ApLmNhdGNoKG5vb3ApO1xuICB9XG4gIGludmFsaWRhdGVRdWVyaWVzKGZpbHRlcnMsIG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcbiAgICAgIHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5mb3JFYWNoKChxdWVyeSkgPT4ge1xuICAgICAgICBxdWVyeS5pbnZhbGlkYXRlKCk7XG4gICAgICB9KTtcbiAgICAgIGlmIChmaWx0ZXJzPy5yZWZldGNoVHlwZSA9PT0gXCJub25lXCIpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMucmVmZXRjaFF1ZXJpZXMoXG4gICAgICAgIHtcbiAgICAgICAgICAuLi5maWx0ZXJzLFxuICAgICAgICAgIHR5cGU6IGZpbHRlcnM/LnJlZmV0Y2hUeXBlID8/IGZpbHRlcnM/LnR5cGUgPz8gXCJhY3RpdmVcIlxuICAgICAgICB9LFxuICAgICAgICBvcHRpb25zXG4gICAgICApO1xuICAgIH0pO1xuICB9XG4gIHJlZmV0Y2hRdWVyaWVzKGZpbHRlcnMsIG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IGZldGNoT3B0aW9ucyA9IHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBjYW5jZWxSZWZldGNoOiBvcHRpb25zLmNhbmNlbFJlZmV0Y2ggPz8gdHJ1ZVxuICAgIH07XG4gICAgY29uc3QgcHJvbWlzZXMgPSBub3RpZnlNYW5hZ2VyLmJhdGNoKFxuICAgICAgKCkgPT4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLmZpbHRlcigocXVlcnkpID0+ICFxdWVyeS5pc0Rpc2FibGVkKCkgJiYgIXF1ZXJ5LmlzU3RhdGljKCkpLm1hcCgocXVlcnkpID0+IHtcbiAgICAgICAgbGV0IHByb21pc2UgPSBxdWVyeS5mZXRjaCh2b2lkIDAsIGZldGNoT3B0aW9ucyk7XG4gICAgICAgIGlmICghZmV0Y2hPcHRpb25zLnRocm93T25FcnJvcikge1xuICAgICAgICAgIHByb21pc2UgPSBwcm9taXNlLmNhdGNoKG5vb3ApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBxdWVyeS5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJwYXVzZWRcIiA/IFByb21pc2UucmVzb2x2ZSgpIDogcHJvbWlzZTtcbiAgICAgIH0pXG4gICAgKTtcbiAgICByZXR1cm4gUHJvbWlzZS5hbGwocHJvbWlzZXMpLnRoZW4obm9vcCk7XG4gIH1cbiAgZmV0Y2hRdWVyeShvcHRpb25zKSB7XG4gICAgY29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcbiAgICBpZiAoZGVmYXVsdGVkT3B0aW9ucy5yZXRyeSA9PT0gdm9pZCAwKSB7XG4gICAgICBkZWZhdWx0ZWRPcHRpb25zLnJldHJ5ID0gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHF1ZXJ5ID0gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKTtcbiAgICByZXR1cm4gcXVlcnkuaXNTdGFsZUJ5VGltZShcbiAgICAgIHJlc29sdmVTdGFsZVRpbWUoZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KVxuICAgICkgPyBxdWVyeS5mZXRjaChkZWZhdWx0ZWRPcHRpb25zKSA6IFByb21pc2UucmVzb2x2ZShxdWVyeS5zdGF0ZS5kYXRhKTtcbiAgfVxuICBwcmVmZXRjaFF1ZXJ5KG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5mZXRjaFF1ZXJ5KG9wdGlvbnMpLnRoZW4obm9vcCkuY2F0Y2gobm9vcCk7XG4gIH1cbiAgZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIHtcbiAgICBvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuICAgIHJldHVybiB0aGlzLmZldGNoUXVlcnkob3B0aW9ucyk7XG4gIH1cbiAgcHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5mZXRjaEluZmluaXRlUXVlcnkob3B0aW9ucykudGhlbihub29wKS5jYXRjaChub29wKTtcbiAgfVxuICBlbnN1cmVJbmZpbml0ZVF1ZXJ5RGF0YShvcHRpb25zKSB7XG4gICAgb3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcbiAgICByZXR1cm4gdGhpcy5lbnN1cmVRdWVyeURhdGEob3B0aW9ucyk7XG4gIH1cbiAgcmVzdW1lUGF1c2VkTXV0YXRpb25zKCkge1xuICAgIGlmIChvbmxpbmVNYW5hZ2VyLmlzT25saW5lKCkpIHtcbiAgICAgIHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlLnJlc3VtZVBhdXNlZE11dGF0aW9ucygpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gIH1cbiAgZ2V0UXVlcnlDYWNoZSgpIHtcbiAgICByZXR1cm4gdGhpcy4jcXVlcnlDYWNoZTtcbiAgfVxuICBnZXRNdXRhdGlvbkNhY2hlKCkge1xuICAgIHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlO1xuICB9XG4gIGdldERlZmF1bHRPcHRpb25zKCkge1xuICAgIHJldHVybiB0aGlzLiNkZWZhdWx0T3B0aW9ucztcbiAgfVxuICBzZXREZWZhdWx0T3B0aW9ucyhvcHRpb25zKSB7XG4gICAgdGhpcy4jZGVmYXVsdE9wdGlvbnMgPSBvcHRpb25zO1xuICB9XG4gIHNldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXksIG9wdGlvbnMpIHtcbiAgICB0aGlzLiNxdWVyeURlZmF1bHRzLnNldChoYXNoS2V5KHF1ZXJ5S2V5KSwge1xuICAgICAgcXVlcnlLZXksXG4gICAgICBkZWZhdWx0T3B0aW9uczogb3B0aW9uc1xuICAgIH0pO1xuICB9XG4gIGdldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXkpIHtcbiAgICBjb25zdCBkZWZhdWx0cyA9IFsuLi50aGlzLiNxdWVyeURlZmF1bHRzLnZhbHVlcygpXTtcbiAgICBjb25zdCByZXN1bHQgPSB7fTtcbiAgICBkZWZhdWx0cy5mb3JFYWNoKChxdWVyeURlZmF1bHQpID0+IHtcbiAgICAgIGlmIChwYXJ0aWFsTWF0Y2hLZXkocXVlcnlLZXksIHF1ZXJ5RGVmYXVsdC5xdWVyeUtleSkpIHtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihyZXN1bHQsIHF1ZXJ5RGVmYXVsdC5kZWZhdWx0T3B0aW9ucyk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBzZXRNdXRhdGlvbkRlZmF1bHRzKG11dGF0aW9uS2V5LCBvcHRpb25zKSB7XG4gICAgdGhpcy4jbXV0YXRpb25EZWZhdWx0cy5zZXQoaGFzaEtleShtdXRhdGlvbktleSksIHtcbiAgICAgIG11dGF0aW9uS2V5LFxuICAgICAgZGVmYXVsdE9wdGlvbnM6IG9wdGlvbnNcbiAgICB9KTtcbiAgfVxuICBnZXRNdXRhdGlvbkRlZmF1bHRzKG11dGF0aW9uS2V5KSB7XG4gICAgY29uc3QgZGVmYXVsdHMgPSBbLi4udGhpcy4jbXV0YXRpb25EZWZhdWx0cy52YWx1ZXMoKV07XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgZGVmYXVsdHMuZm9yRWFjaCgocXVlcnlEZWZhdWx0KSA9PiB7XG4gICAgICBpZiAocGFydGlhbE1hdGNoS2V5KG11dGF0aW9uS2V5LCBxdWVyeURlZmF1bHQubXV0YXRpb25LZXkpKSB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24ocmVzdWx0LCBxdWVyeURlZmF1bHQuZGVmYXVsdE9wdGlvbnMpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMuX2RlZmF1bHRlZCkge1xuICAgICAgcmV0dXJuIG9wdGlvbnM7XG4gICAgfVxuICAgIGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB7XG4gICAgICAuLi50aGlzLiNkZWZhdWx0T3B0aW9ucy5xdWVyaWVzLFxuICAgICAgLi4udGhpcy5nZXRRdWVyeURlZmF1bHRzKG9wdGlvbnMucXVlcnlLZXkpLFxuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIF9kZWZhdWx0ZWQ6IHRydWVcbiAgICB9O1xuICAgIGlmICghZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2gpIHtcbiAgICAgIGRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoID0gaGFzaFF1ZXJ5S2V5QnlPcHRpb25zKFxuICAgICAgICBkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5S2V5LFxuICAgICAgICBkZWZhdWx0ZWRPcHRpb25zXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAoZGVmYXVsdGVkT3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QgPT09IHZvaWQgMCkge1xuICAgICAgZGVmYXVsdGVkT3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QgPSBkZWZhdWx0ZWRPcHRpb25zLm5ldHdvcmtNb2RlICE9PSBcImFsd2F5c1wiO1xuICAgIH1cbiAgICBpZiAoZGVmYXVsdGVkT3B0aW9ucy50aHJvd09uRXJyb3IgPT09IHZvaWQgMCkge1xuICAgICAgZGVmYXVsdGVkT3B0aW9ucy50aHJvd09uRXJyb3IgPSAhIWRlZmF1bHRlZE9wdGlvbnMuc3VzcGVuc2U7XG4gICAgfVxuICAgIGlmICghZGVmYXVsdGVkT3B0aW9ucy5uZXR3b3JrTW9kZSAmJiBkZWZhdWx0ZWRPcHRpb25zLnBlcnNpc3Rlcikge1xuICAgICAgZGVmYXVsdGVkT3B0aW9ucy5uZXR3b3JrTW9kZSA9IFwib2ZmbGluZUZpcnN0XCI7XG4gICAgfVxuICAgIGlmIChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikge1xuICAgICAgZGVmYXVsdGVkT3B0aW9ucy5lbmFibGVkID0gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiBkZWZhdWx0ZWRPcHRpb25zO1xuICB9XG4gIGRlZmF1bHRNdXRhdGlvbk9wdGlvbnMob3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zPy5fZGVmYXVsdGVkKSB7XG4gICAgICByZXR1cm4gb3B0aW9ucztcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLnRoaXMuI2RlZmF1bHRPcHRpb25zLm11dGF0aW9ucyxcbiAgICAgIC4uLm9wdGlvbnM/Lm11dGF0aW9uS2V5ICYmIHRoaXMuZ2V0TXV0YXRpb25EZWZhdWx0cyhvcHRpb25zLm11dGF0aW9uS2V5KSxcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBfZGVmYXVsdGVkOiB0cnVlXG4gICAgfTtcbiAgfVxuICBjbGVhcigpIHtcbiAgICB0aGlzLiNxdWVyeUNhY2hlLmNsZWFyKCk7XG4gICAgdGhpcy4jbXV0YXRpb25DYWNoZS5jbGVhcigpO1xuICB9XG59O1xuZXhwb3J0IHtcbiAgUXVlcnlDbGllbnRcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeUNsaWVudC5qcy5tYXAiLCIvLyBzcmMvc3RyZWFtZWRRdWVyeS50c1xuaW1wb3J0IHsgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLCBhZGRUb0VuZCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5mdW5jdGlvbiBzdHJlYW1lZFF1ZXJ5KHtcbiAgc3RyZWFtRm4sXG4gIHJlZmV0Y2hNb2RlID0gXCJyZXNldFwiLFxuICByZWR1Y2VyID0gKGl0ZW1zLCBjaHVuaykgPT4gYWRkVG9FbmQoaXRlbXMsIGNodW5rKSxcbiAgaW5pdGlhbFZhbHVlID0gW11cbn0pIHtcbiAgcmV0dXJuIGFzeW5jIChjb250ZXh0KSA9PiB7XG4gICAgY29uc3QgcXVlcnkgPSBjb250ZXh0LmNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZmluZCh7IHF1ZXJ5S2V5OiBjb250ZXh0LnF1ZXJ5S2V5LCBleGFjdDogdHJ1ZSB9KTtcbiAgICBjb25zdCBpc1JlZmV0Y2ggPSAhIXF1ZXJ5ICYmIHF1ZXJ5LmlzRmV0Y2hlZCgpO1xuICAgIGlmIChpc1JlZmV0Y2ggJiYgcmVmZXRjaE1vZGUgPT09IFwicmVzZXRcIikge1xuICAgICAgcXVlcnkuc2V0U3RhdGUoe1xuICAgICAgICAuLi5xdWVyeS5yZXNldFN0YXRlLFxuICAgICAgICBmZXRjaFN0YXR1czogXCJmZXRjaGluZ1wiXG4gICAgICB9KTtcbiAgICB9XG4gICAgbGV0IHJlc3VsdCA9IGluaXRpYWxWYWx1ZTtcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgY29uc3Qgc3RyZWFtRm5Db250ZXh0ID0gYWRkQ29uc3VtZUF3YXJlU2lnbmFsKFxuICAgICAge1xuICAgICAgICBjbGllbnQ6IGNvbnRleHQuY2xpZW50LFxuICAgICAgICBtZXRhOiBjb250ZXh0Lm1ldGEsXG4gICAgICAgIHF1ZXJ5S2V5OiBjb250ZXh0LnF1ZXJ5S2V5LFxuICAgICAgICBwYWdlUGFyYW06IGNvbnRleHQucGFnZVBhcmFtLFxuICAgICAgICBkaXJlY3Rpb246IGNvbnRleHQuZGlyZWN0aW9uXG4gICAgICB9LFxuICAgICAgKCkgPT4gY29udGV4dC5zaWduYWwsXG4gICAgICAoKSA9PiBjYW5jZWxsZWQgPSB0cnVlXG4gICAgKTtcbiAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBzdHJlYW1GbihzdHJlYW1GbkNvbnRleHQpO1xuICAgIGNvbnN0IGlzUmVwbGFjZVJlZmV0Y2ggPSBpc1JlZmV0Y2ggJiYgcmVmZXRjaE1vZGUgPT09IFwicmVwbGFjZVwiO1xuICAgIGZvciBhd2FpdCAoY29uc3QgY2h1bmsgb2Ygc3RyZWFtKSB7XG4gICAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgaWYgKGlzUmVwbGFjZVJlZmV0Y2gpIHtcbiAgICAgICAgcmVzdWx0ID0gcmVkdWNlcihyZXN1bHQsIGNodW5rKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnRleHQuY2xpZW50LnNldFF1ZXJ5RGF0YShcbiAgICAgICAgICBjb250ZXh0LnF1ZXJ5S2V5LFxuICAgICAgICAgIChwcmV2KSA9PiByZWR1Y2VyKHByZXYgPT09IHZvaWQgMCA/IGluaXRpYWxWYWx1ZSA6IHByZXYsIGNodW5rKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoaXNSZXBsYWNlUmVmZXRjaCAmJiAhY2FuY2VsbGVkKSB7XG4gICAgICBjb250ZXh0LmNsaWVudC5zZXRRdWVyeURhdGEoY29udGV4dC5xdWVyeUtleSwgcmVzdWx0KTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbnRleHQuY2xpZW50LmdldFF1ZXJ5RGF0YShjb250ZXh0LnF1ZXJ5S2V5KSA/PyBpbml0aWFsVmFsdWU7XG4gIH07XG59XG5leHBvcnQge1xuICBzdHJlYW1lZFF1ZXJ5XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c3RyZWFtZWRRdWVyeS5qcy5tYXAiLCIvLyBzcmMvdHlwZXMudHNcbnZhciBkYXRhVGFnU3ltYm9sID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImRhdGFUYWdTeW1ib2xcIik7XG52YXIgZGF0YVRhZ0Vycm9yU3ltYm9sID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImRhdGFUYWdFcnJvclN5bWJvbFwiKTtcbnZhciB1bnNldE1hcmtlciA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJ1bnNldE1hcmtlclwiKTtcbmV4cG9ydCB7XG4gIGRhdGFUYWdFcnJvclN5bWJvbCxcbiAgZGF0YVRhZ1N5bWJvbCxcbiAgdW5zZXRNYXJrZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD10eXBlcy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL1F1ZXJ5Q2xpZW50UHJvdmlkZXIudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xudmFyIFF1ZXJ5Q2xpZW50Q29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQoXG4gIHZvaWQgMFxuKTtcbnZhciB1c2VRdWVyeUNsaWVudCA9IChxdWVyeUNsaWVudCkgPT4ge1xuICBjb25zdCBjbGllbnQgPSBSZWFjdC51c2VDb250ZXh0KFF1ZXJ5Q2xpZW50Q29udGV4dCk7XG4gIGlmIChxdWVyeUNsaWVudCkge1xuICAgIHJldHVybiBxdWVyeUNsaWVudDtcbiAgfVxuICBpZiAoIWNsaWVudCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk5vIFF1ZXJ5Q2xpZW50IHNldCwgdXNlIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgdG8gc2V0IG9uZVwiKTtcbiAgfVxuICByZXR1cm4gY2xpZW50O1xufTtcbnZhciBRdWVyeUNsaWVudFByb3ZpZGVyID0gKHtcbiAgY2xpZW50LFxuICBjaGlsZHJlblxufSkgPT4ge1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNsaWVudC5tb3VudCgpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjbGllbnQudW5tb3VudCgpO1xuICAgIH07XG4gIH0sIFtjbGllbnRdKTtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUXVlcnlDbGllbnRDb250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiBjbGllbnQsIGNoaWxkcmVuIH0pO1xufTtcbmV4cG9ydCB7XG4gIFF1ZXJ5Q2xpZW50Q29udGV4dCxcbiAgUXVlcnlDbGllbnRQcm92aWRlcixcbiAgdXNlUXVlcnlDbGllbnRcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1RdWVyeUNsaWVudFByb3ZpZGVyLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuXG4vLyBzcmMvSXNSZXN0b3JpbmdQcm92aWRlci50c1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG52YXIgSXNSZXN0b3JpbmdDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChmYWxzZSk7XG52YXIgdXNlSXNSZXN0b3JpbmcgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KElzUmVzdG9yaW5nQ29udGV4dCk7XG52YXIgSXNSZXN0b3JpbmdQcm92aWRlciA9IElzUmVzdG9yaW5nQ29udGV4dC5Qcm92aWRlcjtcbmV4cG9ydCB7XG4gIElzUmVzdG9yaW5nUHJvdmlkZXIsXG4gIHVzZUlzUmVzdG9yaW5nXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SXNSZXN0b3JpbmdQcm92aWRlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmZ1bmN0aW9uIGNyZWF0ZVZhbHVlKCkge1xuICBsZXQgaXNSZXNldCA9IGZhbHNlO1xuICByZXR1cm4ge1xuICAgIGNsZWFyUmVzZXQ6ICgpID0+IHtcbiAgICAgIGlzUmVzZXQgPSBmYWxzZTtcbiAgICB9LFxuICAgIHJlc2V0OiAoKSA9PiB7XG4gICAgICBpc1Jlc2V0ID0gdHJ1ZTtcbiAgICB9LFxuICAgIGlzUmVzZXQ6ICgpID0+IHtcbiAgICAgIHJldHVybiBpc1Jlc2V0O1xuICAgIH1cbiAgfTtcbn1cbnZhciBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeUNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KGNyZWF0ZVZhbHVlKCkpO1xudmFyIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChRdWVyeUVycm9yUmVzZXRCb3VuZGFyeUNvbnRleHQpO1xudmFyIFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5ID0gKHtcbiAgY2hpbGRyZW5cbn0pID0+IHtcbiAgY29uc3QgW3ZhbHVlXSA9IFJlYWN0LnVzZVN0YXRlKCgpID0+IGNyZWF0ZVZhbHVlKCkpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChRdWVyeUVycm9yUmVzZXRCb3VuZGFyeUNvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWUsIGNoaWxkcmVuOiB0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIiA/IGNoaWxkcmVuKHZhbHVlKSA6IGNoaWxkcmVuIH0pO1xufTtcbmV4cG9ydCB7XG4gIFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LFxuICB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuXG4vLyBzcmMvZXJyb3JCb3VuZGFyeVV0aWxzLnRzXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHNob3VsZFRocm93RXJyb3IgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbnZhciBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5ID0gKG9wdGlvbnMsIGVycm9yUmVzZXRCb3VuZGFyeSwgcXVlcnkpID0+IHtcbiAgY29uc3QgdGhyb3dPbkVycm9yID0gcXVlcnk/LnN0YXRlLmVycm9yICYmIHR5cGVvZiBvcHRpb25zLnRocm93T25FcnJvciA9PT0gXCJmdW5jdGlvblwiID8gc2hvdWxkVGhyb3dFcnJvcihvcHRpb25zLnRocm93T25FcnJvciwgW3F1ZXJ5LnN0YXRlLmVycm9yLCBxdWVyeV0pIDogb3B0aW9ucy50aHJvd09uRXJyb3I7XG4gIGlmIChvcHRpb25zLnN1c3BlbnNlIHx8IG9wdGlvbnMuZXhwZXJpbWVudGFsX3ByZWZldGNoSW5SZW5kZXIgfHwgdGhyb3dPbkVycm9yKSB7XG4gICAgaWYgKCFlcnJvclJlc2V0Qm91bmRhcnkuaXNSZXNldCgpKSB7XG4gICAgICBvcHRpb25zLnJldHJ5T25Nb3VudCA9IGZhbHNlO1xuICAgIH1cbiAgfVxufTtcbnZhciB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeSA9IChlcnJvclJlc2V0Qm91bmRhcnkpID0+IHtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBlcnJvclJlc2V0Qm91bmRhcnkuY2xlYXJSZXNldCgpO1xuICB9LCBbZXJyb3JSZXNldEJvdW5kYXJ5XSk7XG59O1xudmFyIGdldEhhc0Vycm9yID0gKHtcbiAgcmVzdWx0LFxuICBlcnJvclJlc2V0Qm91bmRhcnksXG4gIHRocm93T25FcnJvcixcbiAgcXVlcnksXG4gIHN1c3BlbnNlXG59KSA9PiB7XG4gIHJldHVybiByZXN1bHQuaXNFcnJvciAmJiAhZXJyb3JSZXNldEJvdW5kYXJ5LmlzUmVzZXQoKSAmJiAhcmVzdWx0LmlzRmV0Y2hpbmcgJiYgcXVlcnkgJiYgKHN1c3BlbnNlICYmIHJlc3VsdC5kYXRhID09PSB2b2lkIDAgfHwgc2hvdWxkVGhyb3dFcnJvcih0aHJvd09uRXJyb3IsIFtyZXN1bHQuZXJyb3IsIHF1ZXJ5XSkpO1xufTtcbmV4cG9ydCB7XG4gIGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksXG4gIGdldEhhc0Vycm9yLFxuICB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVycm9yQm91bmRhcnlVdGlscy5qcy5tYXAiLCIvLyBzcmMvc3VzcGVuc2UudHNcbnZhciBkZWZhdWx0VGhyb3dPbkVycm9yID0gKF9lcnJvciwgcXVlcnkpID0+IHF1ZXJ5LnN0YXRlLmRhdGEgPT09IHZvaWQgMDtcbnZhciBlbnN1cmVTdXNwZW5zZVRpbWVycyA9IChkZWZhdWx0ZWRPcHRpb25zKSA9PiB7XG4gIGlmIChkZWZhdWx0ZWRPcHRpb25zLnN1c3BlbnNlKSB7XG4gICAgY29uc3QgTUlOX1NVU1BFTlNFX1RJTUVfTVMgPSAxZTM7XG4gICAgY29uc3QgY2xhbXAgPSAodmFsdWUpID0+IHZhbHVlID09PSBcInN0YXRpY1wiID8gdmFsdWUgOiBNYXRoLm1heCh2YWx1ZSA/PyBNSU5fU1VTUEVOU0VfVElNRV9NUywgTUlOX1NVU1BFTlNFX1RJTUVfTVMpO1xuICAgIGNvbnN0IG9yaWdpbmFsU3RhbGVUaW1lID0gZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWU7XG4gICAgZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUgPSB0eXBlb2Ygb3JpZ2luYWxTdGFsZVRpbWUgPT09IFwiZnVuY3Rpb25cIiA/ICguLi5hcmdzKSA9PiBjbGFtcChvcmlnaW5hbFN0YWxlVGltZSguLi5hcmdzKSkgOiBjbGFtcChvcmlnaW5hbFN0YWxlVGltZSk7XG4gICAgaWYgKHR5cGVvZiBkZWZhdWx0ZWRPcHRpb25zLmdjVGltZSA9PT0gXCJudW1iZXJcIikge1xuICAgICAgZGVmYXVsdGVkT3B0aW9ucy5nY1RpbWUgPSBNYXRoLm1heChcbiAgICAgICAgZGVmYXVsdGVkT3B0aW9ucy5nY1RpbWUsXG4gICAgICAgIE1JTl9TVVNQRU5TRV9USU1FX01TXG4gICAgICApO1xuICAgIH1cbiAgfVxufTtcbnZhciB3aWxsRmV0Y2ggPSAocmVzdWx0LCBpc1Jlc3RvcmluZykgPT4gcmVzdWx0LmlzTG9hZGluZyAmJiByZXN1bHQuaXNGZXRjaGluZyAmJiAhaXNSZXN0b3Jpbmc7XG52YXIgc2hvdWxkU3VzcGVuZCA9IChkZWZhdWx0ZWRPcHRpb25zLCByZXN1bHQpID0+IGRlZmF1bHRlZE9wdGlvbnM/LnN1c3BlbnNlICYmIHJlc3VsdC5pc1BlbmRpbmc7XG52YXIgZmV0Y2hPcHRpbWlzdGljID0gKGRlZmF1bHRlZE9wdGlvbnMsIG9ic2VydmVyLCBlcnJvclJlc2V0Qm91bmRhcnkpID0+IG9ic2VydmVyLmZldGNoT3B0aW1pc3RpYyhkZWZhdWx0ZWRPcHRpb25zKS5jYXRjaCgoKSA9PiB7XG4gIGVycm9yUmVzZXRCb3VuZGFyeS5jbGVhclJlc2V0KCk7XG59KTtcbmV4cG9ydCB7XG4gIGRlZmF1bHRUaHJvd09uRXJyb3IsXG4gIGVuc3VyZVN1c3BlbnNlVGltZXJzLFxuICBmZXRjaE9wdGltaXN0aWMsXG4gIHNob3VsZFN1c3BlbmQsXG4gIHdpbGxGZXRjaFxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN1c3BlbnNlLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuXG4vLyBzcmMvdXNlUXVlcmllcy50c1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBRdWVyaWVzT2JzZXJ2ZXIsXG4gIFF1ZXJ5T2JzZXJ2ZXIsXG4gIG5vb3AsXG4gIG5vdGlmeU1hbmFnZXJcbn0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IHVzZUlzUmVzdG9yaW5nIH0gZnJvbSBcIi4vSXNSZXN0b3JpbmdQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkgfSBmcm9tIFwiLi9RdWVyeUVycm9yUmVzZXRCb3VuZGFyeS5qc1wiO1xuaW1wb3J0IHtcbiAgZW5zdXJlUHJldmVudEVycm9yQm91bmRhcnlSZXRyeSxcbiAgZ2V0SGFzRXJyb3IsXG4gIHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5XG59IGZyb20gXCIuL2Vycm9yQm91bmRhcnlVdGlscy5qc1wiO1xuaW1wb3J0IHtcbiAgZW5zdXJlU3VzcGVuc2VUaW1lcnMsXG4gIGZldGNoT3B0aW1pc3RpYyxcbiAgc2hvdWxkU3VzcGVuZFxufSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuZnVuY3Rpb24gdXNlUXVlcmllcyh7XG4gIHF1ZXJpZXMsXG4gIC4uLm9wdGlvbnNcbn0sIHF1ZXJ5Q2xpZW50KSB7XG4gIGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcbiAgY29uc3QgaXNSZXN0b3JpbmcgPSB1c2VJc1Jlc3RvcmluZygpO1xuICBjb25zdCBlcnJvclJlc2V0Qm91bmRhcnkgPSB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSgpO1xuICBjb25zdCBkZWZhdWx0ZWRRdWVyaWVzID0gUmVhY3QudXNlTWVtbyhcbiAgICAoKSA9PiBxdWVyaWVzLm1hcCgob3B0cykgPT4ge1xuICAgICAgY29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IGNsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKFxuICAgICAgICBvcHRzXG4gICAgICApO1xuICAgICAgZGVmYXVsdGVkT3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMgPSBpc1Jlc3RvcmluZyA/IFwiaXNSZXN0b3JpbmdcIiA6IFwib3B0aW1pc3RpY1wiO1xuICAgICAgcmV0dXJuIGRlZmF1bHRlZE9wdGlvbnM7XG4gICAgfSksXG4gICAgW3F1ZXJpZXMsIGNsaWVudCwgaXNSZXN0b3JpbmddXG4gICk7XG4gIGRlZmF1bHRlZFF1ZXJpZXMuZm9yRWFjaCgocXVlcnlPcHRpb25zKSA9PiB7XG4gICAgZW5zdXJlU3VzcGVuc2VUaW1lcnMocXVlcnlPcHRpb25zKTtcbiAgICBjb25zdCBxdWVyeSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0KHF1ZXJ5T3B0aW9ucy5xdWVyeUhhc2gpO1xuICAgIGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnkocXVlcnlPcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KTtcbiAgfSk7XG4gIHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5KGVycm9yUmVzZXRCb3VuZGFyeSk7XG4gIGNvbnN0IFtvYnNlcnZlcl0gPSBSZWFjdC51c2VTdGF0ZShcbiAgICAoKSA9PiBuZXcgUXVlcmllc09ic2VydmVyKFxuICAgICAgY2xpZW50LFxuICAgICAgZGVmYXVsdGVkUXVlcmllcyxcbiAgICAgIG9wdGlvbnNcbiAgICApXG4gICk7XG4gIGNvbnN0IFtvcHRpbWlzdGljUmVzdWx0LCBnZXRDb21iaW5lZFJlc3VsdCwgdHJhY2tSZXN1bHRdID0gb2JzZXJ2ZXIuZ2V0T3B0aW1pc3RpY1Jlc3VsdChcbiAgICBkZWZhdWx0ZWRRdWVyaWVzLFxuICAgIG9wdGlvbnMuY29tYmluZVxuICApO1xuICBjb25zdCBzaG91bGRTdWJzY3JpYmUgPSAhaXNSZXN0b3JpbmcgJiYgb3B0aW9ucy5zdWJzY3JpYmVkICE9PSBmYWxzZTtcbiAgUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoXG4gICAgUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgICAob25TdG9yZUNoYW5nZSkgPT4gc2hvdWxkU3Vic2NyaWJlID8gb2JzZXJ2ZXIuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSkgOiBub29wLFxuICAgICAgW29ic2VydmVyLCBzaG91bGRTdWJzY3JpYmVdXG4gICAgKSxcbiAgICAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCksXG4gICAgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpXG4gICk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgb2JzZXJ2ZXIuc2V0UXVlcmllcyhcbiAgICAgIGRlZmF1bHRlZFF1ZXJpZXMsXG4gICAgICBvcHRpb25zXG4gICAgKTtcbiAgfSwgW2RlZmF1bHRlZFF1ZXJpZXMsIG9wdGlvbnMsIG9ic2VydmVyXSk7XG4gIGNvbnN0IHNob3VsZEF0TGVhc3RPbmVTdXNwZW5kID0gb3B0aW1pc3RpY1Jlc3VsdC5zb21lKFxuICAgIChyZXN1bHQsIGluZGV4KSA9PiBzaG91bGRTdXNwZW5kKGRlZmF1bHRlZFF1ZXJpZXNbaW5kZXhdLCByZXN1bHQpXG4gICk7XG4gIGNvbnN0IHN1c3BlbnNlUHJvbWlzZXMgPSBzaG91bGRBdExlYXN0T25lU3VzcGVuZCA/IG9wdGltaXN0aWNSZXN1bHQuZmxhdE1hcCgocmVzdWx0LCBpbmRleCkgPT4ge1xuICAgIGNvbnN0IG9wdHMgPSBkZWZhdWx0ZWRRdWVyaWVzW2luZGV4XTtcbiAgICBpZiAob3B0cyAmJiBzaG91bGRTdXNwZW5kKG9wdHMsIHJlc3VsdCkpIHtcbiAgICAgIGNvbnN0IHF1ZXJ5T2JzZXJ2ZXIgPSBuZXcgUXVlcnlPYnNlcnZlcihjbGllbnQsIG9wdHMpO1xuICAgICAgcmV0dXJuIGZldGNoT3B0aW1pc3RpYyhvcHRzLCBxdWVyeU9ic2VydmVyLCBlcnJvclJlc2V0Qm91bmRhcnkpO1xuICAgIH1cbiAgICByZXR1cm4gW107XG4gIH0pIDogW107XG4gIGlmIChzdXNwZW5zZVByb21pc2VzLmxlbmd0aCA+IDApIHtcbiAgICB0aHJvdyBQcm9taXNlLmFsbChzdXNwZW5zZVByb21pc2VzKTtcbiAgfVxuICBjb25zdCBmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3cgPSBvcHRpbWlzdGljUmVzdWx0LmZpbmQoXG4gICAgKHJlc3VsdCwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHF1ZXJ5ID0gZGVmYXVsdGVkUXVlcmllc1tpbmRleF07XG4gICAgICByZXR1cm4gcXVlcnkgJiYgZ2V0SGFzRXJyb3Ioe1xuICAgICAgICByZXN1bHQsXG4gICAgICAgIGVycm9yUmVzZXRCb3VuZGFyeSxcbiAgICAgICAgdGhyb3dPbkVycm9yOiBxdWVyeS50aHJvd09uRXJyb3IsXG4gICAgICAgIHF1ZXJ5OiBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChxdWVyeS5xdWVyeUhhc2gpLFxuICAgICAgICBzdXNwZW5zZTogcXVlcnkuc3VzcGVuc2VcbiAgICAgIH0pO1xuICAgIH1cbiAgKTtcbiAgaWYgKGZpcnN0U2luZ2xlUmVzdWx0V2hpY2hTaG91bGRUaHJvdz8uZXJyb3IpIHtcbiAgICB0aHJvdyBmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3cuZXJyb3I7XG4gIH1cbiAgcmV0dXJuIGdldENvbWJpbmVkUmVzdWx0KHRyYWNrUmVzdWx0KCkpO1xufVxuZXhwb3J0IHtcbiAgdXNlUXVlcmllc1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVF1ZXJpZXMuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5cbi8vIHNyYy91c2VCYXNlUXVlcnkudHNcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgZW52aXJvbm1lbnRNYW5hZ2VyLCBub29wLCBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7XG4gIGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksXG4gIGdldEhhc0Vycm9yLFxuICB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeVxufSBmcm9tIFwiLi9lcnJvckJvdW5kYXJ5VXRpbHMuanNcIjtcbmltcG9ydCB7IHVzZUlzUmVzdG9yaW5nIH0gZnJvbSBcIi4vSXNSZXN0b3JpbmdQcm92aWRlci5qc1wiO1xuaW1wb3J0IHtcbiAgZW5zdXJlU3VzcGVuc2VUaW1lcnMsXG4gIGZldGNoT3B0aW1pc3RpYyxcbiAgc2hvdWxkU3VzcGVuZCxcbiAgd2lsbEZldGNoXG59IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5mdW5jdGlvbiB1c2VCYXNlUXVlcnkob3B0aW9ucywgT2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMgIT09IFwib2JqZWN0XCIgfHwgQXJyYXkuaXNBcnJheShvcHRpb25zKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnQmFkIGFyZ3VtZW50IHR5cGUuIFN0YXJ0aW5nIHdpdGggdjUsIG9ubHkgdGhlIFwiT2JqZWN0XCIgZm9ybSBpcyBhbGxvd2VkIHdoZW4gY2FsbGluZyBxdWVyeSByZWxhdGVkIGZ1bmN0aW9ucy4gUGxlYXNlIHVzZSB0aGUgZXJyb3Igc3RhY2sgdG8gZmluZCB0aGUgY3VscHJpdCBjYWxsLiBNb3JlIGluZm8gaGVyZTogaHR0cHM6Ly90YW5zdGFjay5jb20vcXVlcnkvbGF0ZXN0L2RvY3MvcmVhY3QvZ3VpZGVzL21pZ3JhdGluZy10by12NSNzdXBwb3J0cy1hLXNpbmdsZS1zaWduYXR1cmUtb25lLW9iamVjdCdcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGNvbnN0IGlzUmVzdG9yaW5nID0gdXNlSXNSZXN0b3JpbmcoKTtcbiAgY29uc3QgZXJyb3JSZXNldEJvdW5kYXJ5ID0gdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkoKTtcbiAgY29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuICBjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG4gIGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLnF1ZXJpZXM/Ll9leHBlcmltZW50YWxfYmVmb3JlUXVlcnk/LihcbiAgICBkZWZhdWx0ZWRPcHRpb25zXG4gICk7XG4gIGNvbnN0IHF1ZXJ5ID0gY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5nZXQoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2gpO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgaWYgKCFkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5Rm4pIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBbJHtkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaH1dOiBObyBxdWVyeUZuIHdhcyBwYXNzZWQgYXMgYW4gb3B0aW9uLCBhbmQgbm8gZGVmYXVsdCBxdWVyeUZuIHdhcyBmb3VuZC4gVGhlIHF1ZXJ5Rm4gcGFyYW1ldGVyIGlzIG9ubHkgb3B0aW9uYWwgd2hlbiB1c2luZyBhIGRlZmF1bHQgcXVlcnlGbi4gTW9yZSBpbmZvIGhlcmU6IGh0dHBzOi8vdGFuc3RhY2suY29tL3F1ZXJ5L2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZXMvZGVmYXVsdC1xdWVyeS1mdW5jdGlvbmBcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGNvbnN0IHN1YnNjcmliZWQgPSBvcHRpb25zLnN1YnNjcmliZWQgIT09IGZhbHNlO1xuICBkZWZhdWx0ZWRPcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cyA9IGlzUmVzdG9yaW5nID8gXCJpc1Jlc3RvcmluZ1wiIDogc3Vic2NyaWJlZCA/IFwib3B0aW1pc3RpY1wiIDogdm9pZCAwO1xuICBlbnN1cmVTdXNwZW5zZVRpbWVycyhkZWZhdWx0ZWRPcHRpb25zKTtcbiAgZW5zdXJlUHJldmVudEVycm9yQm91bmRhcnlSZXRyeShkZWZhdWx0ZWRPcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KTtcbiAgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkoZXJyb3JSZXNldEJvdW5kYXJ5KTtcbiAgY29uc3QgaXNOZXdDYWNoZUVudHJ5ID0gIWNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0KGRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKTtcbiAgY29uc3QgW29ic2VydmVyXSA9IFJlYWN0LnVzZVN0YXRlKFxuICAgICgpID0+IG5ldyBPYnNlcnZlcihcbiAgICAgIGNsaWVudCxcbiAgICAgIGRlZmF1bHRlZE9wdGlvbnNcbiAgICApXG4gICk7XG4gIGNvbnN0IHJlc3VsdCA9IG9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQoZGVmYXVsdGVkT3B0aW9ucyk7XG4gIGNvbnN0IHNob3VsZFN1YnNjcmliZSA9ICFpc1Jlc3RvcmluZyAmJiBzdWJzY3JpYmVkO1xuICBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShcbiAgICBSZWFjdC51c2VDYWxsYmFjayhcbiAgICAgIChvblN0b3JlQ2hhbmdlKSA9PiB7XG4gICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gc2hvdWxkU3Vic2NyaWJlID8gb2JzZXJ2ZXIuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSkgOiBub29wO1xuICAgICAgICBvYnNlcnZlci51cGRhdGVSZXN1bHQoKTtcbiAgICAgICAgcmV0dXJuIHVuc3Vic2NyaWJlO1xuICAgICAgfSxcbiAgICAgIFtvYnNlcnZlciwgc2hvdWxkU3Vic2NyaWJlXVxuICAgICksXG4gICAgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLFxuICAgICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuICApO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIG9ic2VydmVyLnNldE9wdGlvbnMoZGVmYXVsdGVkT3B0aW9ucyk7XG4gIH0sIFtkZWZhdWx0ZWRPcHRpb25zLCBvYnNlcnZlcl0pO1xuICBpZiAoc2hvdWxkU3VzcGVuZChkZWZhdWx0ZWRPcHRpb25zLCByZXN1bHQpKSB7XG4gICAgdGhyb3cgZmV0Y2hPcHRpbWlzdGljKGRlZmF1bHRlZE9wdGlvbnMsIG9ic2VydmVyLCBlcnJvclJlc2V0Qm91bmRhcnkpO1xuICB9XG4gIGlmIChnZXRIYXNFcnJvcih7XG4gICAgcmVzdWx0LFxuICAgIGVycm9yUmVzZXRCb3VuZGFyeSxcbiAgICB0aHJvd09uRXJyb3I6IGRlZmF1bHRlZE9wdGlvbnMudGhyb3dPbkVycm9yLFxuICAgIHF1ZXJ5LFxuICAgIHN1c3BlbnNlOiBkZWZhdWx0ZWRPcHRpb25zLnN1c3BlbnNlXG4gIH0pKSB7XG4gICAgdGhyb3cgcmVzdWx0LmVycm9yO1xuICB9XG4gIDtcbiAgY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkucXVlcmllcz8uX2V4cGVyaW1lbnRhbF9hZnRlclF1ZXJ5Py4oXG4gICAgZGVmYXVsdGVkT3B0aW9ucyxcbiAgICByZXN1bHRcbiAgKTtcbiAgaWYgKGRlZmF1bHRlZE9wdGlvbnMuZXhwZXJpbWVudGFsX3ByZWZldGNoSW5SZW5kZXIgJiYgIWVudmlyb25tZW50TWFuYWdlci5pc1NlcnZlcigpICYmIHdpbGxGZXRjaChyZXN1bHQsIGlzUmVzdG9yaW5nKSkge1xuICAgIGNvbnN0IHByb21pc2UgPSBpc05ld0NhY2hlRW50cnkgPyAoXG4gICAgICAvLyBGZXRjaCBpbW1lZGlhdGVseSBvbiByZW5kZXIgaW4gb3JkZXIgdG8gZW5zdXJlIGAucHJvbWlzZWAgaXMgcmVzb2x2ZWQgZXZlbiBpZiB0aGUgY29tcG9uZW50IGlzIHVubW91bnRlZFxuICAgICAgZmV0Y2hPcHRpbWlzdGljKGRlZmF1bHRlZE9wdGlvbnMsIG9ic2VydmVyLCBlcnJvclJlc2V0Qm91bmRhcnkpXG4gICAgKSA6IChcbiAgICAgIC8vIHN1YnNjcmliZSB0byB0aGUgXCJjYWNoZSBwcm9taXNlXCIgc28gdGhhdCB3ZSBjYW4gZmluYWxpemUgdGhlIGN1cnJlbnRUaGVuYWJsZSBvbmNlIGRhdGEgY29tZXMgaW5cbiAgICAgIHF1ZXJ5Py5wcm9taXNlXG4gICAgKTtcbiAgICBwcm9taXNlPy5jYXRjaChub29wKS5maW5hbGx5KCgpID0+IHtcbiAgICAgIG9ic2VydmVyLnVwZGF0ZVJlc3VsdCgpO1xuICAgIH0pO1xuICB9XG4gIHJldHVybiAhZGVmYXVsdGVkT3B0aW9ucy5ub3RpZnlPbkNoYW5nZVByb3BzID8gb2JzZXJ2ZXIudHJhY2tSZXN1bHQocmVzdWx0KSA6IHJlc3VsdDtcbn1cbmV4cG9ydCB7XG4gIHVzZUJhc2VRdWVyeVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUJhc2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL3VzZVF1ZXJ5LnRzXG5pbXBvcnQgeyBRdWVyeU9ic2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgeyB1c2VCYXNlUXVlcnkgfSBmcm9tIFwiLi91c2VCYXNlUXVlcnkuanNcIjtcbmZ1bmN0aW9uIHVzZVF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG4gIHJldHVybiB1c2VCYXNlUXVlcnkob3B0aW9ucywgUXVlcnlPYnNlcnZlciwgcXVlcnlDbGllbnQpO1xufVxuZXhwb3J0IHtcbiAgdXNlUXVlcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL3VzZVN1c3BlbnNlUXVlcnkudHNcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIsIHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBkZWZhdWx0VGhyb3dPbkVycm9yIH0gZnJvbSBcIi4vc3VzcGVuc2UuanNcIjtcbmZ1bmN0aW9uIHVzZVN1c3BlbnNlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIGlmIChvcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikge1xuICAgICAgY29uc29sZS5lcnJvcihcInNraXBUb2tlbiBpcyBub3QgYWxsb3dlZCBmb3IgdXNlU3VzcGVuc2VRdWVyeVwiKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHVzZUJhc2VRdWVyeShcbiAgICB7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgIHN1c3BlbnNlOiB0cnVlLFxuICAgICAgdGhyb3dPbkVycm9yOiBkZWZhdWx0VGhyb3dPbkVycm9yLFxuICAgICAgcGxhY2Vob2xkZXJEYXRhOiB2b2lkIDBcbiAgICB9LFxuICAgIFF1ZXJ5T2JzZXJ2ZXIsXG4gICAgcXVlcnlDbGllbnRcbiAgKTtcbn1cbmV4cG9ydCB7XG4gIHVzZVN1c3BlbnNlUXVlcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTdXNwZW5zZVF1ZXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuXG4vLyBzcmMvdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LnRzXG5pbXBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIsIHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBkZWZhdWx0VGhyb3dPbkVycm9yIH0gZnJvbSBcIi4vc3VzcGVuc2UuanNcIjtcbmZ1bmN0aW9uIHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgaWYgKG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwic2tpcFRva2VuIGlzIG5vdCBhbGxvd2VkIGZvciB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlcIik7XG4gICAgfVxuICB9XG4gIHJldHVybiB1c2VCYXNlUXVlcnkoXG4gICAge1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICBzdXNwZW5zZTogdHJ1ZSxcbiAgICAgIHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvclxuICAgIH0sXG4gICAgSW5maW5pdGVRdWVyeU9ic2VydmVyLFxuICAgIHF1ZXJ5Q2xpZW50XG4gICk7XG59XG5leHBvcnQge1xuICB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTdXNwZW5zZUluZmluaXRlUXVlcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5cbi8vIHNyYy91c2VTdXNwZW5zZVF1ZXJpZXMudHNcbmltcG9ydCB7IHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gXCIuL3VzZVF1ZXJpZXMuanNcIjtcbmltcG9ydCB7IGRlZmF1bHRUaHJvd09uRXJyb3IgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuZnVuY3Rpb24gdXNlU3VzcGVuc2VRdWVyaWVzKG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG4gIHJldHVybiB1c2VRdWVyaWVzKFxuICAgIHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBxdWVyaWVzOiBvcHRpb25zLnF1ZXJpZXMubWFwKChxdWVyeSkgPT4ge1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICAgICAgaWYgKHF1ZXJ5LnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcInNraXBUb2tlbiBpcyBub3QgYWxsb3dlZCBmb3IgdXNlU3VzcGVuc2VRdWVyaWVzXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIC4uLnF1ZXJ5LFxuICAgICAgICAgIHN1c3BlbnNlOiB0cnVlLFxuICAgICAgICAgIHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvcixcbiAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgIHBsYWNlaG9sZGVyRGF0YTogdm9pZCAwXG4gICAgICAgIH07XG4gICAgICB9KVxuICAgIH0sXG4gICAgcXVlcnlDbGllbnRcbiAgKTtcbn1cbmV4cG9ydCB7XG4gIHVzZVN1c3BlbnNlUXVlcmllc1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVN1c3BlbnNlUXVlcmllcy5qcy5tYXAiLCIvLyBzcmMvdXNlUHJlZmV0Y2hRdWVyeS50c3hcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuZnVuY3Rpb24gdXNlUHJlZmV0Y2hRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuICBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG4gIGlmICghY2xpZW50LmdldFF1ZXJ5U3RhdGUob3B0aW9ucy5xdWVyeUtleSkpIHtcbiAgICBjbGllbnQucHJlZmV0Y2hRdWVyeShvcHRpb25zKTtcbiAgfVxufVxuZXhwb3J0IHtcbiAgdXNlUHJlZmV0Y2hRdWVyeVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVByZWZldGNoUXVlcnkuanMubWFwIiwiLy8gc3JjL3VzZVByZWZldGNoSW5maW5pdGVRdWVyeS50c3hcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuZnVuY3Rpb24gdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG4gIGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcbiAgaWYgKCFjbGllbnQuZ2V0UXVlcnlTdGF0ZShvcHRpb25zLnF1ZXJ5S2V5KSkge1xuICAgIGNsaWVudC5wcmVmZXRjaEluZmluaXRlUXVlcnkob3B0aW9ucyk7XG4gIH1cbn1cbmV4cG9ydCB7XG4gIHVzZVByZWZldGNoSW5maW5pdGVRdWVyeVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVByZWZldGNoSW5maW5pdGVRdWVyeS5qcy5tYXAiLCIvLyBzcmMvcXVlcnlPcHRpb25zLnRzXG5mdW5jdGlvbiBxdWVyeU9wdGlvbnMob3B0aW9ucykge1xuICByZXR1cm4gb3B0aW9ucztcbn1cbmV4cG9ydCB7XG4gIHF1ZXJ5T3B0aW9uc1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5T3B0aW9ucy5qcy5tYXAiLCIvLyBzcmMvaW5maW5pdGVRdWVyeU9wdGlvbnMudHNcbmZ1bmN0aW9uIGluZmluaXRlUXVlcnlPcHRpb25zKG9wdGlvbnMpIHtcbiAgcmV0dXJuIG9wdGlvbnM7XG59XG5leHBvcnQge1xuICBpbmZpbml0ZVF1ZXJ5T3B0aW9uc1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZmluaXRlUXVlcnlPcHRpb25zLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuXG4vLyBzcmMvSHlkcmF0aW9uQm91bmRhcnkudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGh5ZHJhdGUgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xudmFyIEh5ZHJhdGlvbkJvdW5kYXJ5ID0gKHtcbiAgY2hpbGRyZW4sXG4gIG9wdGlvbnMgPSB7fSxcbiAgc3RhdGUsXG4gIHF1ZXJ5Q2xpZW50XG59KSA9PiB7XG4gIGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcbiAgY29uc3Qgb3B0aW9uc1JlZiA9IFJlYWN0LnVzZVJlZihvcHRpb25zKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBvcHRpb25zUmVmLmN1cnJlbnQgPSBvcHRpb25zO1xuICB9KTtcbiAgY29uc3QgaHlkcmF0aW9uUXVldWUgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoc3RhdGUpIHtcbiAgICAgIGlmICh0eXBlb2Ygc3RhdGUgIT09IFwib2JqZWN0XCIpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgcXVlcnlDYWNoZSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCk7XG4gICAgICBjb25zdCBxdWVyaWVzID0gc3RhdGUucXVlcmllcyB8fCBbXTtcbiAgICAgIGNvbnN0IG5ld1F1ZXJpZXMgPSBbXTtcbiAgICAgIGNvbnN0IGV4aXN0aW5nUXVlcmllcyA9IFtdO1xuICAgICAgZm9yIChjb25zdCBkZWh5ZHJhdGVkUXVlcnkgb2YgcXVlcmllcykge1xuICAgICAgICBjb25zdCBleGlzdGluZ1F1ZXJ5ID0gcXVlcnlDYWNoZS5nZXQoZGVoeWRyYXRlZFF1ZXJ5LnF1ZXJ5SGFzaCk7XG4gICAgICAgIGlmICghZXhpc3RpbmdRdWVyeSkge1xuICAgICAgICAgIG5ld1F1ZXJpZXMucHVzaChkZWh5ZHJhdGVkUXVlcnkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IGh5ZHJhdGlvbklzTmV3ZXIgPSBkZWh5ZHJhdGVkUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCA+IGV4aXN0aW5nUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCB8fCBkZWh5ZHJhdGVkUXVlcnkucHJvbWlzZSAmJiBleGlzdGluZ1F1ZXJ5LnN0YXRlLnN0YXR1cyAhPT0gXCJwZW5kaW5nXCIgJiYgZXhpc3RpbmdRdWVyeS5zdGF0ZS5mZXRjaFN0YXR1cyAhPT0gXCJmZXRjaGluZ1wiICYmIGRlaHlkcmF0ZWRRdWVyeS5kZWh5ZHJhdGVkQXQgIT09IHZvaWQgMCAmJiBkZWh5ZHJhdGVkUXVlcnkuZGVoeWRyYXRlZEF0ID4gZXhpc3RpbmdRdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0O1xuICAgICAgICAgIGlmIChoeWRyYXRpb25Jc05ld2VyKSB7XG4gICAgICAgICAgICBleGlzdGluZ1F1ZXJpZXMucHVzaChkZWh5ZHJhdGVkUXVlcnkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKG5ld1F1ZXJpZXMubGVuZ3RoID4gMCkge1xuICAgICAgICBoeWRyYXRlKGNsaWVudCwgeyBxdWVyaWVzOiBuZXdRdWVyaWVzIH0sIG9wdGlvbnNSZWYuY3VycmVudCk7XG4gICAgICB9XG4gICAgICBpZiAoZXhpc3RpbmdRdWVyaWVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgcmV0dXJuIGV4aXN0aW5nUXVlcmllcztcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgfSwgW2NsaWVudCwgc3RhdGVdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaHlkcmF0aW9uUXVldWUpIHtcbiAgICAgIGh5ZHJhdGUoY2xpZW50LCB7IHF1ZXJpZXM6IGh5ZHJhdGlvblF1ZXVlIH0sIG9wdGlvbnNSZWYuY3VycmVudCk7XG4gICAgfVxuICB9LCBbY2xpZW50LCBoeWRyYXRpb25RdWV1ZV0pO1xuICByZXR1cm4gY2hpbGRyZW47XG59O1xuZXhwb3J0IHtcbiAgSHlkcmF0aW9uQm91bmRhcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1IeWRyYXRpb25Cb3VuZGFyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL3VzZUlzRmV0Y2hpbmcudHNcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5mdW5jdGlvbiB1c2VJc0ZldGNoaW5nKGZpbHRlcnMsIHF1ZXJ5Q2xpZW50KSB7XG4gIGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcbiAgY29uc3QgcXVlcnlDYWNoZSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCk7XG4gIHJldHVybiBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShcbiAgICBSZWFjdC51c2VDYWxsYmFjayhcbiAgICAgIChvblN0b3JlQ2hhbmdlKSA9PiBxdWVyeUNhY2hlLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpLFxuICAgICAgW3F1ZXJ5Q2FjaGVdXG4gICAgKSxcbiAgICAoKSA9PiBjbGllbnQuaXNGZXRjaGluZyhmaWx0ZXJzKSxcbiAgICAoKSA9PiBjbGllbnQuaXNGZXRjaGluZyhmaWx0ZXJzKVxuICApO1xufVxuZXhwb3J0IHtcbiAgdXNlSXNGZXRjaGluZ1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUlzRmV0Y2hpbmcuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5cbi8vIHNyYy91c2VNdXRhdGlvblN0YXRlLnRzXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIsIHJlcGxhY2VFcXVhbERlZXAgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuZnVuY3Rpb24gdXNlSXNNdXRhdGluZyhmaWx0ZXJzLCBxdWVyeUNsaWVudCkge1xuICBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG4gIHJldHVybiB1c2VNdXRhdGlvblN0YXRlKFxuICAgIHsgZmlsdGVyczogeyAuLi5maWx0ZXJzLCBzdGF0dXM6IFwicGVuZGluZ1wiIH0gfSxcbiAgICBjbGllbnRcbiAgKS5sZW5ndGg7XG59XG5mdW5jdGlvbiBnZXRSZXN1bHQobXV0YXRpb25DYWNoZSwgb3B0aW9ucykge1xuICByZXR1cm4gbXV0YXRpb25DYWNoZS5maW5kQWxsKG9wdGlvbnMuZmlsdGVycykubWFwKFxuICAgIChtdXRhdGlvbikgPT4gb3B0aW9ucy5zZWxlY3QgPyBvcHRpb25zLnNlbGVjdChtdXRhdGlvbikgOiBtdXRhdGlvbi5zdGF0ZVxuICApO1xufVxuZnVuY3Rpb24gdXNlTXV0YXRpb25TdGF0ZShvcHRpb25zID0ge30sIHF1ZXJ5Q2xpZW50KSB7XG4gIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCkuZ2V0TXV0YXRpb25DYWNoZSgpO1xuICBjb25zdCBvcHRpb25zUmVmID0gUmVhY3QudXNlUmVmKG9wdGlvbnMpO1xuICBjb25zdCByZXN1bHQgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGlmIChyZXN1bHQuY3VycmVudCA9PT0gbnVsbCkge1xuICAgIHJlc3VsdC5jdXJyZW50ID0gZ2V0UmVzdWx0KG11dGF0aW9uQ2FjaGUsIG9wdGlvbnMpO1xuICB9XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgb3B0aW9uc1JlZi5jdXJyZW50ID0gb3B0aW9ucztcbiAgfSk7XG4gIHJldHVybiBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShcbiAgICBSZWFjdC51c2VDYWxsYmFjayhcbiAgICAgIChvblN0b3JlQ2hhbmdlKSA9PiBtdXRhdGlvbkNhY2hlLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHRSZXN1bHQgPSByZXBsYWNlRXF1YWxEZWVwKFxuICAgICAgICAgIHJlc3VsdC5jdXJyZW50LFxuICAgICAgICAgIGdldFJlc3VsdChtdXRhdGlvbkNhY2hlLCBvcHRpb25zUmVmLmN1cnJlbnQpXG4gICAgICAgICk7XG4gICAgICAgIGlmIChyZXN1bHQuY3VycmVudCAhPT0gbmV4dFJlc3VsdCkge1xuICAgICAgICAgIHJlc3VsdC5jdXJyZW50ID0gbmV4dFJlc3VsdDtcbiAgICAgICAgICBub3RpZnlNYW5hZ2VyLnNjaGVkdWxlKG9uU3RvcmVDaGFuZ2UpO1xuICAgICAgICB9XG4gICAgICB9KSxcbiAgICAgIFttdXRhdGlvbkNhY2hlXVxuICAgICksXG4gICAgKCkgPT4gcmVzdWx0LmN1cnJlbnQsXG4gICAgKCkgPT4gcmVzdWx0LmN1cnJlbnRcbiAgKTtcbn1cbmV4cG9ydCB7XG4gIHVzZUlzTXV0YXRpbmcsXG4gIHVzZU11dGF0aW9uU3RhdGVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VNdXRhdGlvblN0YXRlLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuXG4vLyBzcmMvdXNlTXV0YXRpb24udHNcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgTXV0YXRpb25PYnNlcnZlcixcbiAgbm9vcCxcbiAgbm90aWZ5TWFuYWdlcixcbiAgc2hvdWxkVGhyb3dFcnJvclxufSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuZnVuY3Rpb24gdXNlTXV0YXRpb24ob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcbiAgY29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuICBjb25zdCBbb2JzZXJ2ZXJdID0gUmVhY3QudXNlU3RhdGUoXG4gICAgKCkgPT4gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoXG4gICAgICBjbGllbnQsXG4gICAgICBvcHRpb25zXG4gICAgKVxuICApO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIG9ic2VydmVyLnNldE9wdGlvbnMob3B0aW9ucyk7XG4gIH0sIFtvYnNlcnZlciwgb3B0aW9uc10pO1xuICBjb25zdCByZXN1bHQgPSBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShcbiAgICBSZWFjdC51c2VDYWxsYmFjayhcbiAgICAgIChvblN0b3JlQ2hhbmdlKSA9PiBvYnNlcnZlci5zdWJzY3JpYmUobm90aWZ5TWFuYWdlci5iYXRjaENhbGxzKG9uU3RvcmVDaGFuZ2UpKSxcbiAgICAgIFtvYnNlcnZlcl1cbiAgICApLFxuICAgICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSxcbiAgICAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KClcbiAgKTtcbiAgY29uc3QgbXV0YXRlID0gUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgKHZhcmlhYmxlcywgbXV0YXRlT3B0aW9ucykgPT4ge1xuICAgICAgb2JzZXJ2ZXIubXV0YXRlKHZhcmlhYmxlcywgbXV0YXRlT3B0aW9ucykuY2F0Y2gobm9vcCk7XG4gICAgfSxcbiAgICBbb2JzZXJ2ZXJdXG4gICk7XG4gIGlmIChyZXN1bHQuZXJyb3IgJiYgc2hvdWxkVGhyb3dFcnJvcihvYnNlcnZlci5vcHRpb25zLnRocm93T25FcnJvciwgW3Jlc3VsdC5lcnJvcl0pKSB7XG4gICAgdGhyb3cgcmVzdWx0LmVycm9yO1xuICB9XG4gIHJldHVybiB7IC4uLnJlc3VsdCwgbXV0YXRlLCBtdXRhdGVBc3luYzogcmVzdWx0Lm11dGF0ZSB9O1xufVxuZXhwb3J0IHtcbiAgdXNlTXV0YXRpb25cbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VNdXRhdGlvbi5qcy5tYXAiLCIvLyBzcmMvbXV0YXRpb25PcHRpb25zLnRzXG5mdW5jdGlvbiBtdXRhdGlvbk9wdGlvbnMob3B0aW9ucykge1xuICByZXR1cm4gb3B0aW9ucztcbn1cbmV4cG9ydCB7XG4gIG11dGF0aW9uT3B0aW9uc1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW11dGF0aW9uT3B0aW9ucy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcblxuLy8gc3JjL3VzZUluZmluaXRlUXVlcnkudHNcbmltcG9ydCB7IEluZmluaXRlUXVlcnlPYnNlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5mdW5jdGlvbiB1c2VJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG4gIHJldHVybiB1c2VCYXNlUXVlcnkoXG4gICAgb3B0aW9ucyxcbiAgICBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIsXG4gICAgcXVlcnlDbGllbnRcbiAgKTtcbn1cbmV4cG9ydCB7XG4gIHVzZUluZmluaXRlUXVlcnlcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VJbmZpbml0ZVF1ZXJ5LmpzLm1hcCJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0M10sIm1hcHBpbmdzIjoiOzs7O0FBQ0EsSUFBSSxlQUFlLE1BQU07Q0FDdkIsY0FBYztFQUNaLEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssSUFBSTtDQUMzQztDQUNBLFVBQVUsVUFBVTtFQUNsQixLQUFLLFVBQVUsSUFBSSxRQUFRO0VBQzNCLEtBQUssWUFBWTtFQUNqQixhQUFhO0dBQ1gsS0FBSyxVQUFVLE9BQU8sUUFBUTtHQUM5QixLQUFLLGNBQWM7RUFDckI7Q0FDRjtDQUNBLGVBQWU7RUFDYixPQUFPLEtBQUssVUFBVSxPQUFPO0NBQy9CO0NBQ0EsY0FBYyxDQUNkO0NBQ0EsZ0JBQWdCLENBQ2hCO0FBQ0Y7OztBQ25CQSxJQUFJLGVBQWUsY0FBYyxhQUFhO0NBQzVDO0NBQ0E7Q0FDQTtDQUNBLGNBQWM7RUFDWixNQUFNO0VBQ04sS0FBS0EsVUFBVSxZQUFZO0dBQ3pCLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxrQkFBa0I7SUFDNUQsTUFBTSxpQkFBaUIsUUFBUTtJQUMvQixPQUFPLGlCQUFpQixvQkFBb0IsVUFBVSxLQUFLO0lBQzNELGFBQWE7S0FDWCxPQUFPLG9CQUFvQixvQkFBb0IsUUFBUTtJQUN6RDtHQUNGO0VBRUY7Q0FDRjtDQUNBLGNBQWM7RUFDWixJQUFJLENBQUMsS0FBS0MsVUFDUixLQUFLLGlCQUFpQixLQUFLRCxNQUFNO0NBRXJDO0NBQ0EsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHO0dBQ3hCLEtBQUtDLFdBQVc7R0FDaEIsS0FBS0EsV0FBVyxLQUFLO0VBQ3ZCO0NBQ0Y7Q0FDQSxpQkFBaUIsT0FBTztFQUN0QixLQUFLRCxTQUFTO0VBQ2QsS0FBS0MsV0FBVztFQUNoQixLQUFLQSxXQUFXLE9BQU8sWUFBWTtHQUNqQyxJQUFJLE9BQU8sWUFBWSxXQUNyQixLQUFLLFdBQVcsT0FBTztRQUV2QixLQUFLLFFBQVE7RUFFakIsQ0FBQztDQUNIO0NBQ0EsV0FBVyxTQUFTO0VBRWxCLElBRGdCLEtBQUtDLGFBQWEsU0FDckI7R0FDWCxLQUFLQSxXQUFXO0dBQ2hCLEtBQUssUUFBUTtFQUNmO0NBQ0Y7Q0FDQSxVQUFVO0VBQ1IsTUFBTSxZQUFZLEtBQUssVUFBVTtFQUNqQyxLQUFLLFVBQVUsU0FBUyxhQUFhO0dBQ25DLFNBQVMsU0FBUztFQUNwQixDQUFDO0NBQ0g7Q0FDQSxZQUFZO0VBQ1YsSUFBSSxPQUFPLEtBQUtBLGFBQWEsV0FDM0IsT0FBTyxLQUFLQTtFQUVkLE9BQU8sV0FBVyxVQUFVLG9CQUFvQjtDQUNsRDtBQUNGO0FBQ0EsSUFBSSxlQUFlLElBQUksYUFBYTs7O0FDNURwQyxJQUFJLHlCQUF5QjtDQVczQixhQUFhLFVBQVUsVUFBVSxXQUFXLFVBQVUsS0FBSztDQUMzRCxlQUFlLGNBQWMsYUFBYSxTQUFTO0NBQ25ELGNBQWMsVUFBVSxVQUFVLFlBQVksVUFBVSxLQUFLO0NBQzdELGdCQUFnQixlQUFlLGNBQWMsVUFBVTtBQUN6RDtBQUNBLElBQUksaUJBQWlCLE1BQU07Q0FRekIsWUFBWTtDQUNaLGtCQUFrQjtDQUNsQixtQkFBbUIsVUFBVTtFQUV6QixJQUFJLEtBQUtDLG1CQUFtQixhQUFhLEtBQUtDLFdBQzVDLFFBQVEsTUFDTiw4R0FDQTtHQUFFLFVBQVUsS0FBS0E7R0FBVztFQUFTLENBQ3ZDO0VBR0osS0FBS0EsWUFBWTtFQUVmLEtBQUtELGtCQUFrQjtDQUUzQjtDQUNBLFdBQVcsVUFBVSxPQUFPO0VBRXhCLEtBQUtBLGtCQUFrQjtFQUV6QixPQUFPLEtBQUtDLFVBQVUsV0FBVyxVQUFVLEtBQUs7Q0FDbEQ7Q0FDQSxhQUFhLFdBQVc7RUFDdEIsS0FBS0EsVUFBVSxhQUFhLFNBQVM7Q0FDdkM7Q0FDQSxZQUFZLFVBQVUsT0FBTztFQUV6QixLQUFLRCxrQkFBa0I7RUFFekIsT0FBTyxLQUFLQyxVQUFVLFlBQVksVUFBVSxLQUFLO0NBQ25EO0NBQ0EsY0FBYyxZQUFZO0VBQ3hCLEtBQUtBLFVBQVUsY0FBYyxVQUFVO0NBQ3pDO0FBQ0Y7QUFDQSxJQUFJLGlCQUFpQixJQUFJLGVBQWU7QUFDeEMsU0FBUyxxQkFBcUIsVUFBVTtDQUN0QyxXQUFXLFVBQVUsQ0FBQztBQUN4Qjs7O0FDN0RBLElBQUksV0FBVyxPQUFPLFdBQVcsZUFBZSxVQUFVO0FBQzFELFNBQVMsT0FBTyxDQUNoQjtBQUNBLFNBQVMsaUJBQWlCLFNBQVMsT0FBTztDQUN4QyxPQUFPLE9BQU8sWUFBWSxhQUFhLFFBQVEsS0FBSyxJQUFJO0FBQzFEO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDN0IsT0FBTyxPQUFPLFVBQVUsWUFBWSxTQUFTLEtBQUssVUFBVTtBQUM5RDtBQUNBLFNBQVMsZUFBZSxXQUFXLFdBQVc7Q0FDNUMsT0FBTyxLQUFLLElBQUksYUFBYSxhQUFhLEtBQUssS0FBSyxJQUFJLEdBQUcsQ0FBQztBQUM5RDtBQUNBLFNBQVMsaUJBQWlCLFdBQVcsT0FBTztDQUMxQyxPQUFPLE9BQU8sY0FBYyxhQUFhLFVBQVUsS0FBSyxJQUFJO0FBQzlEO0FBQ0EsU0FBUyxvQkFBb0IsUUFBUSxPQUFPO0NBQzFDLE9BQU8sT0FBTyxXQUFXLGFBQWEsT0FBTyxLQUFLLElBQUk7QUFDeEQ7QUFDQSxTQUFTLFdBQVcsU0FBUyxPQUFPO0NBQ2xDLE1BQU0sRUFDSixPQUFPLE9BQ1AsT0FDQSxhQUNBLFdBQ0EsVUFDQSxVQUNFO0NBQ0osSUFBSSxVQUNFO01BQUEsT0FDRTtPQUFBLE1BQU0sY0FBYyxzQkFBc0IsVUFBVSxNQUFNLE9BQU8sR0FDbkUsT0FBTztFQUFBLE9BRUosSUFBSSxDQUFDLGdCQUFnQixNQUFNLFVBQVUsUUFBUSxHQUNsRCxPQUFPO0NBQUE7Q0FHWCxJQUFJLFNBQVMsT0FBTztFQUNsQixNQUFNLFdBQVcsTUFBTSxTQUFTO0VBQ2hDLElBQUksU0FBUyxZQUFZLENBQUMsVUFDeEIsT0FBTztFQUVULElBQUksU0FBUyxjQUFjLFVBQ3pCLE9BQU87Q0FFWDtDQUNBLElBQUksT0FBTyxVQUFVLGFBQWEsTUFBTSxRQUFRLE1BQU0sT0FDcEQsT0FBTztDQUVULElBQUksZUFBZSxnQkFBZ0IsTUFBTSxNQUFNLGFBQzdDLE9BQU87Q0FFVCxJQUFJLGFBQWEsQ0FBQyxVQUFVLEtBQUssR0FDL0IsT0FBTztDQUVULE9BQU87QUFDVDtBQUNBLFNBQVMsY0FBYyxTQUFTLFVBQVU7Q0FDeEMsTUFBTSxFQUFFLE9BQU8sUUFBUSxXQUFXLGdCQUFnQjtDQUNsRCxJQUFJLGFBQWE7RUFDZixJQUFJLENBQUMsU0FBUyxRQUFRLGFBQ3BCLE9BQU87RUFFVCxJQUFJLE9BQ0U7T0FBQSxRQUFRLFNBQVMsUUFBUSxXQUFXLE1BQU0sUUFBUSxXQUFXLEdBQy9ELE9BQU87RUFBQSxPQUVKLElBQUksQ0FBQyxnQkFBZ0IsU0FBUyxRQUFRLGFBQWEsV0FBVyxHQUNuRSxPQUFPO0NBRVg7Q0FDQSxJQUFJLFVBQVUsU0FBUyxNQUFNLFdBQVcsUUFDdEMsT0FBTztDQUVULElBQUksYUFBYSxDQUFDLFVBQVUsUUFBUSxHQUNsQyxPQUFPO0NBRVQsT0FBTztBQUNUO0FBQ0EsU0FBUyxzQkFBc0IsVUFBVSxTQUFTO0NBRWhELFFBRGUsU0FBUyxrQkFBa0IsUUFBQSxDQUM1QixRQUFRO0FBQ3hCO0FBQ0EsU0FBUyxRQUFRLFVBQVU7Q0FDekIsT0FBTyxLQUFLLFVBQ1YsV0FDQyxHQUFHLFFBQVEsY0FBYyxHQUFHLElBQUksT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsUUFBUSxRQUFRO0VBQy9FLE9BQU8sT0FBTyxJQUFJO0VBQ2xCLE9BQU87Q0FDVCxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQ1g7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRztDQUM3QixJQUFJLE1BQU0sR0FDUixPQUFPO0NBRVQsSUFBSSxPQUFPLE1BQU0sT0FBTyxHQUN0QixPQUFPO0NBRVQsSUFBSSxLQUFLLEtBQUssT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFVBQVU7RUFDNUQsSUFBSSxNQUFNLFFBQVEsQ0FBQyxLQUFLLE1BQU0sUUFBUSxDQUFDLEdBQUc7R0FDeEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUM1QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLEVBQUUsR0FDN0IsT0FBTztHQUdYLE9BQU87RUFDVDtFQUNBLE1BQU0sUUFBUSxPQUFPLEtBQUssQ0FBQztFQUMzQixLQUFLLE1BQU0sT0FBTyxPQUNoQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLElBQUksR0FDakMsT0FBTztFQUdYLE9BQU87Q0FDVDtDQUNBLE9BQU87QUFDVDtBQUNBLElBQUksU0FBUyxPQUFPLFVBQVU7QUFDOUIsU0FBUyxpQkFBaUIsR0FBRyxHQUFHLFFBQVEsR0FBRztDQUN6QyxJQUFJLE1BQU0sR0FDUixPQUFPO0NBRVQsSUFBSSxRQUFRLEtBQUssT0FBTztDQUN4QixNQUFNLFFBQVEsYUFBYSxDQUFDLEtBQUssYUFBYSxDQUFDO0NBQy9DLElBQUksQ0FBQyxTQUFTLEVBQUUsY0FBYyxDQUFDLEtBQUssY0FBYyxDQUFDLElBQUksT0FBTztDQUU5RCxNQUFNLFNBRFMsUUFBUSxJQUFJLE9BQU8sS0FBSyxDQUFDLEVBQUEsQ0FDbkI7Q0FDckIsTUFBTSxTQUFTLFFBQVEsSUFBSSxPQUFPLEtBQUssQ0FBQztDQUN4QyxNQUFNLFFBQVEsT0FBTztDQUNyQixNQUFNLE9BQU8sUUFBUSxJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUM7Q0FDekMsSUFBSSxhQUFhO0NBQ2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLEtBQUs7RUFDOUIsTUFBTSxNQUFNLFFBQVEsSUFBSSxPQUFPO0VBQy9CLE1BQU0sUUFBUSxFQUFFO0VBQ2hCLE1BQU0sUUFBUSxFQUFFO0VBQ2hCLElBQUksVUFBVSxPQUFPO0dBQ25CLEtBQUssT0FBTztHQUNaLElBQUksUUFBUSxJQUFJLFFBQVEsT0FBTyxLQUFLLEdBQUcsR0FBRyxHQUFHO0dBQzdDO0VBQ0Y7RUFDQSxJQUFJLFVBQVUsUUFBUSxVQUFVLFFBQVEsT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFVBQVU7R0FDOUYsS0FBSyxPQUFPO0dBQ1o7RUFDRjtFQUNBLE1BQU0sSUFBSSxpQkFBaUIsT0FBTyxPQUFPLFFBQVEsQ0FBQztFQUNsRCxLQUFLLE9BQU87RUFDWixJQUFJLE1BQU0sT0FBTztDQUNuQjtDQUNBLE9BQU8sVUFBVSxTQUFTLGVBQWUsUUFBUSxJQUFJO0FBQ3ZEO0FBQ0EsU0FBUyxvQkFBb0IsR0FBRyxHQUFHO0NBQ2pDLElBQUksQ0FBQyxLQUFLLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUNqRCxPQUFPO0NBRVQsS0FBSyxNQUFNLE9BQU8sR0FDaEIsSUFBSSxFQUFFLFNBQVMsRUFBRSxNQUNmLE9BQU87Q0FHWCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGFBQWEsT0FBTztDQUMzQixPQUFPLE1BQU0sUUFBUSxLQUFLLEtBQUssTUFBTSxXQUFXLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQztBQUNyRTtBQUNBLFNBQVMsY0FBYyxHQUFHO0NBQ3hCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUN2QixPQUFPO0NBRVQsTUFBTSxPQUFPLEVBQUU7Q0FDZixJQUFJLFNBQVMsS0FBSyxHQUNoQixPQUFPO0NBRVQsTUFBTSxPQUFPLEtBQUs7Q0FDbEIsSUFBSSxDQUFDLG1CQUFtQixJQUFJLEdBQzFCLE9BQU87Q0FFVCxJQUFJLENBQUMsS0FBSyxlQUFlLGVBQWUsR0FDdEMsT0FBTztDQUVULElBQUksT0FBTyxlQUFlLENBQUMsTUFBTSxPQUFPLFdBQ3RDLE9BQU87Q0FFVCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLG1CQUFtQixHQUFHO0NBQzdCLE9BQU8sT0FBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU07QUFDL0M7QUFDQSxTQUFTLE1BQU0sU0FBUztDQUN0QixPQUFPLElBQUksU0FBUyxZQUFZO0VBQzlCLGVBQWUsV0FBVyxTQUFTLE9BQU87Q0FDNUMsQ0FBQztBQUNIO0FBQ0EsU0FBUyxZQUFZLFVBQVUsTUFBTSxTQUFTO0NBQzVDLElBQUksT0FBTyxRQUFRLHNCQUFzQixZQUN2QyxPQUFPLFFBQVEsa0JBQWtCLFVBQVUsSUFBSTtNQUMxQyxJQUFJLFFBQVEsc0JBQXNCLE9BRXJDLElBQUk7RUFDRixPQUFPLGlCQUFpQixVQUFVLElBQUk7Q0FDeEMsU0FBUyxPQUFPO0VBQ2QsUUFBUSxNQUNOLDBKQUEwSixRQUFRLFVBQVUsS0FBSyxPQUNuTDtFQUNBLE1BQU07Q0FDUjtDQUlKLE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLGNBQWM7Q0FDdEMsT0FBTztBQUNUO0FBQ0EsU0FBUyxTQUFTLE9BQU8sTUFBTSxNQUFNLEdBQUc7Q0FDdEMsTUFBTSxXQUFXLENBQUMsR0FBRyxPQUFPLElBQUk7Q0FDaEMsT0FBTyxPQUFPLFNBQVMsU0FBUyxNQUFNLFNBQVMsTUFBTSxDQUFDLElBQUk7QUFDNUQ7QUFDQSxTQUFTLFdBQVcsT0FBTyxNQUFNLE1BQU0sR0FBRztDQUN4QyxNQUFNLFdBQVcsQ0FBQyxNQUFNLEdBQUcsS0FBSztDQUNoQyxPQUFPLE9BQU8sU0FBUyxTQUFTLE1BQU0sU0FBUyxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQ2hFO0FBQ0EsSUFBSSxZQUE0Qix1QkFBTztBQUN2QyxTQUFTLGNBQWMsU0FBUyxjQUFjO0NBRTFDLElBQUksUUFBUSxZQUFZLFdBQ3RCLFFBQVEsTUFDTix5R0FBeUcsUUFBUSxVQUFVLEVBQzdIO0NBR0osSUFBSSxDQUFDLFFBQVEsV0FBVyxjQUFjLGdCQUNwQyxhQUFhLGFBQWE7Q0FFNUIsSUFBSSxDQUFDLFFBQVEsV0FBVyxRQUFRLFlBQVksV0FDMUMsYUFBYSxRQUFRLHVCQUFPLElBQUksTUFBTSxxQkFBcUIsUUFBUSxVQUFVLEVBQUUsQ0FBQztDQUVsRixPQUFPLFFBQVE7QUFDakI7QUFDQSxTQUFTLGlCQUFpQixjQUFjLFFBQVE7Q0FDOUMsSUFBSSxPQUFPLGlCQUFpQixZQUMxQixPQUFPLGFBQWEsR0FBRyxNQUFNO0NBRS9CLE9BQU8sQ0FBQyxDQUFDO0FBQ1g7QUFDQSxTQUFTLHNCQUFzQixRQUFRLFdBQVcsYUFBYTtDQUM3RCxJQUFJLFdBQVc7Q0FDZixJQUFJO0NBQ0osT0FBTyxlQUFlLFFBQVEsVUFBVTtFQUN0QyxZQUFZO0VBQ1osV0FBVztHQUNULFdBQVcsVUFBVTtHQUNyQixJQUFJLFVBQ0YsT0FBTztHQUVULFdBQVc7R0FDWCxJQUFJLE9BQU8sU0FDVCxZQUFZO1FBRVosT0FBTyxpQkFBaUIsU0FBUyxhQUFhLEVBQUUsTUFBTSxLQUFLLENBQUM7R0FFOUQsT0FBTztFQUNUO0NBQ0YsQ0FBQztDQUNELE9BQU87QUFDVDs7O0FDeFFBLElBQUkscUJBQXFDLHVCQUFPO0NBQzlDLElBQUksbUJBQW1CO0NBQ3ZCLE9BQU87Ozs7RUFJTCxXQUFXO0dBQ1QsT0FBTyxXQUFXO0VBQ3BCOzs7O0VBSUEsWUFBWSxlQUFlO0dBQ3pCLGFBQWE7RUFDZjtDQUNGO0FBQ0YsRUFBQSxDQUFHOzs7QUNoQkgsU0FBUyxrQkFBa0I7Q0FDekIsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLFdBQVcsSUFBSSxTQUFTLFVBQVUsWUFBWTtFQUNsRCxVQUFVO0VBQ1YsU0FBUztDQUNYLENBQUM7Q0FDRCxTQUFTLFNBQVM7Q0FDbEIsU0FBUyxZQUFZLENBQ3JCLENBQUM7Q0FDRCxTQUFTLFNBQVMsTUFBTTtFQUN0QixPQUFPLE9BQU8sVUFBVSxJQUFJO0VBQzVCLE9BQU8sU0FBUztFQUNoQixPQUFPLFNBQVM7Q0FDbEI7Q0FDQSxTQUFTLFdBQVcsVUFBVTtFQUM1QixTQUFTO0dBQ1AsUUFBUTtHQUNSO0VBQ0YsQ0FBQztFQUNELFFBQVEsS0FBSztDQUNmO0NBQ0EsU0FBUyxVQUFVLFdBQVc7RUFDNUIsU0FBUztHQUNQLFFBQVE7R0FDUjtFQUNGLENBQUM7RUFDRCxPQUFPLE1BQU07Q0FDZjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxTQUFTO0NBQy9CLElBQUk7Q0FDSixRQUFRLE1BQU0sV0FBVztFQUN2QixPQUFPO0VBQ1AsT0FBTztDQUNULEdBQUcsSUFBSSxDQUFDLEVBQUUsTUFBTSxJQUFJO0NBQ3BCLElBQUksU0FBUyxLQUFLLEdBQ2hCLE9BQU8sRUFBRSxLQUFLO0FBR2xCOzs7QUN4Q0EsU0FBUyxxQkFBcUIsTUFBTTtDQUNsQyxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixVQUFVO0NBQ25DLE9BQU87RUFDTCxhQUFhLFNBQVMsUUFBUTtFQUM5QixPQUFPLFNBQVM7RUFDaEIsR0FBRyxTQUFTLFFBQVEsU0FBUyxFQUFFLE9BQU8sU0FBUyxRQUFRLE1BQU07RUFDN0QsR0FBRyxTQUFTLFFBQVEsRUFBRSxNQUFNLFNBQVMsS0FBSztDQUM1QztBQUNGO0FBQ0EsU0FBUyxlQUFlLE9BQU8sZUFBZSxvQkFBb0I7Q0FDaEUsTUFBTSx5QkFBeUI7RUFDN0IsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLGFBQWEsQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUNsRSxJQUFJLENBQUMsbUJBQW1CLEtBQUssR0FDM0IsT0FBTyxRQUFRLE9BQU8sS0FBSztHQUczQixRQUFRLE1BQ04sK0RBQStELE1BQU0sVUFBVSxLQUFLLE1BQU0sa0RBQzVGO0dBRUYsT0FBTyxRQUFRLHVCQUFPLElBQUksTUFBTSxVQUFVLENBQUM7RUFDN0MsQ0FBQztFQUNELFNBQVMsTUFBTSxJQUFJO0VBQ25CLE9BQU87Q0FDVDtDQUNBLE9BQU87RUFDTCxjQUFjLEtBQUssSUFBSTtFQUN2QixPQUFPO0dBQ0wsR0FBRyxNQUFNO0dBQ1QsR0FBRyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFDaEMsTUFBTSxjQUFjLE1BQU0sTUFBTSxJQUFJLEVBQ3RDO0VBQ0Y7RUFDQSxVQUFVLE1BQU07RUFDaEIsV0FBVyxNQUFNO0VBQ2pCLEdBQUcsTUFBTSxNQUFNLFdBQVcsYUFBYSxFQUNyQyxTQUFTLGlCQUFpQixFQUM1QjtFQUNBLEdBQUcsTUFBTSxRQUFRLEVBQUUsTUFBTSxNQUFNLEtBQUs7RUFDcEMsR0FBRyxNQUFNLGFBQWEsRUFBRSxXQUFXLE1BQU0sVUFBVTtDQUNyRDtBQUNGO0FBQ0EsU0FBUywrQkFBK0IsVUFBVTtDQUNoRCxPQUFPLFNBQVMsTUFBTTtBQUN4QjtBQUNBLFNBQVMsNEJBQTRCLE9BQU87Q0FDMUMsT0FBTyxNQUFNLE1BQU0sV0FBVztBQUNoQztBQUNBLFNBQVMsMEJBQTBCLEdBQUc7Q0FDcEMsT0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDdkMsTUFBTSxpQkFBaUIsUUFBUSwyQkFBMkIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFdBQVcsMkJBQTJCO0NBQzNILE1BQU0sWUFBWSxPQUFPLGlCQUFpQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FDbEQsYUFBYSxlQUFlLFFBQVEsSUFBSSxDQUFDLGtCQUFrQixRQUFRLENBQUMsSUFBSSxDQUFDLENBQzVFO0NBQ0EsTUFBTSxjQUFjLFFBQVEsd0JBQXdCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXLHdCQUF3QjtDQUNsSCxNQUFNLHFCQUFxQixRQUFRLHNCQUFzQixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVyxzQkFBc0I7Q0FDckgsTUFBTSxnQkFBZ0IsUUFBUSxpQkFBaUIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFdBQVcsaUJBQWlCO0NBSXRHLE9BQU87RUFBRTtFQUFXLFNBSEosT0FBTyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUM3QyxVQUFVLFlBQVksS0FBSyxJQUFJLENBQUMsZUFBZSxPQUFPLGVBQWUsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBRXRFO0NBQUU7QUFDOUI7QUFDQSxTQUFTLFFBQVEsUUFBUSxpQkFBaUIsU0FBUztDQUNqRCxJQUFJLE9BQU8sb0JBQW9CLFlBQVksb0JBQW9CLE1BQzdEO0NBRUYsTUFBTSxnQkFBZ0IsT0FBTyxpQkFBaUI7Q0FDOUMsTUFBTSxhQUFhLE9BQU8sY0FBYztDQUN4QyxNQUFNLGtCQUFrQixTQUFTLGdCQUFnQixtQkFBbUIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVMsbUJBQW1CO0NBQzNILE1BQU0sWUFBWSxnQkFBZ0IsYUFBYSxDQUFDO0NBQ2hELE1BQU0sVUFBVSxnQkFBZ0IsV0FBVyxDQUFDO0NBQzVDLFVBQVUsU0FBUyxFQUFFLE9BQU8sR0FBRyxzQkFBc0I7RUFDbkQsY0FBYyxNQUNaLFFBQ0E7R0FDRSxHQUFHLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxTQUFTO0dBQ3ZDLEdBQUcsU0FBUyxnQkFBZ0I7R0FDNUIsR0FBRztFQUNMLEdBQ0EsS0FDRjtDQUNGLENBQUM7Q0FDRCxRQUFRLFNBQ0wsRUFDQyxVQUNBLE9BQ0EsV0FDQSxNQUNBLFNBQ0EsY0FDQSxnQkFDSTtFQUNKLE1BQU0sV0FBVyxVQUFVLGVBQWUsT0FBTyxJQUFJLEtBQUs7RUFDMUQsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLElBQUksVUFBVSxPQUFPLE1BQU07RUFDL0QsTUFBTSxPQUFPLFlBQVksS0FBSyxJQUFJLFVBQVUsZ0JBQWdCLE9BQU87RUFDbkUsSUFBSSxRQUFRLFdBQVcsSUFBSSxTQUFTO0VBQ3BDLE1BQU0seUJBQXlCLE9BQU8sTUFBTSxXQUFXO0VBQ3ZELE1BQU0sMEJBQTBCLE9BQU8sTUFBTSxnQkFBZ0I7RUFDN0QsSUFBSSxPQUFPO0dBQ1QsTUFBTSxtQkFBbUIsWUFFekIsaUJBQWlCLEtBQUssS0FBSyxlQUFlLE1BQU0sTUFBTTtHQUN0RCxJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sTUFBTSxpQkFBaUIsa0JBQWtCO0lBQ3ZFLE1BQU0sRUFBRSxhQUFhLFVBQVUsR0FBRyxvQkFBb0I7SUFDdEQsTUFBTSxTQUFTO0tBQ2IsR0FBRztLQUNIO0tBTUEsR0FBRyxNQUFNLFdBQVcsYUFBYSxTQUFTLEtBQUssS0FBSztNQUNsRCxRQUFRO01BQ1IsZUFBZSxnQkFBZ0IsS0FBSyxJQUFJO01BRXhDLEdBQUcsQ0FBQywyQkFBMkIsRUFDN0IsYUFBYSxPQUNmO0tBQ0Y7SUFDRixDQUFDO0dBQ0g7RUFDRixPQUNFLFFBQVEsV0FBVyxNQUNqQixRQUNBO0dBQ0UsR0FBRyxPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUztHQUN2QyxHQUFHLFNBQVMsZ0JBQWdCO0dBQzVCO0dBQ0E7R0FDQTtHQUNBLE9BQU87RUFDVCxHQUdBO0dBQ0UsR0FBRztHQUNIO0dBQ0EsYUFBYTtHQUdiLFFBQVEsTUFBTSxXQUFXLGFBQWEsU0FBUyxLQUFLLElBQUksWUFBWSxNQUFNO0dBQzFFLEdBQUcsTUFBTSxXQUFXLGFBQWEsU0FBUyxLQUFLLEtBQUssRUFDbEQsZUFBZSxnQkFBZ0IsS0FBSyxJQUFJLEVBQzFDO0VBQ0YsQ0FDRjtFQUVGLElBQUksV0FFSixDQUFDLFlBQVksQ0FBQywwQkFBMEIsQ0FBQyw0QkFFeEMsaUJBQWlCLEtBQUssS0FBSyxlQUFlLE1BQU0sTUFBTSxnQkFDckQsTUFBTSxNQUFNLEtBQUssR0FBRyxFQUVsQixnQkFBZ0IsUUFBUSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssZUFBZSxFQUMvRCxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FFakIsQ0FDRjtBQUNGOzs7QUNyS0EsSUFBSSxtQkFBbUI7QUFDdkIsU0FBUyxzQkFBc0I7Q0FDN0IsSUFBSSxRQUFRLENBQUM7Q0FDYixJQUFJLGVBQWU7Q0FDbkIsSUFBSSxZQUFZLGFBQWE7RUFDM0IsU0FBUztDQUNYO0NBQ0EsSUFBSSxpQkFBaUIsYUFBYTtFQUNoQyxTQUFTO0NBQ1g7Q0FDQSxJQUFJLGFBQWE7Q0FDakIsTUFBTSxZQUFZLGFBQWE7RUFDN0IsSUFBSSxjQUNGLE1BQU0sS0FBSyxRQUFRO09BRW5CLGlCQUFpQjtHQUNmLFNBQVMsUUFBUTtFQUNuQixDQUFDO0NBRUw7Q0FDQSxNQUFNLGNBQWM7RUFDbEIsTUFBTSxnQkFBZ0I7RUFDdEIsUUFBUSxDQUFDO0VBQ1QsSUFBSSxjQUFjLFFBQ2hCLGlCQUFpQjtHQUNmLG9CQUFvQjtJQUNsQixjQUFjLFNBQVMsYUFBYTtLQUNsQyxTQUFTLFFBQVE7SUFDbkIsQ0FBQztHQUNILENBQUM7RUFDSCxDQUFDO0NBRUw7Q0FDQSxPQUFPO0VBQ0wsUUFBUSxhQUFhO0dBQ25CLElBQUk7R0FDSjtHQUNBLElBQUk7SUFDRixTQUFTLFNBQVM7R0FDcEIsVUFBVTtJQUNSO0lBQ0EsSUFBSSxDQUFDLGNBQ0gsTUFBTTtHQUVWO0dBQ0EsT0FBTztFQUNUOzs7O0VBSUEsYUFBYSxhQUFhO0dBQ3hCLFFBQVEsR0FBRyxTQUFTO0lBQ2xCLGVBQWU7S0FDYixTQUFTLEdBQUcsSUFBSTtJQUNsQixDQUFDO0dBQ0g7RUFDRjtFQUNBOzs7OztFQUtBLG9CQUFvQixPQUFPO0dBQ3pCLFdBQVc7RUFDYjs7Ozs7RUFLQSx5QkFBeUIsT0FBTztHQUM5QixnQkFBZ0I7RUFDbEI7RUFDQSxlQUFlLE9BQU87R0FDcEIsYUFBYTtFQUNmO0NBQ0Y7QUFDRjtBQUNBLElBQUksZ0JBQWdCLG9CQUFvQjs7O0FDN0V4QyxJQUFJLGdCQUFnQixjQUFjLGFBQWE7Q0FDN0MsVUFBVTtDQUNWO0NBQ0E7Q0FDQSxjQUFjO0VBQ1osTUFBTTtFQUNOLEtBQUtDLFVBQVUsYUFBYTtHQUMxQixJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sa0JBQWtCO0lBQzVELE1BQU0sdUJBQXVCLFNBQVMsSUFBSTtJQUMxQyxNQUFNLHdCQUF3QixTQUFTLEtBQUs7SUFDNUMsT0FBTyxpQkFBaUIsVUFBVSxnQkFBZ0IsS0FBSztJQUN2RCxPQUFPLGlCQUFpQixXQUFXLGlCQUFpQixLQUFLO0lBQ3pELGFBQWE7S0FDWCxPQUFPLG9CQUFvQixVQUFVLGNBQWM7S0FDbkQsT0FBTyxvQkFBb0IsV0FBVyxlQUFlO0lBQ3ZEO0dBQ0Y7RUFFRjtDQUNGO0NBQ0EsY0FBYztFQUNaLElBQUksQ0FBQyxLQUFLQyxVQUNSLEtBQUssaUJBQWlCLEtBQUtELE1BQU07Q0FFckM7Q0FDQSxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUc7R0FDeEIsS0FBS0MsV0FBVztHQUNoQixLQUFLQSxXQUFXLEtBQUs7RUFDdkI7Q0FDRjtDQUNBLGlCQUFpQixPQUFPO0VBQ3RCLEtBQUtELFNBQVM7RUFDZCxLQUFLQyxXQUFXO0VBQ2hCLEtBQUtBLFdBQVcsTUFBTSxLQUFLLFVBQVUsS0FBSyxJQUFJLENBQUM7Q0FDakQ7Q0FDQSxVQUFVLFFBQVE7RUFFaEIsSUFEZ0IsS0FBS0MsWUFBWSxRQUNwQjtHQUNYLEtBQUtBLFVBQVU7R0FDZixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ25DLFNBQVMsTUFBTTtHQUNqQixDQUFDO0VBQ0g7Q0FDRjtDQUNBLFdBQVc7RUFDVCxPQUFPLEtBQUtBO0NBQ2Q7QUFDRjtBQUNBLElBQUksZ0JBQWdCLElBQUksY0FBYzs7O0FDN0N0QyxTQUFTLGtCQUFrQixjQUFjO0NBQ3ZDLE9BQU8sS0FBSyxJQUFJLE1BQU0sS0FBSyxjQUFjLEdBQUc7QUFDOUM7QUFDQSxTQUFTLFNBQVMsYUFBYTtDQUM3QixRQUFRLGVBQWUsY0FBYyxXQUFXLGNBQWMsU0FBUyxJQUFJO0FBQzdFO0FBQ0EsSUFBSSxpQkFBaUIsY0FBYyxNQUFNO0NBQ3ZDLFlBQVksU0FBUztFQUNuQixNQUFNLGdCQUFnQjtFQUN0QixLQUFLLFNBQVMsU0FBUztFQUN2QixLQUFLLFNBQVMsU0FBUztDQUN6QjtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTztDQUMvQixPQUFPLGlCQUFpQjtBQUMxQjtBQUNBLFNBQVMsY0FBYyxRQUFRO0NBQzdCLElBQUksbUJBQW1CO0NBQ3ZCLElBQUksZUFBZTtDQUNuQixJQUFJO0NBQ0osTUFBTSxXQUFXLGdCQUFnQjtDQUNqQyxNQUFNLG1CQUFtQixTQUFTLFdBQVc7Q0FDN0MsTUFBTSxVQUFVLGtCQUFrQjtFQUNoQyxJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2pCLE1BQU0sUUFBUSxJQUFJLGVBQWUsYUFBYTtHQUM5QyxPQUFPLEtBQUs7R0FDWixPQUFPLFdBQVcsS0FBSztFQUN6QjtDQUNGO0NBQ0EsTUFBTSxvQkFBb0I7RUFDeEIsbUJBQW1CO0NBQ3JCO0NBQ0EsTUFBTSxzQkFBc0I7RUFDMUIsbUJBQW1CO0NBQ3JCO0NBQ0EsTUFBTSxvQkFBb0IsYUFBYSxVQUFVLE1BQU0sT0FBTyxnQkFBZ0IsWUFBWSxjQUFjLFNBQVMsTUFBTSxPQUFPLE9BQU87Q0FDckksTUFBTSxpQkFBaUIsU0FBUyxPQUFPLFdBQVcsS0FBSyxPQUFPLE9BQU87Q0FDckUsTUFBTSxXQUFXLFVBQVU7RUFDekIsSUFBSSxDQUFDLFdBQVcsR0FBRztHQUNqQixhQUFhO0dBQ2IsU0FBUyxRQUFRLEtBQUs7RUFDeEI7Q0FDRjtDQUNBLE1BQU0sVUFBVSxVQUFVO0VBQ3hCLElBQUksQ0FBQyxXQUFXLEdBQUc7R0FDakIsYUFBYTtHQUNiLFNBQVMsT0FBTyxLQUFLO0VBQ3ZCO0NBQ0Y7Q0FDQSxNQUFNLGNBQWM7RUFDbEIsT0FBTyxJQUFJLFNBQVMsb0JBQW9CO0dBQ3RDLGNBQWMsVUFBVTtJQUN0QixJQUFJLFdBQVcsS0FBSyxZQUFZLEdBQzlCLGdCQUFnQixLQUFLO0dBRXpCO0dBQ0EsT0FBTyxVQUFVO0VBQ25CLENBQUMsQ0FBQyxDQUFDLFdBQVc7R0FDWixhQUFhLEtBQUs7R0FDbEIsSUFBSSxDQUFDLFdBQVcsR0FDZCxPQUFPLGFBQWE7RUFFeEIsQ0FBQztDQUNIO0NBQ0EsTUFBTSxZQUFZO0VBQ2hCLElBQUksV0FBVyxHQUNiO0VBRUYsSUFBSTtFQUNKLE1BQU0saUJBQWlCLGlCQUFpQixJQUFJLE9BQU8saUJBQWlCLEtBQUs7RUFDekUsSUFBSTtHQUNGLGlCQUFpQixrQkFBa0IsT0FBTyxHQUFHO0VBQy9DLFNBQVMsT0FBTztHQUNkLGlCQUFpQixRQUFRLE9BQU8sS0FBSztFQUN2QztFQUNBLFFBQVEsUUFBUSxjQUFjLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUM3RCxJQUFJLFdBQVcsR0FDYjtHQUVGLE1BQU0sUUFBUSxPQUFPLFVBQVUsbUJBQW1CLFNBQVMsSUFBSSxJQUFJO0dBQ25FLE1BQU0sYUFBYSxPQUFPLGNBQWM7R0FDeEMsTUFBTSxRQUFRLE9BQU8sZUFBZSxhQUFhLFdBQVcsY0FBYyxLQUFLLElBQUk7R0FDbkYsTUFBTSxjQUFjLFVBQVUsUUFBUSxPQUFPLFVBQVUsWUFBWSxlQUFlLFNBQVMsT0FBTyxVQUFVLGNBQWMsTUFBTSxjQUFjLEtBQUs7R0FDbkosSUFBSSxvQkFBb0IsQ0FBQyxhQUFhO0lBQ3BDLE9BQU8sS0FBSztJQUNaO0dBQ0Y7R0FDQTtHQUNBLE9BQU8sU0FBUyxjQUFjLEtBQUs7R0FDbkMsTUFBTSxLQUFLLENBQUMsQ0FBQyxXQUFXO0lBQ3RCLE9BQU8sWUFBWSxJQUFJLEtBQUssSUFBSSxNQUFNO0dBQ3hDLENBQUMsQ0FBQyxDQUFDLFdBQVc7SUFDWixJQUFJLGtCQUNGLE9BQU8sS0FBSztTQUVaLElBQUk7R0FFUixDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsT0FBTztFQUNMLFNBQVM7RUFDVCxjQUFjLFNBQVM7RUFDdkI7RUFDQSxnQkFBZ0I7R0FDZCxhQUFhO0dBQ2IsT0FBTztFQUNUO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsYUFBYTtHQUNYLElBQUksU0FBUyxHQUNYLElBQUk7UUFFSixNQUFNLENBQUMsQ0FBQyxLQUFLLEdBQUc7R0FFbEIsT0FBTztFQUNUO0NBQ0Y7QUFDRjs7O0FDMUhBLElBQUksWUFBWSxNQUFNO0NBQ3BCO0NBQ0EsVUFBVTtFQUNSLEtBQUssZUFBZTtDQUN0QjtDQUNBLGFBQWE7RUFDWCxLQUFLLGVBQWU7RUFDcEIsSUFBSSxlQUFlLEtBQUssTUFBTSxHQUM1QixLQUFLQyxhQUFhLGVBQWUsaUJBQWlCO0dBQ2hELEtBQUssZUFBZTtFQUN0QixHQUFHLEtBQUssTUFBTTtDQUVsQjtDQUNBLGFBQWEsV0FBVztFQUN0QixLQUFLLFNBQVMsS0FBSyxJQUNqQixLQUFLLFVBQVUsR0FDZixjQUFjLG1CQUFtQixTQUFTLElBQUksV0FBVyxJQUMzRDtDQUNGO0NBQ0EsaUJBQWlCO0VBQ2YsSUFBSSxLQUFLQSxlQUFlLEtBQUssR0FBRztHQUM5QixlQUFlLGFBQWEsS0FBS0EsVUFBVTtHQUMzQyxLQUFLQSxhQUFhLEtBQUs7RUFDekI7Q0FDRjtBQUNGOzs7QUN0QkEsU0FBUyxzQkFBc0IsT0FBTztDQUNwQyxPQUFPLEVBQ0wsVUFBVSxTQUFTLFVBQVU7RUFDM0IsTUFBTSxVQUFVLFFBQVE7RUFDeEIsTUFBTSxZQUFZLFFBQVEsY0FBYyxNQUFNLFdBQVc7RUFDekQsTUFBTSxXQUFXLFFBQVEsTUFBTSxNQUFNLFNBQVMsQ0FBQztFQUMvQyxNQUFNLGdCQUFnQixRQUFRLE1BQU0sTUFBTSxjQUFjLENBQUM7RUFDekQsSUFBSSxTQUFTO0dBQUUsT0FBTyxDQUFDO0dBQUcsWUFBWSxDQUFDO0VBQUU7RUFDekMsSUFBSSxjQUFjO0VBQ2xCLE1BQU0sVUFBVSxZQUFZO0dBQzFCLElBQUksWUFBWTtHQUNoQixNQUFNLHFCQUFxQixXQUFXO0lBQ3BDLHNCQUNFLGNBQ00sUUFBUSxjQUNSLFlBQVksSUFDcEI7R0FDRjtHQUNBLE1BQU0sVUFBVSxjQUFjLFFBQVEsU0FBUyxRQUFRLFlBQVk7R0FDbkUsTUFBTSxZQUFZLE9BQU8sTUFBTSxPQUFPLGFBQWE7SUFDakQsSUFBSSxXQUNGLE9BQU8sUUFBUSxPQUFPLFFBQVEsT0FBTyxNQUFNO0lBRTdDLElBQUksU0FBUyxRQUFRLEtBQUssTUFBTSxRQUM5QixPQUFPLFFBQVEsUUFBUSxJQUFJO0lBRTdCLE1BQU0sNkJBQTZCO0tBQ2pDLE1BQU0sa0JBQWtCO01BQ3RCLFFBQVEsUUFBUTtNQUNoQixVQUFVLFFBQVE7TUFDbEIsV0FBVztNQUNYLFdBQVcsV0FBVyxhQUFhO01BQ25DLE1BQU0sUUFBUSxRQUFRO0tBQ3hCO0tBQ0Esa0JBQWtCLGVBQWU7S0FDakMsT0FBTztJQUNUO0lBQ0EsTUFBTSxpQkFBaUIscUJBQXFCO0lBQzVDLE1BQU0sT0FBTyxNQUFNLFFBQVEsY0FBYztJQUN6QyxNQUFNLEVBQUUsYUFBYSxRQUFRO0lBQzdCLE1BQU0sUUFBUSxXQUFXLGFBQWE7SUFDdEMsT0FBTztLQUNMLE9BQU8sTUFBTSxLQUFLLE9BQU8sTUFBTSxRQUFRO0tBQ3ZDLFlBQVksTUFBTSxLQUFLLFlBQVksT0FBTyxRQUFRO0lBQ3BEO0dBQ0Y7R0FDQSxJQUFJLGFBQWEsU0FBUyxRQUFRO0lBQ2hDLE1BQU0sV0FBVyxjQUFjO0lBQy9CLE1BQU0sY0FBYyxXQUFXLHVCQUF1QjtJQUN0RCxNQUFNLFVBQVU7S0FDZCxPQUFPO0tBQ1AsWUFBWTtJQUNkO0lBRUEsU0FBUyxNQUFNLFVBQVUsU0FEWCxZQUFZLFNBQVMsT0FDRyxHQUFHLFFBQVE7R0FDbkQsT0FBTztJQUNMLE1BQU0saUJBQWlCLFNBQVMsU0FBUztJQUN6QyxHQUFHO0tBQ0QsTUFBTSxRQUFRLGdCQUFnQixJQUFJLGNBQWMsTUFBTSxRQUFRLG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0tBQ2pILElBQUksY0FBYyxLQUFLLFNBQVMsTUFDOUI7S0FFRixTQUFTLE1BQU0sVUFBVSxRQUFRLEtBQUs7S0FDdEM7SUFDRixTQUFTLGNBQWM7R0FDekI7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxJQUFJLFFBQVEsUUFBUSxXQUNsQixRQUFRLGdCQUFnQjtHQUN0QixPQUFPLFFBQVEsUUFBUSxZQUNyQixTQUNBO0lBQ0UsUUFBUSxRQUFRO0lBQ2hCLFVBQVUsUUFBUTtJQUNsQixNQUFNLFFBQVEsUUFBUTtJQUN0QixRQUFRLFFBQVE7R0FDbEIsR0FDQSxLQUNGO0VBQ0Y7T0FFQSxRQUFRLFVBQVU7Q0FFdEIsRUFDRjtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUyxFQUFFLE9BQU8sY0FBYztDQUN4RCxNQUFNLFlBQVksTUFBTSxTQUFTO0NBQ2pDLE9BQU8sTUFBTSxTQUFTLElBQUksUUFBUSxpQkFDaEMsTUFBTSxZQUNOLE9BQ0EsV0FBVyxZQUNYLFVBQ0YsSUFBSSxLQUFLO0FBQ1g7QUFDQSxTQUFTLHFCQUFxQixTQUFTLEVBQUUsT0FBTyxjQUFjO0NBQzVELE9BQU8sTUFBTSxTQUFTLElBQUksUUFBUSx1QkFBdUIsTUFBTSxJQUFJLE9BQU8sV0FBVyxJQUFJLFVBQVUsSUFBSSxLQUFLO0FBQzlHO0FBQ0EsU0FBUyxZQUFZLFNBQVMsTUFBTTtDQUNsQyxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLE9BQU8saUJBQWlCLFNBQVMsSUFBSSxLQUFLO0FBQzVDO0FBQ0EsU0FBUyxnQkFBZ0IsU0FBUyxNQUFNO0NBQ3RDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxzQkFBc0IsT0FBTztDQUNuRCxPQUFPLHFCQUFxQixTQUFTLElBQUksS0FBSztBQUNoRDs7O0FDbkdBLElBQUksUUFBUSxjQUFjLFVBQVU7Q0FDbEM7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLFlBQVksUUFBUTtFQUNsQixNQUFNO0VBQ04sS0FBS0MsdUJBQXVCO0VBQzVCLEtBQUtDLGtCQUFrQixPQUFPO0VBQzlCLEtBQUssV0FBVyxPQUFPLE9BQU87RUFDOUIsS0FBSyxZQUFZLENBQUM7RUFDbEIsS0FBS0MsVUFBVSxPQUFPO0VBQ3RCLEtBQUtDLFNBQVMsS0FBS0QsUUFBUSxjQUFjO0VBQ3pDLEtBQUssV0FBVyxPQUFPO0VBQ3ZCLEtBQUssWUFBWSxPQUFPO0VBQ3hCLEtBQUtFLGdCQUFnQkMsa0JBQWdCLEtBQUssT0FBTztFQUNqRCxLQUFLLFFBQVEsT0FBTyxTQUFTLEtBQUtEO0VBQ2xDLEtBQUssV0FBVztDQUNsQjtDQUNBLElBQUksT0FBTztFQUNULE9BQU8sS0FBSyxRQUFRO0NBQ3RCO0NBQ0EsSUFBSSxZQUFZO0VBQ2QsT0FBTyxLQUFLRTtDQUNkO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLQyxVQUFVO0NBQ3hCO0NBQ0EsV0FBVyxTQUFTO0VBQ2xCLEtBQUssVUFBVTtHQUFFLEdBQUcsS0FBS047R0FBaUIsR0FBRztFQUFRO0VBQ3JELElBQUksU0FBUyxPQUNYLEtBQUtLLGFBQWEsUUFBUTtFQUU1QixLQUFLLGFBQWEsS0FBSyxRQUFRLE1BQU07RUFDckMsSUFBSSxLQUFLLFNBQVMsS0FBSyxNQUFNLFNBQVMsS0FBSyxHQUFHO0dBQzVDLE1BQU0sZUFBZUQsa0JBQWdCLEtBQUssT0FBTztHQUNqRCxJQUFJLGFBQWEsU0FBUyxLQUFLLEdBQUc7SUFDaEMsS0FBSyxTQUNILGFBQWEsYUFBYSxNQUFNLGFBQWEsYUFBYSxDQUM1RDtJQUNBLEtBQUtELGdCQUFnQjtHQUN2QjtFQUNGO0NBQ0Y7Q0FDQSxpQkFBaUI7RUFDZixJQUFJLENBQUMsS0FBSyxVQUFVLFVBQVUsS0FBSyxNQUFNLGdCQUFnQixRQUN2RCxLQUFLRCxPQUFPLE9BQU8sSUFBSTtDQUUzQjtDQUNBLFFBQVEsU0FBUyxTQUFTO0VBQ3hCLE1BQU0sT0FBTyxZQUFZLEtBQUssTUFBTSxNQUFNLFNBQVMsS0FBSyxPQUFPO0VBQy9ELEtBQUtLLFVBQVU7R0FDYjtHQUNBLE1BQU07R0FDTixlQUFlLFNBQVM7R0FDeEIsUUFBUSxTQUFTO0VBQ25CLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLE9BQU87RUFDZCxLQUFLQSxVQUFVO0dBQUUsTUFBTTtHQUFZO0VBQU0sQ0FBQztDQUM1QztDQUNBLE9BQU8sU0FBUztFQUNkLE1BQU0sVUFBVSxLQUFLRCxVQUFVO0VBQy9CLEtBQUtBLFVBQVUsT0FBTyxPQUFPO0VBQzdCLE9BQU8sVUFBVSxRQUFRLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJLElBQUksUUFBUSxRQUFRO0NBQ3BFO0NBQ0EsVUFBVTtFQUNSLE1BQU0sUUFBUTtFQUNkLEtBQUssT0FBTyxFQUFFLFFBQVEsS0FBSyxDQUFDO0NBQzlCO0NBQ0EsSUFBSSxhQUFhO0VBQ2YsT0FBTyxLQUFLSDtDQUNkO0NBQ0EsUUFBUTtFQUNOLEtBQUssUUFBUTtFQUNiLEtBQUssU0FBUyxLQUFLLFVBQVU7Q0FDL0I7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxLQUFLLFVBQVUsTUFDbkIsYUFBYSxvQkFBb0IsU0FBUyxRQUFRLFNBQVMsSUFBSSxNQUFNLEtBQ3hFO0NBQ0Y7Q0FDQSxhQUFhO0VBQ1gsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQzdCLE9BQU8sQ0FBQyxLQUFLLFNBQVM7RUFFeEIsT0FBTyxLQUFLLFFBQVEsWUFBWSxhQUFhLENBQUMsS0FBSyxVQUFVO0NBQy9EO0NBQ0EsWUFBWTtFQUNWLE9BQU8sS0FBSyxNQUFNLGtCQUFrQixLQUFLLE1BQU0sbUJBQW1CO0NBQ3BFO0NBQ0EsV0FBVztFQUNULElBQUksS0FBSyxrQkFBa0IsSUFBSSxHQUM3QixPQUFPLEtBQUssVUFBVSxNQUNuQixhQUFhLGlCQUFpQixTQUFTLFFBQVEsV0FBVyxJQUFJLE1BQU0sUUFDdkU7RUFFRixPQUFPO0NBQ1Q7Q0FDQSxVQUFVO0VBQ1IsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQzdCLE9BQU8sS0FBSyxVQUFVLE1BQ25CLGFBQWEsU0FBUyxpQkFBaUIsQ0FBQyxDQUFDLE9BQzVDO0VBRUYsT0FBTyxLQUFLLE1BQU0sU0FBUyxLQUFLLEtBQUssS0FBSyxNQUFNO0NBQ2xEO0NBQ0EsY0FBYyxZQUFZLEdBQUc7RUFDM0IsSUFBSSxLQUFLLE1BQU0sU0FBUyxLQUFLLEdBQzNCLE9BQU87RUFFVCxJQUFJLGNBQWMsVUFDaEIsT0FBTztFQUVULElBQUksS0FBSyxNQUFNLGVBQ2IsT0FBTztFQUVULE9BQU8sQ0FBQyxlQUFlLEtBQUssTUFBTSxlQUFlLFNBQVM7Q0FDNUQ7Q0FDQSxVQUFVO0VBRVIsS0FEc0IsVUFBVSxNQUFNLE1BQU0sRUFBRSx5QkFBeUIsQ0FDaEUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztFQUMxQyxLQUFLRyxVQUFVLFNBQVM7Q0FDMUI7Q0FDQSxXQUFXO0VBRVQsS0FEc0IsVUFBVSxNQUFNLE1BQU0sRUFBRSx1QkFBdUIsQ0FDOUQsQ0FBQyxFQUFFLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztFQUMxQyxLQUFLQSxVQUFVLFNBQVM7Q0FDMUI7Q0FDQSxZQUFZLFVBQVU7RUFDcEIsSUFBSSxDQUFDLEtBQUssVUFBVSxTQUFTLFFBQVEsR0FBRztHQUN0QyxLQUFLLFVBQVUsS0FBSyxRQUFRO0dBQzVCLEtBQUssZUFBZTtHQUNwQixLQUFLSixPQUFPLE9BQU87SUFBRSxNQUFNO0lBQWlCLE9BQU87SUFBTTtHQUFTLENBQUM7RUFDckU7Q0FDRjtDQUNBLGVBQWUsVUFBVTtFQUN2QixJQUFJLEtBQUssVUFBVSxTQUFTLFFBQVEsR0FBRztHQUNyQyxLQUFLLFlBQVksS0FBSyxVQUFVLFFBQVEsTUFBTSxNQUFNLFFBQVE7R0FDNUQsSUFBSSxDQUFDLEtBQUssVUFBVSxRQUFRO0lBQzFCLElBQUksS0FBS0ksVUFDUCxJQUFJLEtBQUtQLHdCQUF3QixLQUFLUyxzQkFBc0IsR0FDMUQsS0FBS0YsU0FBUyxPQUFPLEVBQUUsUUFBUSxLQUFLLENBQUM7U0FFckMsS0FBS0EsU0FBUyxZQUFZO0lBRzlCLEtBQUssV0FBVztHQUNsQjtHQUNBLEtBQUtKLE9BQU8sT0FBTztJQUFFLE1BQU07SUFBbUIsT0FBTztJQUFNO0dBQVMsQ0FBQztFQUN2RTtDQUNGO0NBQ0Esb0JBQW9CO0VBQ2xCLE9BQU8sS0FBSyxVQUFVO0NBQ3hCO0NBQ0Esd0JBQXdCO0VBQ3RCLE9BQU8sS0FBSyxNQUFNLGdCQUFnQixZQUFZLEtBQUssTUFBTSxXQUFXO0NBQ3RFO0NBQ0EsYUFBYTtFQUNYLElBQUksQ0FBQyxLQUFLLE1BQU0sZUFDZCxLQUFLSyxVQUFVLEVBQUUsTUFBTSxhQUFhLENBQUM7Q0FFekM7Q0FDQSxNQUFNLE1BQU0sU0FBUyxjQUFjO0VBQ2pDLElBQUksS0FBSyxNQUFNLGdCQUFnQixVQUcvQixLQUFLRCxVQUFVLE9BQU8sTUFBTSxZQUN0QjtPQUFBLEtBQUssTUFBTSxTQUFTLEtBQUssS0FBSyxjQUFjLGVBQzlDLEtBQUssT0FBTyxFQUFFLFFBQVEsS0FBSyxDQUFDO1FBQ3ZCLElBQUksS0FBS0EsVUFBVTtJQUN4QixLQUFLQSxTQUFTLGNBQWM7SUFDNUIsT0FBTyxLQUFLQSxTQUFTO0dBQ3ZCOztFQUVGLElBQUksU0FDRixLQUFLLFdBQVcsT0FBTztFQUV6QixJQUFJLENBQUMsS0FBSyxRQUFRLFNBQVM7R0FDekIsTUFBTSxXQUFXLEtBQUssVUFBVSxNQUFNLE1BQU0sRUFBRSxRQUFRLE9BQU87R0FDN0QsSUFBSSxVQUNGLEtBQUssV0FBVyxTQUFTLE9BQU87RUFFcEM7RUFFRSxJQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssUUFBUSxRQUFRLEdBQ3RDLFFBQVEsTUFDTixxSUFDRjtFQUdKLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0VBQzVDLE1BQU0scUJBQXFCLFdBQVc7R0FDcEMsT0FBTyxlQUFlLFFBQVEsVUFBVTtJQUN0QyxZQUFZO0lBQ1osV0FBVztLQUNULEtBQUtQLHVCQUF1QjtLQUM1QixPQUFPLGdCQUFnQjtJQUN6QjtHQUNGLENBQUM7RUFDSDtFQUNBLE1BQU0sZ0JBQWdCO0dBQ3BCLE1BQU0sVUFBVSxjQUFjLEtBQUssU0FBUyxZQUFZO0dBQ3hELE1BQU0sNkJBQTZCO0lBQ2pDLE1BQU0sa0JBQWtCO0tBQ3RCLFFBQVEsS0FBS0U7S0FDYixVQUFVLEtBQUs7S0FDZixNQUFNLEtBQUs7SUFDYjtJQUNBLGtCQUFrQixlQUFlO0lBQ2pDLE9BQU87R0FDVDtHQUNBLE1BQU0saUJBQWlCLHFCQUFxQjtHQUM1QyxLQUFLRix1QkFBdUI7R0FDNUIsSUFBSSxLQUFLLFFBQVEsV0FDZixPQUFPLEtBQUssUUFBUSxVQUNsQixTQUNBLGdCQUNBLElBQ0Y7R0FFRixPQUFPLFFBQVEsY0FBYztFQUMvQjtFQUNBLE1BQU0sMkJBQTJCO0dBQy9CLE1BQU0sV0FBVztJQUNmO0lBQ0EsU0FBUyxLQUFLO0lBQ2QsVUFBVSxLQUFLO0lBQ2YsUUFBUSxLQUFLRTtJQUNiLE9BQU8sS0FBSztJQUNaO0dBQ0Y7R0FDQSxrQkFBa0IsUUFBUTtHQUMxQixPQUFPO0VBQ1Q7RUFDQSxNQUFNLFVBQVUsbUJBQW1CO0VBSW5DLENBSGlCLEtBQUtJLGVBQWUsYUFBYSxzQkFDaEQsS0FBSyxRQUFRLEtBQ2YsSUFBSSxLQUFLLFFBQVEsU0FBQSxFQUNQLFFBQVEsU0FBUyxJQUFJO0VBQy9CLEtBQUtJLGVBQWUsS0FBSztFQUN6QixJQUFJLEtBQUssTUFBTSxnQkFBZ0IsVUFBVSxLQUFLLE1BQU0sY0FBYyxRQUFRLGNBQWMsTUFDdEYsS0FBS0YsVUFBVTtHQUFFLE1BQU07R0FBUyxNQUFNLFFBQVEsY0FBYztFQUFLLENBQUM7RUFFcEUsS0FBS0QsV0FBVyxjQUFjO0dBQzVCLGdCQUFnQixjQUFjO0dBQzlCLElBQUksUUFBUTtHQUNaLFdBQVcsVUFBVTtJQUNuQixJQUFJLGlCQUFpQixrQkFBa0IsTUFBTSxRQUMzQyxLQUFLLFNBQVM7S0FDWixHQUFHLEtBQUtHO0tBQ1IsYUFBYTtJQUNmLENBQUM7SUFFSCxnQkFBZ0IsTUFBTTtHQUN4QjtHQUNBLFNBQVMsY0FBYyxVQUFVO0lBQy9CLEtBQUtGLFVBQVU7S0FBRSxNQUFNO0tBQVU7S0FBYztJQUFNLENBQUM7R0FDeEQ7R0FDQSxlQUFlO0lBQ2IsS0FBS0EsVUFBVSxFQUFFLE1BQU0sUUFBUSxDQUFDO0dBQ2xDO0dBQ0Esa0JBQWtCO0lBQ2hCLEtBQUtBLFVBQVUsRUFBRSxNQUFNLFdBQVcsQ0FBQztHQUNyQztHQUNBLE9BQU8sUUFBUSxRQUFRO0dBQ3ZCLFlBQVksUUFBUSxRQUFRO0dBQzVCLGFBQWEsUUFBUSxRQUFRO0dBQzdCLGNBQWM7RUFDaEIsQ0FBQztFQUNELElBQUk7R0FDRixNQUFNLE9BQU8sTUFBTSxLQUFLRCxTQUFTLE1BQU07R0FDdkMsSUFBSSxTQUFTLEtBQUssR0FBRztJQUVqQixRQUFRLE1BQ04seUlBQXlJLEtBQUssV0FDaEo7SUFFRixNQUFNLElBQUksTUFBTSxHQUFHLEtBQUssVUFBVSxtQkFBbUI7R0FDdkQ7R0FDQSxLQUFLLFFBQVEsSUFBSTtHQUNqQixLQUFLSixPQUFPLE9BQU8sWUFBWSxNQUFNLElBQUk7R0FDekMsS0FBS0EsT0FBTyxPQUFPLFlBQ2pCLE1BQ0EsS0FBSyxNQUFNLE9BQ1gsSUFDRjtHQUNBLE9BQU87RUFDVCxTQUFTLE9BQU87R0FDZCxJQUFJLGlCQUFpQixnQkFDZjtRQUFBLE1BQU0sUUFDUixPQUFPLEtBQUtJLFNBQVM7U0FDaEIsSUFBSSxNQUFNLFFBQVE7S0FDdkIsSUFBSSxLQUFLLE1BQU0sU0FBUyxLQUFLLEdBQzNCLE1BQU07S0FFUixPQUFPLEtBQUssTUFBTTtJQUNwQjs7R0FFRixLQUFLQyxVQUFVO0lBQ2IsTUFBTTtJQUNOO0dBQ0YsQ0FBQztHQUNELEtBQUtMLE9BQU8sT0FBTyxVQUNqQixPQUNBLElBQ0Y7R0FDQSxLQUFLQSxPQUFPLE9BQU8sWUFDakIsS0FBSyxNQUFNLE1BQ1gsT0FDQSxJQUNGO0dBQ0EsTUFBTTtFQUNSLFVBQVU7R0FDUixLQUFLLFdBQVc7RUFDbEI7Q0FDRjtDQUNBLFVBQVUsUUFBUTtFQUNoQixNQUFNLFdBQVcsVUFBVTtHQUN6QixRQUFRLE9BQU8sTUFBZjtJQUNFLEtBQUssVUFDSCxPQUFPO0tBQ0wsR0FBRztLQUNILG1CQUFtQixPQUFPO0tBQzFCLG9CQUFvQixPQUFPO0lBQzdCO0lBQ0YsS0FBSyxTQUNILE9BQU87S0FDTCxHQUFHO0tBQ0gsYUFBYTtJQUNmO0lBQ0YsS0FBSyxZQUNILE9BQU87S0FDTCxHQUFHO0tBQ0gsYUFBYTtJQUNmO0lBQ0YsS0FBSyxTQUNILE9BQU87S0FDTCxHQUFHO0tBQ0gsR0FBRyxXQUFXLE1BQU0sTUFBTSxLQUFLLE9BQU87S0FDdEMsV0FBVyxPQUFPLFFBQVE7SUFDNUI7SUFDRixLQUFLO0tBQ0gsTUFBTSxXQUFXO01BQ2YsR0FBRztNQUNILEdBQUcsYUFBYSxPQUFPLE1BQU0sT0FBTyxhQUFhO01BQ2pELGlCQUFpQixNQUFNLGtCQUFrQjtNQUN6QyxHQUFHLENBQUMsT0FBTyxVQUFVO09BQ25CLGFBQWE7T0FDYixtQkFBbUI7T0FDbkIsb0JBQW9CO01BQ3RCO0tBQ0Y7S0FDQSxLQUFLTyxlQUFlLE9BQU8sU0FBUyxXQUFXLEtBQUs7S0FDcEQsT0FBTztJQUNULEtBQUs7S0FDSCxNQUFNLFFBQVEsT0FBTztLQUNyQixPQUFPO01BQ0wsR0FBRztNQUNIO01BQ0Esa0JBQWtCLE1BQU0sbUJBQW1CO01BQzNDLGdCQUFnQixLQUFLLElBQUk7TUFDekIsbUJBQW1CLE1BQU0sb0JBQW9CO01BQzdDLG9CQUFvQjtNQUNwQixhQUFhO01BQ2IsUUFBUTtNQUdSLGVBQWU7S0FDakI7SUFDRixLQUFLLGNBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxlQUFlO0lBQ2pCO0lBQ0YsS0FBSyxZQUNILE9BQU87S0FDTCxHQUFHO0tBQ0gsR0FBRyxPQUFPO0lBQ1o7R0FDSjtFQUNGO0VBQ0EsS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLO0VBQy9CLGNBQWMsWUFBWTtHQUN4QixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ25DLFNBQVMsY0FBYztHQUN6QixDQUFDO0dBQ0QsS0FBS1AsT0FBTyxPQUFPO0lBQUUsT0FBTztJQUFNLE1BQU07SUFBVztHQUFPLENBQUM7RUFDN0QsQ0FBQztDQUNIO0FBQ0Y7QUFDQSxTQUFTLFdBQVcsTUFBTSxTQUFTO0NBQ2pDLE9BQU87RUFDTCxtQkFBbUI7RUFDbkIsb0JBQW9CO0VBQ3BCLGFBQWEsU0FBUyxRQUFRLFdBQVcsSUFBSSxhQUFhO0VBQzFELEdBQUcsU0FBUyxLQUFLLEtBQUs7R0FDcEIsT0FBTztHQUNQLFFBQVE7RUFDVjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsTUFBTSxlQUFlO0NBQ3pDLE9BQU87RUFDTDtFQUNBLGVBQWUsaUJBQWlCLEtBQUssSUFBSTtFQUN6QyxPQUFPO0VBQ1AsZUFBZTtFQUNmLFFBQVE7Q0FDVjtBQUNGO0FBQ0EsU0FBU0Usa0JBQWdCLFNBQVM7Q0FDaEMsTUFBTSxPQUFPLE9BQU8sUUFBUSxnQkFBZ0IsYUFBYSxRQUFRLFlBQVksSUFBSSxRQUFRO0NBQ3pGLE1BQU0sVUFBVSxTQUFTLEtBQUs7Q0FDOUIsTUFBTSx1QkFBdUIsVUFBVSxPQUFPLFFBQVEseUJBQXlCLGFBQWEsUUFBUSxxQkFBcUIsSUFBSSxRQUFRLHVCQUF1QjtDQUM1SixPQUFPO0VBQ0w7RUFDQSxpQkFBaUI7RUFDakIsZUFBZSxVQUFVLHdCQUF3QixLQUFLLElBQUksSUFBSTtFQUM5RCxPQUFPO0VBQ1Asa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixtQkFBbUI7RUFDbkIsb0JBQW9CO0VBQ3BCLFdBQVc7RUFDWCxlQUFlO0VBQ2YsUUFBUSxVQUFVLFlBQVk7RUFDOUIsYUFBYTtDQUNmO0FBQ0Y7OztBQy9hQSxJQUFJLGdCQUFnQixjQUFjLGFBQWE7Q0FDN0MsWUFBWSxRQUFRLFNBQVM7RUFDM0IsTUFBTTtFQUNOLEtBQUssVUFBVTtFQUNmLEtBQUtNLFVBQVU7RUFDZixLQUFLQyxlQUFlO0VBQ3BCLEtBQUtDLG1CQUFtQixnQkFBZ0I7RUFDeEMsS0FBSyxZQUFZO0VBQ2pCLEtBQUssV0FBVyxPQUFPO0NBQ3pCO0NBQ0E7Q0FDQSxnQkFBZ0IsS0FBSztDQUNyQiw0QkFBNEIsS0FBSztDQUNqQyxpQkFBaUIsS0FBSztDQUN0QjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FHQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLGdDQUFnQyxJQUFJLElBQUk7Q0FDeEMsY0FBYztFQUNaLEtBQUssVUFBVSxLQUFLLFFBQVEsS0FBSyxJQUFJO0NBQ3ZDO0NBQ0EsY0FBYztFQUNaLElBQUksS0FBSyxVQUFVLFNBQVMsR0FBRztHQUM3QixLQUFLQyxjQUFjLFlBQVksSUFBSTtHQUNuQyxJQUFJLG1CQUFtQixLQUFLQSxlQUFlLEtBQUssT0FBTyxHQUNyRCxLQUFLQyxjQUFjO1FBRW5CLEtBQUssYUFBYTtHQUVwQixLQUFLQyxjQUFjO0VBQ3JCO0NBQ0Y7Q0FDQSxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsS0FBSyxhQUFhLEdBQ3JCLEtBQUssUUFBUTtDQUVqQjtDQUNBLHlCQUF5QjtFQUN2QixPQUFPLGNBQ0wsS0FBS0YsZUFDTCxLQUFLLFNBQ0wsS0FBSyxRQUFRLGtCQUNmO0NBQ0Y7Q0FDQSwyQkFBMkI7RUFDekIsT0FBTyxjQUNMLEtBQUtBLGVBQ0wsS0FBSyxTQUNMLEtBQUssUUFBUSxvQkFDZjtDQUNGO0NBQ0EsVUFBVTtFQUNSLEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLRyxtQkFBbUI7RUFDeEIsS0FBS0Msc0JBQXNCO0VBQzNCLEtBQUtKLGNBQWMsZUFBZSxJQUFJO0NBQ3hDO0NBQ0EsV0FBVyxTQUFTO0VBQ2xCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sWUFBWSxLQUFLQTtFQUN2QixLQUFLLFVBQVUsS0FBS0gsUUFBUSxvQkFBb0IsT0FBTztFQUN2RCxJQUFJLEtBQUssUUFBUSxZQUFZLEtBQUssS0FBSyxPQUFPLEtBQUssUUFBUSxZQUFZLGFBQWEsT0FBTyxLQUFLLFFBQVEsWUFBWSxjQUFjLE9BQU8sb0JBQW9CLEtBQUssUUFBUSxTQUFTLEtBQUtHLGFBQWEsTUFBTSxXQUN6TSxNQUFNLElBQUksTUFDUix1RUFDRjtFQUVGLEtBQUtLLGFBQWE7RUFDbEIsS0FBS0wsY0FBYyxXQUFXLEtBQUssT0FBTztFQUMxQyxJQUFJLFlBQVksY0FBYyxDQUFDLG9CQUFvQixLQUFLLFNBQVMsV0FBVyxHQUMxRSxLQUFLSCxRQUFRLGNBQWMsQ0FBQyxDQUFDLE9BQU87R0FDbEMsTUFBTTtHQUNOLE9BQU8sS0FBS0c7R0FDWixVQUFVO0VBQ1osQ0FBQztFQUVILE1BQU0sVUFBVSxLQUFLLGFBQWE7RUFDbEMsSUFBSSxXQUFXLHNCQUNiLEtBQUtBLGVBQ0wsV0FDQSxLQUFLLFNBQ0wsV0FDRixHQUNFLEtBQUtDLGNBQWM7RUFFckIsS0FBSyxhQUFhO0VBQ2xCLElBQUksWUFBWSxLQUFLRCxrQkFBa0IsYUFBYSxvQkFBb0IsS0FBSyxRQUFRLFNBQVMsS0FBS0EsYUFBYSxNQUFNLG9CQUFvQixZQUFZLFNBQVMsS0FBS0EsYUFBYSxLQUFLLGlCQUFpQixLQUFLLFFBQVEsV0FBVyxLQUFLQSxhQUFhLE1BQU0saUJBQWlCLFlBQVksV0FBVyxLQUFLQSxhQUFhLElBQy9TLEtBQUtNLG9CQUFvQjtFQUUzQixNQUFNLHNCQUFzQixLQUFLQyx3QkFBd0I7RUFDekQsSUFBSSxZQUFZLEtBQUtQLGtCQUFrQixhQUFhLG9CQUFvQixLQUFLLFFBQVEsU0FBUyxLQUFLQSxhQUFhLE1BQU0sb0JBQW9CLFlBQVksU0FBUyxLQUFLQSxhQUFhLEtBQUssd0JBQXdCLEtBQUtRLDBCQUNqTixLQUFLQyx1QkFBdUIsbUJBQW1CO0NBRW5EO0NBQ0Esb0JBQW9CLFNBQVM7RUFDM0IsTUFBTSxRQUFRLEtBQUtaLFFBQVEsY0FBYyxDQUFDLENBQUMsTUFBTSxLQUFLQSxTQUFTLE9BQU87RUFDdEUsTUFBTSxTQUFTLEtBQUssYUFBYSxPQUFPLE9BQU87RUFDL0MsSUFBSSxzQ0FBc0MsTUFBTSxNQUFNLEdBQUc7R0FDdkQsS0FBS2EsaUJBQWlCO0dBQ3RCLEtBQUtDLHdCQUF3QixLQUFLO0dBQ2xDLEtBQUtDLHNCQUFzQixLQUFLWixjQUFjO0VBQ2hEO0VBQ0EsT0FBTztDQUNUO0NBQ0EsbUJBQW1CO0VBQ2pCLE9BQU8sS0FBS1U7Q0FDZDtDQUNBLFlBQVksUUFBUSxlQUFlO0VBQ2pDLE9BQU8sSUFBSSxNQUFNLFFBQVEsRUFDdkIsTUFBTSxRQUFRLFFBQVE7R0FDcEIsS0FBSyxVQUFVLEdBQUc7R0FDbEIsZ0JBQWdCLEdBQUc7R0FDbkIsSUFBSSxRQUFRLFdBQVc7SUFDckIsS0FBSyxVQUFVLE1BQU07SUFDckIsSUFBSSxDQUFDLEtBQUssUUFBUSxpQ0FBaUMsS0FBS1gsaUJBQWlCLFdBQVcsV0FDbEYsS0FBS0EsaUJBQWlCLHVCQUNwQixJQUFJLE1BQ0YsMkRBQ0YsQ0FDRjtHQUVKO0dBQ0EsT0FBTyxRQUFRLElBQUksUUFBUSxHQUFHO0VBQ2hDLEVBQ0YsQ0FBQztDQUNIO0NBQ0EsVUFBVSxLQUFLO0VBQ2IsS0FBS2MsY0FBYyxJQUFJLEdBQUc7Q0FDNUI7Q0FDQSxrQkFBa0I7RUFDaEIsT0FBTyxLQUFLYjtDQUNkO0NBQ0EsUUFBUSxFQUFFLEdBQUcsWUFBWSxDQUFDLEdBQUc7RUFDM0IsT0FBTyxLQUFLLE1BQU0sRUFDaEIsR0FBRyxRQUNMLENBQUM7Q0FDSDtDQUNBLGdCQUFnQixTQUFTO0VBQ3ZCLE1BQU0sbUJBQW1CLEtBQUtILFFBQVEsb0JBQW9CLE9BQU87RUFDakUsTUFBTSxRQUFRLEtBQUtBLFFBQVEsY0FBYyxDQUFDLENBQUMsTUFBTSxLQUFLQSxTQUFTLGdCQUFnQjtFQUMvRSxPQUFPLE1BQU0sTUFBTSxDQUFDLENBQUMsV0FBVyxLQUFLLGFBQWEsT0FBTyxnQkFBZ0IsQ0FBQztDQUM1RTtDQUNBLE1BQU0sY0FBYztFQUNsQixPQUFPLEtBQUtJLGNBQWM7R0FDeEIsR0FBRztHQUNILGVBQWUsYUFBYSxpQkFBaUI7RUFDL0MsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNaLEtBQUssYUFBYTtHQUNsQixPQUFPLEtBQUtTO0VBQ2QsQ0FBQztDQUNIO0NBQ0EsY0FBYyxjQUFjO0VBQzFCLEtBQUtMLGFBQWE7RUFDbEIsSUFBSSxVQUFVLEtBQUtMLGNBQWMsTUFDL0IsS0FBSyxTQUNMLFlBQ0Y7RUFDQSxJQUFJLENBQUMsY0FBYyxjQUNqQixVQUFVLFFBQVEsTUFBTSxJQUFJO0VBRTlCLE9BQU87Q0FDVDtDQUNBLHNCQUFzQjtFQUNwQixLQUFLRyxtQkFBbUI7RUFDeEIsTUFBTSxZQUFZLGlCQUNoQixLQUFLLFFBQVEsV0FDYixLQUFLSCxhQUNQO0VBQ0EsSUFBSSxtQkFBbUIsU0FBUyxLQUFLLEtBQUtVLGVBQWUsV0FBVyxDQUFDLGVBQWUsU0FBUyxHQUMzRjtFQUdGLE1BQU0sVUFETyxlQUFlLEtBQUtBLGVBQWUsZUFBZSxTQUM1QyxJQUFJO0VBQ3ZCLEtBQUtJLGtCQUFrQixlQUFlLGlCQUFpQjtHQUNyRCxJQUFJLENBQUMsS0FBS0osZUFBZSxTQUN2QixLQUFLLGFBQWE7RUFFdEIsR0FBRyxPQUFPO0NBQ1o7Q0FDQSwwQkFBMEI7RUFDeEIsUUFBUSxPQUFPLEtBQUssUUFBUSxvQkFBb0IsYUFBYSxLQUFLLFFBQVEsZ0JBQWdCLEtBQUtWLGFBQWEsSUFBSSxLQUFLLFFBQVEsb0JBQW9CO0NBQ25KO0NBQ0EsdUJBQXVCLGNBQWM7RUFDbkMsS0FBS0ksc0JBQXNCO0VBQzNCLEtBQUtJLDBCQUEwQjtFQUMvQixJQUFJLG1CQUFtQixTQUFTLEtBQUssb0JBQW9CLEtBQUssUUFBUSxTQUFTLEtBQUtSLGFBQWEsTUFBTSxTQUFTLENBQUMsZUFBZSxLQUFLUSx1QkFBdUIsS0FBSyxLQUFLQSw0QkFBNEIsR0FDaE07RUFFRixLQUFLTyxxQkFBcUIsZUFBZSxrQkFBa0I7R0FDekQsSUFBSSxLQUFLLFFBQVEsK0JBQStCLGFBQWEsVUFBVSxHQUNyRSxLQUFLZCxjQUFjO0VBRXZCLEdBQUcsS0FBS08sdUJBQXVCO0NBQ2pDO0NBQ0EsZ0JBQWdCO0VBQ2QsS0FBS0Ysb0JBQW9CO0VBQ3pCLEtBQUtHLHVCQUF1QixLQUFLRix3QkFBd0IsQ0FBQztDQUM1RDtDQUNBLHFCQUFxQjtFQUNuQixJQUFJLEtBQUtPLG9CQUFvQixLQUFLLEdBQUc7R0FDbkMsZUFBZSxhQUFhLEtBQUtBLGVBQWU7R0FDaEQsS0FBS0Esa0JBQWtCLEtBQUs7RUFDOUI7Q0FDRjtDQUNBLHdCQUF3QjtFQUN0QixJQUFJLEtBQUtDLHVCQUF1QixLQUFLLEdBQUc7R0FDdEMsZUFBZSxjQUFjLEtBQUtBLGtCQUFrQjtHQUNwRCxLQUFLQSxxQkFBcUIsS0FBSztFQUNqQztDQUNGO0NBQ0EsYUFBYSxPQUFPLFNBQVM7RUFDM0IsTUFBTSxZQUFZLEtBQUtmO0VBQ3ZCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sYUFBYSxLQUFLVTtFQUN4QixNQUFNLGtCQUFrQixLQUFLRTtFQUM3QixNQUFNLG9CQUFvQixLQUFLRDtFQUUvQixNQUFNLG9CQURjLFVBQVUsWUFDVSxNQUFNLFFBQVEsS0FBS0s7RUFDM0QsTUFBTSxFQUFFLFVBQVU7RUFDbEIsSUFBSSxXQUFXLEVBQUUsR0FBRyxNQUFNO0VBQzFCLElBQUksb0JBQW9CO0VBQ3hCLElBQUk7RUFDSixJQUFJLFFBQVEsb0JBQW9CO0dBQzlCLE1BQU0sVUFBVSxLQUFLLGFBQWE7R0FDbEMsTUFBTSxlQUFlLENBQUMsV0FBVyxtQkFBbUIsT0FBTyxPQUFPO0dBQ2xFLE1BQU0sa0JBQWtCLFdBQVcsc0JBQXNCLE9BQU8sV0FBVyxTQUFTLFdBQVc7R0FDL0YsSUFBSSxnQkFBZ0IsaUJBQ2xCLFdBQVc7SUFDVCxHQUFHO0lBQ0gsR0FBRyxXQUFXLE1BQU0sTUFBTSxNQUFNLE9BQU87R0FDekM7R0FFRixJQUFJLFFBQVEsdUJBQXVCLGVBQ2pDLFNBQVMsY0FBYztFQUUzQjtFQUNBLElBQUksRUFBRSxPQUFPLGdCQUFnQixXQUFXO0VBQ3hDLE9BQU8sU0FBUztFQUNoQixJQUFJLGFBQWE7RUFDakIsSUFBSSxRQUFRLG9CQUFvQixLQUFLLEtBQUssU0FBUyxLQUFLLEtBQUssV0FBVyxXQUFXO0dBQ2pGLElBQUk7R0FDSixJQUFJLFlBQVkscUJBQXFCLFFBQVEsb0JBQW9CLG1CQUFtQixpQkFBaUI7SUFDbkcsa0JBQWtCLFdBQVc7SUFDN0IsYUFBYTtHQUNmLE9BQ0Usa0JBQWtCLE9BQU8sUUFBUSxvQkFBb0IsYUFBYSxRQUFRLGdCQUN4RSxLQUFLQywyQkFBMkIsTUFBTSxNQUN0QyxLQUFLQSx5QkFDUCxJQUFJLFFBQVE7R0FFZCxJQUFJLG9CQUFvQixLQUFLLEdBQUc7SUFDOUIsU0FBUztJQUNULE9BQU8sWUFDTCxZQUFZLE1BQ1osaUJBQ0EsT0FDRjtJQUNBLG9CQUFvQjtHQUN0QjtFQUNGO0VBQ0EsSUFBSSxRQUFRLFVBQVUsU0FBUyxLQUFLLEtBQUssQ0FBQyxZQUN4QyxJQUFJLGNBQWMsU0FBUyxpQkFBaUIsUUFBUSxRQUFRLFdBQVcsS0FBS0MsV0FDMUUsT0FBTyxLQUFLQztPQUVaLElBQUk7R0FDRixLQUFLRCxZQUFZLFFBQVE7R0FDekIsT0FBTyxRQUFRLE9BQU8sSUFBSTtHQUMxQixPQUFPLFlBQVksWUFBWSxNQUFNLE1BQU0sT0FBTztHQUNsRCxLQUFLQyxnQkFBZ0I7R0FDckIsS0FBS3JCLGVBQWU7RUFDdEIsU0FBUyxhQUFhO0dBQ3BCLEtBQUtBLGVBQWU7RUFDdEI7RUFHSixJQUFJLEtBQUtBLGNBQWM7R0FDckIsUUFBUSxLQUFLQTtHQUNiLE9BQU8sS0FBS3FCO0dBQ1osaUJBQWlCLEtBQUssSUFBSTtHQUMxQixTQUFTO0VBQ1g7RUFDQSxNQUFNLGFBQWEsU0FBUyxnQkFBZ0I7RUFDNUMsTUFBTSxZQUFZLFdBQVc7RUFDN0IsTUFBTSxVQUFVLFdBQVc7RUFDM0IsTUFBTSxZQUFZLGFBQWE7RUFDL0IsTUFBTSxVQUFVLFNBQVMsS0FBSztFQTZCOUIsTUFBTSxhQUFhO0dBM0JqQjtHQUNBLGFBQWEsU0FBUztHQUN0QjtHQUNBLFdBQVcsV0FBVztHQUN0QjtHQUNBLGtCQUFrQjtHQUNsQjtHQUNBO0dBQ0EsZUFBZSxTQUFTO0dBQ3hCO0dBQ0E7R0FDQSxjQUFjLFNBQVM7R0FDdkIsZUFBZSxTQUFTO0dBQ3hCLGtCQUFrQixTQUFTO0dBQzNCLFdBQVcsTUFBTSxVQUFVO0dBQzNCLHFCQUFxQixTQUFTLGtCQUFrQixrQkFBa0IsbUJBQW1CLFNBQVMsbUJBQW1CLGtCQUFrQjtHQUNuSTtHQUNBLGNBQWMsY0FBYyxDQUFDO0dBQzdCLGdCQUFnQixXQUFXLENBQUM7R0FDNUIsVUFBVSxTQUFTLGdCQUFnQjtHQUNuQztHQUNBLGdCQUFnQixXQUFXO0dBQzNCLFNBQVMsUUFBUSxPQUFPLE9BQU87R0FDL0IsU0FBUyxLQUFLO0dBQ2QsU0FBUyxLQUFLcEI7R0FDZCxXQUFXLG9CQUFvQixRQUFRLFNBQVMsS0FBSyxNQUFNO0VBRXJDO0VBQ3hCLElBQUksS0FBSyxRQUFRLCtCQUErQjtHQUM5QyxNQUFNLGdCQUFnQixXQUFXLFNBQVMsS0FBSztHQUMvQyxNQUFNLHFCQUFxQixXQUFXLFdBQVcsV0FBVyxDQUFDO0dBQzdELE1BQU0sOEJBQThCLGFBQWE7SUFDL0MsSUFBSSxvQkFDRixTQUFTLE9BQU8sV0FBVyxLQUFLO1NBQzNCLElBQUksZUFDVCxTQUFTLFFBQVEsV0FBVyxJQUFJO0dBRXBDO0dBQ0EsTUFBTSx5QkFBeUI7SUFDN0IsTUFBTSxVQUFVLEtBQUtBLG1CQUFtQixXQUFXLFVBQVUsZ0JBQWdCO0lBQzdFLDJCQUEyQixPQUFPO0dBQ3BDO0dBQ0EsTUFBTSxlQUFlLEtBQUtBO0dBQzFCLFFBQVEsYUFBYSxRQUFyQjtJQUNFLEtBQUs7S0FDSCxJQUFJLE1BQU0sY0FBYyxVQUFVLFdBQ2hDLDJCQUEyQixZQUFZO0tBRXpDO0lBQ0YsS0FBSztLQUNILElBQUksc0JBQXNCLFdBQVcsU0FBUyxhQUFhLE9BQ3pELGlCQUFpQjtLQUVuQjtJQUNGLEtBQUssWUFDSCxJQUFJLENBQUMsc0JBQXNCLFdBQVcsVUFBVSxhQUFhLFFBQzNELGlCQUFpQjtHQUd2QjtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsZUFBZTtFQUNiLE1BQU0sYUFBYSxLQUFLVztFQUN4QixNQUFNLGFBQWEsS0FBSyxhQUFhLEtBQUtWLGVBQWUsS0FBSyxPQUFPO0VBQ3JFLEtBQUtZLHNCQUFzQixLQUFLWixjQUFjO0VBQzlDLEtBQUtXLHdCQUF3QixLQUFLO0VBQ2xDLElBQUksS0FBS0Msb0JBQW9CLFNBQVMsS0FBSyxHQUN6QyxLQUFLSyw0QkFBNEIsS0FBS2pCO0VBRXhDLElBQUksb0JBQW9CLFlBQVksVUFBVSxHQUM1QztFQUVGLEtBQUtVLGlCQUFpQjtFQUN0QixNQUFNLDhCQUE4QjtHQUNsQyxJQUFJLENBQUMsWUFDSCxPQUFPO0dBRVQsTUFBTSxFQUFFLHdCQUF3QixLQUFLO0dBQ3JDLE1BQU0sMkJBQTJCLE9BQU8sd0JBQXdCLGFBQWEsb0JBQW9CLElBQUk7R0FDckcsSUFBSSw2QkFBNkIsU0FBUyxDQUFDLDRCQUE0QixDQUFDLEtBQUtHLGNBQWMsTUFDekYsT0FBTztHQUVULE1BQU0sZ0JBQWdCLElBQUksSUFDeEIsNEJBQTRCLEtBQUtBLGFBQ25DO0dBQ0EsSUFBSSxLQUFLLFFBQVEsY0FDZixjQUFjLElBQUksT0FBTztHQUUzQixPQUFPLE9BQU8sS0FBSyxLQUFLSCxjQUFjLENBQUMsQ0FBQyxNQUFNLFFBQVE7SUFDcEQsTUFBTSxXQUFXO0lBRWpCLE9BRGdCLEtBQUtBLGVBQWUsY0FBYyxXQUFXLGFBQzNDLGNBQWMsSUFBSSxRQUFRO0dBQzlDLENBQUM7RUFDSDtFQUNBLEtBQUtVLFFBQVEsRUFBRSxXQUFXLHNCQUFzQixFQUFFLENBQUM7Q0FDckQ7Q0FDQSxlQUFlO0VBQ2IsTUFBTSxRQUFRLEtBQUt2QixRQUFRLGNBQWMsQ0FBQyxDQUFDLE1BQU0sS0FBS0EsU0FBUyxLQUFLLE9BQU87RUFDM0UsSUFBSSxVQUFVLEtBQUtHLGVBQ2pCO0VBRUYsTUFBTSxZQUFZLEtBQUtBO0VBQ3ZCLEtBQUtBLGdCQUFnQjtFQUNyQixLQUFLZ0IsNEJBQTRCLE1BQU07RUFDdkMsSUFBSSxLQUFLLGFBQWEsR0FBRztHQUN2QixXQUFXLGVBQWUsSUFBSTtHQUM5QixNQUFNLFlBQVksSUFBSTtFQUN4QjtDQUNGO0NBQ0EsZ0JBQWdCO0VBQ2QsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxhQUFhLEdBQ3BCLEtBQUtkLGNBQWM7Q0FFdkI7Q0FDQSxRQUFRLGVBQWU7RUFDckIsY0FBYyxZQUFZO0dBQ3hCLElBQUksY0FBYyxXQUNoQixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ25DLFNBQVMsS0FBS1EsY0FBYztHQUM5QixDQUFDO0dBRUgsS0FBS2IsUUFBUSxjQUFjLENBQUMsQ0FBQyxPQUFPO0lBQ2xDLE9BQU8sS0FBS0c7SUFDWixNQUFNO0dBQ1IsQ0FBQztFQUNILENBQUM7Q0FDSDtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxTQUFTO0NBQ3pDLE9BQU8sb0JBQW9CLFFBQVEsU0FBUyxLQUFLLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxNQUFNLE1BQU0sV0FBVyxXQUFXLG9CQUFvQixRQUFRLGNBQWMsS0FBSyxNQUFNO0FBQzFMO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTyxTQUFTO0NBQzFDLE9BQU8sa0JBQWtCLE9BQU8sT0FBTyxLQUFLLE1BQU0sTUFBTSxTQUFTLEtBQUssS0FBSyxjQUFjLE9BQU8sU0FBUyxRQUFRLGNBQWM7QUFDakk7QUFDQSxTQUFTLGNBQWMsT0FBTyxTQUFTLE9BQU87Q0FDNUMsSUFBSSxvQkFBb0IsUUFBUSxTQUFTLEtBQUssTUFBTSxTQUFTLGlCQUFpQixRQUFRLFdBQVcsS0FBSyxNQUFNLFVBQVU7RUFDcEgsTUFBTSxRQUFRLE9BQU8sVUFBVSxhQUFhLE1BQU0sS0FBSyxJQUFJO0VBQzNELE9BQU8sVUFBVSxZQUFZLFVBQVUsU0FBUyxRQUFRLE9BQU8sT0FBTztDQUN4RTtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsc0JBQXNCLE9BQU8sV0FBVyxTQUFTLGFBQWE7Q0FDckUsUUFBUSxVQUFVLGFBQWEsb0JBQW9CLFlBQVksU0FBUyxLQUFLLE1BQU0sV0FBVyxDQUFDLFFBQVEsWUFBWSxNQUFNLE1BQU0sV0FBVyxZQUFZLFFBQVEsT0FBTyxPQUFPO0FBQzlLO0FBQ0EsU0FBUyxRQUFRLE9BQU8sU0FBUztDQUMvQixPQUFPLG9CQUFvQixRQUFRLFNBQVMsS0FBSyxNQUFNLFNBQVMsTUFBTSxjQUFjLGlCQUFpQixRQUFRLFdBQVcsS0FBSyxDQUFDO0FBQ2hJO0FBQ0EsU0FBUyxzQ0FBc0MsVUFBVSxrQkFBa0I7Q0FDekUsSUFBSSxDQUFDLG9CQUFvQixTQUFTLGlCQUFpQixHQUFHLGdCQUFnQixHQUNwRSxPQUFPO0NBRVQsT0FBTztBQUNUOzs7QUNoZEEsSUFBSSx3QkFBd0IsY0FBYyxjQUFjO0NBQ3RELFlBQVksUUFBUSxTQUFTO0VBQzNCLE1BQU0sUUFBUSxPQUFPO0NBQ3ZCO0NBQ0EsY0FBYztFQUNaLE1BQU0sWUFBWTtFQUNsQixLQUFLLGdCQUFnQixLQUFLLGNBQWMsS0FBSyxJQUFJO0VBQ2pELEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLEtBQUssSUFBSTtDQUMzRDtDQUNBLFdBQVcsU0FBUztFQUNsQixRQUFRLFFBQVE7RUFDaEIsTUFBTSxXQUFXLE9BQU87Q0FDMUI7Q0FDQSxvQkFBb0IsU0FBUztFQUMzQixRQUFRLFFBQVE7RUFDaEIsT0FBTyxNQUFNLG9CQUFvQixPQUFPO0NBQzFDO0NBQ0EsY0FBYyxTQUFTO0VBQ3JCLE9BQU8sS0FBSyxNQUFNO0dBQ2hCLEdBQUc7R0FDSCxNQUFNLEVBQ0osV0FBVyxFQUFFLFdBQVcsVUFBVSxFQUNwQztFQUNGLENBQUM7Q0FDSDtDQUNBLGtCQUFrQixTQUFTO0VBQ3pCLE9BQU8sS0FBSyxNQUFNO0dBQ2hCLEdBQUc7R0FDSCxNQUFNLEVBQ0osV0FBVyxFQUFFLFdBQVcsV0FBVyxFQUNyQztFQUNGLENBQUM7Q0FDSDtDQUNBLGFBQWEsT0FBTyxTQUFTO0VBQzNCLE1BQU0sRUFBRSxVQUFVO0VBQ2xCLE1BQU0sZUFBZSxNQUFNLGFBQWEsT0FBTyxPQUFPO0VBQ3RELE1BQU0sRUFBRSxZQUFZLGNBQWMsU0FBUyxtQkFBbUI7RUFDOUQsTUFBTSxpQkFBaUIsTUFBTSxXQUFXLFdBQVc7RUFDbkQsTUFBTSx1QkFBdUIsV0FBVyxtQkFBbUI7RUFDM0QsTUFBTSxxQkFBcUIsY0FBYyxtQkFBbUI7RUFDNUQsTUFBTSwyQkFBMkIsV0FBVyxtQkFBbUI7RUFDL0QsTUFBTSx5QkFBeUIsY0FBYyxtQkFBbUI7RUFjaEUsT0FBTztHQVpMLEdBQUc7R0FDSCxlQUFlLEtBQUs7R0FDcEIsbUJBQW1CLEtBQUs7R0FDeEIsYUFBYSxZQUFZLFNBQVMsTUFBTSxJQUFJO0dBQzVDLGlCQUFpQixnQkFBZ0IsU0FBUyxNQUFNLElBQUk7R0FDcEQ7R0FDQTtHQUNBO0dBQ0E7R0FDQSxnQkFBZ0Isa0JBQWtCLENBQUMsd0JBQXdCLENBQUM7R0FDNUQsY0FBYyxnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQztFQUU1QztDQUNkO0FBQ0Y7OztBQ3hEQSxJQUFJLFdBQVcsY0FBYyxVQUFVO0NBQ3JDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxRQUFRO0VBQ2xCLE1BQU07RUFDTixLQUFLcUIsVUFBVSxPQUFPO0VBQ3RCLEtBQUssYUFBYSxPQUFPO0VBQ3pCLEtBQUtDLGlCQUFpQixPQUFPO0VBQzdCLEtBQUtDLGFBQWEsQ0FBQztFQUNuQixLQUFLLFFBQVEsT0FBTyxTQUFTLGdCQUFnQjtFQUM3QyxLQUFLLFdBQVcsT0FBTyxPQUFPO0VBQzlCLEtBQUssV0FBVztDQUNsQjtDQUNBLFdBQVcsU0FBUztFQUNsQixLQUFLLFVBQVU7RUFDZixLQUFLLGFBQWEsS0FBSyxRQUFRLE1BQU07Q0FDdkM7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssUUFBUTtDQUN0QjtDQUNBLFlBQVksVUFBVTtFQUNwQixJQUFJLENBQUMsS0FBS0EsV0FBVyxTQUFTLFFBQVEsR0FBRztHQUN2QyxLQUFLQSxXQUFXLEtBQUssUUFBUTtHQUM3QixLQUFLLGVBQWU7R0FDcEIsS0FBS0QsZUFBZSxPQUFPO0lBQ3pCLE1BQU07SUFDTixVQUFVO0lBQ1Y7R0FDRixDQUFDO0VBQ0g7Q0FDRjtDQUNBLGVBQWUsVUFBVTtFQUN2QixLQUFLQyxhQUFhLEtBQUtBLFdBQVcsUUFBUSxNQUFNLE1BQU0sUUFBUTtFQUM5RCxLQUFLLFdBQVc7RUFDaEIsS0FBS0QsZUFBZSxPQUFPO0dBQ3pCLE1BQU07R0FDTixVQUFVO0dBQ1Y7RUFDRixDQUFDO0NBQ0g7Q0FDQSxpQkFBaUI7RUFDZixJQUFJLENBQUMsS0FBS0MsV0FBVyxRQUNuQixJQUFJLEtBQUssTUFBTSxXQUFXLFdBQ3hCLEtBQUssV0FBVztPQUVoQixLQUFLRCxlQUFlLE9BQU8sSUFBSTtDQUdyQztDQUNBLFdBQVc7RUFDVCxPQUFPLEtBQUtFLFVBQVUsU0FBUyxLQUMvQixLQUFLLFFBQVEsS0FBSyxNQUFNLFNBQVM7Q0FDbkM7Q0FDQSxNQUFNLFFBQVEsV0FBVztFQUN2QixNQUFNLG1CQUFtQjtHQUN2QixLQUFLQyxVQUFVLEVBQUUsTUFBTSxXQUFXLENBQUM7RUFDckM7RUFDQSxNQUFNLG9CQUFvQjtHQUN4QixRQUFRLEtBQUtKO0dBQ2IsTUFBTSxLQUFLLFFBQVE7R0FDbkIsYUFBYSxLQUFLLFFBQVE7RUFDNUI7RUFDQSxLQUFLRyxXQUFXLGNBQWM7R0FDNUIsVUFBVTtJQUNSLElBQUksQ0FBQyxLQUFLLFFBQVEsWUFDaEIsT0FBTyxRQUFRLHVCQUFPLElBQUksTUFBTSxxQkFBcUIsQ0FBQztJQUV4RCxPQUFPLEtBQUssUUFBUSxXQUFXLFdBQVcsaUJBQWlCO0dBQzdEO0dBQ0EsU0FBUyxjQUFjLFVBQVU7SUFDL0IsS0FBS0MsVUFBVTtLQUFFLE1BQU07S0FBVTtLQUFjO0lBQU0sQ0FBQztHQUN4RDtHQUNBLGVBQWU7SUFDYixLQUFLQSxVQUFVLEVBQUUsTUFBTSxRQUFRLENBQUM7R0FDbEM7R0FDQTtHQUNBLE9BQU8sS0FBSyxRQUFRLFNBQVM7R0FDN0IsWUFBWSxLQUFLLFFBQVE7R0FDekIsYUFBYSxLQUFLLFFBQVE7R0FDMUIsY0FBYyxLQUFLSCxlQUFlLE9BQU8sSUFBSTtFQUMvQyxDQUFDO0VBQ0QsTUFBTSxXQUFXLEtBQUssTUFBTSxXQUFXO0VBQ3ZDLE1BQU0sV0FBVyxDQUFDLEtBQUtFLFNBQVMsU0FBUztFQUN6QyxJQUFJO0dBQ0YsSUFBSSxVQUNGLFdBQVc7UUFDTjtJQUNMLEtBQUtDLFVBQVU7S0FBRSxNQUFNO0tBQVc7S0FBVztJQUFTLENBQUM7SUFDdkQsSUFBSSxLQUFLSCxlQUFlLE9BQU8sVUFDN0IsTUFBTSxLQUFLQSxlQUFlLE9BQU8sU0FDL0IsV0FDQSxNQUNBLGlCQUNGO0lBRUYsTUFBTSxVQUFVLE1BQU0sS0FBSyxRQUFRLFdBQ2pDLFdBQ0EsaUJBQ0Y7SUFDQSxJQUFJLFlBQVksS0FBSyxNQUFNLFNBQ3pCLEtBQUtHLFVBQVU7S0FDYixNQUFNO0tBQ047S0FDQTtLQUNBO0lBQ0YsQ0FBQztHQUVMO0dBQ0EsTUFBTSxPQUFPLE1BQU0sS0FBS0QsU0FBUyxNQUFNO0dBQ3ZDLE1BQU0sS0FBS0YsZUFBZSxPQUFPLFlBQy9CLE1BQ0EsV0FDQSxLQUFLLE1BQU0sU0FDWCxNQUNBLGlCQUNGO0dBQ0EsTUFBTSxLQUFLLFFBQVEsWUFDakIsTUFDQSxXQUNBLEtBQUssTUFBTSxTQUNYLGlCQUNGO0dBQ0EsTUFBTSxLQUFLQSxlQUFlLE9BQU8sWUFDL0IsTUFDQSxNQUNBLEtBQUssTUFBTSxXQUNYLEtBQUssTUFBTSxTQUNYLE1BQ0EsaUJBQ0Y7R0FDQSxNQUFNLEtBQUssUUFBUSxZQUNqQixNQUNBLE1BQ0EsV0FDQSxLQUFLLE1BQU0sU0FDWCxpQkFDRjtHQUNBLEtBQUtHLFVBQVU7SUFBRSxNQUFNO0lBQVc7R0FBSyxDQUFDO0dBQ3hDLE9BQU87RUFDVCxTQUFTLE9BQU87R0FDZCxJQUFJO0lBQ0YsTUFBTSxLQUFLSCxlQUFlLE9BQU8sVUFDL0IsT0FDQSxXQUNBLEtBQUssTUFBTSxTQUNYLE1BQ0EsaUJBQ0Y7R0FDRixTQUFTLEdBQUc7SUFDVixRQUFhLE9BQU8sQ0FBQztHQUN2QjtHQUNBLElBQUk7SUFDRixNQUFNLEtBQUssUUFBUSxVQUNqQixPQUNBLFdBQ0EsS0FBSyxNQUFNLFNBQ1gsaUJBQ0Y7R0FDRixTQUFTLEdBQUc7SUFDVixRQUFhLE9BQU8sQ0FBQztHQUN2QjtHQUNBLElBQUk7SUFDRixNQUFNLEtBQUtBLGVBQWUsT0FBTyxZQUMvQixLQUFLLEdBQ0wsT0FDQSxLQUFLLE1BQU0sV0FDWCxLQUFLLE1BQU0sU0FDWCxNQUNBLGlCQUNGO0dBQ0YsU0FBUyxHQUFHO0lBQ1YsUUFBYSxPQUFPLENBQUM7R0FDdkI7R0FDQSxJQUFJO0lBQ0YsTUFBTSxLQUFLLFFBQVEsWUFDakIsS0FBSyxHQUNMLE9BQ0EsV0FDQSxLQUFLLE1BQU0sU0FDWCxpQkFDRjtHQUNGLFNBQVMsR0FBRztJQUNWLFFBQWEsT0FBTyxDQUFDO0dBQ3ZCO0dBQ0EsS0FBS0csVUFBVTtJQUFFLE1BQU07SUFBUztHQUFNLENBQUM7R0FDdkMsTUFBTTtFQUNSLFVBQVU7R0FDUixLQUFLSCxlQUFlLFFBQVEsSUFBSTtFQUNsQztDQUNGO0NBQ0EsVUFBVSxRQUFRO0VBQ2hCLE1BQU0sV0FBVyxVQUFVO0dBQ3pCLFFBQVEsT0FBTyxNQUFmO0lBQ0UsS0FBSyxVQUNILE9BQU87S0FDTCxHQUFHO0tBQ0gsY0FBYyxPQUFPO0tBQ3JCLGVBQWUsT0FBTztJQUN4QjtJQUNGLEtBQUssU0FDSCxPQUFPO0tBQ0wsR0FBRztLQUNILFVBQVU7SUFDWjtJQUNGLEtBQUssWUFDSCxPQUFPO0tBQ0wsR0FBRztLQUNILFVBQVU7SUFDWjtJQUNGLEtBQUssV0FDSCxPQUFPO0tBQ0wsR0FBRztLQUNILFNBQVMsT0FBTztLQUNoQixNQUFNLEtBQUs7S0FDWCxjQUFjO0tBQ2QsZUFBZTtLQUNmLE9BQU87S0FDUCxVQUFVLE9BQU87S0FDakIsUUFBUTtLQUNSLFdBQVcsT0FBTztLQUNsQixhQUFhLEtBQUssSUFBSTtJQUN4QjtJQUNGLEtBQUssV0FDSCxPQUFPO0tBQ0wsR0FBRztLQUNILE1BQU0sT0FBTztLQUNiLGNBQWM7S0FDZCxlQUFlO0tBQ2YsT0FBTztLQUNQLFFBQVE7S0FDUixVQUFVO0lBQ1o7SUFDRixLQUFLLFNBQ0gsT0FBTztLQUNMLEdBQUc7S0FDSCxNQUFNLEtBQUs7S0FDWCxPQUFPLE9BQU87S0FDZCxjQUFjLE1BQU0sZUFBZTtLQUNuQyxlQUFlLE9BQU87S0FDdEIsVUFBVTtLQUNWLFFBQVE7SUFDVjtHQUNKO0VBQ0Y7RUFDQSxLQUFLLFFBQVEsUUFBUSxLQUFLLEtBQUs7RUFDL0IsY0FBYyxZQUFZO0dBQ3hCLEtBQUtDLFdBQVcsU0FBUyxhQUFhO0lBQ3BDLFNBQVMsaUJBQWlCLE1BQU07R0FDbEMsQ0FBQztHQUNELEtBQUtELGVBQWUsT0FBTztJQUN6QixVQUFVO0lBQ1YsTUFBTTtJQUNOO0dBQ0YsQ0FBQztFQUNILENBQUM7Q0FDSDtBQUNGO0FBQ0EsU0FBUyxrQkFBa0I7Q0FDekIsT0FBTztFQUNMLFNBQVMsS0FBSztFQUNkLE1BQU0sS0FBSztFQUNYLE9BQU87RUFDUCxjQUFjO0VBQ2QsZUFBZTtFQUNmLFVBQVU7RUFDVixRQUFRO0VBQ1IsV0FBVyxLQUFLO0VBQ2hCLGFBQWE7Q0FDZjtBQUNGOzs7QUM5UUEsSUFBSSxnQkFBZ0IsY0FBYyxhQUFhO0NBQzdDLFlBQVksU0FBUyxDQUFDLEdBQUc7RUFDdkIsTUFBTTtFQUNOLEtBQUssU0FBUztFQUNkLEtBQUtJLDZCQUE2QixJQUFJLElBQUk7RUFDMUMsS0FBS0MsMEJBQTBCLElBQUksSUFBSTtFQUN2QyxLQUFLQyxjQUFjO0NBQ3JCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsTUFBTSxRQUFRLFNBQVMsT0FBTztFQUM1QixNQUFNLFdBQVcsSUFBSSxTQUFTO0dBQzVCO0dBQ0EsZUFBZTtHQUNmLFlBQVksRUFBRSxLQUFLQTtHQUNuQixTQUFTLE9BQU8sdUJBQXVCLE9BQU87R0FDOUM7RUFDRixDQUFDO0VBQ0QsS0FBSyxJQUFJLFFBQVE7RUFDakIsT0FBTztDQUNUO0NBQ0EsSUFBSSxVQUFVO0VBQ1osS0FBS0YsV0FBVyxJQUFJLFFBQVE7RUFDNUIsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVO0dBQzdCLE1BQU0sa0JBQWtCLEtBQUtDLFFBQVEsSUFBSSxLQUFLO0dBQzlDLElBQUksaUJBQ0YsZ0JBQWdCLEtBQUssUUFBUTtRQUU3QixLQUFLQSxRQUFRLElBQUksT0FBTyxDQUFDLFFBQVEsQ0FBQztFQUV0QztFQUNBLEtBQUssT0FBTztHQUFFLE1BQU07R0FBUztFQUFTLENBQUM7Q0FDekM7Q0FDQSxPQUFPLFVBQVU7RUFDZixJQUFJLEtBQUtELFdBQVcsT0FBTyxRQUFRLEdBQUc7R0FDcEMsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVO0lBQzdCLE1BQU0sa0JBQWtCLEtBQUtDLFFBQVEsSUFBSSxLQUFLO0lBQzlDLElBQUksaUJBQ0U7U0FBQSxnQkFBZ0IsU0FBUyxHQUFHO01BQzlCLE1BQU0sUUFBUSxnQkFBZ0IsUUFBUSxRQUFRO01BQzlDLElBQUksVUFBVSxJQUNaLGdCQUFnQixPQUFPLE9BQU8sQ0FBQztLQUVuQyxPQUFPLElBQUksZ0JBQWdCLE9BQU8sVUFDaEMsS0FBS0EsUUFBUSxPQUFPLEtBQUs7SUFBQTtHQUcvQjtFQUNGO0VBQ0EsS0FBSyxPQUFPO0dBQUUsTUFBTTtHQUFXO0VBQVMsQ0FBQztDQUMzQztDQUNBLE9BQU8sVUFBVTtFQUNmLE1BQU0sUUFBUSxTQUFTLFFBQVE7RUFDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUU3QixNQUFNLHVCQUR5QixLQUFLQSxRQUFRLElBQUksS0FDRSxDQUFDLEVBQUUsTUFDbEQsTUFBTSxFQUFFLE1BQU0sV0FBVyxTQUM1QjtHQUNBLE9BQU8sQ0FBQyx3QkFBd0IseUJBQXlCO0VBQzNELE9BQ0UsT0FBTztDQUVYO0NBQ0EsUUFBUSxVQUFVO0VBQ2hCLE1BQU0sUUFBUSxTQUFTLFFBQVE7RUFDL0IsSUFBSSxPQUFPLFVBQVUsVUFFbkIsUUFEc0IsS0FBS0EsUUFBUSxJQUFJLEtBQUssQ0FBQyxFQUFFLE1BQU0sTUFBTSxNQUFNLFlBQVksRUFBRSxNQUFNLFFBQVEsRUFBQSxFQUN2RSxTQUFTLEtBQUssUUFBUSxRQUFRO09BRXBELE9BQU8sUUFBUSxRQUFRO0NBRTNCO0NBQ0EsUUFBUTtFQUNOLGNBQWMsWUFBWTtHQUN4QixLQUFLRCxXQUFXLFNBQVMsYUFBYTtJQUNwQyxLQUFLLE9BQU87S0FBRSxNQUFNO0tBQVc7SUFBUyxDQUFDO0dBQzNDLENBQUM7R0FDRCxLQUFLQSxXQUFXLE1BQU07R0FDdEIsS0FBS0MsUUFBUSxNQUFNO0VBQ3JCLENBQUM7Q0FDSDtDQUNBLFNBQVM7RUFDUCxPQUFPLE1BQU0sS0FBSyxLQUFLRCxVQUFVO0NBQ25DO0NBQ0EsS0FBSyxTQUFTO0VBQ1osTUFBTSxtQkFBbUI7R0FBRSxPQUFPO0dBQU0sR0FBRztFQUFRO0VBQ25ELE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxNQUNsQixhQUFhLGNBQWMsa0JBQWtCLFFBQVEsQ0FDeEQ7Q0FDRjtDQUNBLFFBQVEsVUFBVSxDQUFDLEdBQUc7RUFDcEIsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFFBQVEsYUFBYSxjQUFjLFNBQVMsUUFBUSxDQUFDO0NBQzVFO0NBQ0EsT0FBTyxPQUFPO0VBQ1osY0FBYyxZQUFZO0dBQ3hCLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDbkMsU0FBUyxLQUFLO0dBQ2hCLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSx3QkFBd0I7RUFDdEIsTUFBTSxrQkFBa0IsS0FBSyxPQUFPLENBQUMsQ0FBQyxRQUFRLE1BQU0sRUFBRSxNQUFNLFFBQVE7RUFDcEUsT0FBTyxjQUFjLFlBQ2IsUUFBUSxJQUNaLGdCQUFnQixLQUFLLGFBQWEsU0FBUyxTQUFTLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUNuRSxDQUNGO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsU0FBUyxVQUFVO0NBQzFCLE9BQU8sU0FBUyxRQUFRLE9BQU87QUFDakM7OztBQ2xIQSxJQUFJLG1CQUFtQixjQUFjLGFBQWE7Q0FDaEQ7Q0FDQSxpQkFBaUIsS0FBSztDQUN0QjtDQUNBO0NBQ0EsWUFBWSxRQUFRLFNBQVM7RUFDM0IsTUFBTTtFQUNOLEtBQUtHLFVBQVU7RUFDZixLQUFLLFdBQVcsT0FBTztFQUN2QixLQUFLLFlBQVk7RUFDakIsS0FBS0MsY0FBYztDQUNyQjtDQUNBLGNBQWM7RUFDWixLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssSUFBSTtFQUNuQyxLQUFLLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSTtDQUNuQztDQUNBLFdBQVcsU0FBUztFQUNsQixNQUFNLGNBQWMsS0FBSztFQUN6QixLQUFLLFVBQVUsS0FBS0QsUUFBUSx1QkFBdUIsT0FBTztFQUMxRCxJQUFJLENBQUMsb0JBQW9CLEtBQUssU0FBUyxXQUFXLEdBQ2hELEtBQUtBLFFBQVEsaUJBQWlCLENBQUMsQ0FBQyxPQUFPO0dBQ3JDLE1BQU07R0FDTixVQUFVLEtBQUtFO0dBQ2YsVUFBVTtFQUNaLENBQUM7RUFFSCxJQUFJLGFBQWEsZUFBZSxLQUFLLFFBQVEsZUFBZSxRQUFRLFlBQVksV0FBVyxNQUFNLFFBQVEsS0FBSyxRQUFRLFdBQVcsR0FDL0gsS0FBSyxNQUFNO09BQ04sSUFBSSxLQUFLQSxrQkFBa0IsTUFBTSxXQUFXLFdBQ2pELEtBQUtBLGlCQUFpQixXQUFXLEtBQUssT0FBTztDQUVqRDtDQUNBLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FDckIsS0FBS0Esa0JBQWtCLGVBQWUsSUFBSTtDQUU5QztDQUNBLGlCQUFpQixRQUFRO0VBQ3ZCLEtBQUtELGNBQWM7RUFDbkIsS0FBS0UsUUFBUSxNQUFNO0NBQ3JCO0NBQ0EsbUJBQW1CO0VBQ2pCLE9BQU8sS0FBS0M7Q0FDZDtDQUNBLFFBQVE7RUFDTixLQUFLRixrQkFBa0IsZUFBZSxJQUFJO0VBQzFDLEtBQUtBLG1CQUFtQixLQUFLO0VBQzdCLEtBQUtELGNBQWM7RUFDbkIsS0FBS0UsUUFBUTtDQUNmO0NBQ0EsT0FBTyxXQUFXLFNBQVM7RUFDekIsS0FBS0UsaUJBQWlCO0VBQ3RCLEtBQUtILGtCQUFrQixlQUFlLElBQUk7RUFDMUMsS0FBS0EsbUJBQW1CLEtBQUtGLFFBQVEsaUJBQWlCLENBQUMsQ0FBQyxNQUFNLEtBQUtBLFNBQVMsS0FBSyxPQUFPO0VBQ3hGLEtBQUtFLGlCQUFpQixZQUFZLElBQUk7RUFDdEMsT0FBTyxLQUFLQSxpQkFBaUIsUUFBUSxTQUFTO0NBQ2hEO0NBQ0EsZ0JBQWdCO0VBQ2QsTUFBTSxRQUFRLEtBQUtBLGtCQUFrQixTQUFTLGdCQUFnQjtFQUM5RCxLQUFLRSxpQkFBaUI7R0FDcEIsR0FBRztHQUNILFdBQVcsTUFBTSxXQUFXO0dBQzVCLFdBQVcsTUFBTSxXQUFXO0dBQzVCLFNBQVMsTUFBTSxXQUFXO0dBQzFCLFFBQVEsTUFBTSxXQUFXO0dBQ3pCLFFBQVEsS0FBSztHQUNiLE9BQU8sS0FBSztFQUNkO0NBQ0Y7Q0FDQSxRQUFRLFFBQVE7RUFDZCxjQUFjLFlBQVk7R0FDeEIsSUFBSSxLQUFLQyxrQkFBa0IsS0FBSyxhQUFhLEdBQUc7SUFDOUMsTUFBTSxZQUFZLEtBQUtELGVBQWU7SUFDdEMsTUFBTSxpQkFBaUIsS0FBS0EsZUFBZTtJQUMzQyxNQUFNLFVBQVU7S0FDZCxRQUFRLEtBQUtKO0tBQ2IsTUFBTSxLQUFLLFFBQVE7S0FDbkIsYUFBYSxLQUFLLFFBQVE7SUFDNUI7SUFDQSxJQUFJLFFBQVEsU0FBUyxXQUFXO0tBQzlCLElBQUk7TUFDRixLQUFLSyxlQUFlLFlBQ2xCLE9BQU8sTUFDUCxXQUNBLGdCQUNBLE9BQ0Y7S0FDRixTQUFTLEdBQUc7TUFDVixRQUFhLE9BQU8sQ0FBQztLQUN2QjtLQUNBLElBQUk7TUFDRixLQUFLQSxlQUFlLFlBQ2xCLE9BQU8sTUFDUCxNQUNBLFdBQ0EsZ0JBQ0EsT0FDRjtLQUNGLFNBQVMsR0FBRztNQUNWLFFBQWEsT0FBTyxDQUFDO0tBQ3ZCO0lBQ0YsT0FBTyxJQUFJLFFBQVEsU0FBUyxTQUFTO0tBQ25DLElBQUk7TUFDRixLQUFLQSxlQUFlLFVBQ2xCLE9BQU8sT0FDUCxXQUNBLGdCQUNBLE9BQ0Y7S0FDRixTQUFTLEdBQUc7TUFDVixRQUFhLE9BQU8sQ0FBQztLQUN2QjtLQUNBLElBQUk7TUFDRixLQUFLQSxlQUFlLFlBQ2xCLEtBQUssR0FDTCxPQUFPLE9BQ1AsV0FDQSxnQkFDQSxPQUNGO0tBQ0YsU0FBUyxHQUFHO01BQ1YsUUFBYSxPQUFPLENBQUM7S0FDdkI7SUFDRjtHQUNGO0dBQ0EsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNuQyxTQUFTLEtBQUtELGNBQWM7R0FDOUIsQ0FBQztFQUNILENBQUM7Q0FDSDtBQUNGOzs7QUNsSUEsU0FBUyxXQUFXLFFBQVEsUUFBUTtDQUNsQyxNQUFNLGFBQWEsSUFBSSxJQUFJLE1BQU07Q0FDakMsT0FBTyxPQUFPLFFBQVEsTUFBTSxDQUFDLFdBQVcsSUFBSSxDQUFDLENBQUM7QUFDaEQ7QUFDQSxTQUFTLFVBQVUsT0FBTyxPQUFPLE9BQU87Q0FDdEMsTUFBTSxPQUFPLE1BQU0sTUFBTSxDQUFDO0NBQzFCLEtBQUssU0FBUztDQUNkLE9BQU87QUFDVDtBQUNBLElBQUksa0JBQWtCLGNBQWMsYUFBYTtDQUMvQztDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxtQkFBbUIsQ0FBQztDQUNwQixZQUFZLFFBQVEsU0FBUyxTQUFTO0VBQ3BDLE1BQU07RUFDTixLQUFLRSxVQUFVO0VBQ2YsS0FBS0MsV0FBVztFQUNoQixLQUFLQyxXQUFXLENBQUM7RUFDakIsS0FBS0MsYUFBYSxDQUFDO0VBQ25CLEtBQUtDLFVBQVUsQ0FBQztFQUNoQixLQUFLLFdBQVcsT0FBTztDQUN6QjtDQUNBLGNBQWM7RUFDWixJQUFJLEtBQUssVUFBVSxTQUFTLEdBQzFCLEtBQUtELFdBQVcsU0FBUyxhQUFhO0dBQ3BDLFNBQVMsV0FBVyxXQUFXO0lBQzdCLEtBQUtFLFVBQVUsVUFBVSxNQUFNO0dBQ2pDLENBQUM7RUFDSCxDQUFDO0NBRUw7Q0FDQSxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsS0FBSyxVQUFVLE1BQ2xCLEtBQUssUUFBUTtDQUVqQjtDQUNBLFVBQVU7RUFDUixLQUFLLDRCQUE0QixJQUFJLElBQUk7RUFDekMsS0FBS0YsV0FBVyxTQUFTLGFBQWE7R0FDcEMsU0FBUyxRQUFRO0VBQ25CLENBQUM7Q0FDSDtDQUNBLFdBQVcsU0FBUyxTQUFTO0VBQzNCLEtBQUtELFdBQVc7RUFDaEIsS0FBS0QsV0FBVztFQUMyQjtHQUN6QyxNQUFNLGNBQWMsUUFBUSxLQUN6QixVQUFVLEtBQUtELFFBQVEsb0JBQW9CLEtBQUssQ0FBQyxDQUFDLFNBQ3JEO0dBQ0EsSUFBSSxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsU0FBUyxZQUFZLFFBQzVDLFFBQVEsS0FDTix1RkFDRjtFQUVKO0VBQ0EsY0FBYyxZQUFZO0dBQ3hCLE1BQU0sZ0JBQWdCLEtBQUtHO0dBQzNCLE1BQU0scUJBQXFCLEtBQUtHLHVCQUF1QixLQUFLSixRQUFRO0dBQ3BFLG1CQUFtQixTQUNoQixVQUFVLE1BQU0sU0FBUyxXQUFXLE1BQU0scUJBQXFCLENBQ2xFO0dBQ0EsTUFBTSxlQUFlLG1CQUFtQixLQUFLLFVBQVUsTUFBTSxRQUFRO0dBQ3JFLE1BQU0sWUFBWSxhQUFhLEtBQzVCLGFBQWEsU0FBUyxpQkFBaUIsQ0FDMUM7R0FDQSxNQUFNLGtCQUFrQixjQUFjLFdBQVcsYUFBYTtHQUM5RCxNQUFNLGlCQUFpQixhQUFhLE1BQ2pDLFVBQVUsVUFBVSxhQUFhLGNBQWMsTUFDbEQ7R0FDQSxNQUFNLHNCQUFzQixtQkFBbUI7R0FDL0MsTUFBTSxrQkFBa0Isc0JBQXNCLE9BQU8sVUFBVSxNQUFNLFFBQVEsVUFBVTtJQUNyRixNQUFNLE9BQU8sS0FBS0UsUUFBUTtJQUMxQixPQUFPLENBQUMsUUFBUSxDQUFDLG9CQUFvQixRQUFRLElBQUk7R0FDbkQsQ0FBQztHQUNELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxpQkFBaUI7R0FDOUMsSUFBSSxxQkFBcUI7SUFDdkIsS0FBS0csbUJBQW1CO0lBQ3hCLEtBQUtKLGFBQWE7R0FDcEI7R0FDQSxLQUFLQyxVQUFVO0dBQ2YsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHO0dBQzFCLElBQUkscUJBQXFCO0lBQ3ZCLFdBQVcsZUFBZSxZQUFZLENBQUMsQ0FBQyxTQUFTLGFBQWE7S0FDNUQsU0FBUyxRQUFRO0lBQ25CLENBQUM7SUFDRCxXQUFXLGNBQWMsYUFBYSxDQUFDLENBQUMsU0FBUyxhQUFhO0tBQzVELFNBQVMsV0FBVyxXQUFXO01BQzdCLEtBQUtDLFVBQVUsVUFBVSxNQUFNO0tBQ2pDLENBQUM7SUFDSCxDQUFDO0dBQ0g7R0FDQSxLQUFLRyxRQUFRO0VBQ2YsQ0FBQztDQUNIO0NBQ0EsbUJBQW1CO0VBQ2pCLE9BQU8sS0FBS0o7Q0FDZDtDQUNBLGFBQWE7RUFDWCxPQUFPLEtBQUtELFdBQVcsS0FBSyxhQUFhLFNBQVMsZ0JBQWdCLENBQUM7Q0FDckU7Q0FDQSxlQUFlO0VBQ2IsT0FBTyxLQUFLQTtDQUNkO0NBQ0Esb0JBQW9CLFNBQVMsU0FBUztFQUNwQyxNQUFNLFVBQVUsS0FBS0csdUJBQXVCLE9BQU87RUFDbkQsTUFBTSxTQUFTLFFBQVEsS0FDcEIsVUFBVSxNQUFNLFNBQVMsb0JBQW9CLE1BQU0scUJBQXFCLENBQzNFO0VBQ0EsTUFBTSxjQUFjLFFBQVEsS0FDekIsVUFBVSxNQUFNLHNCQUFzQixTQUN6QztFQUNBLE9BQU87R0FDTDtJQUNDLE1BQU07SUFDTCxPQUFPLEtBQUtHLGVBQWUsS0FBSyxRQUFRLFNBQVMsV0FBVztHQUM5RDtTQUNNO0lBQ0osT0FBTyxLQUFLQyxhQUFhLFFBQVEsT0FBTztHQUMxQztFQUNGO0NBQ0Y7Q0FDQSxhQUFhLFFBQVEsU0FBUztFQUM1QixPQUFPLFFBQVEsS0FBSyxPQUFPLFVBQVU7R0FDbkMsTUFBTSxpQkFBaUIsT0FBTztHQUM5QixPQUFPLENBQUMsTUFBTSxzQkFBc0Isc0JBQXNCLE1BQU0sU0FBUyxZQUFZLGlCQUFpQixpQkFBaUI7SUFDckgsUUFBUSxTQUFTLE1BQU07S0FDckIsRUFBRSxTQUFTLFVBQVUsWUFBWTtJQUNuQyxDQUFDO0dBQ0gsQ0FBQyxJQUFJO0VBQ1AsQ0FBQztDQUNIO0NBQ0EsZUFBZSxPQUFPLFNBQVMsYUFBYTtFQUMxQyxJQUFJLFNBQVM7R0FDWCxNQUFNLGFBQWEsS0FBS0M7R0FDeEIsTUFBTSxxQkFBcUIsZ0JBQWdCLEtBQUssS0FBSyxlQUFlLEtBQUssTUFBTSxXQUFXLFdBQVcsWUFBWSxVQUFVLFlBQVksTUFBTSxNQUFNLE1BQU0sU0FBUyxXQUFXLEVBQUU7R0FDL0ssSUFBSSxDQUFDLEtBQUtDLG1CQUFtQixLQUFLUixZQUFZLEtBQUtTLGVBQWUsc0JBQXNCLFlBQVksS0FBS0MsY0FBYztJQUNySCxLQUFLQSxlQUFlO0lBQ3BCLEtBQUtELGNBQWMsS0FBS1Q7SUFDeEIsSUFBSSxnQkFBZ0IsS0FBSyxHQUN2QixLQUFLTyxtQkFBbUI7SUFFMUIsS0FBS0Msa0JBQWtCLGlCQUNyQixLQUFLQSxpQkFDTCxRQUFRLEtBQUssQ0FDZjtHQUNGO0dBQ0EsT0FBTyxLQUFLQTtFQUNkO0VBQ0EsT0FBTztDQUNUO0NBQ0EscUJBQXFCO0VBQ25CLE9BQU8sS0FBS1gsVUFBVSxZQUFZLEtBQUssS0FBSyxLQUFLRSxXQUFXLE1BQU0sVUFBVSxVQUFVO0dBQ3BGLE9BQU8sU0FBUyxRQUFRLFlBQVksS0FBS0MsUUFBUSxNQUFNLEVBQUUsU0FBUyxLQUFLO0VBQ3pFLENBQUM7Q0FDSDtDQUNBLHVCQUF1QixTQUFTO0VBQzlCLE1BQU0sbUNBQW1DLElBQUksSUFBSTtFQUNqRCxLQUFLRCxXQUFXLFNBQVMsYUFBYTtHQUNwQyxNQUFNLE1BQU0sU0FBUyxRQUFRO0dBQzdCLElBQUksQ0FBQyxLQUFLO0dBQ1YsTUFBTSxvQkFBb0IsaUJBQWlCLElBQUksR0FBRztHQUNsRCxJQUFJLG1CQUNGLGtCQUFrQixLQUFLLFFBQVE7UUFFL0IsaUJBQWlCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQztFQUV4QyxDQUFDO0VBQ0QsTUFBTSxZQUFZLENBQUM7RUFDbkIsUUFBUSxTQUFTLFlBQVk7R0FDM0IsTUFBTSxtQkFBbUIsS0FBS0gsUUFBUSxvQkFBb0IsT0FBTztHQUVqRSxNQUFNLFdBRFEsaUJBQWlCLElBQUksaUJBQWlCLFNBQVMsQ0FBQyxFQUFFLE1BQU0sS0FDNUMsSUFBSSxjQUFjLEtBQUtBLFNBQVMsZ0JBQWdCO0dBQzFFLFVBQVUsS0FBSztJQUNiLHVCQUF1QjtJQUN2QjtHQUNGLENBQUM7RUFDSCxDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsVUFBVSxVQUFVLFFBQVE7RUFDMUIsTUFBTSxRQUFRLEtBQUtHLFdBQVcsUUFBUSxRQUFRO0VBQzlDLElBQUksVUFBVSxJQUFJO0dBQ2hCLEtBQUtDLFVBQVUsVUFBVSxLQUFLQSxTQUFTLE9BQU8sTUFBTTtHQUNwRCxLQUFLSSxRQUFRO0VBQ2Y7Q0FDRjtDQUNBLFVBQVU7RUFDUixJQUFJLEtBQUssYUFBYSxHQUFHO0dBQ3ZCLE1BQU0sYUFBYSxLQUFLRSxhQUFhLEtBQUtOLFNBQVMsS0FBS0csZ0JBQWdCO0dBQ3hFLE1BQU0sb0JBQW9CLEtBQUtRLG1CQUFtQjtHQUNsRCxNQUFNLGlCQUFpQixLQUFLSDtHQUM1QixNQUFNLFlBQVksb0JBQW9CLGlCQUFpQixLQUFLSCxlQUFlLFlBQVksS0FBS1IsVUFBVSxPQUFPO0dBQzdHLElBQUkscUJBQXFCLG1CQUFtQixXQUMxQyxjQUFjLFlBQVk7SUFDeEIsS0FBSyxVQUFVLFNBQVMsYUFBYTtLQUNuQyxTQUFTLEtBQUtHLE9BQU87SUFDdkIsQ0FBQztHQUNILENBQUM7RUFFTDtDQUNGO0FBQ0Y7OztBQ2hOQSxJQUFJLGFBQWEsY0FBYyxhQUFhO0NBQzFDLFlBQVksU0FBUyxDQUFDLEdBQUc7RUFDdkIsTUFBTTtFQUNOLEtBQUssU0FBUztFQUNkLEtBQUtZLDJCQUEyQixJQUFJLElBQUk7Q0FDMUM7Q0FDQTtDQUNBLE1BQU0sUUFBUSxTQUFTLE9BQU87RUFDNUIsTUFBTSxXQUFXLFFBQVE7RUFDekIsTUFBTSxZQUFZLFFBQVEsYUFBYSxzQkFBc0IsVUFBVSxPQUFPO0VBQzlFLElBQUksUUFBUSxLQUFLLElBQUksU0FBUztFQUM5QixJQUFJLENBQUMsT0FBTztHQUNWLFFBQVEsSUFBSSxNQUFNO0lBQ2hCO0lBQ0E7SUFDQTtJQUNBLFNBQVMsT0FBTyxvQkFBb0IsT0FBTztJQUMzQztJQUNBLGdCQUFnQixPQUFPLGlCQUFpQixRQUFRO0dBQ2xELENBQUM7R0FDRCxLQUFLLElBQUksS0FBSztFQUNoQjtFQUNBLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTztFQUNULElBQUksQ0FBQyxLQUFLQSxTQUFTLElBQUksTUFBTSxTQUFTLEdBQUc7R0FDdkMsS0FBS0EsU0FBUyxJQUFJLE1BQU0sV0FBVyxLQUFLO0dBQ3hDLEtBQUssT0FBTztJQUNWLE1BQU07SUFDTjtHQUNGLENBQUM7RUFDSDtDQUNGO0NBQ0EsT0FBTyxPQUFPO0VBQ1osTUFBTSxhQUFhLEtBQUtBLFNBQVMsSUFBSSxNQUFNLFNBQVM7RUFDcEQsSUFBSSxZQUFZO0dBQ2QsTUFBTSxRQUFRO0dBQ2QsSUFBSSxlQUFlLE9BQ2pCLEtBQUtBLFNBQVMsT0FBTyxNQUFNLFNBQVM7R0FFdEMsS0FBSyxPQUFPO0lBQUUsTUFBTTtJQUFXO0dBQU0sQ0FBQztFQUN4QztDQUNGO0NBQ0EsUUFBUTtFQUNOLGNBQWMsWUFBWTtHQUN4QixLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUMvQixLQUFLLE9BQU8sS0FBSztHQUNuQixDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsSUFBSSxXQUFXO0VBQ2IsT0FBTyxLQUFLQSxTQUFTLElBQUksU0FBUztDQUNwQztDQUNBLFNBQVM7RUFDUCxPQUFPLENBQUMsR0FBRyxLQUFLQSxTQUFTLE9BQU8sQ0FBQztDQUNuQztDQUNBLEtBQUssU0FBUztFQUNaLE1BQU0sbUJBQW1CO0dBQUUsT0FBTztHQUFNLEdBQUc7RUFBUTtFQUNuRCxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsTUFDbEIsVUFBVSxXQUFXLGtCQUFrQixLQUFLLENBQy9DO0NBQ0Y7Q0FDQSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0VBQ3BCLE1BQU0sVUFBVSxLQUFLLE9BQU87RUFDNUIsT0FBTyxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxJQUFJLFFBQVEsUUFBUSxVQUFVLFdBQVcsU0FBUyxLQUFLLENBQUMsSUFBSTtDQUNuRztDQUNBLE9BQU8sT0FBTztFQUNaLGNBQWMsWUFBWTtHQUN4QixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ25DLFNBQVMsS0FBSztHQUNoQixDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsVUFBVTtFQUNSLGNBQWMsWUFBWTtHQUN4QixLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUMvQixNQUFNLFFBQVE7R0FDaEIsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLFdBQVc7RUFDVCxjQUFjLFlBQVk7R0FDeEIsS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDL0IsTUFBTSxTQUFTO0dBQ2pCLENBQUM7RUFDSCxDQUFDO0NBQ0g7QUFDRjs7O0FDN0VBLElBQUksY0FBYyxNQUFNO0NBQ3RCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZLFNBQVMsQ0FBQyxHQUFHO0VBQ3ZCLEtBQUtDLGNBQWMsT0FBTyxjQUFjLElBQUksV0FBVztFQUN2RCxLQUFLQyxpQkFBaUIsT0FBTyxpQkFBaUIsSUFBSSxjQUFjO0VBQ2hFLEtBQUtDLGtCQUFrQixPQUFPLGtCQUFrQixDQUFDO0VBQ2pELEtBQUtDLGlDQUFpQyxJQUFJLElBQUk7RUFDOUMsS0FBS0Msb0NBQW9DLElBQUksSUFBSTtFQUNqRCxLQUFLQyxjQUFjO0NBQ3JCO0NBQ0EsUUFBUTtFQUNOLEtBQUtBO0VBQ0wsSUFBSSxLQUFLQSxnQkFBZ0IsR0FBRztFQUM1QixLQUFLQyxvQkFBb0IsYUFBYSxVQUFVLE9BQU8sWUFBWTtHQUNqRSxJQUFJLFNBQVM7SUFDWCxNQUFNLEtBQUssc0JBQXNCO0lBQ2pDLEtBQUtOLFlBQVksUUFBUTtHQUMzQjtFQUNGLENBQUM7RUFDRCxLQUFLTyxxQkFBcUIsY0FBYyxVQUFVLE9BQU8sV0FBVztHQUNsRSxJQUFJLFFBQVE7SUFDVixNQUFNLEtBQUssc0JBQXNCO0lBQ2pDLEtBQUtQLFlBQVksU0FBUztHQUM1QjtFQUNGLENBQUM7Q0FDSDtDQUNBLFVBQVU7RUFDUixLQUFLSztFQUNMLElBQUksS0FBS0EsZ0JBQWdCLEdBQUc7RUFDNUIsS0FBS0Msb0JBQW9CO0VBQ3pCLEtBQUtBLG9CQUFvQixLQUFLO0VBQzlCLEtBQUtDLHFCQUFxQjtFQUMxQixLQUFLQSxxQkFBcUIsS0FBSztDQUNqQztDQUNBLFdBQVcsU0FBUztFQUNsQixPQUFPLEtBQUtQLFlBQVksUUFBUTtHQUFFLEdBQUc7R0FBUyxhQUFhO0VBQVcsQ0FBQyxDQUFDLENBQUM7Q0FDM0U7Q0FDQSxXQUFXLFNBQVM7RUFDbEIsT0FBTyxLQUFLQyxlQUFlLFFBQVE7R0FBRSxHQUFHO0dBQVMsUUFBUTtFQUFVLENBQUMsQ0FBQyxDQUFDO0NBQ3hFOzs7Ozs7OztDQVFBLGFBQWEsVUFBVTtFQUNyQixNQUFNLFVBQVUsS0FBSyxvQkFBb0IsRUFBRSxTQUFTLENBQUM7RUFDckQsT0FBTyxLQUFLRCxZQUFZLElBQUksUUFBUSxTQUFTLENBQUMsRUFBRSxNQUFNO0NBQ3hEO0NBQ0EsZ0JBQWdCLFNBQVM7RUFDdkIsTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsT0FBTztFQUN6RCxNQUFNLFFBQVEsS0FBS0EsWUFBWSxNQUFNLE1BQU0sZ0JBQWdCO0VBQzNELE1BQU0sYUFBYSxNQUFNLE1BQU07RUFDL0IsSUFBSSxlQUFlLEtBQUssR0FDdEIsT0FBTyxLQUFLLFdBQVcsT0FBTztFQUVoQyxJQUFJLFFBQVEscUJBQXFCLE1BQU0sY0FBYyxpQkFBaUIsaUJBQWlCLFdBQVcsS0FBSyxDQUFDLEdBQ3RHLEtBQVUsY0FBYyxnQkFBZ0I7RUFFMUMsT0FBTyxRQUFRLFFBQVEsVUFBVTtDQUNuQztDQUNBLGVBQWUsU0FBUztFQUN0QixPQUFPLEtBQUtBLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxZQUFZO0dBRXBFLE9BQU8sQ0FBQyxVQURLLE1BQU0sSUFDRztFQUN4QixDQUFDO0NBQ0g7Q0FDQSxhQUFhLFVBQVUsU0FBUyxTQUFTO0VBQ3ZDLE1BQU0sbUJBQW1CLEtBQUssb0JBQW9CLEVBQUUsU0FBUyxDQUFDO0VBSTlELE1BQU0sV0FIUSxLQUFLQSxZQUFZLElBQzdCLGlCQUFpQixTQUVFLENBQUMsRUFBRSxNQUFNO0VBQzlCLE1BQU0sT0FBTyxpQkFBaUIsU0FBUyxRQUFRO0VBQy9DLElBQUksU0FBUyxLQUFLLEdBQ2hCO0VBRUYsT0FBTyxLQUFLQSxZQUFZLE1BQU0sTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLFFBQVEsTUFBTTtHQUFFLEdBQUc7R0FBUyxRQUFRO0VBQUssQ0FBQztDQUNsRztDQUNBLGVBQWUsU0FBUyxTQUFTLFNBQVM7RUFDeEMsT0FBTyxjQUFjLFlBQ2IsS0FBS0EsWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxlQUFlLENBQzVELFVBQ0EsS0FBSyxhQUFhLFVBQVUsU0FBUyxPQUFPLENBQzlDLENBQUMsQ0FDSDtDQUNGO0NBQ0EsY0FBYyxVQUFVO0VBQ3RCLE1BQU0sVUFBVSxLQUFLLG9CQUFvQixFQUFFLFNBQVMsQ0FBQztFQUNyRCxPQUFPLEtBQUtBLFlBQVksSUFDdEIsUUFBUSxTQUNWLENBQUMsRUFBRTtDQUNMO0NBQ0EsY0FBYyxTQUFTO0VBQ3JCLE1BQU0sYUFBYSxLQUFLQTtFQUN4QixjQUFjLFlBQVk7R0FDeEIsV0FBVyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUM3QyxXQUFXLE9BQU8sS0FBSztHQUN6QixDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsYUFBYSxTQUFTLFNBQVM7RUFDN0IsTUFBTSxhQUFhLEtBQUtBO0VBQ3hCLE9BQU8sY0FBYyxZQUFZO0dBQy9CLFdBQVcsUUFBUSxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDN0MsTUFBTSxNQUFNO0dBQ2QsQ0FBQztHQUNELE9BQU8sS0FBSyxlQUNWO0lBQ0UsTUFBTTtJQUNOLEdBQUc7R0FDTCxHQUNBLE9BQ0Y7RUFDRixDQUFDO0NBQ0g7Q0FDQSxjQUFjLFNBQVMsZ0JBQWdCLENBQUMsR0FBRztFQUN6QyxNQUFNLHlCQUF5QjtHQUFFLFFBQVE7R0FBTSxHQUFHO0VBQWM7RUFDaEUsTUFBTSxXQUFXLGNBQWMsWUFDdkIsS0FBS0EsWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssVUFBVSxNQUFNLE9BQU8sc0JBQXNCLENBQUMsQ0FDN0Y7RUFDQSxPQUFPLFFBQVEsSUFBSSxRQUFRLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSTtDQUNwRDtDQUNBLGtCQUFrQixTQUFTLFVBQVUsQ0FBQyxHQUFHO0VBQ3ZDLE9BQU8sY0FBYyxZQUFZO0dBQy9CLEtBQUtBLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDbkQsTUFBTSxXQUFXO0dBQ25CLENBQUM7R0FDRCxJQUFJLFNBQVMsZ0JBQWdCLFFBQzNCLE9BQU8sUUFBUSxRQUFRO0dBRXpCLE9BQU8sS0FBSyxlQUNWO0lBQ0UsR0FBRztJQUNILE1BQU0sU0FBUyxlQUFlLFNBQVMsUUFBUTtHQUNqRCxHQUNBLE9BQ0Y7RUFDRixDQUFDO0NBQ0g7Q0FDQSxlQUFlLFNBQVMsVUFBVSxDQUFDLEdBQUc7RUFDcEMsTUFBTSxlQUFlO0dBQ25CLEdBQUc7R0FDSCxlQUFlLFFBQVEsaUJBQWlCO0VBQzFDO0VBQ0EsTUFBTSxXQUFXLGNBQWMsWUFDdkIsS0FBS0EsWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLFFBQVEsVUFBVSxDQUFDLE1BQU0sV0FBVyxLQUFLLENBQUMsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssVUFBVTtHQUNqSCxJQUFJLFVBQVUsTUFBTSxNQUFNLEtBQUssR0FBRyxZQUFZO0dBQzlDLElBQUksQ0FBQyxhQUFhLGNBQ2hCLFVBQVUsUUFBUSxNQUFNLElBQUk7R0FFOUIsT0FBTyxNQUFNLE1BQU0sZ0JBQWdCLFdBQVcsUUFBUSxRQUFRLElBQUk7RUFDcEUsQ0FBQyxDQUNIO0VBQ0EsT0FBTyxRQUFRLElBQUksUUFBUSxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQ3hDO0NBQ0EsV0FBVyxTQUFTO0VBQ2xCLE1BQU0sbUJBQW1CLEtBQUssb0JBQW9CLE9BQU87RUFDekQsSUFBSSxpQkFBaUIsVUFBVSxLQUFLLEdBQ2xDLGlCQUFpQixRQUFRO0VBRTNCLE1BQU0sUUFBUSxLQUFLQSxZQUFZLE1BQU0sTUFBTSxnQkFBZ0I7RUFDM0QsT0FBTyxNQUFNLGNBQ1gsaUJBQWlCLGlCQUFpQixXQUFXLEtBQUssQ0FDcEQsSUFBSSxNQUFNLE1BQU0sZ0JBQWdCLElBQUksUUFBUSxRQUFRLE1BQU0sTUFBTSxJQUFJO0NBQ3RFO0NBQ0EsY0FBYyxTQUFTO0VBQ3JCLE9BQU8sS0FBSyxXQUFXLE9BQU8sQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQ3ZEO0NBQ0EsbUJBQW1CLFNBQVM7RUFDMUIsUUFBUSxRQUFRO0VBQ2hCLE9BQU8sS0FBSyxXQUFXLE9BQU87Q0FDaEM7Q0FDQSxzQkFBc0IsU0FBUztFQUM3QixPQUFPLEtBQUssbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQy9EO0NBQ0Esd0JBQXdCLFNBQVM7RUFDL0IsUUFBUSxRQUFRO0VBQ2hCLE9BQU8sS0FBSyxnQkFBZ0IsT0FBTztDQUNyQztDQUNBLHdCQUF3QjtFQUN0QixJQUFJLGNBQWMsU0FBUyxHQUN6QixPQUFPLEtBQUtDLGVBQWUsc0JBQXNCO0VBRW5ELE9BQU8sUUFBUSxRQUFRO0NBQ3pCO0NBQ0EsZ0JBQWdCO0VBQ2QsT0FBTyxLQUFLRDtDQUNkO0NBQ0EsbUJBQW1CO0VBQ2pCLE9BQU8sS0FBS0M7Q0FDZDtDQUNBLG9CQUFvQjtFQUNsQixPQUFPLEtBQUtDO0NBQ2Q7Q0FDQSxrQkFBa0IsU0FBUztFQUN6QixLQUFLQSxrQkFBa0I7Q0FDekI7Q0FDQSxpQkFBaUIsVUFBVSxTQUFTO0VBQ2xDLEtBQUtDLGVBQWUsSUFBSSxRQUFRLFFBQVEsR0FBRztHQUN6QztHQUNBLGdCQUFnQjtFQUNsQixDQUFDO0NBQ0g7Q0FDQSxpQkFBaUIsVUFBVTtFQUN6QixNQUFNLFdBQVcsQ0FBQyxHQUFHLEtBQUtBLGVBQWUsT0FBTyxDQUFDO0VBQ2pELE1BQU0sU0FBUyxDQUFDO0VBQ2hCLFNBQVMsU0FBUyxpQkFBaUI7R0FDakMsSUFBSSxnQkFBZ0IsVUFBVSxhQUFhLFFBQVEsR0FDakQsT0FBTyxPQUFPLFFBQVEsYUFBYSxjQUFjO0VBRXJELENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxvQkFBb0IsYUFBYSxTQUFTO0VBQ3hDLEtBQUtDLGtCQUFrQixJQUFJLFFBQVEsV0FBVyxHQUFHO0dBQy9DO0dBQ0EsZ0JBQWdCO0VBQ2xCLENBQUM7Q0FDSDtDQUNBLG9CQUFvQixhQUFhO0VBQy9CLE1BQU0sV0FBVyxDQUFDLEdBQUcsS0FBS0Esa0JBQWtCLE9BQU8sQ0FBQztFQUNwRCxNQUFNLFNBQVMsQ0FBQztFQUNoQixTQUFTLFNBQVMsaUJBQWlCO0dBQ2pDLElBQUksZ0JBQWdCLGFBQWEsYUFBYSxXQUFXLEdBQ3ZELE9BQU8sT0FBTyxRQUFRLGFBQWEsY0FBYztFQUVyRCxDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0Esb0JBQW9CLFNBQVM7RUFDM0IsSUFBSSxRQUFRLFlBQ1YsT0FBTztFQUVULE1BQU0sbUJBQW1CO0dBQ3ZCLEdBQUcsS0FBS0YsZ0JBQWdCO0dBQ3hCLEdBQUcsS0FBSyxpQkFBaUIsUUFBUSxRQUFRO0dBQ3pDLEdBQUc7R0FDSCxZQUFZO0VBQ2Q7RUFDQSxJQUFJLENBQUMsaUJBQWlCLFdBQ3BCLGlCQUFpQixZQUFZLHNCQUMzQixpQkFBaUIsVUFDakIsZ0JBQ0Y7RUFFRixJQUFJLGlCQUFpQix1QkFBdUIsS0FBSyxHQUMvQyxpQkFBaUIscUJBQXFCLGlCQUFpQixnQkFBZ0I7RUFFekUsSUFBSSxpQkFBaUIsaUJBQWlCLEtBQUssR0FDekMsaUJBQWlCLGVBQWUsQ0FBQyxDQUFDLGlCQUFpQjtFQUVyRCxJQUFJLENBQUMsaUJBQWlCLGVBQWUsaUJBQWlCLFdBQ3BELGlCQUFpQixjQUFjO0VBRWpDLElBQUksaUJBQWlCLFlBQVksV0FDL0IsaUJBQWlCLFVBQVU7RUFFN0IsT0FBTztDQUNUO0NBQ0EsdUJBQXVCLFNBQVM7RUFDOUIsSUFBSSxTQUFTLFlBQ1gsT0FBTztFQUVULE9BQU87R0FDTCxHQUFHLEtBQUtBLGdCQUFnQjtHQUN4QixHQUFHLFNBQVMsZUFBZSxLQUFLLG9CQUFvQixRQUFRLFdBQVc7R0FDdkUsR0FBRztHQUNILFlBQVk7RUFDZDtDQUNGO0NBQ0EsUUFBUTtFQUNOLEtBQUtGLFlBQVksTUFBTTtFQUN2QixLQUFLQyxlQUFlLE1BQU07Q0FDNUI7QUFDRjs7O0FDelNBLFNBQVMsY0FBYyxFQUNyQixVQUNBLGNBQWMsU0FDZCxXQUFXLE9BQU8sVUFBVSxTQUFTLE9BQU8sS0FBSyxHQUNqRCxlQUFlLENBQUMsS0FDZjtDQUNELE9BQU8sT0FBTyxZQUFZO0VBQ3hCLE1BQU0sUUFBUSxRQUFRLE9BQU8sY0FBYyxDQUFDLENBQUMsS0FBSztHQUFFLFVBQVUsUUFBUTtHQUFVLE9BQU87RUFBSyxDQUFDO0VBQzdGLE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxNQUFNLFVBQVU7RUFDN0MsSUFBSSxhQUFhLGdCQUFnQixTQUMvQixNQUFNLFNBQVM7R0FDYixHQUFHLE1BQU07R0FDVCxhQUFhO0VBQ2YsQ0FBQztFQUVILElBQUksU0FBUztFQUNiLElBQUksWUFBWTtFQVloQixNQUFNLFNBQVMsTUFBTSxTQVhHLHNCQUN0QjtHQUNFLFFBQVEsUUFBUTtHQUNoQixNQUFNLFFBQVE7R0FDZCxVQUFVLFFBQVE7R0FDbEIsV0FBVyxRQUFRO0dBQ25CLFdBQVcsUUFBUTtFQUNyQixTQUNNLFFBQVEsY0FDUixZQUFZLElBRXdCLENBQUM7RUFDN0MsTUFBTSxtQkFBbUIsYUFBYSxnQkFBZ0I7RUFDdEQsV0FBVyxNQUFNLFNBQVMsUUFBUTtHQUNoQyxJQUFJLFdBQ0Y7R0FFRixJQUFJLGtCQUNGLFNBQVMsUUFBUSxRQUFRLEtBQUs7UUFFOUIsUUFBUSxPQUFPLGFBQ2IsUUFBUSxXQUNQLFNBQVMsUUFBUSxTQUFTLEtBQUssSUFBSSxlQUFlLE1BQU0sS0FBSyxDQUNoRTtFQUVKO0VBQ0EsSUFBSSxvQkFBb0IsQ0FBQyxXQUN2QixRQUFRLE9BQU8sYUFBYSxRQUFRLFVBQVUsTUFBTTtFQUV0RCxPQUFPLFFBQVEsT0FBTyxhQUFhLFFBQVEsUUFBUSxLQUFLO0NBQzFEO0FBQ0Y7OztBQ2pEQSxJQUFJLGdCQUFnQyx1QkFBTyxlQUFlO0FBQzFELElBQUkscUJBQXFDLHVCQUFPLG9CQUFvQjtBQUNwRSxJQUFJLGNBQThCLHVCQUFPLGFBQWE7Ozs7O0FDRXRELElBQUkscUJBQUEsYUFBMkIsY0FDN0IsS0FBSyxDQUNQO0FBQ0EsSUFBSSxrQkFBa0IsZ0JBQWdCO0NBQ3BDLE1BQU0sU0FBQSxhQUFlLFdBQVcsa0JBQWtCO0NBQ2xELElBQUksYUFDRixPQUFPO0NBRVQsSUFBSSxDQUFDLFFBQ0gsTUFBTSxJQUFJLE1BQU0sd0RBQXdEO0NBRTFFLE9BQU87QUFDVDtBQUNBLElBQUksdUJBQXVCLEVBQ3pCLFFBQ0EsZUFDSTtDQUNKLGFBQU0sZ0JBQWdCO0VBQ3BCLE9BQU8sTUFBTTtFQUNiLGFBQWE7R0FDWCxPQUFPLFFBQVE7RUFDakI7Q0FDRixHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ1gsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksbUJBQW1CLFVBQVU7RUFBRSxPQUFPO0VBQVE7Q0FBUyxDQUFDO0FBQ3JGOzs7QUN6QkEsSUFBSSxxQkFBQSxhQUEyQixjQUFjLEtBQUs7QUFDbEQsSUFBSSx1QkFBQSxhQUE2QixXQUFXLGtCQUFrQjtBQUM5RCxJQUFJLHNCQUFzQixtQkFBbUI7OztBQ0Q3QyxTQUFTLGNBQWM7Q0FDckIsSUFBSSxVQUFVO0NBQ2QsT0FBTztFQUNMLGtCQUFrQjtHQUNoQixVQUFVO0VBQ1o7RUFDQSxhQUFhO0dBQ1gsVUFBVTtFQUNaO0VBQ0EsZUFBZTtHQUNiLE9BQU87RUFDVDtDQUNGO0FBQ0Y7QUFDQSxJQUFJLGlDQUFBLGFBQXVDLGNBQWMsWUFBWSxDQUFDO0FBQ3RFLElBQUksbUNBQUEsYUFBeUMsV0FBVyw4QkFBOEI7QUFDdEYsSUFBSSwyQkFBMkIsRUFDN0IsZUFDSTtDQUNKLE1BQU0sQ0FBQyxTQUFBLGFBQWUsZUFBZSxZQUFZLENBQUM7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksK0JBQStCLFVBQVU7RUFBRTtFQUFPLFVBQVUsT0FBTyxhQUFhLGFBQWEsU0FBUyxLQUFLLElBQUk7Q0FBUyxDQUFDO0FBQ3RKOzs7QUNyQkEsSUFBSSxtQ0FBbUMsU0FBUyxvQkFBb0IsVUFBVTtDQUM1RSxNQUFNLGVBQWUsT0FBTyxNQUFNLFNBQVMsT0FBTyxRQUFRLGlCQUFpQixhQUFhLGlCQUFpQixRQUFRLGNBQWMsQ0FBQyxNQUFNLE1BQU0sT0FBTyxLQUFLLENBQUMsSUFBSSxRQUFRO0NBQ3JLLElBQUksUUFBUSxZQUFZLFFBQVEsaUNBQWlDLGNBQzNEO01BQUEsQ0FBQyxtQkFBbUIsUUFBUSxHQUM5QixRQUFRLGVBQWU7Q0FBQTtBQUc3QjtBQUNBLElBQUksOEJBQThCLHVCQUF1QjtDQUN2RCxhQUFNLGdCQUFnQjtFQUNwQixtQkFBbUIsV0FBVztDQUNoQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7QUFDekI7QUFDQSxJQUFJLGVBQWUsRUFDakIsUUFDQSxvQkFDQSxjQUNBLE9BQ0EsZUFDSTtDQUNKLE9BQU8sT0FBTyxXQUFXLENBQUMsbUJBQW1CLFFBQVEsS0FBSyxDQUFDLE9BQU8sY0FBYyxVQUFVLFlBQVksT0FBTyxTQUFTLEtBQUssS0FBSyxpQkFBaUIsY0FBYyxDQUFDLE9BQU8sT0FBTyxLQUFLLENBQUM7QUFDdEw7OztBQ3pCQSxJQUFJLHVCQUF1QixRQUFRLFVBQVUsTUFBTSxNQUFNLFNBQVMsS0FBSztBQUN2RSxJQUFJLHdCQUF3QixxQkFBcUI7Q0FDL0MsSUFBSSxpQkFBaUIsVUFBVTtFQUM3QixNQUFNLHVCQUF1QjtFQUM3QixNQUFNLFNBQVMsVUFBVSxVQUFVLFdBQVcsUUFBUSxLQUFLLElBQUksU0FBUyxzQkFBc0Isb0JBQW9CO0VBQ2xILE1BQU0sb0JBQW9CLGlCQUFpQjtFQUMzQyxpQkFBaUIsWUFBWSxPQUFPLHNCQUFzQixjQUFjLEdBQUcsU0FBUyxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxJQUFJLE1BQU0saUJBQWlCO0VBQy9JLElBQUksT0FBTyxpQkFBaUIsV0FBVyxVQUNyQyxpQkFBaUIsU0FBUyxLQUFLLElBQzdCLGlCQUFpQixRQUNqQixvQkFDRjtDQUVKO0FBQ0Y7QUFDQSxJQUFJLGFBQWEsUUFBUSxnQkFBZ0IsT0FBTyxhQUFhLE9BQU8sY0FBYyxDQUFDO0FBQ25GLElBQUksaUJBQWlCLGtCQUFrQixXQUFXLGtCQUFrQixZQUFZLE9BQU87QUFDdkYsSUFBSSxtQkFBbUIsa0JBQWtCLFVBQVUsdUJBQXVCLFNBQVMsZ0JBQWdCLGdCQUFnQixDQUFDLENBQUMsWUFBWTtDQUMvSCxtQkFBbUIsV0FBVztBQUNoQyxDQUFDOzs7QUNHRCxTQUFTLFdBQVcsRUFDbEIsU0FDQSxHQUFHLFdBQ0YsYUFBYTtDQUNkLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxxQkFBcUIsMkJBQTJCO0NBQ3RELE1BQU0sbUJBQUEsYUFBeUIsY0FDdkIsUUFBUSxLQUFLLFNBQVM7RUFDMUIsTUFBTSxtQkFBbUIsT0FBTyxvQkFDOUIsSUFDRjtFQUNBLGlCQUFpQixxQkFBcUIsY0FBYyxnQkFBZ0I7RUFDcEUsT0FBTztDQUNULENBQUMsR0FDRDtFQUFDO0VBQVM7RUFBUTtDQUFXLENBQy9CO0NBQ0EsaUJBQWlCLFNBQVMsaUJBQWlCO0VBQ3pDLHFCQUFxQixZQUFZO0VBQ2pDLE1BQU0sUUFBUSxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksYUFBYSxTQUFTO0VBQy9ELGdDQUFnQyxjQUFjLG9CQUFvQixLQUFLO0NBQ3pFLENBQUM7Q0FDRCwyQkFBMkIsa0JBQWtCO0NBQzdDLE1BQU0sQ0FBQyxZQUFBLGFBQWtCLGVBQ2pCLElBQUksZ0JBQ1IsUUFDQSxrQkFDQSxPQUNGLENBQ0Y7Q0FDQSxNQUFNLENBQUMsa0JBQWtCLG1CQUFtQixlQUFlLFNBQVMsb0JBQ2xFLGtCQUNBLFFBQVEsT0FDVjtDQUNBLE1BQU0sa0JBQWtCLENBQUMsZUFBZSxRQUFRLGVBQWU7Q0FDL0QsYUFBTSxxQkFBQSxhQUNFLGFBQ0gsa0JBQWtCLGtCQUFrQixTQUFTLFVBQVUsY0FBYyxXQUFXLGFBQWEsQ0FBQyxJQUFJLE1BQ25HLENBQUMsVUFBVSxlQUFlLENBQzVCLFNBQ00sU0FBUyxpQkFBaUIsU0FDMUIsU0FBUyxpQkFBaUIsQ0FDbEM7Q0FDQSxhQUFNLGdCQUFnQjtFQUNwQixTQUFTLFdBQ1Asa0JBQ0EsT0FDRjtDQUNGLEdBQUc7RUFBQztFQUFrQjtFQUFTO0NBQVEsQ0FBQztDQUl4QyxNQUFNLG1CQUgwQixpQkFBaUIsTUFDOUMsUUFBUSxVQUFVLGNBQWMsaUJBQWlCLFFBQVEsTUFBTSxDQUVuQixJQUFJLGlCQUFpQixTQUFTLFFBQVEsVUFBVTtFQUM3RixNQUFNLE9BQU8saUJBQWlCO0VBQzlCLElBQUksUUFBUSxjQUFjLE1BQU0sTUFBTSxHQUVwQyxPQUFPLGdCQUFnQixNQUFNLElBREgsY0FBYyxRQUFRLElBQ25CLEdBQWUsa0JBQWtCO0VBRWhFLE9BQU8sQ0FBQztDQUNWLENBQUMsSUFBSSxDQUFDO0NBQ04sSUFBSSxpQkFBaUIsU0FBUyxHQUM1QixNQUFNLFFBQVEsSUFBSSxnQkFBZ0I7Q0FFcEMsTUFBTSxvQ0FBb0MsaUJBQWlCLE1BQ3hELFFBQVEsVUFBVTtFQUNqQixNQUFNLFFBQVEsaUJBQWlCO0VBQy9CLE9BQU8sU0FBUyxZQUFZO0dBQzFCO0dBQ0E7R0FDQSxjQUFjLE1BQU07R0FDcEIsT0FBTyxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksTUFBTSxTQUFTO0dBQ2pELFVBQVUsTUFBTTtFQUNsQixDQUFDO0NBQ0gsQ0FDRjtDQUNBLElBQUksbUNBQW1DLE9BQ3JDLE1BQU0sa0NBQWtDO0NBRTFDLE9BQU8sa0JBQWtCLFlBQVksQ0FBQztBQUN4Qzs7O0FDbkZBLFNBQVMsYUFBYSxTQUFTLFVBQVUsYUFBYTtDQUVsRCxJQUFJLE9BQU8sWUFBWSxZQUFZLE1BQU0sUUFBUSxPQUFPLEdBQ3RELE1BQU0sSUFBSSxNQUNSLGdTQUNGO0NBR0osTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxxQkFBcUIsMkJBQTJCO0NBQ3RELE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxtQkFBbUIsT0FBTyxvQkFBb0IsT0FBTztDQUMzRCxPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUyw0QkFDbEMsZ0JBQ0Y7Q0FDQSxNQUFNLFFBQVEsT0FBTyxjQUFjLENBQUMsQ0FBQyxJQUFJLGlCQUFpQixTQUFTO0NBRWpFLElBQUksQ0FBQyxpQkFBaUIsU0FDcEIsUUFBUSxNQUNOLElBQUksaUJBQWlCLFVBQVUsbVBBQ2pDO0NBR0osTUFBTSxhQUFhLFFBQVEsZUFBZTtDQUMxQyxpQkFBaUIscUJBQXFCLGNBQWMsZ0JBQWdCLGFBQWEsZUFBZSxLQUFLO0NBQ3JHLHFCQUFxQixnQkFBZ0I7Q0FDckMsZ0NBQWdDLGtCQUFrQixvQkFBb0IsS0FBSztDQUMzRSwyQkFBMkIsa0JBQWtCO0NBQzdDLE1BQU0sa0JBQWtCLENBQUMsT0FBTyxjQUFjLENBQUMsQ0FBQyxJQUFJLGlCQUFpQixTQUFTO0NBQzlFLE1BQU0sQ0FBQyxZQUFBLGFBQWtCLGVBQ2pCLElBQUksU0FDUixRQUNBLGdCQUNGLENBQ0Y7Q0FDQSxNQUFNLFNBQVMsU0FBUyxvQkFBb0IsZ0JBQWdCO0NBQzVELE1BQU0sa0JBQWtCLENBQUMsZUFBZTtDQUN4QyxhQUFNLHFCQUFBLGFBQ0UsYUFDSCxrQkFBa0I7RUFDakIsTUFBTSxjQUFjLGtCQUFrQixTQUFTLFVBQVUsY0FBYyxXQUFXLGFBQWEsQ0FBQyxJQUFJO0VBQ3BHLFNBQVMsYUFBYTtFQUN0QixPQUFPO0NBQ1QsR0FDQSxDQUFDLFVBQVUsZUFBZSxDQUM1QixTQUNNLFNBQVMsaUJBQWlCLFNBQzFCLFNBQVMsaUJBQWlCLENBQ2xDO0NBQ0EsYUFBTSxnQkFBZ0I7RUFDcEIsU0FBUyxXQUFXLGdCQUFnQjtDQUN0QyxHQUFHLENBQUMsa0JBQWtCLFFBQVEsQ0FBQztDQUMvQixJQUFJLGNBQWMsa0JBQWtCLE1BQU0sR0FDeEMsTUFBTSxnQkFBZ0Isa0JBQWtCLFVBQVUsa0JBQWtCO0NBRXRFLElBQUksWUFBWTtFQUNkO0VBQ0E7RUFDQSxjQUFjLGlCQUFpQjtFQUMvQjtFQUNBLFVBQVUsaUJBQWlCO0NBQzdCLENBQUMsR0FDQyxNQUFNLE9BQU87Q0FHZixPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUywyQkFDbEMsa0JBQ0EsTUFDRjtDQUNBLElBQUksaUJBQWlCLGlDQUFpQyxDQUFDLG1CQUFtQixTQUFTLEtBQUssVUFBVSxRQUFRLFdBQVcsR0FRbkgsQ0FQZ0Isa0JBRWQsZ0JBQWdCLGtCQUFrQixVQUFVLGtCQUFrQixJQUc5RCxPQUFPLFFBQUEsRUFFQSxNQUFNLElBQUksQ0FBQyxDQUFDLGNBQWM7RUFDakMsU0FBUyxhQUFhO0NBQ3hCLENBQUM7Q0FFSCxPQUFPLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLFlBQVksTUFBTSxJQUFJO0FBQ2hGOzs7QUNoR0EsU0FBUyxTQUFTLFNBQVMsYUFBYTtDQUN0QyxPQUFPLGFBQWEsU0FBUyxlQUFlLFdBQVc7QUFDekQ7OztBQ0RBLFNBQVMsaUJBQWlCLFNBQVMsYUFBYTtDQUU1QyxJQUFJLFFBQVEsWUFBWSxXQUN0QixRQUFRLE1BQU0sK0NBQStDO0NBR2pFLE9BQU8sYUFDTDtFQUNFLEdBQUc7RUFDSCxTQUFTO0VBQ1QsVUFBVTtFQUNWLGNBQWM7RUFDZCxpQkFBaUIsS0FBSztDQUN4QixHQUNBLGVBQ0EsV0FDRjtBQUNGOzs7QUNqQkEsU0FBUyx5QkFBeUIsU0FBUyxhQUFhO0NBRXBELElBQUksUUFBUSxZQUFZLFdBQ3RCLFFBQVEsTUFBTSx1REFBdUQ7Q0FHekUsT0FBTyxhQUNMO0VBQ0UsR0FBRztFQUNILFNBQVM7RUFDVCxVQUFVO0VBQ1YsY0FBYztDQUNoQixHQUNBLHVCQUNBLFdBQ0Y7QUFDRjs7O0FDaEJBLFNBQVMsbUJBQW1CLFNBQVMsYUFBYTtDQUNoRCxPQUFPLFdBQ0w7RUFDRSxHQUFHO0VBQ0gsU0FBUyxRQUFRLFFBQVEsS0FBSyxVQUFVO0dBRXBDLElBQUksTUFBTSxZQUFZLFdBQ3BCLFFBQVEsTUFBTSxpREFBaUQ7R0FHbkUsT0FBTztJQUNMLEdBQUc7SUFDSCxVQUFVO0lBQ1YsY0FBYztJQUNkLFNBQVM7SUFDVCxpQkFBaUIsS0FBSztHQUN4QjtFQUNGLENBQUM7Q0FDSCxHQUNBLFdBQ0Y7QUFDRjs7O0FDekJBLFNBQVMsaUJBQWlCLFNBQVMsYUFBYTtDQUM5QyxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLElBQUksQ0FBQyxPQUFPLGNBQWMsUUFBUSxRQUFRLEdBQ3hDLE9BQU8sY0FBYyxPQUFPO0FBRWhDOzs7QUNMQSxTQUFTLHlCQUF5QixTQUFTLGFBQWE7Q0FDdEQsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxJQUFJLENBQUMsT0FBTyxjQUFjLFFBQVEsUUFBUSxHQUN4QyxPQUFPLHNCQUFzQixPQUFPO0FBRXhDOzs7QUNOQSxTQUFTLGFBQWEsU0FBUztDQUM3QixPQUFPO0FBQ1Q7OztBQ0ZBLFNBQVMscUJBQXFCLFNBQVM7Q0FDckMsT0FBTztBQUNUOzs7QUNHQSxJQUFJLHFCQUFxQixFQUN2QixVQUNBLFVBQVUsQ0FBQyxHQUNYLE9BQ0Esa0JBQ0k7Q0FDSixNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE1BQU0sYUFBQSxhQUFtQixPQUFPLE9BQU87Q0FDdkMsYUFBTSxnQkFBZ0I7RUFDcEIsV0FBVyxVQUFVO0NBQ3ZCLENBQUM7Q0FDRCxNQUFNLGlCQUFBLGFBQXVCLGNBQWM7RUFDekMsSUFBSSxPQUFPO0dBQ1QsSUFBSSxPQUFPLFVBQVUsVUFDbkI7R0FFRixNQUFNLGFBQWEsT0FBTyxjQUFjO0dBQ3hDLE1BQU0sVUFBVSxNQUFNLFdBQVcsQ0FBQztHQUNsQyxNQUFNLGFBQWEsQ0FBQztHQUNwQixNQUFNLGtCQUFrQixDQUFDO0dBQ3pCLEtBQUssTUFBTSxtQkFBbUIsU0FBUztJQUNyQyxNQUFNLGdCQUFnQixXQUFXLElBQUksZ0JBQWdCLFNBQVM7SUFDOUQsSUFBSSxDQUFDLGVBQ0gsV0FBVyxLQUFLLGVBQWU7U0FHL0IsSUFEeUIsZ0JBQWdCLE1BQU0sZ0JBQWdCLGNBQWMsTUFBTSxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYyxNQUFNLFdBQVcsYUFBYSxjQUFjLE1BQU0sZ0JBQWdCLGNBQWMsZ0JBQWdCLGlCQUFpQixLQUFLLEtBQUssZ0JBQWdCLGVBQWUsY0FBYyxNQUFNLGVBRXpULGdCQUFnQixLQUFLLGVBQWU7R0FHMUM7R0FDQSxJQUFJLFdBQVcsU0FBUyxHQUN0QixRQUFRLFFBQVEsRUFBRSxTQUFTLFdBQVcsR0FBRyxXQUFXLE9BQU87R0FFN0QsSUFBSSxnQkFBZ0IsU0FBUyxHQUMzQixPQUFPO0VBRVg7Q0FFRixHQUFHLENBQUMsUUFBUSxLQUFLLENBQUM7Q0FDbEIsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxnQkFDRixRQUFRLFFBQVEsRUFBRSxTQUFTLGVBQWUsR0FBRyxXQUFXLE9BQU87Q0FFbkUsR0FBRyxDQUFDLFFBQVEsY0FBYyxDQUFDO0NBQzNCLE9BQU87QUFDVDs7O0FDOUNBLFNBQVMsY0FBYyxTQUFTLGFBQWE7Q0FDM0MsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLGFBQWEsT0FBTyxjQUFjO0NBQ3hDLE9BQUEsYUFBYSxxQkFBQSxhQUNMLGFBQ0gsa0JBQWtCLFdBQVcsVUFBVSxjQUFjLFdBQVcsYUFBYSxDQUFDLEdBQy9FLENBQUMsVUFBVSxDQUNiLFNBQ00sT0FBTyxXQUFXLE9BQU8sU0FDekIsT0FBTyxXQUFXLE9BQU8sQ0FDakM7QUFDRjs7O0FDWEEsU0FBUyxjQUFjLFNBQVMsYUFBYTtDQUMzQyxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE9BQU8saUJBQ0wsRUFBRSxTQUFTO0VBQUUsR0FBRztFQUFTLFFBQVE7Q0FBVSxFQUFFLEdBQzdDLE1BQ0YsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxTQUFTLFVBQVUsZUFBZSxTQUFTO0NBQ3pDLE9BQU8sY0FBYyxRQUFRLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FDM0MsYUFBYSxRQUFRLFNBQVMsUUFBUSxPQUFPLFFBQVEsSUFBSSxTQUFTLEtBQ3JFO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQixVQUFVLENBQUMsR0FBRyxhQUFhO0NBQ25ELE1BQU0sZ0JBQWdCLGVBQWUsV0FBVyxDQUFDLENBQUMsaUJBQWlCO0NBQ25FLE1BQU0sYUFBQSxhQUFtQixPQUFPLE9BQU87Q0FDdkMsTUFBTSxTQUFBLGFBQWUsT0FBTyxJQUFJO0NBQ2hDLElBQUksT0FBTyxZQUFZLE1BQ3JCLE9BQU8sVUFBVSxVQUFVLGVBQWUsT0FBTztDQUVuRCxhQUFNLGdCQUFnQjtFQUNwQixXQUFXLFVBQVU7Q0FDdkIsQ0FBQztDQUNELE9BQUEsYUFBYSxxQkFBQSxhQUNMLGFBQ0gsa0JBQWtCLGNBQWMsZ0JBQWdCO0VBQy9DLE1BQU0sYUFBYSxpQkFDakIsT0FBTyxTQUNQLFVBQVUsZUFBZSxXQUFXLE9BQU8sQ0FDN0M7RUFDQSxJQUFJLE9BQU8sWUFBWSxZQUFZO0dBQ2pDLE9BQU8sVUFBVTtHQUNqQixjQUFjLFNBQVMsYUFBYTtFQUN0QztDQUNGLENBQUMsR0FDRCxDQUFDLGFBQWEsQ0FDaEIsU0FDTSxPQUFPLGVBQ1AsT0FBTyxPQUNmO0FBQ0Y7OztBQ2xDQSxTQUFTLFlBQVksU0FBUyxhQUFhO0NBQ3pDLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxDQUFDLFlBQUEsYUFBa0IsZUFDakIsSUFBSSxpQkFDUixRQUNBLE9BQ0YsQ0FDRjtDQUNBLGFBQU0sZ0JBQWdCO0VBQ3BCLFNBQVMsV0FBVyxPQUFPO0NBQzdCLEdBQUcsQ0FBQyxVQUFVLE9BQU8sQ0FBQztDQUN0QixNQUFNLFNBQUEsYUFBZSxxQkFBQSxhQUNiLGFBQ0gsa0JBQWtCLFNBQVMsVUFBVSxjQUFjLFdBQVcsYUFBYSxDQUFDLEdBQzdFLENBQUMsUUFBUSxDQUNYLFNBQ00sU0FBUyxpQkFBaUIsU0FDMUIsU0FBUyxpQkFBaUIsQ0FDbEM7Q0FDQSxNQUFNLFNBQUEsYUFBZSxhQUNsQixXQUFXLGtCQUFrQjtFQUM1QixTQUFTLE9BQU8sV0FBVyxhQUFhLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDdEQsR0FDQSxDQUFDLFFBQVEsQ0FDWDtDQUNBLElBQUksT0FBTyxTQUFTLGlCQUFpQixTQUFTLFFBQVEsY0FBYyxDQUFDLE9BQU8sS0FBSyxDQUFDLEdBQ2hGLE1BQU0sT0FBTztDQUVmLE9BQU87RUFBRSxHQUFHO0VBQVE7RUFBUSxhQUFhLE9BQU87Q0FBTztBQUN6RDs7O0FDdkNBLFNBQVMsZ0JBQWdCLFNBQVM7Q0FDaEMsT0FBTztBQUNUOzs7QUNFQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FDOUMsT0FBTyxhQUNMLFNBQ0EsdUJBQ0EsV0FDRjtBQUNGIn0=