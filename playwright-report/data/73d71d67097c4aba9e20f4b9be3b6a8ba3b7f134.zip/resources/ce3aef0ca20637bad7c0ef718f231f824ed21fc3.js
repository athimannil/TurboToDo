import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/todos/index.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Panel } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/index.ts";
import { Todos, CreateTodoForm } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/index.ts?t=1785728509668";
import { useAtom } from "/node_modules/.vite/deps/jotai.js?v=f71da48c";
import { selectedUserIdAtom } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/index.ts";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/todos/index.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
var _s = $RefreshSig$();
const TodosPage = () => {
	_s();
	const [selectedUserId, setSelectedUserId] = useAtom(selectedUserIdAtom);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-8",
		children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("h1", {
			className: "text-3xl font-semibold tracking-tight text-foreground",
			children: "Add Todos"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: "Create a new todo or select an existing todo to view and manage its details."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]",
			children: [/* @__PURE__ */ _jsxDEV(Panel, {
				title: "Create Todo",
				description: "Fill out the form to create a new todo.",
				children: /* @__PURE__ */ _jsxDEV(CreateTodoForm, {
					selectedUserId,
					setSelectedUserId
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(Panel, {
				title: "Existing Todos",
				description: selectedUserId ? "Filtered todos for selected user." : "All todos from all users.",
				children: /* @__PURE__ */ _jsxDEV(Todos, { userId: selectedUserId }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
};
_s(TodosPage, "douEyBeDmPPFeRSzGeCo1uAsGis=", false, function() {
	return [useAtom];
});
_c = TodosPage;
export default TodosPage;
var _c;
$RefreshReg$(_c, "TodosPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/todos/index.tsx?t=1785728509668";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/todos/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/todos/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/todos/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsT0FBTyxzQkFBc0I7QUFDdEMsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsMEJBQTBCOzs7O0FBRW5DLE1BQU0sa0JBQWtCOztDQUN0QixNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixRQUFRLGtCQUFrQjtDQUV0RSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxVQUFELGFBQ0Usd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFBd0Q7RUFFbEU7Ozs7WUFDSix3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUFxQztFQUcvQzs7OztVQUNHOzs7O1lBRVIsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQ7SUFDRSxPQUFNO0lBQ04sYUFBWTtjQUVaLHdCQUFDLGdCQUFEO0tBQ2tCO0tBQ0c7SUFDcEI7Ozs7O0dBQ0k7Ozs7YUFDUCx3QkFBQyxPQUFEO0lBQ0UsT0FBTTtJQUNOLGFBQ0UsaUJBQ0ksc0NBQ0E7Y0FHTix3QkFBQyxPQUFELEVBQU8sUUFBUSxlQUFpQjs7Ozs7R0FDM0I7Ozs7V0FDSjs7Ozs7VUFDRjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFuZWwgfSBmcm9tIFwiQHJlcG8vc2hhcmVkXCI7XG5pbXBvcnQgeyBUb2RvcywgQ3JlYXRlVG9kb0Zvcm0gfSBmcm9tIFwiQHJlcG8vdG9kb3NcIjtcbmltcG9ydCB7IHVzZUF0b20gfSBmcm9tIFwiam90YWlcIjtcbmltcG9ydCB7IHNlbGVjdGVkVXNlcklkQXRvbSB9IGZyb20gXCJAcmVwby9zaGFyZWRcIjtcblxuY29uc3QgVG9kb3NQYWdlID0gKCkgPT4ge1xuICBjb25zdCBbc2VsZWN0ZWRVc2VySWQsIHNldFNlbGVjdGVkVXNlcklkXSA9IHVzZUF0b20oc2VsZWN0ZWRVc2VySWRBdG9tKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtOFwiPlxuICAgICAgPGhlYWRlcj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgQWRkIFRvZG9zXG4gICAgICAgIDwvaDE+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICBDcmVhdGUgYSBuZXcgdG9kbyBvciBzZWxlY3QgYW4gZXhpc3RpbmcgdG9kbyB0byB2aWV3IGFuZCBtYW5hZ2UgaXRzXG4gICAgICAgICAgZGV0YWlscy5cbiAgICAgICAgPC9wPlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNiBsZzpncmlkLWNvbHMtW21pbm1heCgwLDFmcilfbWlubWF4KDAsMS4yZnIpXVwiPlxuICAgICAgICA8UGFuZWxcbiAgICAgICAgICB0aXRsZT1cIkNyZWF0ZSBUb2RvXCJcbiAgICAgICAgICBkZXNjcmlwdGlvbj1cIkZpbGwgb3V0IHRoZSBmb3JtIHRvIGNyZWF0ZSBhIG5ldyB0b2RvLlwiXG4gICAgICAgID5cbiAgICAgICAgICA8Q3JlYXRlVG9kb0Zvcm1cbiAgICAgICAgICAgIHNlbGVjdGVkVXNlcklkPXtzZWxlY3RlZFVzZXJJZH1cbiAgICAgICAgICAgIHNldFNlbGVjdGVkVXNlcklkPXtzZXRTZWxlY3RlZFVzZXJJZH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L1BhbmVsPlxuICAgICAgICA8UGFuZWxcbiAgICAgICAgICB0aXRsZT1cIkV4aXN0aW5nIFRvZG9zXCJcbiAgICAgICAgICBkZXNjcmlwdGlvbj17XG4gICAgICAgICAgICBzZWxlY3RlZFVzZXJJZFxuICAgICAgICAgICAgICA/IFwiRmlsdGVyZWQgdG9kb3MgZm9yIHNlbGVjdGVkIHVzZXIuXCJcbiAgICAgICAgICAgICAgOiBcIkFsbCB0b2RvcyBmcm9tIGFsbCB1c2Vycy5cIlxuICAgICAgICAgIH1cbiAgICAgICAgPlxuICAgICAgICAgIDxUb2RvcyB1c2VySWQ9e3NlbGVjdGVkVXNlcklkfSAvPlxuICAgICAgICA8L1BhbmVsPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBUb2Rvc1BhZ2U7XG4iXX0=