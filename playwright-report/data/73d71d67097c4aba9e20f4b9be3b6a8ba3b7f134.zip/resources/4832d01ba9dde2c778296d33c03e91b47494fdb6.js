import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/AvailableUsers.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=f71da48c";
import { Spinner } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/index.ts";
import { useUsers } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/hooks.ts";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/AvailableUsers.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
var _s = $RefreshSig$();
const AvailableUsers = () => {
	_s();
	const { data: users, isLoading, error } = useUsers();
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV(Spinner, { label: "Loading users..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 12
		}, this);
	}
	if (error) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "rounded-md border border-destructive/50 bg-destructive/10 p-4",
			children: /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm text-destructive",
				children: error?.message || "Error loading users. Please try again later."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this);
	}
	if (!users || users.length === 0) {
		return /* @__PURE__ */ _jsxDEV("p", { children: "No users yet. Create the first one." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-2",
		children: /* @__PURE__ */ _jsxDEV("ul", {
			className: "divide-y divide-border rounded-md border border-border",
			children: users.map((user) => {
				return /* @__PURE__ */ _jsxDEV("li", {
					className: "flex items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0",
						children: /* @__PURE__ */ _jsxDEV("p", {
							className: "truncate text-sm font-medium text-foreground",
							children: user.username
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 36,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex shrink-0 items-center gap-2",
						children: /* @__PURE__ */ _jsxDEV(Link, {
							to: "/users/$userId",
							params: { userId: user.id },
							className: "rounded-md px-2.5 py-1 text-xs font-medium text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
							children: "View"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 15
					}, this)]
				}, user.id, true, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 13
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
};
_s(AvailableUsers, "i0onwqqMIjqtB5kzGag4eynaRd0=", false, function() {
	return [useUsers];
});
_c = AvailableUsers;
export { AvailableUsers };
var _c;
$RefreshReg$(_c, "AvailableUsers");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/AvailableUsers.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/AvailableUsers.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/AvailableUsers.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/AvailableUsers.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsZUFBZTtBQUN4QixTQUFTLGdCQUFnQjs7OztBQUV6QixNQUFNLHVCQUF1Qjs7Q0FDM0IsTUFBTSxFQUFFLE1BQU0sT0FBTyxXQUFXLFVBQVUsU0FBUztDQUVuRCxJQUFJLFdBQVc7RUFDYixPQUFPLHdCQUFDLFNBQUQsRUFBUyxPQUFNLG1CQUFvQjs7Ozs7Q0FDNUM7Q0FFQSxJQUFJLE9BQU87RUFDVCxPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FDVixPQUFPLFdBQVc7R0FDbEI7Ozs7O0VBQ0E7Ozs7O0NBRVQ7Q0FFQSxJQUFJLENBQUMsU0FBUyxNQUFNLFdBQVcsR0FBRztFQUNoQyxPQUFPLHdCQUFDLEtBQUQsWUFBRyxzQ0FBc0M7Ozs7O0NBQ2xEO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQ1gsTUFBTSxLQUFLLFNBQVM7SUFDbkIsT0FDRSx3QkFBQyxNQUFEO0tBRUUsV0FBVTtlQUZaLENBSUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsS0FBSztNQUNMOzs7OztLQUNBOzs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsTUFBRDtPQUNFLElBQUc7T0FDSCxRQUFRLEVBQUUsUUFBUSxLQUFLLEdBQUc7T0FDMUIsV0FBVTtpQkFDWDtNQUVLOzs7OztLQUNIOzs7O2FBQ0g7T0FqQkcsS0FBSzs7OztXQWlCUjtHQUVSLENBQUM7RUFDQzs7Ozs7Q0FDRDs7Ozs7QUFFVDs7Ozs7QUFFQSxTQUFTIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkF2YWlsYWJsZVVzZXJzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1yb3V0ZXJcIjtcbmltcG9ydCB7IFNwaW5uZXIgfSBmcm9tIFwiQHJlcG8vc2hhcmVkXCI7XG5pbXBvcnQgeyB1c2VVc2VycyB9IGZyb20gXCIuLi9ob29rc1wiO1xuXG5jb25zdCBBdmFpbGFibGVVc2VycyA9ICgpID0+IHtcbiAgY29uc3QgeyBkYXRhOiB1c2VycywgaXNMb2FkaW5nLCBlcnJvciB9ID0gdXNlVXNlcnMoKTtcblxuICBpZiAoaXNMb2FkaW5nKSB7XG4gICAgcmV0dXJuIDxTcGlubmVyIGxhYmVsPVwiTG9hZGluZyB1c2Vycy4uLlwiIC8+O1xuICB9XG5cbiAgaWYgKGVycm9yKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWRlc3RydWN0aXZlLzUwIGJnLWRlc3RydWN0aXZlLzEwIHAtNFwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZGVzdHJ1Y3RpdmVcIj5cbiAgICAgICAgICB7ZXJyb3I/Lm1lc3NhZ2UgfHwgXCJFcnJvciBsb2FkaW5nIHVzZXJzLiBQbGVhc2UgdHJ5IGFnYWluIGxhdGVyLlwifVxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgaWYgKCF1c2VycyB8fCB1c2Vycy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gPHA+Tm8gdXNlcnMgeWV0LiBDcmVhdGUgdGhlIGZpcnN0IG9uZS48L3A+O1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgIDx1bCBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtYm9yZGVyIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ib3JkZXJcIj5cbiAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4ge1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8bGlcbiAgICAgICAgICAgICAga2V5PXt1c2VyLmlkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcHgtNCBweS0zXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgIHt1c2VyLnVzZXJuYW1lfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgdG89XCIvdXNlcnMvJHVzZXJJZFwiXG4gICAgICAgICAgICAgICAgICBwYXJhbXM9e3sgdXNlcklkOiB1c2VyLmlkIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5IHVuZGVybGluZS1vZmZzZXQtNCBob3Zlcjp1bmRlcmxpbmUgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmdcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFZpZXdcbiAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApO1xuICAgICAgICB9KX1cbiAgICAgIDwvdWw+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgeyBBdmFpbGFibGVVc2VycyB9O1xuIl19