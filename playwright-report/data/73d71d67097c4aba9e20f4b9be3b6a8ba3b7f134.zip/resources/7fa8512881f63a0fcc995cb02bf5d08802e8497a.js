export { users } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/mocks/data/users.ts";
export { todoItems } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/mocks/data/todos.ts";

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsaUJBQWlCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB7IHVzZXJzIH0gZnJvbSBcIi4vdXNlcnNcIjtcbmV4cG9ydCB7IHRvZG9JdGVtcyB9IGZyb20gXCIuL3RvZG9zXCI7XG4iXX0=