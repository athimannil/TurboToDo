export { Button } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Button/Button.tsx";

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi9CdXR0b25cIjtcbiJdfQ==