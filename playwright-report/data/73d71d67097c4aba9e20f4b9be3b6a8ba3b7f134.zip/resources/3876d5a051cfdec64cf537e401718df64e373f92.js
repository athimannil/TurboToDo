import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/TodoList.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/TodoList.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
const TodoList = ({ todos, onToggle, isUpdating, updateTodoId }) => {
	return /* @__PURE__ */ _jsxDEV("ul", {
		className: "divide-y divide-border rounded-md border border-border",
		children: todos.map((todo) => /* @__PURE__ */ _jsxDEV("li", {
			className: "flex flex-col gap-2 px-4 py-3 transition-opacity",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ _jsxDEV("input", {
						type: "checkbox",
						id: `todo-${todo.id}`,
						checked: todo.status === "done",
						disabled: isUpdating && updateTodoId === todo.id,
						onChange: () => onToggle(todo.id, todo.status === "done" ? "pending" : "done"),
						className: "size-4 accent-primary"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: `todo-${todo.id}`,
						className: `flex-1 cursor-pointer text-sm ${todo.status === "done" ? "text-muted-foreground line-through" : "text-foreground"}`,
						children: todo.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 13
					}, this),
					isUpdating && updateTodoId === todo.id && /* @__PURE__ */ _jsxDEV("span", {
						className: "font-mono text-[10px] uppercase tracking-widest text-muted-foreground",
						children: "updating..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 15
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 11
			}, this), todo.description && /* @__PURE__ */ _jsxDEV("p", {
				className: "ml-7 text-xs text-muted-foreground",
				children: todo.description
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 13
			}, this)]
		}, todo.id, true, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
};
_c = TodoList;
export { TodoList };
var _c;
$RefreshReg$(_c, "TodoList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/TodoList.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/TodoList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/TodoList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/TodoList.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFTQSxNQUFNLFlBQVksRUFDaEIsT0FDQSxVQUNBLFlBQ0EsbUJBQ21CO0NBQ25CLE9BQ0Usd0JBQUMsTUFBRDtFQUFJLFdBQVU7WUFDWCxNQUFNLEtBQUssU0FDVix3QkFBQyxNQUFEO0dBRUUsV0FBVTthQUZaLENBSUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsSUFBSSxRQUFRLEtBQUs7TUFDakIsU0FBUyxLQUFLLFdBQVc7TUFDekIsVUFBVSxjQUFjLGlCQUFpQixLQUFLO01BQzlDLGdCQUNFLFNBQVMsS0FBSyxJQUFJLEtBQUssV0FBVyxTQUFTLFlBQVksTUFBTTtNQUUvRCxXQUFVO0tBQ1g7Ozs7O0tBQ0Qsd0JBQUMsU0FBRDtNQUNFLFNBQVMsUUFBUSxLQUFLO01BQ3RCLFdBQVcsaUNBQ1QsS0FBSyxXQUFXLFNBQ1osdUNBQ0E7Z0JBR0wsS0FBSztLQUNEOzs7OztLQUNOLGNBQWMsaUJBQWlCLEtBQUssTUFDbkMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQXdFO0tBRWxGOzs7OztJQUVMOzs7OzthQUNKLEtBQUssZUFDSix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUNWLEtBQUs7R0FDTDs7OztXQUVIO0tBbkNHLEtBQUs7Ozs7U0FtQ1IsQ0FDTDtDQUNDOzs7OztBQUVSOztBQUVBLFNBQVMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVG9kb0xpc3QudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgVG9Eb0l0ZW0sIFRvRG9TdGF0dXMgfSBmcm9tIFwiQHJlcG8vc2hhcmVkXCI7XG5cbmludGVyZmFjZSBUb2RvTGlzdFByb3BzIHtcbiAgdG9kb3M6IFRvRG9JdGVtW107XG4gIGlzVXBkYXRpbmc6IGJvb2xlYW47XG4gIHVwZGF0ZVRvZG9JZD86IHN0cmluZztcbiAgb25Ub2dnbGU6IChpZDogc3RyaW5nLCBzdGF0dXM6IFRvRG9TdGF0dXMpID0+IHZvaWQ7XG59XG5cbmNvbnN0IFRvZG9MaXN0ID0gKHtcbiAgdG9kb3MsXG4gIG9uVG9nZ2xlLFxuICBpc1VwZGF0aW5nLFxuICB1cGRhdGVUb2RvSWQsXG59OiBUb2RvTGlzdFByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHVsIGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1ib3JkZXIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWJvcmRlclwiPlxuICAgICAge3RvZG9zLm1hcCgodG9kbykgPT4gKFxuICAgICAgICA8bGlcbiAgICAgICAgICBrZXk9e3RvZG8uaWR9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiBweC00IHB5LTMgdHJhbnNpdGlvbi1vcGFjaXR5XCJcbiAgICAgICAgPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICBpZD17YHRvZG8tJHt0b2RvLmlkfWB9XG4gICAgICAgICAgICAgIGNoZWNrZWQ9e3RvZG8uc3RhdHVzID09PSBcImRvbmVcIn1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVXBkYXRpbmcgJiYgdXBkYXRlVG9kb0lkID09PSB0b2RvLmlkfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT5cbiAgICAgICAgICAgICAgICBvblRvZ2dsZSh0b2RvLmlkLCB0b2RvLnN0YXR1cyA9PT0gXCJkb25lXCIgPyBcInBlbmRpbmdcIiA6IFwiZG9uZVwiKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpemUtNCBhY2NlbnQtcHJpbWFyeVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgIGh0bWxGb3I9e2B0b2RvLSR7dG9kby5pZH1gfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbSAke1xuICAgICAgICAgICAgICAgIHRvZG8uc3RhdHVzID09PSBcImRvbmVcIlxuICAgICAgICAgICAgICAgICAgPyBcInRleHQtbXV0ZWQtZm9yZWdyb3VuZCBsaW5lLXRocm91Z2hcIlxuICAgICAgICAgICAgICAgICAgOiBcInRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7dG9kby50aXRsZX1cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICB7aXNVcGRhdGluZyAmJiB1cGRhdGVUb2RvSWQgPT09IHRvZG8uaWQgJiYgKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICB1cGRhdGluZy4uLlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHt0b2RvLmRlc2NyaXB0aW9uICYmIChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1sLTcgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAge3RvZG8uZGVzY3JpcHRpb259XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9saT5cbiAgICAgICkpfVxuICAgIDwvdWw+XG4gICk7XG59O1xuXG5leHBvcnQgeyBUb2RvTGlzdCB9O1xuIl19