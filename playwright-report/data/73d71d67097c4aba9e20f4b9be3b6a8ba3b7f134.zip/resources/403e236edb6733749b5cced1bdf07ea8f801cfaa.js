import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "TSS_INLINE_CSS_ENABLED": "false"};import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=f71da48c";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=f71da48c";
//#region ../../node_modules/jotai/esm/vanilla/internals.mjs
function hasInitialValue(atom) {
	return "init" in atom;
}
function isActuallyWritableAtom(atom) {
	return typeof atom.write === "function";
}
function hasOnMount(atom) {
	return !!atom.onMount;
}
function isAtomStateInitialized(atomState) {
	return "v" in atomState || "e" in atomState;
}
function returnAtomValue(atomState) {
	if ("e" in atomState) throw atomState.e;
	if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production" && !("v" in atomState)) throw new Error("[Bug] atom state is not initialized");
	return atomState.v;
}
function isPromiseLike$1(p) {
	return typeof (p == null ? void 0 : p.then) === "function";
}
function shouldThrowSynchronously(error) {
	if (!(error instanceof Error)) return false;
	const name = error.name;
	const message = error.message.toLowerCase();
	return (name === "RangeError" || name === "InternalError") && (message.includes("call stack") || message.includes("too much recursion") || message.includes("stack overflow"));
}
function addPendingPromiseToDependency(atom, promise, dependencyAtomState) {
	if (!dependencyAtomState.p.has(atom)) {
		dependencyAtomState.p.add(atom);
		const cleanup = () => dependencyAtomState.p.delete(atom);
		promise.then(cleanup, cleanup);
	}
}
function getMountedOrPendingDependents(atom, atomState, mountedMap) {
	const mounted = mountedMap.get(atom);
	const mountedDependents = mounted == null ? void 0 : mounted.t;
	const pendingDependents = atomState.p;
	if (!(mountedDependents == null ? void 0 : mountedDependents.size)) return pendingDependents;
	if (!pendingDependents.size) return mountedDependents;
	const dependents = new Set(mountedDependents);
	for (const a of pendingDependents) dependents.add(a);
	return dependents;
}
function hasOnInit(atom) {
	return !!atom.INTERNAL_onInit;
}
var BUILDING_BLOCK_atomRead = (_buildingBlocks, _store, atom, ...params) => atom.read(...params);
var BUILDING_BLOCK_atomWrite = (_buildingBlocks, _store, atom, ...params) => atom.write(...params);
var BUILDING_BLOCK_atomOnInit = (_buildingBlocks, store, atom) => atom.INTERNAL_onInit(store);
var BUILDING_BLOCK_atomOnMount = (_buildingBlocks, _store, atom, setAtom) => {
	var _a;
	return (_a = atom.onMount) == null ? void 0 : _a.call(atom, setAtom);
};
var BUILDING_BLOCK_ensureAtomState = (buildingBlocks, store, atom) => {
	var _a;
	const atomStateMap = buildingBlocks[0];
	let atomState = atomStateMap.get(atom);
	if (!atomState) {
		const storeHooks = buildingBlocks[6];
		const atomOnInit = buildingBlocks[9];
		atomState = {
			d: /* @__PURE__ */ new Map(),
			p: /* @__PURE__ */ new Set(),
			n: 0
		};
		atomStateMap.set(atom, atomState);
		(_a = storeHooks.i) == null || _a.call(storeHooks, atom);
		if (hasOnInit(atom)) atomOnInit(buildingBlocks, store, atom);
	}
	return atomState;
};
var BUILDING_BLOCK_flushCallbacks = (buildingBlocks, store) => {
	var _a;
	const mountedMap = buildingBlocks[1];
	const changedAtoms = buildingBlocks[3];
	const mountCallbacks = buildingBlocks[4];
	const unmountCallbacks = buildingBlocks[5];
	const storeHooks = buildingBlocks[6];
	const recomputeInvalidatedAtoms = buildingBlocks[13];
	if (!storeHooks.f && !changedAtoms.size && !mountCallbacks.size && !unmountCallbacks.size) return;
	const errors = [];
	const call = (fn) => {
		try {
			fn();
		} catch (e) {
			errors.push(e);
		}
	};
	do {
		if (storeHooks.f) call(storeHooks.f);
		const callbacks = /* @__PURE__ */ new Set();
		for (const atom of changedAtoms) {
			const listeners = (_a = mountedMap.get(atom)) == null ? void 0 : _a.l;
			if (listeners) for (const listener of listeners) callbacks.add(listener);
		}
		changedAtoms.clear();
		for (const fn of unmountCallbacks) callbacks.add(fn);
		unmountCallbacks.clear();
		for (const fn of mountCallbacks) callbacks.add(fn);
		mountCallbacks.clear();
		for (const fn of callbacks) call(fn);
		if (changedAtoms.size) recomputeInvalidatedAtoms(buildingBlocks, store);
	} while (changedAtoms.size || unmountCallbacks.size || mountCallbacks.size);
	if (errors.length) throw new AggregateError(errors);
};
var BUILDING_BLOCK_recomputeInvalidatedAtoms = (buildingBlocks, store) => {
	const mountedMap = buildingBlocks[1];
	const invalidatedAtoms = buildingBlocks[2];
	const changedAtoms = buildingBlocks[3];
	const ensureAtomState = buildingBlocks[11];
	const readAtomState = buildingBlocks[14];
	const mountDependencies = buildingBlocks[17];
	if (!changedAtoms.size) return;
	const sortedReversedAtoms = [];
	const sortedReversedStates = [];
	const visiting = /* @__PURE__ */ new WeakSet();
	const visited = /* @__PURE__ */ new WeakSet();
	const stackAtoms = [];
	const stackStates = [];
	for (const atom of changedAtoms) {
		stackAtoms.push(atom);
		stackStates.push(ensureAtomState(buildingBlocks, store, atom));
	}
	while (stackAtoms.length) {
		const top = stackAtoms.length - 1;
		const a = stackAtoms[top];
		const aState = stackStates[top];
		if (visited.has(a)) {
			stackAtoms.pop();
			stackStates.pop();
			continue;
		}
		if (visiting.has(a)) {
			if (invalidatedAtoms.get(a) === aState.n) {
				sortedReversedAtoms.push(a);
				sortedReversedStates.push(aState);
			} else if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production" && invalidatedAtoms.has(a)) throw new Error("[Bug] invalidated atom exists");
			visited.add(a);
			stackAtoms.pop();
			stackStates.pop();
			continue;
		}
		visiting.add(a);
		for (const d of getMountedOrPendingDependents(a, aState, mountedMap)) if (!visiting.has(d)) {
			stackAtoms.push(d);
			stackStates.push(ensureAtomState(buildingBlocks, store, d));
		}
	}
	for (let i = sortedReversedAtoms.length - 1; i >= 0; --i) {
		const a = sortedReversedAtoms[i];
		const aState = sortedReversedStates[i];
		let hasChangedDeps = false;
		for (const dep of aState.d.keys()) if (dep !== a && changedAtoms.has(dep)) {
			hasChangedDeps = true;
			break;
		}
		if (hasChangedDeps) {
			invalidatedAtoms.set(a, aState.n);
			readAtomState(buildingBlocks, store, a);
			mountDependencies(buildingBlocks, store, a);
		}
		invalidatedAtoms.delete(a);
	}
};
var storeMutationSet = /* @__PURE__ */ new WeakSet();
var BUILDING_BLOCK_readAtomState = (buildingBlocks, store, atom) => {
	var _a, _b;
	const mountedMap = buildingBlocks[1];
	const invalidatedAtoms = buildingBlocks[2];
	const changedAtoms = buildingBlocks[3];
	const storeHooks = buildingBlocks[6];
	const atomRead = buildingBlocks[7];
	const ensureAtomState = buildingBlocks[11];
	const flushCallbacks = buildingBlocks[12];
	const recomputeInvalidatedAtoms = buildingBlocks[13];
	const readAtomState = buildingBlocks[14];
	const writeAtomState = buildingBlocks[16];
	const mountDependencies = buildingBlocks[17];
	const setAtomStateValueOrPromise = buildingBlocks[20];
	const registerAbortHandler = buildingBlocks[26];
	const storeEpochHolder = buildingBlocks[28];
	const atomState = ensureAtomState(buildingBlocks, store, atom);
	const storeEpochNumber = storeEpochHolder[0];
	if (isAtomStateInitialized(atomState)) {
		if (mountedMap.has(atom) && invalidatedAtoms.get(atom) !== atomState.n || atomState.m === storeEpochNumber) {
			atomState.m = storeEpochNumber;
			return atomState;
		}
		let hasChangedDeps = false;
		for (const [a, n] of atomState.d) if (readAtomState(buildingBlocks, store, a).n !== n) {
			hasChangedDeps = true;
			break;
		}
		if (!hasChangedDeps) {
			atomState.m = storeEpochNumber;
			return atomState;
		}
	}
	let isSync = true;
	const prevDeps = new Set(atomState.d.keys());
	const pruneDependencies = () => {
		for (const a of prevDeps) atomState.d.delete(a);
	};
	const mountDependenciesIfAsync = () => {
		if (mountedMap.has(atom)) {
			const shouldRecompute = !changedAtoms.size;
			mountDependencies(buildingBlocks, store, atom);
			if (shouldRecompute) {
				recomputeInvalidatedAtoms(buildingBlocks, store);
				flushCallbacks(buildingBlocks, store);
			}
		}
	};
	const getter = (a) => {
		var _a2;
		if (a === atom) {
			const aState2 = ensureAtomState(buildingBlocks, store, a);
			if (!isAtomStateInitialized(aState2)) if (hasInitialValue(a)) setAtomStateValueOrPromise(buildingBlocks, store, a, a.init);
			else throw new Error("no atom init");
			return returnAtomValue(aState2);
		}
		const aState = readAtomState(buildingBlocks, store, a);
		try {
			return returnAtomValue(aState);
		} finally {
			prevDeps.delete(a);
			atomState.d.set(a, aState.n);
			if (isPromiseLike$1(atomState.v)) addPendingPromiseToDependency(atom, atomState.v, aState);
			if (mountedMap.has(atom)) (_a2 = mountedMap.get(a)) == null || _a2.t.add(atom);
			if (!isSync) mountDependenciesIfAsync();
		}
	};
	let controller;
	let setSelf;
	const options = {
		get signal() {
			if (!controller) controller = new AbortController();
			return controller.signal;
		},
		get setSelf() {
			if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production") console.warn("[DEPRECATED] setSelf is deprecated and will be removed in v3.");
			if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production" && !isActuallyWritableAtom(atom)) console.warn("setSelf function cannot be used with read-only atom");
			if (!setSelf && isActuallyWritableAtom(atom)) setSelf = (...args) => {
				if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production" && isSync) console.warn("setSelf function cannot be called in sync");
				if (!isSync) try {
					return writeAtomState(buildingBlocks, store, atom, args);
				} finally {
					recomputeInvalidatedAtoms(buildingBlocks, store);
					flushCallbacks(buildingBlocks, store);
				}
			};
			return setSelf;
		}
	};
	const prevEpochNumber = atomState.n;
	const prevInvalidated = invalidatedAtoms.get(atom) === prevEpochNumber;
	try {
		if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production") storeMutationSet.delete(store);
		const valueOrPromise = atomRead(buildingBlocks, store, atom, getter, options);
		if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production" && storeMutationSet.has(store)) console.warn("Detected store mutation during atom read. This is not supported.");
		setAtomStateValueOrPromise(buildingBlocks, store, atom, valueOrPromise);
		if (isPromiseLike$1(valueOrPromise)) {
			registerAbortHandler(buildingBlocks, store, valueOrPromise, () => controller == null ? void 0 : controller.abort());
			const settle = () => {
				pruneDependencies();
				mountDependenciesIfAsync();
			};
			valueOrPromise.then(settle, settle);
		} else pruneDependencies();
		(_a = storeHooks.r) == null || _a.call(storeHooks, atom);
		atomState.m = storeEpochNumber;
		return atomState;
	} catch (error) {
		if (shouldThrowSynchronously(error)) throw error;
		delete atomState.v;
		atomState.e = error;
		++atomState.n;
		atomState.m = storeEpochNumber;
		return atomState;
	} finally {
		isSync = false;
		if (atomState.n !== prevEpochNumber && prevInvalidated) {
			invalidatedAtoms.set(atom, atomState.n);
			changedAtoms.add(atom);
			(_b = storeHooks.c) == null || _b.call(storeHooks, atom);
		}
	}
};
var BUILDING_BLOCK_invalidateDependents = (buildingBlocks, store, atom) => {
	const mountedMap = buildingBlocks[1];
	const invalidatedAtoms = buildingBlocks[2];
	const ensureAtomState = buildingBlocks[11];
	const stack = [atom];
	while (stack.length) {
		const a = stack.pop();
		const aState = ensureAtomState(buildingBlocks, store, a);
		for (const d of getMountedOrPendingDependents(a, aState, mountedMap)) {
			const dState = ensureAtomState(buildingBlocks, store, d);
			if (invalidatedAtoms.get(d) !== dState.n) {
				invalidatedAtoms.set(d, dState.n);
				stack.push(d);
			}
		}
	}
};
var BUILDING_BLOCK_writeAtomState = (buildingBlocks, store, atom, args) => {
	const changedAtoms = buildingBlocks[3];
	const storeHooks = buildingBlocks[6];
	const atomWrite = buildingBlocks[8];
	const ensureAtomState = buildingBlocks[11];
	const flushCallbacks = buildingBlocks[12];
	const recomputeInvalidatedAtoms = buildingBlocks[13];
	const readAtomState = buildingBlocks[14];
	const invalidateDependents = buildingBlocks[15];
	const writeAtomState = buildingBlocks[16];
	const mountDependencies = buildingBlocks[17];
	const setAtomStateValueOrPromise = buildingBlocks[20];
	const storeEpochHolder = buildingBlocks[28];
	let isSync = true;
	const getter = (a) => returnAtomValue(readAtomState(buildingBlocks, store, a));
	const setter = (a, ...args2) => {
		var _a;
		const aState = ensureAtomState(buildingBlocks, store, a);
		try {
			if (a === atom) {
				if (!hasInitialValue(a)) throw new Error("atom not writable");
				if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production") storeMutationSet.add(store);
				const prevEpochNumber = aState.n;
				const v = args2[0];
				setAtomStateValueOrPromise(buildingBlocks, store, a, v);
				mountDependencies(buildingBlocks, store, a);
				if (prevEpochNumber !== aState.n) {
					++storeEpochHolder[0];
					changedAtoms.add(a);
					invalidateDependents(buildingBlocks, store, a);
					(_a = storeHooks.c) == null || _a.call(storeHooks, a);
				}
				return;
			} else return writeAtomState(buildingBlocks, store, a, args2);
		} finally {
			if (!isSync) {
				recomputeInvalidatedAtoms(buildingBlocks, store);
				flushCallbacks(buildingBlocks, store);
			}
		}
	};
	try {
		return atomWrite(buildingBlocks, store, atom, getter, setter, ...args);
	} finally {
		isSync = false;
	}
};
var BUILDING_BLOCK_mountDependencies = (buildingBlocks, store, atom) => {
	var _a;
	const mountedMap = buildingBlocks[1];
	const changedAtoms = buildingBlocks[3];
	const storeHooks = buildingBlocks[6];
	const ensureAtomState = buildingBlocks[11];
	const invalidateDependents = buildingBlocks[15];
	const mountAtom = buildingBlocks[18];
	const unmountAtom = buildingBlocks[19];
	const atomState = ensureAtomState(buildingBlocks, store, atom);
	const mounted = mountedMap.get(atom);
	if (mounted && atomState.d.size > 0) {
		for (const [a, n] of atomState.d) if (!mounted.d.has(a)) {
			const aState = ensureAtomState(buildingBlocks, store, a);
			mountAtom(buildingBlocks, store, a).t.add(atom);
			mounted.d.add(a);
			if (n !== aState.n) {
				changedAtoms.add(a);
				invalidateDependents(buildingBlocks, store, a);
				(_a = storeHooks.c) == null || _a.call(storeHooks, a);
			}
		}
		for (const a of mounted.d) if (!atomState.d.has(a)) {
			mounted.d.delete(a);
			unmountAtom(buildingBlocks, store, a)?.t.delete(atom);
		}
	}
};
var BUILDING_BLOCK_mountAtom = (buildingBlocks, store, atom) => {
	var _a;
	const mountedMap = buildingBlocks[1];
	const mountCallbacks = buildingBlocks[4];
	const storeHooks = buildingBlocks[6];
	const atomOnMount = buildingBlocks[10];
	const ensureAtomState = buildingBlocks[11];
	const flushCallbacks = buildingBlocks[12];
	const recomputeInvalidatedAtoms = buildingBlocks[13];
	const readAtomState = buildingBlocks[14];
	const writeAtomState = buildingBlocks[16];
	const mountAtom = buildingBlocks[18];
	const atomState = ensureAtomState(buildingBlocks, store, atom);
	let mounted = mountedMap.get(atom);
	if (!mounted) {
		readAtomState(buildingBlocks, store, atom);
		for (const a of atomState.d.keys()) mountAtom(buildingBlocks, store, a).t.add(atom);
		mounted = {
			l: /* @__PURE__ */ new Set(),
			d: new Set(atomState.d.keys()),
			t: /* @__PURE__ */ new Set()
		};
		mountedMap.set(atom, mounted);
		if (isActuallyWritableAtom(atom) && hasOnMount(atom)) {
			const processOnMount = () => {
				let isSync = true;
				const setAtom = (...args) => {
					try {
						return writeAtomState(buildingBlocks, store, atom, args);
					} finally {
						if (!isSync) {
							recomputeInvalidatedAtoms(buildingBlocks, store);
							flushCallbacks(buildingBlocks, store);
						}
					}
				};
				try {
					const onUnmount = atomOnMount(buildingBlocks, store, atom, setAtom);
					if (onUnmount) mounted.u = () => {
						isSync = true;
						try {
							onUnmount();
						} finally {
							isSync = false;
						}
					};
				} finally {
					isSync = false;
				}
			};
			mountCallbacks.add(processOnMount);
		}
		(_a = storeHooks.m) == null || _a.call(storeHooks, atom);
	}
	return mounted;
};
var BUILDING_BLOCK_unmountAtom = (buildingBlocks, store, atom) => {
	var _a, _b;
	const mountedMap = buildingBlocks[1];
	const unmountCallbacks = buildingBlocks[5];
	const storeHooks = buildingBlocks[6];
	const ensureAtomState = buildingBlocks[11];
	const unmountAtom = buildingBlocks[19];
	const atomState = ensureAtomState(buildingBlocks, store, atom);
	let mounted = mountedMap.get(atom);
	if (!mounted || mounted.l.size) return mounted;
	let isDependent = false;
	for (const a of mounted.t) if ((_a = mountedMap.get(a)) == null ? void 0 : _a.d.has(atom)) {
		isDependent = true;
		break;
	}
	if (!isDependent) {
		if (mounted.u) unmountCallbacks.add(mounted.u);
		mounted = void 0;
		mountedMap.delete(atom);
		for (const a of atomState.d.keys()) unmountAtom(buildingBlocks, store, a)?.t.delete(atom);
		(_b = storeHooks.u) == null || _b.call(storeHooks, atom);
		return;
	}
	return mounted;
};
var BUILDING_BLOCK_setAtomStateValueOrPromise = (buildingBlocks, store, atom, valueOrPromise) => {
	const ensureAtomState = buildingBlocks[11];
	const abortPromise = buildingBlocks[27];
	const atomState = ensureAtomState(buildingBlocks, store, atom);
	const hasPrevValue = "v" in atomState;
	const prevValue = atomState.v;
	if (isPromiseLike$1(valueOrPromise)) for (const a of atomState.d.keys()) addPendingPromiseToDependency(atom, valueOrPromise, ensureAtomState(buildingBlocks, store, a));
	atomState.v = valueOrPromise;
	delete atomState.e;
	if (!hasPrevValue || !Object.is(prevValue, atomState.v)) {
		++atomState.n;
		if (isPromiseLike$1(prevValue)) abortPromise(buildingBlocks, store, prevValue);
	}
};
var BUILDING_BLOCK_storeGet = (buildingBlocks, store, atom) => {
	const readAtomState = buildingBlocks[14];
	return returnAtomValue(readAtomState(buildingBlocks, store, atom));
};
var BUILDING_BLOCK_storeSet = (buildingBlocks, store, atom, ...args) => {
	const changedAtoms = buildingBlocks[3];
	const flushCallbacks = buildingBlocks[12];
	const recomputeInvalidatedAtoms = buildingBlocks[13];
	const writeAtomState = buildingBlocks[16];
	const prevChangedAtomsSize = changedAtoms.size;
	try {
		return writeAtomState(buildingBlocks, store, atom, args);
	} finally {
		if (changedAtoms.size !== prevChangedAtomsSize) {
			recomputeInvalidatedAtoms(buildingBlocks, store);
			flushCallbacks(buildingBlocks, store);
		}
	}
};
var BUILDING_BLOCK_storeSub = (buildingBlocks, store, atom, listener) => {
	const flushCallbacks = buildingBlocks[12];
	const recomputeInvalidatedAtoms = buildingBlocks[13];
	const mountAtom = buildingBlocks[18];
	const unmountAtom = buildingBlocks[19];
	const listeners = mountAtom(buildingBlocks, store, atom).l;
	listeners.add(listener);
	recomputeInvalidatedAtoms(buildingBlocks, store);
	flushCallbacks(buildingBlocks, store);
	return () => {
		listeners.delete(listener);
		unmountAtom(buildingBlocks, store, atom);
		recomputeInvalidatedAtoms(buildingBlocks, store);
		flushCallbacks(buildingBlocks, store);
	};
};
var BUILDING_BLOCK_registerAbortHandler = (buildingBlocks, _store, promise, abortHandler) => {
	const abortHandlersMap = buildingBlocks[25];
	let abortHandlers = abortHandlersMap.get(promise);
	if (!abortHandlers) {
		abortHandlers = /* @__PURE__ */ new Set();
		abortHandlersMap.set(promise, abortHandlers);
		const cleanup = () => abortHandlersMap.delete(promise);
		promise.then(cleanup, cleanup);
	}
	abortHandlers.add(abortHandler);
};
var BUILDING_BLOCK_abortPromise = (buildingBlocks, _store, promise) => {
	buildingBlocks[25].get(promise)?.forEach((fn) => fn());
};
var buildingBlockMap = /* @__PURE__ */ new WeakMap();
function getBuildingBlocks(store) {
	const buildingBlocks = buildingBlockMap.get(store);
	if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production" && !buildingBlocks) throw new Error("Store must be created by buildStore to read its building blocks");
	const enhanceBuildingBlocks = buildingBlocks[24];
	if (enhanceBuildingBlocks) return enhanceBuildingBlocks(buildingBlocks, store);
	return buildingBlocks;
}
function buildStore(...partialBuildingBlocks) {
	const store = {
		get(atom) {
			return storeGet(buildingBlocks, store, atom);
		},
		set(atom, ...args) {
			return storeSet(buildingBlocks, store, atom, ...args);
		},
		sub(atom, listener) {
			return storeSub(buildingBlocks, store, atom, listener);
		}
	};
	const buildingBlocks = [
		/* @__PURE__ */ new WeakMap(),
		/* @__PURE__ */ new WeakMap(),
		/* @__PURE__ */ new WeakMap(),
		/* @__PURE__ */ new Set(),
		/* @__PURE__ */ new Set(),
		/* @__PURE__ */ new Set(),
		{},
		BUILDING_BLOCK_atomRead,
		BUILDING_BLOCK_atomWrite,
		BUILDING_BLOCK_atomOnInit,
		BUILDING_BLOCK_atomOnMount,
		BUILDING_BLOCK_ensureAtomState,
		BUILDING_BLOCK_flushCallbacks,
		BUILDING_BLOCK_recomputeInvalidatedAtoms,
		BUILDING_BLOCK_readAtomState,
		BUILDING_BLOCK_invalidateDependents,
		BUILDING_BLOCK_writeAtomState,
		BUILDING_BLOCK_mountDependencies,
		BUILDING_BLOCK_mountAtom,
		BUILDING_BLOCK_unmountAtom,
		BUILDING_BLOCK_setAtomStateValueOrPromise,
		BUILDING_BLOCK_storeGet,
		BUILDING_BLOCK_storeSet,
		BUILDING_BLOCK_storeSub,
		void 0,
		/* @__PURE__ */ new WeakMap(),
		BUILDING_BLOCK_registerAbortHandler,
		BUILDING_BLOCK_abortPromise,
		[0]
	].map((fn, i) => partialBuildingBlocks[i] || fn);
	buildingBlockMap.set(store, Object.freeze(buildingBlocks));
	const storeGet = buildingBlocks[21];
	const storeSet = buildingBlocks[22];
	const storeSub = buildingBlocks[23];
	return store;
}
//#endregion
//#region ../../node_modules/jotai/esm/vanilla.mjs
var keyCount = 0;
function atom(read, write) {
	const key = `atom${++keyCount}`;
	const config = { toString() {
		return (import.meta.env ? import.meta.env.MODE : void 0) !== "production" && this.debugLabel ? key + ":" + this.debugLabel : key;
	} };
	if (typeof read === "function") config.read = read;
	else {
		config.init = read;
		config.read = defaultRead;
		config.write = defaultWrite;
	}
	if (write) config.write = write;
	return config;
}
function defaultRead(get) {
	return get(this);
}
function defaultWrite(get, set, arg) {
	return set(this, typeof arg === "function" ? arg(get(this)) : arg);
}
var overriddenCreateStore;
function INTERNAL_overrideCreateStore(fn) {
	overriddenCreateStore = fn(overriddenCreateStore);
}
function createStore() {
	if (overriddenCreateStore) return overriddenCreateStore();
	return buildStore();
}
var defaultStore;
function getDefaultStore() {
	if (!defaultStore) {
		defaultStore = createStore();
		if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production") {
			globalThis.__JOTAI_DEFAULT_STORE__ || (globalThis.__JOTAI_DEFAULT_STORE__ = defaultStore);
			if (globalThis.__JOTAI_DEFAULT_STORE__ !== defaultStore) console.warn("Detected multiple Jotai instances. It may cause unexpected behavior with the default store. https://github.com/pmndrs/jotai/discussions/2044");
		}
	}
	return defaultStore;
}
//#endregion
//#region ../../node_modules/jotai/esm/react.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var StoreContext = (0, import_react.createContext)(void 0);
function useStore(options) {
	const store = (0, import_react.useContext)(StoreContext);
	return (options == null ? void 0 : options.store) || store || getDefaultStore();
}
function Provider({ children, store }) {
	const storeRef = (0, import_react.useRef)(null);
	if (store) return (0, import_react.createElement)(StoreContext.Provider, { value: store }, children);
	if (storeRef.current === null) storeRef.current = createStore();
	return (0, import_react.createElement)(StoreContext.Provider, { value: storeRef.current }, children);
}
var isPromiseLike = (x) => typeof (x == null ? void 0 : x.then) === "function";
var attachPromiseStatus = (promise) => {
	if (!promise.status) {
		promise.status = "pending";
		promise.then((v) => {
			promise.status = "fulfilled";
			promise.value = v;
		}, (e) => {
			promise.status = "rejected";
			promise.reason = e;
		});
	}
};
var use = import_react.use || ((promise) => {
	if (promise.status === "pending") throw promise;
	else if (promise.status === "fulfilled") return promise.value;
	else if (promise.status === "rejected") throw promise.reason;
	else {
		attachPromiseStatus(promise);
		throw promise;
	}
});
var continuablePromiseMap = /* @__PURE__ */ new WeakMap();
var createContinuablePromise = (store, promise, getValue) => {
	const buildingBlocks = getBuildingBlocks(store);
	const registerAbortHandler = buildingBlocks[26];
	let continuablePromise = continuablePromiseMap.get(promise);
	if (!continuablePromise) {
		continuablePromise = new Promise((resolve, reject) => {
			let curr = promise;
			const onFulfilled = (me) => (v) => {
				if (curr === me) resolve(v);
			};
			const onRejected = (me) => (e) => {
				if (curr === me) reject(e);
			};
			const onAbort = () => {
				try {
					const nextValue = getValue();
					if (isPromiseLike(nextValue)) {
						continuablePromiseMap.set(nextValue, continuablePromise);
						curr = nextValue;
						nextValue.then(onFulfilled(nextValue), onRejected(nextValue));
						registerAbortHandler(buildingBlocks, store, nextValue, onAbort);
					} else resolve(nextValue);
				} catch (e) {
					reject(e);
				}
			};
			promise.then(onFulfilled(promise), onRejected(promise));
			registerAbortHandler(buildingBlocks, store, promise, onAbort);
		});
		continuablePromiseMap.set(promise, continuablePromise);
	}
	return continuablePromise;
};
function useAtomValue(atom, options) {
	const { delay, unstable_promiseStatus: promiseStatus = !import_react.use } = options || {};
	const store = useStore(options);
	const [[valueFromReducer, storeFromReducer, atomFromReducer], rerender] = (0, import_react.useReducer)((prev) => {
		const nextValue = store.get(atom);
		if (Object.is(prev[0], nextValue) && prev[1] === store && prev[2] === atom) return prev;
		return [
			nextValue,
			store,
			atom
		];
	}, void 0, () => [
		store.get(atom),
		store,
		atom
	]);
	let value = valueFromReducer;
	if (storeFromReducer !== store || atomFromReducer !== atom) {
		rerender();
		value = store.get(atom);
	}
	(0, import_react.useEffect)(() => {
		const unsub = store.sub(atom, () => {
			if (promiseStatus) try {
				const value2 = store.get(atom);
				if (isPromiseLike(value2)) attachPromiseStatus(createContinuablePromise(store, value2, () => store.get(atom)));
			} catch (e) {}
			if (typeof delay === "number") {
				console.warn(`[DEPRECATED] delay option is deprecated and will be removed in v3.

Migration guide:

Create a custom hook like the following.

function useAtomValueWithDelay<Value>(
  atom: Atom<Value>,
  options: { delay: number },
): Value {
  const { delay } = options
  const store = useStore(options)
  const [value, setValue] = useState(() => store.get(atom))
  useEffect(() => {
    const unsub = store.sub(atom, () => {
      setTimeout(() => setValue(store.get(atom)), delay)
    })
    return unsub
  }, [store, atom, delay])
  return value
}
`);
				setTimeout(rerender, delay);
				return;
			}
			rerender();
		});
		rerender();
		return unsub;
	}, [
		store,
		atom,
		delay,
		promiseStatus
	]);
	(0, import_react.useDebugValue)(value);
	if (isPromiseLike(value)) {
		const promise = createContinuablePromise(store, value, () => store.get(atom));
		if (promiseStatus) attachPromiseStatus(promise);
		return use(promise);
	}
	return value;
}
function useSetAtom(atom, options) {
	const store = useStore(options);
	return (0, import_react.useCallback)((...args) => {
		if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production" && !("write" in atom)) throw new Error("not writable atom");
		return store.set(atom, ...args);
	}, [store, atom]);
}
function useAtom(atom, options) {
	return [useAtomValue(atom, options), useSetAtom(atom, options)];
}
//#endregion
export { INTERNAL_overrideCreateStore, Provider, atom, createStore, getDefaultStore, useAtom, useAtomValue, useSetAtom, useStore };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiam90YWkuanMiLCJuYW1lcyI6WyJpc1Byb21pc2VMaWtlIiwiSU5URVJOQUxfYnVpbGRTdG9yZVJldjMiLCJjcmVhdGVDb250ZXh0IiwidXNlQ29udGV4dCIsInVzZVJlZiIsImNyZWF0ZUVsZW1lbnQiLCJJTlRFUk5BTF9nZXRCdWlsZGluZ0Jsb2Nrc1JldjMiLCJ1c2VSZWR1Y2VyIiwidXNlQ2FsbGJhY2siXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvam90YWkvZXNtL3ZhbmlsbGEvaW50ZXJuYWxzLm1qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9qb3RhaS9lc20vdmFuaWxsYS5tanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvam90YWkvZXNtL3JlYWN0Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBoYXNJbml0aWFsVmFsdWUoYXRvbSkge1xuICByZXR1cm4gXCJpbml0XCIgaW4gYXRvbTtcbn1cbmZ1bmN0aW9uIGlzQWN0dWFsbHlXcml0YWJsZUF0b20oYXRvbSkge1xuICByZXR1cm4gdHlwZW9mIGF0b20ud3JpdGUgPT09IFwiZnVuY3Rpb25cIjtcbn1cbmZ1bmN0aW9uIGhhc09uTW91bnQoYXRvbSkge1xuICByZXR1cm4gISFhdG9tLm9uTW91bnQ7XG59XG5mdW5jdGlvbiBpc0F0b21TdGF0ZUluaXRpYWxpemVkKGF0b21TdGF0ZSkge1xuICByZXR1cm4gXCJ2XCIgaW4gYXRvbVN0YXRlIHx8IFwiZVwiIGluIGF0b21TdGF0ZTtcbn1cbmZ1bmN0aW9uIHJldHVybkF0b21WYWx1ZShhdG9tU3RhdGUpIHtcbiAgaWYgKFwiZVwiIGluIGF0b21TdGF0ZSkge1xuICAgIHRocm93IGF0b21TdGF0ZS5lO1xuICB9XG4gIGlmICgoaW1wb3J0Lm1ldGEuZW52ID8gaW1wb3J0Lm1ldGEuZW52Lk1PREUgOiB2b2lkIDApICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhKFwidlwiIGluIGF0b21TdGF0ZSkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJbQnVnXSBhdG9tIHN0YXRlIGlzIG5vdCBpbml0aWFsaXplZFwiKTtcbiAgfVxuICByZXR1cm4gYXRvbVN0YXRlLnY7XG59XG5mdW5jdGlvbiBpc1Byb21pc2VMaWtlKHApIHtcbiAgcmV0dXJuIHR5cGVvZiAocCA9PSBudWxsID8gdm9pZCAwIDogcC50aGVuKSA9PT0gXCJmdW5jdGlvblwiO1xufVxuZnVuY3Rpb24gc2hvdWxkVGhyb3dTeW5jaHJvbm91c2x5KGVycm9yKSB7XG4gIGlmICghKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGNvbnN0IG5hbWUgPSBlcnJvci5uYW1lO1xuICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZS50b0xvd2VyQ2FzZSgpO1xuICByZXR1cm4gKG5hbWUgPT09IFwiUmFuZ2VFcnJvclwiIHx8IG5hbWUgPT09IFwiSW50ZXJuYWxFcnJvclwiKSAmJiAobWVzc2FnZS5pbmNsdWRlcyhcImNhbGwgc3RhY2tcIikgfHwgbWVzc2FnZS5pbmNsdWRlcyhcInRvbyBtdWNoIHJlY3Vyc2lvblwiKSB8fCBtZXNzYWdlLmluY2x1ZGVzKFwic3RhY2sgb3ZlcmZsb3dcIikpO1xufVxuZnVuY3Rpb24gYWRkUGVuZGluZ1Byb21pc2VUb0RlcGVuZGVuY3koYXRvbSwgcHJvbWlzZSwgZGVwZW5kZW5jeUF0b21TdGF0ZSkge1xuICBpZiAoIWRlcGVuZGVuY3lBdG9tU3RhdGUucC5oYXMoYXRvbSkpIHtcbiAgICBkZXBlbmRlbmN5QXRvbVN0YXRlLnAuYWRkKGF0b20pO1xuICAgIGNvbnN0IGNsZWFudXAgPSAoKSA9PiBkZXBlbmRlbmN5QXRvbVN0YXRlLnAuZGVsZXRlKGF0b20pO1xuICAgIHByb21pc2UudGhlbihjbGVhbnVwLCBjbGVhbnVwKTtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0TW91bnRlZE9yUGVuZGluZ0RlcGVuZGVudHMoYXRvbSwgYXRvbVN0YXRlLCBtb3VudGVkTWFwKSB7XG4gIGNvbnN0IG1vdW50ZWQgPSBtb3VudGVkTWFwLmdldChhdG9tKTtcbiAgY29uc3QgbW91bnRlZERlcGVuZGVudHMgPSBtb3VudGVkID09IG51bGwgPyB2b2lkIDAgOiBtb3VudGVkLnQ7XG4gIGNvbnN0IHBlbmRpbmdEZXBlbmRlbnRzID0gYXRvbVN0YXRlLnA7XG4gIGlmICghKG1vdW50ZWREZXBlbmRlbnRzID09IG51bGwgPyB2b2lkIDAgOiBtb3VudGVkRGVwZW5kZW50cy5zaXplKSkge1xuICAgIHJldHVybiBwZW5kaW5nRGVwZW5kZW50cztcbiAgfVxuICBpZiAoIXBlbmRpbmdEZXBlbmRlbnRzLnNpemUpIHtcbiAgICByZXR1cm4gbW91bnRlZERlcGVuZGVudHM7XG4gIH1cbiAgY29uc3QgZGVwZW5kZW50cyA9IG5ldyBTZXQobW91bnRlZERlcGVuZGVudHMpO1xuICBmb3IgKGNvbnN0IGEgb2YgcGVuZGluZ0RlcGVuZGVudHMpIHtcbiAgICBkZXBlbmRlbnRzLmFkZChhKTtcbiAgfVxuICByZXR1cm4gZGVwZW5kZW50cztcbn1cbmNvbnN0IGNyZWF0ZVN0b3JlSG9vayA9ICgpID0+IHtcbiAgY29uc3QgY2FsbGJhY2tzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgY29uc3Qgbm90aWZ5ID0gKCkgPT4gY2FsbGJhY2tzLmZvckVhY2goKGZuKSA9PiBmbigpKTtcbiAgbm90aWZ5LmFkZCA9IChmbikgPT4ge1xuICAgIGNhbGxiYWNrcy5hZGQoZm4pO1xuICAgIHJldHVybiAoKSA9PiBjYWxsYmFja3MuZGVsZXRlKGZuKTtcbiAgfTtcbiAgcmV0dXJuIG5vdGlmeTtcbn07XG5jb25zdCBjcmVhdGVTdG9yZUhvb2tGb3JBdG9tcyA9ICgpID0+IHtcbiAgY29uc3QgYWxsID0ge307XG4gIGNvbnN0IGNhbGxiYWNrcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuICBjb25zdCBub3RpZnkgPSAoYXRvbSkgPT4ge1xuICAgIHZhciBfYSwgX2I7XG4gICAgKF9hID0gY2FsbGJhY2tzLmdldChhbGwpKSA9PSBudWxsID8gdm9pZCAwIDogX2EuZm9yRWFjaCgoZm4pID0+IGZuKGF0b20pKTtcbiAgICAoX2IgPSBjYWxsYmFja3MuZ2V0KGF0b20pKSA9PSBudWxsID8gdm9pZCAwIDogX2IuZm9yRWFjaCgoZm4pID0+IGZuKCkpO1xuICB9O1xuICBub3RpZnkuYWRkID0gKGF0b20sIGZuKSA9PiB7XG4gICAgY29uc3Qga2V5ID0gYXRvbSB8fCBhbGw7XG4gICAgbGV0IGZucyA9IGNhbGxiYWNrcy5nZXQoa2V5KTtcbiAgICBpZiAoIWZucykge1xuICAgICAgZm5zID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgICAgIGNhbGxiYWNrcy5zZXQoa2V5LCBmbnMpO1xuICAgIH1cbiAgICBmbnMuYWRkKGZuKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZm5zLmRlbGV0ZShmbik7XG4gICAgICBpZiAoIWZucy5zaXplKSB7XG4gICAgICAgIGNhbGxiYWNrcy5kZWxldGUoa2V5KTtcbiAgICAgIH1cbiAgICB9O1xuICB9O1xuICByZXR1cm4gbm90aWZ5O1xufTtcbmZ1bmN0aW9uIGluaXRpYWxpemVTdG9yZUhvb2tzKHN0b3JlSG9va3MpIHtcbiAgc3RvcmVIb29rcy5pIHx8IChzdG9yZUhvb2tzLmkgPSBjcmVhdGVTdG9yZUhvb2tGb3JBdG9tcygpKTtcbiAgc3RvcmVIb29rcy5yIHx8IChzdG9yZUhvb2tzLnIgPSBjcmVhdGVTdG9yZUhvb2tGb3JBdG9tcygpKTtcbiAgc3RvcmVIb29rcy5jIHx8IChzdG9yZUhvb2tzLmMgPSBjcmVhdGVTdG9yZUhvb2tGb3JBdG9tcygpKTtcbiAgc3RvcmVIb29rcy5tIHx8IChzdG9yZUhvb2tzLm0gPSBjcmVhdGVTdG9yZUhvb2tGb3JBdG9tcygpKTtcbiAgc3RvcmVIb29rcy51IHx8IChzdG9yZUhvb2tzLnUgPSBjcmVhdGVTdG9yZUhvb2tGb3JBdG9tcygpKTtcbiAgc3RvcmVIb29rcy5mIHx8IChzdG9yZUhvb2tzLmYgPSBjcmVhdGVTdG9yZUhvb2soKSk7XG4gIHJldHVybiBzdG9yZUhvb2tzO1xufVxuZnVuY3Rpb24gaGFzT25Jbml0KGF0b20pIHtcbiAgcmV0dXJuICEhYXRvbS5JTlRFUk5BTF9vbkluaXQ7XG59XG5jb25zdCBCVUlMRElOR19CTE9DS19hdG9tUmVhZCA9IChfYnVpbGRpbmdCbG9ja3MsIF9zdG9yZSwgYXRvbSwgLi4ucGFyYW1zKSA9PiBhdG9tLnJlYWQoLi4ucGFyYW1zKTtcbmNvbnN0IEJVSUxESU5HX0JMT0NLX2F0b21Xcml0ZSA9IChfYnVpbGRpbmdCbG9ja3MsIF9zdG9yZSwgYXRvbSwgLi4ucGFyYW1zKSA9PiBhdG9tLndyaXRlKC4uLnBhcmFtcyk7XG5jb25zdCBCVUlMRElOR19CTE9DS19hdG9tT25Jbml0ID0gKF9idWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pID0+IGF0b20uSU5URVJOQUxfb25Jbml0KHN0b3JlKTtcbmNvbnN0IEJVSUxESU5HX0JMT0NLX2F0b21Pbk1vdW50ID0gKF9idWlsZGluZ0Jsb2NrcywgX3N0b3JlLCBhdG9tLCBzZXRBdG9tKSA9PiB7XG4gIHZhciBfYTtcbiAgcmV0dXJuIChfYSA9IGF0b20ub25Nb3VudCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmNhbGwoYXRvbSwgc2V0QXRvbSk7XG59O1xuY29uc3QgQlVJTERJTkdfQkxPQ0tfZW5zdXJlQXRvbVN0YXRlID0gKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYXRvbSkgPT4ge1xuICB2YXIgX2E7XG4gIGNvbnN0IGF0b21TdGF0ZU1hcCA9IGJ1aWxkaW5nQmxvY2tzWzBdO1xuICBsZXQgYXRvbVN0YXRlID0gYXRvbVN0YXRlTWFwLmdldChhdG9tKTtcbiAgaWYgKCFhdG9tU3RhdGUpIHtcbiAgICBjb25zdCBzdG9yZUhvb2tzID0gYnVpbGRpbmdCbG9ja3NbNl07XG4gICAgY29uc3QgYXRvbU9uSW5pdCA9IGJ1aWxkaW5nQmxvY2tzWzldO1xuICAgIGF0b21TdGF0ZSA9IHsgZDogLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSwgcDogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSwgbjogMCB9O1xuICAgIGF0b21TdGF0ZU1hcC5zZXQoYXRvbSwgYXRvbVN0YXRlKTtcbiAgICAoX2EgPSBzdG9yZUhvb2tzLmkpID09IG51bGwgPyB2b2lkIDAgOiBfYS5jYWxsKHN0b3JlSG9va3MsIGF0b20pO1xuICAgIGlmIChoYXNPbkluaXQoYXRvbSkpIHtcbiAgICAgIGF0b21PbkluaXQoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGF0b21TdGF0ZTtcbn07XG5jb25zdCBCVUlMRElOR19CTE9DS19mbHVzaENhbGxiYWNrcyA9IChidWlsZGluZ0Jsb2Nrcywgc3RvcmUpID0+IHtcbiAgdmFyIF9hO1xuICBjb25zdCBtb3VudGVkTWFwID0gYnVpbGRpbmdCbG9ja3NbMV07XG4gIGNvbnN0IGNoYW5nZWRBdG9tcyA9IGJ1aWxkaW5nQmxvY2tzWzNdO1xuICBjb25zdCBtb3VudENhbGxiYWNrcyA9IGJ1aWxkaW5nQmxvY2tzWzRdO1xuICBjb25zdCB1bm1vdW50Q2FsbGJhY2tzID0gYnVpbGRpbmdCbG9ja3NbNV07XG4gIGNvbnN0IHN0b3JlSG9va3MgPSBidWlsZGluZ0Jsb2Nrc1s2XTtcbiAgY29uc3QgcmVjb21wdXRlSW52YWxpZGF0ZWRBdG9tcyA9IGJ1aWxkaW5nQmxvY2tzWzEzXTtcbiAgaWYgKCFzdG9yZUhvb2tzLmYgJiYgIWNoYW5nZWRBdG9tcy5zaXplICYmICFtb3VudENhbGxiYWNrcy5zaXplICYmICF1bm1vdW50Q2FsbGJhY2tzLnNpemUpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgZXJyb3JzID0gW107XG4gIGNvbnN0IGNhbGwgPSAoZm4pID0+IHtcbiAgICB0cnkge1xuICAgICAgZm4oKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBlcnJvcnMucHVzaChlKTtcbiAgICB9XG4gIH07XG4gIGRvIHtcbiAgICBpZiAoc3RvcmVIb29rcy5mKSB7XG4gICAgICBjYWxsKHN0b3JlSG9va3MuZik7XG4gICAgfVxuICAgIGNvbnN0IGNhbGxiYWNrcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgZm9yIChjb25zdCBhdG9tIG9mIGNoYW5nZWRBdG9tcykge1xuICAgICAgY29uc3QgbGlzdGVuZXJzID0gKF9hID0gbW91bnRlZE1hcC5nZXQoYXRvbSkpID09IG51bGwgPyB2b2lkIDAgOiBfYS5sO1xuICAgICAgaWYgKGxpc3RlbmVycykge1xuICAgICAgICBmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIGxpc3RlbmVycykge1xuICAgICAgICAgIGNhbGxiYWNrcy5hZGQobGlzdGVuZXIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGNoYW5nZWRBdG9tcy5jbGVhcigpO1xuICAgIGZvciAoY29uc3QgZm4gb2YgdW5tb3VudENhbGxiYWNrcykge1xuICAgICAgY2FsbGJhY2tzLmFkZChmbik7XG4gICAgfVxuICAgIHVubW91bnRDYWxsYmFja3MuY2xlYXIoKTtcbiAgICBmb3IgKGNvbnN0IGZuIG9mIG1vdW50Q2FsbGJhY2tzKSB7XG4gICAgICBjYWxsYmFja3MuYWRkKGZuKTtcbiAgICB9XG4gICAgbW91bnRDYWxsYmFja3MuY2xlYXIoKTtcbiAgICBmb3IgKGNvbnN0IGZuIG9mIGNhbGxiYWNrcykge1xuICAgICAgY2FsbChmbik7XG4gICAgfVxuICAgIGlmIChjaGFuZ2VkQXRvbXMuc2l6ZSkge1xuICAgICAgcmVjb21wdXRlSW52YWxpZGF0ZWRBdG9tcyhidWlsZGluZ0Jsb2Nrcywgc3RvcmUpO1xuICAgIH1cbiAgfSB3aGlsZSAoY2hhbmdlZEF0b21zLnNpemUgfHwgdW5tb3VudENhbGxiYWNrcy5zaXplIHx8IG1vdW50Q2FsbGJhY2tzLnNpemUpO1xuICBpZiAoZXJyb3JzLmxlbmd0aCkge1xuICAgIHRocm93IG5ldyBBZ2dyZWdhdGVFcnJvcihlcnJvcnMpO1xuICB9XG59O1xuY29uc3QgQlVJTERJTkdfQkxPQ0tfcmVjb21wdXRlSW52YWxpZGF0ZWRBdG9tcyA9IChidWlsZGluZ0Jsb2Nrcywgc3RvcmUpID0+IHtcbiAgY29uc3QgbW91bnRlZE1hcCA9IGJ1aWxkaW5nQmxvY2tzWzFdO1xuICBjb25zdCBpbnZhbGlkYXRlZEF0b21zID0gYnVpbGRpbmdCbG9ja3NbMl07XG4gIGNvbnN0IGNoYW5nZWRBdG9tcyA9IGJ1aWxkaW5nQmxvY2tzWzNdO1xuICBjb25zdCBlbnN1cmVBdG9tU3RhdGUgPSBidWlsZGluZ0Jsb2Nrc1sxMV07XG4gIGNvbnN0IHJlYWRBdG9tU3RhdGUgPSBidWlsZGluZ0Jsb2Nrc1sxNF07XG4gIGNvbnN0IG1vdW50RGVwZW5kZW5jaWVzID0gYnVpbGRpbmdCbG9ja3NbMTddO1xuICBpZiAoIWNoYW5nZWRBdG9tcy5zaXplKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHNvcnRlZFJldmVyc2VkQXRvbXMgPSBbXTtcbiAgY29uc3Qgc29ydGVkUmV2ZXJzZWRTdGF0ZXMgPSBbXTtcbiAgY29uc3QgdmlzaXRpbmcgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtTZXQoKTtcbiAgY29uc3QgdmlzaXRlZCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha1NldCgpO1xuICBjb25zdCBzdGFja0F0b21zID0gW107XG4gIGNvbnN0IHN0YWNrU3RhdGVzID0gW107XG4gIGZvciAoY29uc3QgYXRvbSBvZiBjaGFuZ2VkQXRvbXMpIHtcbiAgICBzdGFja0F0b21zLnB1c2goYXRvbSk7XG4gICAgc3RhY2tTdGF0ZXMucHVzaChlbnN1cmVBdG9tU3RhdGUoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tKSk7XG4gIH1cbiAgd2hpbGUgKHN0YWNrQXRvbXMubGVuZ3RoKSB7XG4gICAgY29uc3QgdG9wID0gc3RhY2tBdG9tcy5sZW5ndGggLSAxO1xuICAgIGNvbnN0IGEgPSBzdGFja0F0b21zW3RvcF07XG4gICAgY29uc3QgYVN0YXRlID0gc3RhY2tTdGF0ZXNbdG9wXTtcbiAgICBpZiAodmlzaXRlZC5oYXMoYSkpIHtcbiAgICAgIHN0YWNrQXRvbXMucG9wKCk7XG4gICAgICBzdGFja1N0YXRlcy5wb3AoKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAodmlzaXRpbmcuaGFzKGEpKSB7XG4gICAgICBpZiAoaW52YWxpZGF0ZWRBdG9tcy5nZXQoYSkgPT09IGFTdGF0ZS5uKSB7XG4gICAgICAgIHNvcnRlZFJldmVyc2VkQXRvbXMucHVzaChhKTtcbiAgICAgICAgc29ydGVkUmV2ZXJzZWRTdGF0ZXMucHVzaChhU3RhdGUpO1xuICAgICAgfSBlbHNlIGlmICgoaW1wb3J0Lm1ldGEuZW52ID8gaW1wb3J0Lm1ldGEuZW52Lk1PREUgOiB2b2lkIDApICE9PSBcInByb2R1Y3Rpb25cIiAmJiBpbnZhbGlkYXRlZEF0b21zLmhhcyhhKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJbQnVnXSBpbnZhbGlkYXRlZCBhdG9tIGV4aXN0c1wiKTtcbiAgICAgIH1cbiAgICAgIHZpc2l0ZWQuYWRkKGEpO1xuICAgICAgc3RhY2tBdG9tcy5wb3AoKTtcbiAgICAgIHN0YWNrU3RhdGVzLnBvcCgpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIHZpc2l0aW5nLmFkZChhKTtcbiAgICBmb3IgKGNvbnN0IGQgb2YgZ2V0TW91bnRlZE9yUGVuZGluZ0RlcGVuZGVudHMoYSwgYVN0YXRlLCBtb3VudGVkTWFwKSkge1xuICAgICAgaWYgKCF2aXNpdGluZy5oYXMoZCkpIHtcbiAgICAgICAgc3RhY2tBdG9tcy5wdXNoKGQpO1xuICAgICAgICBzdGFja1N0YXRlcy5wdXNoKGVuc3VyZUF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGQpKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgZm9yIChsZXQgaSA9IHNvcnRlZFJldmVyc2VkQXRvbXMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICBjb25zdCBhID0gc29ydGVkUmV2ZXJzZWRBdG9tc1tpXTtcbiAgICBjb25zdCBhU3RhdGUgPSBzb3J0ZWRSZXZlcnNlZFN0YXRlc1tpXTtcbiAgICBsZXQgaGFzQ2hhbmdlZERlcHMgPSBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IGRlcCBvZiBhU3RhdGUuZC5rZXlzKCkpIHtcbiAgICAgIGlmIChkZXAgIT09IGEgJiYgY2hhbmdlZEF0b21zLmhhcyhkZXApKSB7XG4gICAgICAgIGhhc0NoYW5nZWREZXBzID0gdHJ1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChoYXNDaGFuZ2VkRGVwcykge1xuICAgICAgaW52YWxpZGF0ZWRBdG9tcy5zZXQoYSwgYVN0YXRlLm4pO1xuICAgICAgcmVhZEF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGEpO1xuICAgICAgbW91bnREZXBlbmRlbmNpZXMoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhKTtcbiAgICB9XG4gICAgaW52YWxpZGF0ZWRBdG9tcy5kZWxldGUoYSk7XG4gIH1cbn07XG5jb25zdCBzdG9yZU11dGF0aW9uU2V0ID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrU2V0KCk7XG5jb25zdCBCVUlMRElOR19CTE9DS19yZWFkQXRvbVN0YXRlID0gKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYXRvbSkgPT4ge1xuICB2YXIgX2EsIF9iO1xuICBjb25zdCBtb3VudGVkTWFwID0gYnVpbGRpbmdCbG9ja3NbMV07XG4gIGNvbnN0IGludmFsaWRhdGVkQXRvbXMgPSBidWlsZGluZ0Jsb2Nrc1syXTtcbiAgY29uc3QgY2hhbmdlZEF0b21zID0gYnVpbGRpbmdCbG9ja3NbM107XG4gIGNvbnN0IHN0b3JlSG9va3MgPSBidWlsZGluZ0Jsb2Nrc1s2XTtcbiAgY29uc3QgYXRvbVJlYWQgPSBidWlsZGluZ0Jsb2Nrc1s3XTtcbiAgY29uc3QgZW5zdXJlQXRvbVN0YXRlID0gYnVpbGRpbmdCbG9ja3NbMTFdO1xuICBjb25zdCBmbHVzaENhbGxiYWNrcyA9IGJ1aWxkaW5nQmxvY2tzWzEyXTtcbiAgY29uc3QgcmVjb21wdXRlSW52YWxpZGF0ZWRBdG9tcyA9IGJ1aWxkaW5nQmxvY2tzWzEzXTtcbiAgY29uc3QgcmVhZEF0b21TdGF0ZSA9IGJ1aWxkaW5nQmxvY2tzWzE0XTtcbiAgY29uc3Qgd3JpdGVBdG9tU3RhdGUgPSBidWlsZGluZ0Jsb2Nrc1sxNl07XG4gIGNvbnN0IG1vdW50RGVwZW5kZW5jaWVzID0gYnVpbGRpbmdCbG9ja3NbMTddO1xuICBjb25zdCBzZXRBdG9tU3RhdGVWYWx1ZU9yUHJvbWlzZSA9IGJ1aWxkaW5nQmxvY2tzWzIwXTtcbiAgY29uc3QgcmVnaXN0ZXJBYm9ydEhhbmRsZXIgPSBidWlsZGluZ0Jsb2Nrc1syNl07XG4gIGNvbnN0IHN0b3JlRXBvY2hIb2xkZXIgPSBidWlsZGluZ0Jsb2Nrc1syOF07XG4gIGNvbnN0IGF0b21TdGF0ZSA9IGVuc3VyZUF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pO1xuICBjb25zdCBzdG9yZUVwb2NoTnVtYmVyID0gc3RvcmVFcG9jaEhvbGRlclswXTtcbiAgaWYgKGlzQXRvbVN0YXRlSW5pdGlhbGl6ZWQoYXRvbVN0YXRlKSkge1xuICAgIGlmIChcbiAgICAgIC8vIElmIHRoZSBhdG9tIGlzIG1vdW50ZWQsIHdlIGNhbiB1c2UgY2FjaGVkIGF0b20gc3RhdGUsXG4gICAgICAvLyBiZWNhdXNlIGl0IHNob3VsZCBoYXZlIGJlZW4gdXBkYXRlZCBieSBkZXBlbmRlbmNpZXMuXG4gICAgICAvLyBXZSBjYW4ndCB1c2UgdGhlIGNhY2hlIGlmIHRoZSBhdG9tIGlzIGludmFsaWRhdGVkLlxuICAgICAgbW91bnRlZE1hcC5oYXMoYXRvbSkgJiYgaW52YWxpZGF0ZWRBdG9tcy5nZXQoYXRvbSkgIT09IGF0b21TdGF0ZS5uIHx8IC8vIElmIGF0b20gaXMgbm90IG1vdW50ZWQsIHdlIGNhbiB1c2UgY2FjaGVkIGF0b20gc3RhdGUsXG4gICAgICAvLyBvbmx5IGlmIHN0b3JlIGhhc24ndCBiZWVuIG11dGF0ZWQuXG4gICAgICBhdG9tU3RhdGUubSA9PT0gc3RvcmVFcG9jaE51bWJlclxuICAgICkge1xuICAgICAgYXRvbVN0YXRlLm0gPSBzdG9yZUVwb2NoTnVtYmVyO1xuICAgICAgcmV0dXJuIGF0b21TdGF0ZTtcbiAgICB9XG4gICAgbGV0IGhhc0NoYW5nZWREZXBzID0gZmFsc2U7XG4gICAgZm9yIChjb25zdCBbYSwgbl0gb2YgYXRvbVN0YXRlLmQpIHtcbiAgICAgIGlmIChyZWFkQXRvbVN0YXRlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYSkubiAhPT0gbikge1xuICAgICAgICBoYXNDaGFuZ2VkRGVwcyA9IHRydWU7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIWhhc0NoYW5nZWREZXBzKSB7XG4gICAgICBhdG9tU3RhdGUubSA9IHN0b3JlRXBvY2hOdW1iZXI7XG4gICAgICByZXR1cm4gYXRvbVN0YXRlO1xuICAgIH1cbiAgfVxuICBsZXQgaXNTeW5jID0gdHJ1ZTtcbiAgY29uc3QgcHJldkRlcHMgPSBuZXcgU2V0KGF0b21TdGF0ZS5kLmtleXMoKSk7XG4gIGNvbnN0IHBydW5lRGVwZW5kZW5jaWVzID0gKCkgPT4ge1xuICAgIGZvciAoY29uc3QgYSBvZiBwcmV2RGVwcykge1xuICAgICAgYXRvbVN0YXRlLmQuZGVsZXRlKGEpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgbW91bnREZXBlbmRlbmNpZXNJZkFzeW5jID0gKCkgPT4ge1xuICAgIGlmIChtb3VudGVkTWFwLmhhcyhhdG9tKSkge1xuICAgICAgY29uc3Qgc2hvdWxkUmVjb21wdXRlID0gIWNoYW5nZWRBdG9tcy5zaXplO1xuICAgICAgbW91bnREZXBlbmRlbmNpZXMoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tKTtcbiAgICAgIGlmIChzaG91bGRSZWNvbXB1dGUpIHtcbiAgICAgICAgcmVjb21wdXRlSW52YWxpZGF0ZWRBdG9tcyhidWlsZGluZ0Jsb2Nrcywgc3RvcmUpO1xuICAgICAgICBmbHVzaENhbGxiYWNrcyhidWlsZGluZ0Jsb2Nrcywgc3RvcmUpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgY29uc3QgZ2V0dGVyID0gKGEpID0+IHtcbiAgICB2YXIgX2EyO1xuICAgIGlmIChhID09PSBhdG9tKSB7XG4gICAgICBjb25zdCBhU3RhdGUyID0gZW5zdXJlQXRvbVN0YXRlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYSk7XG4gICAgICBpZiAoIWlzQXRvbVN0YXRlSW5pdGlhbGl6ZWQoYVN0YXRlMikpIHtcbiAgICAgICAgaWYgKGhhc0luaXRpYWxWYWx1ZShhKSkge1xuICAgICAgICAgIHNldEF0b21TdGF0ZVZhbHVlT3JQcm9taXNlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYSwgYS5pbml0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJubyBhdG9tIGluaXRcIik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiByZXR1cm5BdG9tVmFsdWUoYVN0YXRlMik7XG4gICAgfVxuICAgIGNvbnN0IGFTdGF0ZSA9IHJlYWRBdG9tU3RhdGUoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhKTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIHJldHVybkF0b21WYWx1ZShhU3RhdGUpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBwcmV2RGVwcy5kZWxldGUoYSk7XG4gICAgICBhdG9tU3RhdGUuZC5zZXQoYSwgYVN0YXRlLm4pO1xuICAgICAgaWYgKGlzUHJvbWlzZUxpa2UoYXRvbVN0YXRlLnYpKSB7XG4gICAgICAgIGFkZFBlbmRpbmdQcm9taXNlVG9EZXBlbmRlbmN5KGF0b20sIGF0b21TdGF0ZS52LCBhU3RhdGUpO1xuICAgICAgfVxuICAgICAgaWYgKG1vdW50ZWRNYXAuaGFzKGF0b20pKSB7XG4gICAgICAgIChfYTIgPSBtb3VudGVkTWFwLmdldChhKSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi50LmFkZChhdG9tKTtcbiAgICAgIH1cbiAgICAgIGlmICghaXNTeW5jKSB7XG4gICAgICAgIG1vdW50RGVwZW5kZW5jaWVzSWZBc3luYygpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgbGV0IGNvbnRyb2xsZXI7XG4gIGxldCBzZXRTZWxmO1xuICBjb25zdCBvcHRpb25zID0ge1xuICAgIGdldCBzaWduYWwoKSB7XG4gICAgICBpZiAoIWNvbnRyb2xsZXIpIHtcbiAgICAgICAgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjb250cm9sbGVyLnNpZ25hbDtcbiAgICB9LFxuICAgIGdldCBzZXRTZWxmKCkge1xuICAgICAgaWYgKChpbXBvcnQubWV0YS5lbnYgPyBpbXBvcnQubWV0YS5lbnYuTU9ERSA6IHZvaWQgMCkgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICBcIltERVBSRUNBVEVEXSBzZXRTZWxmIGlzIGRlcHJlY2F0ZWQgYW5kIHdpbGwgYmUgcmVtb3ZlZCBpbiB2My5cIlxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYgKChpbXBvcnQubWV0YS5lbnYgPyBpbXBvcnQubWV0YS5lbnYuTU9ERSA6IHZvaWQgMCkgIT09IFwicHJvZHVjdGlvblwiICYmICFpc0FjdHVhbGx5V3JpdGFibGVBdG9tKGF0b20pKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcInNldFNlbGYgZnVuY3Rpb24gY2Fubm90IGJlIHVzZWQgd2l0aCByZWFkLW9ubHkgYXRvbVwiKTtcbiAgICAgIH1cbiAgICAgIGlmICghc2V0U2VsZiAmJiBpc0FjdHVhbGx5V3JpdGFibGVBdG9tKGF0b20pKSB7XG4gICAgICAgIHNldFNlbGYgPSAoLi4uYXJncykgPT4ge1xuICAgICAgICAgIGlmICgoaW1wb3J0Lm1ldGEuZW52ID8gaW1wb3J0Lm1ldGEuZW52Lk1PREUgOiB2b2lkIDApICE9PSBcInByb2R1Y3Rpb25cIiAmJiBpc1N5bmMpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcInNldFNlbGYgZnVuY3Rpb24gY2Fubm90IGJlIGNhbGxlZCBpbiBzeW5jXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoIWlzU3luYykge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgcmV0dXJuIHdyaXRlQXRvbVN0YXRlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYXRvbSwgYXJncyk7XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICByZWNvbXB1dGVJbnZhbGlkYXRlZEF0b21zKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gICAgICAgICAgICAgIGZsdXNoQ2FsbGJhY2tzKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHNldFNlbGY7XG4gICAgfVxuICB9O1xuICBjb25zdCBwcmV2RXBvY2hOdW1iZXIgPSBhdG9tU3RhdGUubjtcbiAgY29uc3QgcHJldkludmFsaWRhdGVkID0gaW52YWxpZGF0ZWRBdG9tcy5nZXQoYXRvbSkgPT09IHByZXZFcG9jaE51bWJlcjtcbiAgdHJ5IHtcbiAgICBpZiAoKGltcG9ydC5tZXRhLmVudiA/IGltcG9ydC5tZXRhLmVudi5NT0RFIDogdm9pZCAwKSAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIHN0b3JlTXV0YXRpb25TZXQuZGVsZXRlKHN0b3JlKTtcbiAgICB9XG4gICAgY29uc3QgdmFsdWVPclByb21pc2UgPSBhdG9tUmVhZChcbiAgICAgIGJ1aWxkaW5nQmxvY2tzLFxuICAgICAgc3RvcmUsXG4gICAgICBhdG9tLFxuICAgICAgZ2V0dGVyLFxuICAgICAgb3B0aW9uc1xuICAgICk7XG4gICAgaWYgKChpbXBvcnQubWV0YS5lbnYgPyBpbXBvcnQubWV0YS5lbnYuTU9ERSA6IHZvaWQgMCkgIT09IFwicHJvZHVjdGlvblwiICYmIHN0b3JlTXV0YXRpb25TZXQuaGFzKHN0b3JlKSkge1xuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBcIkRldGVjdGVkIHN0b3JlIG11dGF0aW9uIGR1cmluZyBhdG9tIHJlYWQuIFRoaXMgaXMgbm90IHN1cHBvcnRlZC5cIlxuICAgICAgKTtcbiAgICB9XG4gICAgc2V0QXRvbVN0YXRlVmFsdWVPclByb21pc2UoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tLCB2YWx1ZU9yUHJvbWlzZSk7XG4gICAgaWYgKGlzUHJvbWlzZUxpa2UodmFsdWVPclByb21pc2UpKSB7XG4gICAgICByZWdpc3RlckFib3J0SGFuZGxlcihcbiAgICAgICAgYnVpbGRpbmdCbG9ja3MsXG4gICAgICAgIHN0b3JlLFxuICAgICAgICB2YWx1ZU9yUHJvbWlzZSxcbiAgICAgICAgKCkgPT4gY29udHJvbGxlciA9PSBudWxsID8gdm9pZCAwIDogY29udHJvbGxlci5hYm9ydCgpXG4gICAgICApO1xuICAgICAgY29uc3Qgc2V0dGxlID0gKCkgPT4ge1xuICAgICAgICBwcnVuZURlcGVuZGVuY2llcygpO1xuICAgICAgICBtb3VudERlcGVuZGVuY2llc0lmQXN5bmMoKTtcbiAgICAgIH07XG4gICAgICB2YWx1ZU9yUHJvbWlzZS50aGVuKHNldHRsZSwgc2V0dGxlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcHJ1bmVEZXBlbmRlbmNpZXMoKTtcbiAgICB9XG4gICAgKF9hID0gc3RvcmVIb29rcy5yKSA9PSBudWxsID8gdm9pZCAwIDogX2EuY2FsbChzdG9yZUhvb2tzLCBhdG9tKTtcbiAgICBhdG9tU3RhdGUubSA9IHN0b3JlRXBvY2hOdW1iZXI7XG4gICAgcmV0dXJuIGF0b21TdGF0ZTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBpZiAoc2hvdWxkVGhyb3dTeW5jaHJvbm91c2x5KGVycm9yKSkge1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICAgIGRlbGV0ZSBhdG9tU3RhdGUudjtcbiAgICBhdG9tU3RhdGUuZSA9IGVycm9yO1xuICAgICsrYXRvbVN0YXRlLm47XG4gICAgYXRvbVN0YXRlLm0gPSBzdG9yZUVwb2NoTnVtYmVyO1xuICAgIHJldHVybiBhdG9tU3RhdGU7XG4gIH0gZmluYWxseSB7XG4gICAgaXNTeW5jID0gZmFsc2U7XG4gICAgaWYgKGF0b21TdGF0ZS5uICE9PSBwcmV2RXBvY2hOdW1iZXIgJiYgcHJldkludmFsaWRhdGVkKSB7XG4gICAgICBpbnZhbGlkYXRlZEF0b21zLnNldChhdG9tLCBhdG9tU3RhdGUubik7XG4gICAgICBjaGFuZ2VkQXRvbXMuYWRkKGF0b20pO1xuICAgICAgKF9iID0gc3RvcmVIb29rcy5jKSA9PSBudWxsID8gdm9pZCAwIDogX2IuY2FsbChzdG9yZUhvb2tzLCBhdG9tKTtcbiAgICB9XG4gIH1cbn07XG5jb25zdCBCVUlMRElOR19CTE9DS19pbnZhbGlkYXRlRGVwZW5kZW50cyA9IChidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pID0+IHtcbiAgY29uc3QgbW91bnRlZE1hcCA9IGJ1aWxkaW5nQmxvY2tzWzFdO1xuICBjb25zdCBpbnZhbGlkYXRlZEF0b21zID0gYnVpbGRpbmdCbG9ja3NbMl07XG4gIGNvbnN0IGVuc3VyZUF0b21TdGF0ZSA9IGJ1aWxkaW5nQmxvY2tzWzExXTtcbiAgY29uc3Qgc3RhY2sgPSBbYXRvbV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGgpIHtcbiAgICBjb25zdCBhID0gc3RhY2sucG9wKCk7XG4gICAgY29uc3QgYVN0YXRlID0gZW5zdXJlQXRvbVN0YXRlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYSk7XG4gICAgZm9yIChjb25zdCBkIG9mIGdldE1vdW50ZWRPclBlbmRpbmdEZXBlbmRlbnRzKGEsIGFTdGF0ZSwgbW91bnRlZE1hcCkpIHtcbiAgICAgIGNvbnN0IGRTdGF0ZSA9IGVuc3VyZUF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGQpO1xuICAgICAgaWYgKGludmFsaWRhdGVkQXRvbXMuZ2V0KGQpICE9PSBkU3RhdGUubikge1xuICAgICAgICBpbnZhbGlkYXRlZEF0b21zLnNldChkLCBkU3RhdGUubik7XG4gICAgICAgIHN0YWNrLnB1c2goZCk7XG4gICAgICB9XG4gICAgfVxuICB9XG59O1xuY29uc3QgQlVJTERJTkdfQkxPQ0tfd3JpdGVBdG9tU3RhdGUgPSAoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tLCBhcmdzKSA9PiB7XG4gIGNvbnN0IGNoYW5nZWRBdG9tcyA9IGJ1aWxkaW5nQmxvY2tzWzNdO1xuICBjb25zdCBzdG9yZUhvb2tzID0gYnVpbGRpbmdCbG9ja3NbNl07XG4gIGNvbnN0IGF0b21Xcml0ZSA9IGJ1aWxkaW5nQmxvY2tzWzhdO1xuICBjb25zdCBlbnN1cmVBdG9tU3RhdGUgPSBidWlsZGluZ0Jsb2Nrc1sxMV07XG4gIGNvbnN0IGZsdXNoQ2FsbGJhY2tzID0gYnVpbGRpbmdCbG9ja3NbMTJdO1xuICBjb25zdCByZWNvbXB1dGVJbnZhbGlkYXRlZEF0b21zID0gYnVpbGRpbmdCbG9ja3NbMTNdO1xuICBjb25zdCByZWFkQXRvbVN0YXRlID0gYnVpbGRpbmdCbG9ja3NbMTRdO1xuICBjb25zdCBpbnZhbGlkYXRlRGVwZW5kZW50cyA9IGJ1aWxkaW5nQmxvY2tzWzE1XTtcbiAgY29uc3Qgd3JpdGVBdG9tU3RhdGUgPSBidWlsZGluZ0Jsb2Nrc1sxNl07XG4gIGNvbnN0IG1vdW50RGVwZW5kZW5jaWVzID0gYnVpbGRpbmdCbG9ja3NbMTddO1xuICBjb25zdCBzZXRBdG9tU3RhdGVWYWx1ZU9yUHJvbWlzZSA9IGJ1aWxkaW5nQmxvY2tzWzIwXTtcbiAgY29uc3Qgc3RvcmVFcG9jaEhvbGRlciA9IGJ1aWxkaW5nQmxvY2tzWzI4XTtcbiAgbGV0IGlzU3luYyA9IHRydWU7XG4gIGNvbnN0IGdldHRlciA9IChhKSA9PiByZXR1cm5BdG9tVmFsdWUocmVhZEF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGEpKTtcbiAgY29uc3Qgc2V0dGVyID0gKGEsIC4uLmFyZ3MyKSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIGNvbnN0IGFTdGF0ZSA9IGVuc3VyZUF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGEpO1xuICAgIHRyeSB7XG4gICAgICBpZiAoYSA9PT0gYXRvbSkge1xuICAgICAgICBpZiAoIWhhc0luaXRpYWxWYWx1ZShhKSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcImF0b20gbm90IHdyaXRhYmxlXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgoaW1wb3J0Lm1ldGEuZW52ID8gaW1wb3J0Lm1ldGEuZW52Lk1PREUgOiB2b2lkIDApICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgICAgIHN0b3JlTXV0YXRpb25TZXQuYWRkKHN0b3JlKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcmV2RXBvY2hOdW1iZXIgPSBhU3RhdGUubjtcbiAgICAgICAgY29uc3QgdiA9IGFyZ3MyWzBdO1xuICAgICAgICBzZXRBdG9tU3RhdGVWYWx1ZU9yUHJvbWlzZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGEsIHYpO1xuICAgICAgICBtb3VudERlcGVuZGVuY2llcyhidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGEpO1xuICAgICAgICBpZiAocHJldkVwb2NoTnVtYmVyICE9PSBhU3RhdGUubikge1xuICAgICAgICAgICsrc3RvcmVFcG9jaEhvbGRlclswXTtcbiAgICAgICAgICBjaGFuZ2VkQXRvbXMuYWRkKGEpO1xuICAgICAgICAgIGludmFsaWRhdGVEZXBlbmRlbnRzKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYSk7XG4gICAgICAgICAgKF9hID0gc3RvcmVIb29rcy5jKSA9PSBudWxsID8gdm9pZCAwIDogX2EuY2FsbChzdG9yZUhvb2tzLCBhKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdm9pZCAwO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHdyaXRlQXRvbVN0YXRlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYSwgYXJnczIpO1xuICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICBpZiAoIWlzU3luYykge1xuICAgICAgICByZWNvbXB1dGVJbnZhbGlkYXRlZEF0b21zKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gICAgICAgIGZsdXNoQ2FsbGJhY2tzKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuICB0cnkge1xuICAgIHJldHVybiBhdG9tV3JpdGUoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tLCBnZXR0ZXIsIHNldHRlciwgLi4uYXJncyk7XG4gIH0gZmluYWxseSB7XG4gICAgaXNTeW5jID0gZmFsc2U7XG4gIH1cbn07XG5jb25zdCBCVUlMRElOR19CTE9DS19tb3VudERlcGVuZGVuY2llcyA9IChidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pID0+IHtcbiAgdmFyIF9hO1xuICBjb25zdCBtb3VudGVkTWFwID0gYnVpbGRpbmdCbG9ja3NbMV07XG4gIGNvbnN0IGNoYW5nZWRBdG9tcyA9IGJ1aWxkaW5nQmxvY2tzWzNdO1xuICBjb25zdCBzdG9yZUhvb2tzID0gYnVpbGRpbmdCbG9ja3NbNl07XG4gIGNvbnN0IGVuc3VyZUF0b21TdGF0ZSA9IGJ1aWxkaW5nQmxvY2tzWzExXTtcbiAgY29uc3QgaW52YWxpZGF0ZURlcGVuZGVudHMgPSBidWlsZGluZ0Jsb2Nrc1sxNV07XG4gIGNvbnN0IG1vdW50QXRvbSA9IGJ1aWxkaW5nQmxvY2tzWzE4XTtcbiAgY29uc3QgdW5tb3VudEF0b20gPSBidWlsZGluZ0Jsb2Nrc1sxOV07XG4gIGNvbnN0IGF0b21TdGF0ZSA9IGVuc3VyZUF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pO1xuICBjb25zdCBtb3VudGVkID0gbW91bnRlZE1hcC5nZXQoYXRvbSk7XG4gIGlmIChtb3VudGVkICYmIGF0b21TdGF0ZS5kLnNpemUgPiAwKSB7XG4gICAgZm9yIChjb25zdCBbYSwgbl0gb2YgYXRvbVN0YXRlLmQpIHtcbiAgICAgIGlmICghbW91bnRlZC5kLmhhcyhhKSkge1xuICAgICAgICBjb25zdCBhU3RhdGUgPSBlbnN1cmVBdG9tU3RhdGUoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhKTtcbiAgICAgICAgY29uc3QgYU1vdW50ZWQgPSBtb3VudEF0b20oYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhKTtcbiAgICAgICAgYU1vdW50ZWQudC5hZGQoYXRvbSk7XG4gICAgICAgIG1vdW50ZWQuZC5hZGQoYSk7XG4gICAgICAgIGlmIChuICE9PSBhU3RhdGUubikge1xuICAgICAgICAgIGNoYW5nZWRBdG9tcy5hZGQoYSk7XG4gICAgICAgICAgaW52YWxpZGF0ZURlcGVuZGVudHMoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhKTtcbiAgICAgICAgICAoX2EgPSBzdG9yZUhvb2tzLmMpID09IG51bGwgPyB2b2lkIDAgOiBfYS5jYWxsKHN0b3JlSG9va3MsIGEpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3QgYSBvZiBtb3VudGVkLmQpIHtcbiAgICAgIGlmICghYXRvbVN0YXRlLmQuaGFzKGEpKSB7XG4gICAgICAgIG1vdW50ZWQuZC5kZWxldGUoYSk7XG4gICAgICAgIGNvbnN0IGFNb3VudGVkID0gdW5tb3VudEF0b20oYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhKTtcbiAgICAgICAgYU1vdW50ZWQgPT0gbnVsbCA/IHZvaWQgMCA6IGFNb3VudGVkLnQuZGVsZXRlKGF0b20pO1xuICAgICAgfVxuICAgIH1cbiAgfVxufTtcbmNvbnN0IEJVSUxESU5HX0JMT0NLX21vdW50QXRvbSA9IChidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pID0+IHtcbiAgdmFyIF9hO1xuICBjb25zdCBtb3VudGVkTWFwID0gYnVpbGRpbmdCbG9ja3NbMV07XG4gIGNvbnN0IG1vdW50Q2FsbGJhY2tzID0gYnVpbGRpbmdCbG9ja3NbNF07XG4gIGNvbnN0IHN0b3JlSG9va3MgPSBidWlsZGluZ0Jsb2Nrc1s2XTtcbiAgY29uc3QgYXRvbU9uTW91bnQgPSBidWlsZGluZ0Jsb2Nrc1sxMF07XG4gIGNvbnN0IGVuc3VyZUF0b21TdGF0ZSA9IGJ1aWxkaW5nQmxvY2tzWzExXTtcbiAgY29uc3QgZmx1c2hDYWxsYmFja3MgPSBidWlsZGluZ0Jsb2Nrc1sxMl07XG4gIGNvbnN0IHJlY29tcHV0ZUludmFsaWRhdGVkQXRvbXMgPSBidWlsZGluZ0Jsb2Nrc1sxM107XG4gIGNvbnN0IHJlYWRBdG9tU3RhdGUgPSBidWlsZGluZ0Jsb2Nrc1sxNF07XG4gIGNvbnN0IHdyaXRlQXRvbVN0YXRlID0gYnVpbGRpbmdCbG9ja3NbMTZdO1xuICBjb25zdCBtb3VudEF0b20gPSBidWlsZGluZ0Jsb2Nrc1sxOF07XG4gIGNvbnN0IGF0b21TdGF0ZSA9IGVuc3VyZUF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pO1xuICBsZXQgbW91bnRlZCA9IG1vdW50ZWRNYXAuZ2V0KGF0b20pO1xuICBpZiAoIW1vdW50ZWQpIHtcbiAgICByZWFkQXRvbVN0YXRlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYXRvbSk7XG4gICAgZm9yIChjb25zdCBhIG9mIGF0b21TdGF0ZS5kLmtleXMoKSkge1xuICAgICAgY29uc3QgYU1vdW50ZWQgPSBtb3VudEF0b20oYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhKTtcbiAgICAgIGFNb3VudGVkLnQuYWRkKGF0b20pO1xuICAgIH1cbiAgICBtb3VudGVkID0ge1xuICAgICAgbDogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcbiAgICAgIGQ6IG5ldyBTZXQoYXRvbVN0YXRlLmQua2V5cygpKSxcbiAgICAgIHQ6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KClcbiAgICB9O1xuICAgIG1vdW50ZWRNYXAuc2V0KGF0b20sIG1vdW50ZWQpO1xuICAgIGlmIChpc0FjdHVhbGx5V3JpdGFibGVBdG9tKGF0b20pICYmIGhhc09uTW91bnQoYXRvbSkpIHtcbiAgICAgIGNvbnN0IHByb2Nlc3NPbk1vdW50ID0gKCkgPT4ge1xuICAgICAgICBsZXQgaXNTeW5jID0gdHJ1ZTtcbiAgICAgICAgY29uc3Qgc2V0QXRvbSA9ICguLi5hcmdzKSA9PiB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiB3cml0ZUF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20sIGFyZ3MpO1xuICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBpZiAoIWlzU3luYykge1xuICAgICAgICAgICAgICByZWNvbXB1dGVJbnZhbGlkYXRlZEF0b21zKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gICAgICAgICAgICAgIGZsdXNoQ2FsbGJhY2tzKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG9uVW5tb3VudCA9IGF0b21Pbk1vdW50KGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYXRvbSwgc2V0QXRvbSk7XG4gICAgICAgICAgaWYgKG9uVW5tb3VudCkge1xuICAgICAgICAgICAgbW91bnRlZC51ID0gKCkgPT4ge1xuICAgICAgICAgICAgICBpc1N5bmMgPSB0cnVlO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIG9uVW5tb3VudCgpO1xuICAgICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIGlzU3luYyA9IGZhbHNlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBpc1N5bmMgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIG1vdW50Q2FsbGJhY2tzLmFkZChwcm9jZXNzT25Nb3VudCk7XG4gICAgfVxuICAgIChfYSA9IHN0b3JlSG9va3MubSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmNhbGwoc3RvcmVIb29rcywgYXRvbSk7XG4gIH1cbiAgcmV0dXJuIG1vdW50ZWQ7XG59O1xuY29uc3QgQlVJTERJTkdfQkxPQ0tfdW5tb3VudEF0b20gPSAoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tKSA9PiB7XG4gIHZhciBfYSwgX2I7XG4gIGNvbnN0IG1vdW50ZWRNYXAgPSBidWlsZGluZ0Jsb2Nrc1sxXTtcbiAgY29uc3QgdW5tb3VudENhbGxiYWNrcyA9IGJ1aWxkaW5nQmxvY2tzWzVdO1xuICBjb25zdCBzdG9yZUhvb2tzID0gYnVpbGRpbmdCbG9ja3NbNl07XG4gIGNvbnN0IGVuc3VyZUF0b21TdGF0ZSA9IGJ1aWxkaW5nQmxvY2tzWzExXTtcbiAgY29uc3QgdW5tb3VudEF0b20gPSBidWlsZGluZ0Jsb2Nrc1sxOV07XG4gIGNvbnN0IGF0b21TdGF0ZSA9IGVuc3VyZUF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pO1xuICBsZXQgbW91bnRlZCA9IG1vdW50ZWRNYXAuZ2V0KGF0b20pO1xuICBpZiAoIW1vdW50ZWQgfHwgbW91bnRlZC5sLnNpemUpIHtcbiAgICByZXR1cm4gbW91bnRlZDtcbiAgfVxuICBsZXQgaXNEZXBlbmRlbnQgPSBmYWxzZTtcbiAgZm9yIChjb25zdCBhIG9mIG1vdW50ZWQudCkge1xuICAgIGlmICgoX2EgPSBtb3VudGVkTWFwLmdldChhKSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmQuaGFzKGF0b20pKSB7XG4gICAgICBpc0RlcGVuZGVudCA9IHRydWU7XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cbiAgaWYgKCFpc0RlcGVuZGVudCkge1xuICAgIGlmIChtb3VudGVkLnUpIHtcbiAgICAgIHVubW91bnRDYWxsYmFja3MuYWRkKG1vdW50ZWQudSk7XG4gICAgfVxuICAgIG1vdW50ZWQgPSB2b2lkIDA7XG4gICAgbW91bnRlZE1hcC5kZWxldGUoYXRvbSk7XG4gICAgZm9yIChjb25zdCBhIG9mIGF0b21TdGF0ZS5kLmtleXMoKSkge1xuICAgICAgY29uc3QgYU1vdW50ZWQgPSB1bm1vdW50QXRvbShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGEpO1xuICAgICAgYU1vdW50ZWQgPT0gbnVsbCA/IHZvaWQgMCA6IGFNb3VudGVkLnQuZGVsZXRlKGF0b20pO1xuICAgIH1cbiAgICAoX2IgPSBzdG9yZUhvb2tzLnUpID09IG51bGwgPyB2b2lkIDAgOiBfYi5jYWxsKHN0b3JlSG9va3MsIGF0b20pO1xuICAgIHJldHVybiB2b2lkIDA7XG4gIH1cbiAgcmV0dXJuIG1vdW50ZWQ7XG59O1xuY29uc3QgQlVJTERJTkdfQkxPQ0tfc2V0QXRvbVN0YXRlVmFsdWVPclByb21pc2UgPSAoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tLCB2YWx1ZU9yUHJvbWlzZSkgPT4ge1xuICBjb25zdCBlbnN1cmVBdG9tU3RhdGUgPSBidWlsZGluZ0Jsb2Nrc1sxMV07XG4gIGNvbnN0IGFib3J0UHJvbWlzZSA9IGJ1aWxkaW5nQmxvY2tzWzI3XTtcbiAgY29uc3QgYXRvbVN0YXRlID0gZW5zdXJlQXRvbVN0YXRlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYXRvbSk7XG4gIGNvbnN0IGhhc1ByZXZWYWx1ZSA9IFwidlwiIGluIGF0b21TdGF0ZTtcbiAgY29uc3QgcHJldlZhbHVlID0gYXRvbVN0YXRlLnY7XG4gIGlmIChpc1Byb21pc2VMaWtlKHZhbHVlT3JQcm9taXNlKSkge1xuICAgIGZvciAoY29uc3QgYSBvZiBhdG9tU3RhdGUuZC5rZXlzKCkpIHtcbiAgICAgIGFkZFBlbmRpbmdQcm9taXNlVG9EZXBlbmRlbmN5KFxuICAgICAgICBhdG9tLFxuICAgICAgICB2YWx1ZU9yUHJvbWlzZSxcbiAgICAgICAgZW5zdXJlQXRvbVN0YXRlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYSlcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGF0b21TdGF0ZS52ID0gdmFsdWVPclByb21pc2U7XG4gIGRlbGV0ZSBhdG9tU3RhdGUuZTtcbiAgaWYgKCFoYXNQcmV2VmFsdWUgfHwgIU9iamVjdC5pcyhwcmV2VmFsdWUsIGF0b21TdGF0ZS52KSkge1xuICAgICsrYXRvbVN0YXRlLm47XG4gICAgaWYgKGlzUHJvbWlzZUxpa2UocHJldlZhbHVlKSkge1xuICAgICAgYWJvcnRQcm9taXNlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgcHJldlZhbHVlKTtcbiAgICB9XG4gIH1cbn07XG5jb25zdCBCVUlMRElOR19CTE9DS19zdG9yZUdldCA9IChidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pID0+IHtcbiAgY29uc3QgcmVhZEF0b21TdGF0ZSA9IGJ1aWxkaW5nQmxvY2tzWzE0XTtcbiAgcmV0dXJuIHJldHVybkF0b21WYWx1ZShyZWFkQXRvbVN0YXRlKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYXRvbSkpO1xufTtcbmNvbnN0IEJVSUxESU5HX0JMT0NLX3N0b3JlU2V0ID0gKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgYXRvbSwgLi4uYXJncykgPT4ge1xuICBjb25zdCBjaGFuZ2VkQXRvbXMgPSBidWlsZGluZ0Jsb2Nrc1szXTtcbiAgY29uc3QgZmx1c2hDYWxsYmFja3MgPSBidWlsZGluZ0Jsb2Nrc1sxMl07XG4gIGNvbnN0IHJlY29tcHV0ZUludmFsaWRhdGVkQXRvbXMgPSBidWlsZGluZ0Jsb2Nrc1sxM107XG4gIGNvbnN0IHdyaXRlQXRvbVN0YXRlID0gYnVpbGRpbmdCbG9ja3NbMTZdO1xuICBjb25zdCBwcmV2Q2hhbmdlZEF0b21zU2l6ZSA9IGNoYW5nZWRBdG9tcy5zaXplO1xuICB0cnkge1xuICAgIHJldHVybiB3cml0ZUF0b21TdGF0ZShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20sIGFyZ3MpO1xuICB9IGZpbmFsbHkge1xuICAgIGlmIChjaGFuZ2VkQXRvbXMuc2l6ZSAhPT0gcHJldkNoYW5nZWRBdG9tc1NpemUpIHtcbiAgICAgIHJlY29tcHV0ZUludmFsaWRhdGVkQXRvbXMoYnVpbGRpbmdCbG9ja3MsIHN0b3JlKTtcbiAgICAgIGZsdXNoQ2FsbGJhY2tzKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gICAgfVxuICB9XG59O1xuY29uc3QgQlVJTERJTkdfQkxPQ0tfc3RvcmVTdWIgPSAoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tLCBsaXN0ZW5lcikgPT4ge1xuICBjb25zdCBmbHVzaENhbGxiYWNrcyA9IGJ1aWxkaW5nQmxvY2tzWzEyXTtcbiAgY29uc3QgcmVjb21wdXRlSW52YWxpZGF0ZWRBdG9tcyA9IGJ1aWxkaW5nQmxvY2tzWzEzXTtcbiAgY29uc3QgbW91bnRBdG9tID0gYnVpbGRpbmdCbG9ja3NbMThdO1xuICBjb25zdCB1bm1vdW50QXRvbSA9IGJ1aWxkaW5nQmxvY2tzWzE5XTtcbiAgY29uc3QgbW91bnRlZCA9IG1vdW50QXRvbShidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pO1xuICBjb25zdCBsaXN0ZW5lcnMgPSBtb3VudGVkLmw7XG4gIGxpc3RlbmVycy5hZGQobGlzdGVuZXIpO1xuICByZWNvbXB1dGVJbnZhbGlkYXRlZEF0b21zKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gIGZsdXNoQ2FsbGJhY2tzKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgbGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcik7XG4gICAgdW5tb3VudEF0b20oYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tKTtcbiAgICByZWNvbXB1dGVJbnZhbGlkYXRlZEF0b21zKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gICAgZmx1c2hDYWxsYmFja3MoYnVpbGRpbmdCbG9ja3MsIHN0b3JlKTtcbiAgfTtcbn07XG5jb25zdCBCVUlMRElOR19CTE9DS19yZWdpc3RlckFib3J0SGFuZGxlciA9IChidWlsZGluZ0Jsb2NrcywgX3N0b3JlLCBwcm9taXNlLCBhYm9ydEhhbmRsZXIpID0+IHtcbiAgY29uc3QgYWJvcnRIYW5kbGVyc01hcCA9IGJ1aWxkaW5nQmxvY2tzWzI1XTtcbiAgbGV0IGFib3J0SGFuZGxlcnMgPSBhYm9ydEhhbmRsZXJzTWFwLmdldChwcm9taXNlKTtcbiAgaWYgKCFhYm9ydEhhbmRsZXJzKSB7XG4gICAgYWJvcnRIYW5kbGVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgYWJvcnRIYW5kbGVyc01hcC5zZXQocHJvbWlzZSwgYWJvcnRIYW5kbGVycyk7XG4gICAgY29uc3QgY2xlYW51cCA9ICgpID0+IGFib3J0SGFuZGxlcnNNYXAuZGVsZXRlKHByb21pc2UpO1xuICAgIHByb21pc2UudGhlbihjbGVhbnVwLCBjbGVhbnVwKTtcbiAgfVxuICBhYm9ydEhhbmRsZXJzLmFkZChhYm9ydEhhbmRsZXIpO1xufTtcbmNvbnN0IEJVSUxESU5HX0JMT0NLX2Fib3J0UHJvbWlzZSA9IChidWlsZGluZ0Jsb2NrcywgX3N0b3JlLCBwcm9taXNlKSA9PiB7XG4gIGNvbnN0IGFib3J0SGFuZGxlcnNNYXAgPSBidWlsZGluZ0Jsb2Nrc1syNV07XG4gIGNvbnN0IGFib3J0SGFuZGxlcnMgPSBhYm9ydEhhbmRsZXJzTWFwLmdldChwcm9taXNlKTtcbiAgYWJvcnRIYW5kbGVycyA9PSBudWxsID8gdm9pZCAwIDogYWJvcnRIYW5kbGVycy5mb3JFYWNoKChmbikgPT4gZm4oKSk7XG59O1xuY29uc3QgYnVpbGRpbmdCbG9ja01hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuZnVuY3Rpb24gZ2V0QnVpbGRpbmdCbG9ja3Moc3RvcmUpIHtcbiAgY29uc3QgYnVpbGRpbmdCbG9ja3MgPSBidWlsZGluZ0Jsb2NrTWFwLmdldChzdG9yZSk7XG4gIGlmICgoaW1wb3J0Lm1ldGEuZW52ID8gaW1wb3J0Lm1ldGEuZW52Lk1PREUgOiB2b2lkIDApICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhYnVpbGRpbmdCbG9ja3MpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBcIlN0b3JlIG11c3QgYmUgY3JlYXRlZCBieSBidWlsZFN0b3JlIHRvIHJlYWQgaXRzIGJ1aWxkaW5nIGJsb2Nrc1wiXG4gICAgKTtcbiAgfVxuICBjb25zdCBlbmhhbmNlQnVpbGRpbmdCbG9ja3MgPSBidWlsZGluZ0Jsb2Nrc1syNF07XG4gIGlmIChlbmhhbmNlQnVpbGRpbmdCbG9ja3MpIHtcbiAgICByZXR1cm4gZW5oYW5jZUJ1aWxkaW5nQmxvY2tzKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSk7XG4gIH1cbiAgcmV0dXJuIGJ1aWxkaW5nQmxvY2tzO1xufVxuZnVuY3Rpb24gYnVpbGRTdG9yZSguLi5wYXJ0aWFsQnVpbGRpbmdCbG9ja3MpIHtcbiAgY29uc3Qgc3RvcmUgPSB7XG4gICAgZ2V0KGF0b20pIHtcbiAgICAgIHJldHVybiBzdG9yZUdldChidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20pO1xuICAgIH0sXG4gICAgc2V0KGF0b20sIC4uLmFyZ3MpIHtcbiAgICAgIHJldHVybiBzdG9yZVNldChidWlsZGluZ0Jsb2Nrcywgc3RvcmUsIGF0b20sIC4uLmFyZ3MpO1xuICAgIH0sXG4gICAgc3ViKGF0b20sIGxpc3RlbmVyKSB7XG4gICAgICByZXR1cm4gc3RvcmVTdWIoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBhdG9tLCBsaXN0ZW5lcik7XG4gICAgfVxuICB9O1xuICBjb25zdCBidWlsZGluZ0Jsb2NrcyA9IFtcbiAgICAvLyBzdG9yZSBzdGF0ZVxuICAgIC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpLFxuICAgIC8vIGF0b21TdGF0ZU1hcFxuICAgIC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpLFxuICAgIC8vIG1vdW50ZWRNYXBcbiAgICAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKSxcbiAgICAvLyBpbnZhbGlkYXRlZEF0b21zXG4gICAgLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcbiAgICAvLyBjaGFuZ2VkQXRvbXNcbiAgICAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuICAgIC8vIG1vdW50Q2FsbGJhY2tzXG4gICAgLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcbiAgICAvLyB1bm1vdW50Q2FsbGJhY2tzXG4gICAge30sXG4gICAgLy8gc3RvcmVIb29rc1xuICAgIC8vIGF0b20gaW50ZXJjZXB0b3JzXG4gICAgQlVJTERJTkdfQkxPQ0tfYXRvbVJlYWQsXG4gICAgQlVJTERJTkdfQkxPQ0tfYXRvbVdyaXRlLFxuICAgIEJVSUxESU5HX0JMT0NLX2F0b21PbkluaXQsXG4gICAgQlVJTERJTkdfQkxPQ0tfYXRvbU9uTW91bnQsXG4gICAgLy8gYnVpbGRpbmctYmxvY2sgZnVuY3Rpb25zXG4gICAgQlVJTERJTkdfQkxPQ0tfZW5zdXJlQXRvbVN0YXRlLFxuICAgIEJVSUxESU5HX0JMT0NLX2ZsdXNoQ2FsbGJhY2tzLFxuICAgIEJVSUxESU5HX0JMT0NLX3JlY29tcHV0ZUludmFsaWRhdGVkQXRvbXMsXG4gICAgQlVJTERJTkdfQkxPQ0tfcmVhZEF0b21TdGF0ZSxcbiAgICBCVUlMRElOR19CTE9DS19pbnZhbGlkYXRlRGVwZW5kZW50cyxcbiAgICBCVUlMRElOR19CTE9DS193cml0ZUF0b21TdGF0ZSxcbiAgICBCVUlMRElOR19CTE9DS19tb3VudERlcGVuZGVuY2llcyxcbiAgICBCVUlMRElOR19CTE9DS19tb3VudEF0b20sXG4gICAgQlVJTERJTkdfQkxPQ0tfdW5tb3VudEF0b20sXG4gICAgQlVJTERJTkdfQkxPQ0tfc2V0QXRvbVN0YXRlVmFsdWVPclByb21pc2UsXG4gICAgQlVJTERJTkdfQkxPQ0tfc3RvcmVHZXQsXG4gICAgQlVJTERJTkdfQkxPQ0tfc3RvcmVTZXQsXG4gICAgQlVJTERJTkdfQkxPQ0tfc3RvcmVTdWIsXG4gICAgdm9pZCAwLFxuICAgIC8vIGVuaGFuY2VCdWlsZGluZ0Jsb2Nrc1xuICAgIC8vIGFib3J0YWJsZSBwcm9taXNlIHN1cHBvcnRcbiAgICAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKSxcbiAgICAvLyBhYm9ydEhhbmRsZXJzTWFwXG4gICAgQlVJTERJTkdfQkxPQ0tfcmVnaXN0ZXJBYm9ydEhhbmRsZXIsXG4gICAgQlVJTERJTkdfQkxPQ0tfYWJvcnRQcm9taXNlLFxuICAgIC8vIHN0b3JlIGVwb2NoXG4gICAgWzBdXG4gIF0ubWFwKChmbiwgaSkgPT4gcGFydGlhbEJ1aWxkaW5nQmxvY2tzW2ldIHx8IGZuKTtcbiAgYnVpbGRpbmdCbG9ja01hcC5zZXQoc3RvcmUsIE9iamVjdC5mcmVlemUoYnVpbGRpbmdCbG9ja3MpKTtcbiAgY29uc3Qgc3RvcmVHZXQgPSBidWlsZGluZ0Jsb2Nrc1syMV07XG4gIGNvbnN0IHN0b3JlU2V0ID0gYnVpbGRpbmdCbG9ja3NbMjJdO1xuICBjb25zdCBzdG9yZVN1YiA9IGJ1aWxkaW5nQmxvY2tzWzIzXTtcbiAgcmV0dXJuIHN0b3JlO1xufVxuXG5leHBvcnQgeyBhZGRQZW5kaW5nUHJvbWlzZVRvRGVwZW5kZW5jeSBhcyBJTlRFUk5BTF9hZGRQZW5kaW5nUHJvbWlzZVRvRGVwZW5kZW5jeSwgYnVpbGRTdG9yZSBhcyBJTlRFUk5BTF9idWlsZFN0b3JlUmV2MywgZ2V0QnVpbGRpbmdCbG9ja3MgYXMgSU5URVJOQUxfZ2V0QnVpbGRpbmdCbG9ja3NSZXYzLCBnZXRNb3VudGVkT3JQZW5kaW5nRGVwZW5kZW50cyBhcyBJTlRFUk5BTF9nZXRNb3VudGVkT3JQZW5kaW5nRGVwZW5kZW50cywgaGFzSW5pdGlhbFZhbHVlIGFzIElOVEVSTkFMX2hhc0luaXRpYWxWYWx1ZSwgaW5pdGlhbGl6ZVN0b3JlSG9va3MgYXMgSU5URVJOQUxfaW5pdGlhbGl6ZVN0b3JlSG9va3NSZXYzLCBpc0FjdHVhbGx5V3JpdGFibGVBdG9tIGFzIElOVEVSTkFMX2lzQWN0dWFsbHlXcml0YWJsZUF0b20sIGlzQXRvbVN0YXRlSW5pdGlhbGl6ZWQgYXMgSU5URVJOQUxfaXNBdG9tU3RhdGVJbml0aWFsaXplZCwgaXNQcm9taXNlTGlrZSBhcyBJTlRFUk5BTF9pc1Byb21pc2VMaWtlLCByZXR1cm5BdG9tVmFsdWUgYXMgSU5URVJOQUxfcmV0dXJuQXRvbVZhbHVlLCBzaG91bGRUaHJvd1N5bmNocm9ub3VzbHkgYXMgSU5URVJOQUxfc2hvdWxkVGhyb3dTeW5jaHJvbm91c2x5IH07XG4iLCJpbXBvcnQgeyBJTlRFUk5BTF9idWlsZFN0b3JlUmV2MyB9IGZyb20gJ2pvdGFpL3ZhbmlsbGEvaW50ZXJuYWxzJztcblxubGV0IGtleUNvdW50ID0gMDtcbmZ1bmN0aW9uIGF0b20ocmVhZCwgd3JpdGUpIHtcbiAgY29uc3Qga2V5ID0gYGF0b20keysra2V5Q291bnR9YDtcbiAgY29uc3QgY29uZmlnID0ge1xuICAgIHRvU3RyaW5nKCkge1xuICAgICAgcmV0dXJuIChpbXBvcnQubWV0YS5lbnYgPyBpbXBvcnQubWV0YS5lbnYuTU9ERSA6IHZvaWQgMCkgIT09IFwicHJvZHVjdGlvblwiICYmIHRoaXMuZGVidWdMYWJlbCA/IGtleSArIFwiOlwiICsgdGhpcy5kZWJ1Z0xhYmVsIDoga2V5O1xuICAgIH1cbiAgfTtcbiAgaWYgKHR5cGVvZiByZWFkID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICBjb25maWcucmVhZCA9IHJlYWQ7XG4gIH0gZWxzZSB7XG4gICAgY29uZmlnLmluaXQgPSByZWFkO1xuICAgIGNvbmZpZy5yZWFkID0gZGVmYXVsdFJlYWQ7XG4gICAgY29uZmlnLndyaXRlID0gZGVmYXVsdFdyaXRlO1xuICB9XG4gIGlmICh3cml0ZSkge1xuICAgIGNvbmZpZy53cml0ZSA9IHdyaXRlO1xuICB9XG4gIHJldHVybiBjb25maWc7XG59XG5mdW5jdGlvbiBkZWZhdWx0UmVhZChnZXQpIHtcbiAgcmV0dXJuIGdldCh0aGlzKTtcbn1cbmZ1bmN0aW9uIGRlZmF1bHRXcml0ZShnZXQsIHNldCwgYXJnKSB7XG4gIHJldHVybiBzZXQoXG4gICAgdGhpcyxcbiAgICB0eXBlb2YgYXJnID09PSBcImZ1bmN0aW9uXCIgPyBhcmcoZ2V0KHRoaXMpKSA6IGFyZ1xuICApO1xufVxuXG5sZXQgb3ZlcnJpZGRlbkNyZWF0ZVN0b3JlO1xuZnVuY3Rpb24gSU5URVJOQUxfb3ZlcnJpZGVDcmVhdGVTdG9yZShmbikge1xuICBvdmVycmlkZGVuQ3JlYXRlU3RvcmUgPSBmbihvdmVycmlkZGVuQ3JlYXRlU3RvcmUpO1xufVxuZnVuY3Rpb24gY3JlYXRlU3RvcmUoKSB7XG4gIGlmIChvdmVycmlkZGVuQ3JlYXRlU3RvcmUpIHtcbiAgICByZXR1cm4gb3ZlcnJpZGRlbkNyZWF0ZVN0b3JlKCk7XG4gIH1cbiAgcmV0dXJuIElOVEVSTkFMX2J1aWxkU3RvcmVSZXYzKCk7XG59XG5sZXQgZGVmYXVsdFN0b3JlO1xuZnVuY3Rpb24gZ2V0RGVmYXVsdFN0b3JlKCkge1xuICBpZiAoIWRlZmF1bHRTdG9yZSkge1xuICAgIGRlZmF1bHRTdG9yZSA9IGNyZWF0ZVN0b3JlKCk7XG4gICAgaWYgKChpbXBvcnQubWV0YS5lbnYgPyBpbXBvcnQubWV0YS5lbnYuTU9ERSA6IHZvaWQgMCkgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICBnbG9iYWxUaGlzLl9fSk9UQUlfREVGQVVMVF9TVE9SRV9fIHx8IChnbG9iYWxUaGlzLl9fSk9UQUlfREVGQVVMVF9TVE9SRV9fID0gZGVmYXVsdFN0b3JlKTtcbiAgICAgIGlmIChnbG9iYWxUaGlzLl9fSk9UQUlfREVGQVVMVF9TVE9SRV9fICE9PSBkZWZhdWx0U3RvcmUpIHtcbiAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgIFwiRGV0ZWN0ZWQgbXVsdGlwbGUgSm90YWkgaW5zdGFuY2VzLiBJdCBtYXkgY2F1c2UgdW5leHBlY3RlZCBiZWhhdmlvciB3aXRoIHRoZSBkZWZhdWx0IHN0b3JlLiBodHRwczovL2dpdGh1Yi5jb20vcG1uZHJzL2pvdGFpL2Rpc2N1c3Npb25zLzIwNDRcIlxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gZGVmYXVsdFN0b3JlO1xufVxuXG5leHBvcnQgeyBJTlRFUk5BTF9vdmVycmlkZUNyZWF0ZVN0b3JlLCBhdG9tLCBjcmVhdGVTdG9yZSwgZ2V0RGVmYXVsdFN0b3JlIH07XG4iLCIndXNlIGNsaWVudCc7XG5pbXBvcnQgUmVhY3QsIHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlUmVmLCBjcmVhdGVFbGVtZW50LCB1c2VSZWR1Y2VyLCB1c2VFZmZlY3QsIHVzZURlYnVnVmFsdWUsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZ2V0RGVmYXVsdFN0b3JlLCBjcmVhdGVTdG9yZSB9IGZyb20gJ2pvdGFpL3ZhbmlsbGEnO1xuaW1wb3J0IHsgSU5URVJOQUxfZ2V0QnVpbGRpbmdCbG9ja3NSZXYzIH0gZnJvbSAnam90YWkvdmFuaWxsYS9pbnRlcm5hbHMnO1xuXG5jb25zdCBTdG9yZUNvbnRleHQgPSBjcmVhdGVDb250ZXh0KFxuICB2b2lkIDBcbik7XG5mdW5jdGlvbiB1c2VTdG9yZShvcHRpb25zKSB7XG4gIGNvbnN0IHN0b3JlID0gdXNlQ29udGV4dChTdG9yZUNvbnRleHQpO1xuICByZXR1cm4gKG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMuc3RvcmUpIHx8IHN0b3JlIHx8IGdldERlZmF1bHRTdG9yZSgpO1xufVxuZnVuY3Rpb24gUHJvdmlkZXIoe1xuICBjaGlsZHJlbixcbiAgc3RvcmVcbn0pIHtcbiAgY29uc3Qgc3RvcmVSZWYgPSB1c2VSZWYobnVsbCk7XG4gIGlmIChzdG9yZSkge1xuICAgIHJldHVybiBjcmVhdGVFbGVtZW50KFN0b3JlQ29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZTogc3RvcmUgfSwgY2hpbGRyZW4pO1xuICB9XG4gIGlmIChzdG9yZVJlZi5jdXJyZW50ID09PSBudWxsKSB7XG4gICAgc3RvcmVSZWYuY3VycmVudCA9IGNyZWF0ZVN0b3JlKCk7XG4gIH1cbiAgcmV0dXJuIGNyZWF0ZUVsZW1lbnQoXG4gICAgU3RvcmVDb250ZXh0LlByb3ZpZGVyLFxuICAgIHtcbiAgICAgIC8vIFRPRE86IElmIHRoaXMgaXMgbm90IGEgZmFsc2UgcG9zaXRpdmUsIGNvbnNpZGVyIHVzaW5nIHVzZVN0YXRlIGluc3RlYWQgb2YgdXNlUmVmIGxpa2UgaHR0cHM6Ly9naXRodWIuY29tL3BtbmRycy9qb3RhaS9wdWxsLzI3NzFcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9yZWZzXG4gICAgICB2YWx1ZTogc3RvcmVSZWYuY3VycmVudFxuICAgIH0sXG4gICAgY2hpbGRyZW5cbiAgKTtcbn1cblxuY29uc3QgaXNQcm9taXNlTGlrZSA9ICh4KSA9PiB0eXBlb2YgKHggPT0gbnVsbCA/IHZvaWQgMCA6IHgudGhlbikgPT09IFwiZnVuY3Rpb25cIjtcbmNvbnN0IGF0dGFjaFByb21pc2VTdGF0dXMgPSAocHJvbWlzZSkgPT4ge1xuICBpZiAoIXByb21pc2Uuc3RhdHVzKSB7XG4gICAgcHJvbWlzZS5zdGF0dXMgPSBcInBlbmRpbmdcIjtcbiAgICBwcm9taXNlLnRoZW4oXG4gICAgICAodikgPT4ge1xuICAgICAgICBwcm9taXNlLnN0YXR1cyA9IFwiZnVsZmlsbGVkXCI7XG4gICAgICAgIHByb21pc2UudmFsdWUgPSB2O1xuICAgICAgfSxcbiAgICAgIChlKSA9PiB7XG4gICAgICAgIHByb21pc2Uuc3RhdHVzID0gXCJyZWplY3RlZFwiO1xuICAgICAgICBwcm9taXNlLnJlYXNvbiA9IGU7XG4gICAgICB9XG4gICAgKTtcbiAgfVxufTtcbmNvbnN0IHVzZSA9IFJlYWN0LnVzZSB8fCAvLyBBIHNoaW0gZm9yIG9sZGVyIFJlYWN0IHZlcnNpb25zXG4oKHByb21pc2UpID0+IHtcbiAgaWYgKHByb21pc2Uuc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuICAgIHRocm93IHByb21pc2U7XG4gIH0gZWxzZSBpZiAocHJvbWlzZS5zdGF0dXMgPT09IFwiZnVsZmlsbGVkXCIpIHtcbiAgICByZXR1cm4gcHJvbWlzZS52YWx1ZTtcbiAgfSBlbHNlIGlmIChwcm9taXNlLnN0YXR1cyA9PT0gXCJyZWplY3RlZFwiKSB7XG4gICAgdGhyb3cgcHJvbWlzZS5yZWFzb247XG4gIH0gZWxzZSB7XG4gICAgYXR0YWNoUHJvbWlzZVN0YXR1cyhwcm9taXNlKTtcbiAgICB0aHJvdyBwcm9taXNlO1xuICB9XG59KTtcbmNvbnN0IGNvbnRpbnVhYmxlUHJvbWlzZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuY29uc3QgY3JlYXRlQ29udGludWFibGVQcm9taXNlID0gKHN0b3JlLCBwcm9taXNlLCBnZXRWYWx1ZSkgPT4ge1xuICBjb25zdCBidWlsZGluZ0Jsb2NrcyA9IElOVEVSTkFMX2dldEJ1aWxkaW5nQmxvY2tzUmV2MyhzdG9yZSk7XG4gIGNvbnN0IHJlZ2lzdGVyQWJvcnRIYW5kbGVyID0gYnVpbGRpbmdCbG9ja3NbMjZdO1xuICBsZXQgY29udGludWFibGVQcm9taXNlID0gY29udGludWFibGVQcm9taXNlTWFwLmdldChwcm9taXNlKTtcbiAgaWYgKCFjb250aW51YWJsZVByb21pc2UpIHtcbiAgICBjb250aW51YWJsZVByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBsZXQgY3VyciA9IHByb21pc2U7XG4gICAgICBjb25zdCBvbkZ1bGZpbGxlZCA9IChtZSkgPT4gKHYpID0+IHtcbiAgICAgICAgaWYgKGN1cnIgPT09IG1lKSB7XG4gICAgICAgICAgcmVzb2x2ZSh2KTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IG9uUmVqZWN0ZWQgPSAobWUpID0+IChlKSA9PiB7XG4gICAgICAgIGlmIChjdXJyID09PSBtZSkge1xuICAgICAgICAgIHJlamVjdChlKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IG9uQWJvcnQgPSAoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgbmV4dFZhbHVlID0gZ2V0VmFsdWUoKTtcbiAgICAgICAgICBpZiAoaXNQcm9taXNlTGlrZShuZXh0VmFsdWUpKSB7XG4gICAgICAgICAgICBjb250aW51YWJsZVByb21pc2VNYXAuc2V0KG5leHRWYWx1ZSwgY29udGludWFibGVQcm9taXNlKTtcbiAgICAgICAgICAgIGN1cnIgPSBuZXh0VmFsdWU7XG4gICAgICAgICAgICBuZXh0VmFsdWUudGhlbihvbkZ1bGZpbGxlZChuZXh0VmFsdWUpLCBvblJlamVjdGVkKG5leHRWYWx1ZSkpO1xuICAgICAgICAgICAgcmVnaXN0ZXJBYm9ydEhhbmRsZXIoYnVpbGRpbmdCbG9ja3MsIHN0b3JlLCBuZXh0VmFsdWUsIG9uQWJvcnQpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlKG5leHRWYWx1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgcHJvbWlzZS50aGVuKG9uRnVsZmlsbGVkKHByb21pc2UpLCBvblJlamVjdGVkKHByb21pc2UpKTtcbiAgICAgIHJlZ2lzdGVyQWJvcnRIYW5kbGVyKGJ1aWxkaW5nQmxvY2tzLCBzdG9yZSwgcHJvbWlzZSwgb25BYm9ydCk7XG4gICAgfSk7XG4gICAgY29udGludWFibGVQcm9taXNlTWFwLnNldChwcm9taXNlLCBjb250aW51YWJsZVByb21pc2UpO1xuICB9XG4gIHJldHVybiBjb250aW51YWJsZVByb21pc2U7XG59O1xuZnVuY3Rpb24gdXNlQXRvbVZhbHVlKGF0b20sIG9wdGlvbnMpIHtcbiAgY29uc3QgeyBkZWxheSwgdW5zdGFibGVfcHJvbWlzZVN0YXR1czogcHJvbWlzZVN0YXR1cyA9ICFSZWFjdC51c2UgfSA9IG9wdGlvbnMgfHwge307XG4gIGNvbnN0IHN0b3JlID0gdXNlU3RvcmUob3B0aW9ucyk7XG4gIGNvbnN0IFtbdmFsdWVGcm9tUmVkdWNlciwgc3RvcmVGcm9tUmVkdWNlciwgYXRvbUZyb21SZWR1Y2VyXSwgcmVyZW5kZXJdID0gdXNlUmVkdWNlcihcbiAgICAocHJldikgPT4ge1xuICAgICAgY29uc3QgbmV4dFZhbHVlID0gc3RvcmUuZ2V0KGF0b20pO1xuICAgICAgaWYgKE9iamVjdC5pcyhwcmV2WzBdLCBuZXh0VmFsdWUpICYmIHByZXZbMV0gPT09IHN0b3JlICYmIHByZXZbMl0gPT09IGF0b20pIHtcbiAgICAgICAgcmV0dXJuIHByZXY7XG4gICAgICB9XG4gICAgICByZXR1cm4gW25leHRWYWx1ZSwgc3RvcmUsIGF0b21dO1xuICAgIH0sXG4gICAgdm9pZCAwLFxuICAgICgpID0+IFtzdG9yZS5nZXQoYXRvbSksIHN0b3JlLCBhdG9tXVxuICApO1xuICBsZXQgdmFsdWUgPSB2YWx1ZUZyb21SZWR1Y2VyO1xuICBpZiAoc3RvcmVGcm9tUmVkdWNlciAhPT0gc3RvcmUgfHwgYXRvbUZyb21SZWR1Y2VyICE9PSBhdG9tKSB7XG4gICAgcmVyZW5kZXIoKTtcbiAgICB2YWx1ZSA9IHN0b3JlLmdldChhdG9tKTtcbiAgfVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHVuc3ViID0gc3RvcmUuc3ViKGF0b20sICgpID0+IHtcbiAgICAgIGlmIChwcm9taXNlU3RhdHVzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgdmFsdWUyID0gc3RvcmUuZ2V0KGF0b20pO1xuICAgICAgICAgIGlmIChpc1Byb21pc2VMaWtlKHZhbHVlMikpIHtcbiAgICAgICAgICAgIGF0dGFjaFByb21pc2VTdGF0dXMoXG4gICAgICAgICAgICAgIGNyZWF0ZUNvbnRpbnVhYmxlUHJvbWlzZShzdG9yZSwgdmFsdWUyLCAoKSA9PiBzdG9yZS5nZXQoYXRvbSkpXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIGRlbGF5ID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihgW0RFUFJFQ0FURURdIGRlbGF5IG9wdGlvbiBpcyBkZXByZWNhdGVkIGFuZCB3aWxsIGJlIHJlbW92ZWQgaW4gdjMuXG5cbk1pZ3JhdGlvbiBndWlkZTpcblxuQ3JlYXRlIGEgY3VzdG9tIGhvb2sgbGlrZSB0aGUgZm9sbG93aW5nLlxuXG5mdW5jdGlvbiB1c2VBdG9tVmFsdWVXaXRoRGVsYXk8VmFsdWU+KFxuICBhdG9tOiBBdG9tPFZhbHVlPixcbiAgb3B0aW9uczogeyBkZWxheTogbnVtYmVyIH0sXG4pOiBWYWx1ZSB7XG4gIGNvbnN0IHsgZGVsYXkgfSA9IG9wdGlvbnNcbiAgY29uc3Qgc3RvcmUgPSB1c2VTdG9yZShvcHRpb25zKVxuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IHVzZVN0YXRlKCgpID0+IHN0b3JlLmdldChhdG9tKSlcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB1bnN1YiA9IHN0b3JlLnN1YihhdG9tLCAoKSA9PiB7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFZhbHVlKHN0b3JlLmdldChhdG9tKSksIGRlbGF5KVxuICAgIH0pXG4gICAgcmV0dXJuIHVuc3ViXG4gIH0sIFtzdG9yZSwgYXRvbSwgZGVsYXldKVxuICByZXR1cm4gdmFsdWVcbn1cbmApO1xuICAgICAgICBzZXRUaW1lb3V0KHJlcmVuZGVyLCBkZWxheSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHJlcmVuZGVyKCk7XG4gICAgfSk7XG4gICAgcmVyZW5kZXIoKTtcbiAgICByZXR1cm4gdW5zdWI7XG4gIH0sIFtzdG9yZSwgYXRvbSwgZGVsYXksIHByb21pc2VTdGF0dXNdKTtcbiAgdXNlRGVidWdWYWx1ZSh2YWx1ZSk7XG4gIGlmIChpc1Byb21pc2VMaWtlKHZhbHVlKSkge1xuICAgIGNvbnN0IHByb21pc2UgPSBjcmVhdGVDb250aW51YWJsZVByb21pc2UoXG4gICAgICBzdG9yZSxcbiAgICAgIHZhbHVlLFxuICAgICAgKCkgPT4gc3RvcmUuZ2V0KGF0b20pXG4gICAgKTtcbiAgICBpZiAocHJvbWlzZVN0YXR1cykge1xuICAgICAgYXR0YWNoUHJvbWlzZVN0YXR1cyhwcm9taXNlKTtcbiAgICB9XG4gICAgcmV0dXJuIHVzZShwcm9taXNlKTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG5cbmZ1bmN0aW9uIHVzZVNldEF0b20oYXRvbSwgb3B0aW9ucykge1xuICBjb25zdCBzdG9yZSA9IHVzZVN0b3JlKG9wdGlvbnMpO1xuICBjb25zdCBzZXRBdG9tID0gdXNlQ2FsbGJhY2soXG4gICAgKC4uLmFyZ3MpID0+IHtcbiAgICAgIGlmICgoaW1wb3J0Lm1ldGEuZW52ID8gaW1wb3J0Lm1ldGEuZW52Lk1PREUgOiB2b2lkIDApICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhKFwid3JpdGVcIiBpbiBhdG9tKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJub3Qgd3JpdGFibGUgYXRvbVwiKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdG9yZS5zZXQoYXRvbSwgLi4uYXJncyk7XG4gICAgfSxcbiAgICBbc3RvcmUsIGF0b21dXG4gICk7XG4gIHJldHVybiBzZXRBdG9tO1xufVxuXG5mdW5jdGlvbiB1c2VBdG9tKGF0b20sIG9wdGlvbnMpIHtcbiAgcmV0dXJuIFtcbiAgICB1c2VBdG9tVmFsdWUoYXRvbSwgb3B0aW9ucyksXG4gICAgLy8gV2UgZG8gd3JvbmcgdHlwZSBhc3NlcnRpb24gaGVyZSwgd2hpY2ggcmVzdWx0cyBpbiB0aHJvd2luZyBhbiBlcnJvci5cbiAgICB1c2VTZXRBdG9tKGF0b20sIG9wdGlvbnMpXG4gIF07XG59XG5cbmV4cG9ydCB7IFByb3ZpZGVyLCB1c2VBdG9tLCB1c2VBdG9tVmFsdWUsIHVzZVNldEF0b20sIHVzZVN0b3JlIH07XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyXSwibWFwcGluZ3MiOiI7OztBQUFBLFNBQVMsZ0JBQWdCLE1BQU07Q0FDN0IsT0FBTyxVQUFVO0FBQ25CO0FBQ0EsU0FBUyx1QkFBdUIsTUFBTTtDQUNwQyxPQUFPLE9BQU8sS0FBSyxVQUFVO0FBQy9CO0FBQ0EsU0FBUyxXQUFXLE1BQU07Q0FDeEIsT0FBTyxDQUFDLENBQUMsS0FBSztBQUNoQjtBQUNBLFNBQVMsdUJBQXVCLFdBQVc7Q0FDekMsT0FBTyxPQUFPLGFBQWEsT0FBTztBQUNwQztBQUNBLFNBQVMsZ0JBQWdCLFdBQVc7Q0FDbEMsSUFBSSxPQUFPLFdBQ1QsTUFBTSxVQUFVO0NBRWxCLEtBQUssWUFBWSxNQUFNLFlBQVksSUFBSSxPQUFPLEtBQUssT0FBTyxnQkFBZ0IsRUFBRSxPQUFPLFlBQ2pGLE1BQU0sSUFBSSxNQUFNLHFDQUFxQztDQUV2RCxPQUFPLFVBQVU7QUFDbkI7QUFDQSxTQUFTQSxnQkFBYyxHQUFHO0NBQ3hCLE9BQU8sUUFBUSxLQUFLLE9BQU8sS0FBSyxJQUFJLEVBQUUsVUFBVTtBQUNsRDtBQUNBLFNBQVMseUJBQXlCLE9BQU87Q0FDdkMsSUFBSSxFQUFFLGlCQUFpQixRQUNyQixPQUFPO0NBRVQsTUFBTSxPQUFPLE1BQU07Q0FDbkIsTUFBTSxVQUFVLE1BQU0sUUFBUSxZQUFZO0NBQzFDLFFBQVEsU0FBUyxnQkFBZ0IsU0FBUyxxQkFBcUIsUUFBUSxTQUFTLFlBQVksS0FBSyxRQUFRLFNBQVMsb0JBQW9CLEtBQUssUUFBUSxTQUFTLGdCQUFnQjtBQUM5SztBQUNBLFNBQVMsOEJBQThCLE1BQU0sU0FBUyxxQkFBcUI7Q0FDekUsSUFBSSxDQUFDLG9CQUFvQixFQUFFLElBQUksSUFBSSxHQUFHO0VBQ3BDLG9CQUFvQixFQUFFLElBQUksSUFBSTtFQUM5QixNQUFNLGdCQUFnQixvQkFBb0IsRUFBRSxPQUFPLElBQUk7RUFDdkQsUUFBUSxLQUFLLFNBQVMsT0FBTztDQUMvQjtBQUNGO0FBQ0EsU0FBUyw4QkFBOEIsTUFBTSxXQUFXLFlBQVk7Q0FDbEUsTUFBTSxVQUFVLFdBQVcsSUFBSSxJQUFJO0NBQ25DLE1BQU0sb0JBQW9CLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUTtDQUM3RCxNQUFNLG9CQUFvQixVQUFVO0NBQ3BDLElBQUksRUFBRSxxQkFBcUIsT0FBTyxLQUFLLElBQUksa0JBQWtCLE9BQzNELE9BQU87Q0FFVCxJQUFJLENBQUMsa0JBQWtCLE1BQ3JCLE9BQU87Q0FFVCxNQUFNLGFBQWEsSUFBSSxJQUFJLGlCQUFpQjtDQUM1QyxLQUFLLE1BQU0sS0FBSyxtQkFDZCxXQUFXLElBQUksQ0FBQztDQUVsQixPQUFPO0FBQ1Q7QUE0Q0EsU0FBUyxVQUFVLE1BQU07Q0FDdkIsT0FBTyxDQUFDLENBQUMsS0FBSztBQUNoQjtBQUNBLElBQU0sMkJBQTJCLGlCQUFpQixRQUFRLE1BQU0sR0FBRyxXQUFXLEtBQUssS0FBSyxHQUFHLE1BQU07QUFDakcsSUFBTSw0QkFBNEIsaUJBQWlCLFFBQVEsTUFBTSxHQUFHLFdBQVcsS0FBSyxNQUFNLEdBQUcsTUFBTTtBQUNuRyxJQUFNLDZCQUE2QixpQkFBaUIsT0FBTyxTQUFTLEtBQUssZ0JBQWdCLEtBQUs7QUFDOUYsSUFBTSw4QkFBOEIsaUJBQWlCLFFBQVEsTUFBTSxZQUFZO0NBQzdFLElBQUk7Q0FDSixRQUFRLEtBQUssS0FBSyxZQUFZLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLE9BQU87QUFDckU7QUFDQSxJQUFNLGtDQUFrQyxnQkFBZ0IsT0FBTyxTQUFTO0NBQ3RFLElBQUk7Q0FDSixNQUFNLGVBQWUsZUFBZTtDQUNwQyxJQUFJLFlBQVksYUFBYSxJQUFJLElBQUk7Q0FDckMsSUFBSSxDQUFDLFdBQVc7RUFDZCxNQUFNLGFBQWEsZUFBZTtFQUNsQyxNQUFNLGFBQWEsZUFBZTtFQUNsQyxZQUFZO0dBQUUsbUJBQW1CLElBQUksSUFBSTtHQUFHLG1CQUFtQixJQUFJLElBQUk7R0FBRyxHQUFHO0VBQUU7RUFDL0UsYUFBYSxJQUFJLE1BQU0sU0FBUztFQUNoQyxDQUFDLEtBQUssV0FBVyxNQUFNLFFBQWdCLEdBQUcsS0FBSyxZQUFZLElBQUk7RUFDL0QsSUFBSSxVQUFVLElBQUksR0FDaEIsV0FBVyxnQkFBZ0IsT0FBTyxJQUFJO0NBRTFDO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBTSxpQ0FBaUMsZ0JBQWdCLFVBQVU7Q0FDL0QsSUFBSTtDQUNKLE1BQU0sYUFBYSxlQUFlO0NBQ2xDLE1BQU0sZUFBZSxlQUFlO0NBQ3BDLE1BQU0saUJBQWlCLGVBQWU7Q0FDdEMsTUFBTSxtQkFBbUIsZUFBZTtDQUN4QyxNQUFNLGFBQWEsZUFBZTtDQUNsQyxNQUFNLDRCQUE0QixlQUFlO0NBQ2pELElBQUksQ0FBQyxXQUFXLEtBQUssQ0FBQyxhQUFhLFFBQVEsQ0FBQyxlQUFlLFFBQVEsQ0FBQyxpQkFBaUIsTUFDbkY7Q0FFRixNQUFNLFNBQVMsQ0FBQztDQUNoQixNQUFNLFFBQVEsT0FBTztFQUNuQixJQUFJO0dBQ0YsR0FBRztFQUNMLFNBQVMsR0FBRztHQUNWLE9BQU8sS0FBSyxDQUFDO0VBQ2Y7Q0FDRjtDQUNBLEdBQUc7RUFDRCxJQUFJLFdBQVcsR0FDYixLQUFLLFdBQVcsQ0FBQztFQUVuQixNQUFNLDRCQUE0QixJQUFJLElBQUk7RUFDMUMsS0FBSyxNQUFNLFFBQVEsY0FBYztHQUMvQixNQUFNLGFBQWEsS0FBSyxXQUFXLElBQUksSUFBSSxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUc7R0FDcEUsSUFBSSxXQUNGLEtBQUssTUFBTSxZQUFZLFdBQ3JCLFVBQVUsSUFBSSxRQUFRO0VBRzVCO0VBQ0EsYUFBYSxNQUFNO0VBQ25CLEtBQUssTUFBTSxNQUFNLGtCQUNmLFVBQVUsSUFBSSxFQUFFO0VBRWxCLGlCQUFpQixNQUFNO0VBQ3ZCLEtBQUssTUFBTSxNQUFNLGdCQUNmLFVBQVUsSUFBSSxFQUFFO0VBRWxCLGVBQWUsTUFBTTtFQUNyQixLQUFLLE1BQU0sTUFBTSxXQUNmLEtBQUssRUFBRTtFQUVULElBQUksYUFBYSxNQUNmLDBCQUEwQixnQkFBZ0IsS0FBSztDQUVuRCxTQUFTLGFBQWEsUUFBUSxpQkFBaUIsUUFBUSxlQUFlO0NBQ3RFLElBQUksT0FBTyxRQUNULE1BQU0sSUFBSSxlQUFlLE1BQU07QUFFbkM7QUFDQSxJQUFNLDRDQUE0QyxnQkFBZ0IsVUFBVTtDQUMxRSxNQUFNLGFBQWEsZUFBZTtDQUNsQyxNQUFNLG1CQUFtQixlQUFlO0NBQ3hDLE1BQU0sZUFBZSxlQUFlO0NBQ3BDLE1BQU0sa0JBQWtCLGVBQWU7Q0FDdkMsTUFBTSxnQkFBZ0IsZUFBZTtDQUNyQyxNQUFNLG9CQUFvQixlQUFlO0NBQ3pDLElBQUksQ0FBQyxhQUFhLE1BQ2hCO0NBRUYsTUFBTSxzQkFBc0IsQ0FBQztDQUM3QixNQUFNLHVCQUF1QixDQUFDO0NBQzlCLE1BQU0sMkJBQTJCLElBQUksUUFBUTtDQUM3QyxNQUFNLDBCQUEwQixJQUFJLFFBQVE7Q0FDNUMsTUFBTSxhQUFhLENBQUM7Q0FDcEIsTUFBTSxjQUFjLENBQUM7Q0FDckIsS0FBSyxNQUFNLFFBQVEsY0FBYztFQUMvQixXQUFXLEtBQUssSUFBSTtFQUNwQixZQUFZLEtBQUssZ0JBQWdCLGdCQUFnQixPQUFPLElBQUksQ0FBQztDQUMvRDtDQUNBLE9BQU8sV0FBVyxRQUFRO0VBQ3hCLE1BQU0sTUFBTSxXQUFXLFNBQVM7RUFDaEMsTUFBTSxJQUFJLFdBQVc7RUFDckIsTUFBTSxTQUFTLFlBQVk7RUFDM0IsSUFBSSxRQUFRLElBQUksQ0FBQyxHQUFHO0dBQ2xCLFdBQVcsSUFBSTtHQUNmLFlBQVksSUFBSTtHQUNoQjtFQUNGO0VBQ0EsSUFBSSxTQUFTLElBQUksQ0FBQyxHQUFHO0dBQ25CLElBQUksaUJBQWlCLElBQUksQ0FBQyxNQUFNLE9BQU8sR0FBRztJQUN4QyxvQkFBb0IsS0FBSyxDQUFDO0lBQzFCLHFCQUFxQixLQUFLLE1BQU07R0FDbEMsT0FBTyxLQUFLLFlBQVksTUFBTSxZQUFZLElBQUksT0FBTyxLQUFLLE9BQU8sZ0JBQWdCLGlCQUFpQixJQUFJLENBQUMsR0FDckcsTUFBTSxJQUFJLE1BQU0sK0JBQStCO0dBRWpELFFBQVEsSUFBSSxDQUFDO0dBQ2IsV0FBVyxJQUFJO0dBQ2YsWUFBWSxJQUFJO0dBQ2hCO0VBQ0Y7RUFDQSxTQUFTLElBQUksQ0FBQztFQUNkLEtBQUssTUFBTSxLQUFLLDhCQUE4QixHQUFHLFFBQVEsVUFBVSxHQUNqRSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsR0FBRztHQUNwQixXQUFXLEtBQUssQ0FBQztHQUNqQixZQUFZLEtBQUssZ0JBQWdCLGdCQUFnQixPQUFPLENBQUMsQ0FBQztFQUM1RDtDQUVKO0NBQ0EsS0FBSyxJQUFJLElBQUksb0JBQW9CLFNBQVMsR0FBRyxLQUFLLEdBQUcsRUFBRSxHQUFHO0VBQ3hELE1BQU0sSUFBSSxvQkFBb0I7RUFDOUIsTUFBTSxTQUFTLHFCQUFxQjtFQUNwQyxJQUFJLGlCQUFpQjtFQUNyQixLQUFLLE1BQU0sT0FBTyxPQUFPLEVBQUUsS0FBSyxHQUM5QixJQUFJLFFBQVEsS0FBSyxhQUFhLElBQUksR0FBRyxHQUFHO0dBQ3RDLGlCQUFpQjtHQUNqQjtFQUNGO0VBRUYsSUFBSSxnQkFBZ0I7R0FDbEIsaUJBQWlCLElBQUksR0FBRyxPQUFPLENBQUM7R0FDaEMsY0FBYyxnQkFBZ0IsT0FBTyxDQUFDO0dBQ3RDLGtCQUFrQixnQkFBZ0IsT0FBTyxDQUFDO0VBQzVDO0VBQ0EsaUJBQWlCLE9BQU8sQ0FBQztDQUMzQjtBQUNGO0FBQ0EsSUFBTSxtQ0FBbUMsSUFBSSxRQUFRO0FBQ3JELElBQU0sZ0NBQWdDLGdCQUFnQixPQUFPLFNBQVM7Q0FDcEUsSUFBSSxJQUFJO0NBQ1IsTUFBTSxhQUFhLGVBQWU7Q0FDbEMsTUFBTSxtQkFBbUIsZUFBZTtDQUN4QyxNQUFNLGVBQWUsZUFBZTtDQUNwQyxNQUFNLGFBQWEsZUFBZTtDQUNsQyxNQUFNLFdBQVcsZUFBZTtDQUNoQyxNQUFNLGtCQUFrQixlQUFlO0NBQ3ZDLE1BQU0saUJBQWlCLGVBQWU7Q0FDdEMsTUFBTSw0QkFBNEIsZUFBZTtDQUNqRCxNQUFNLGdCQUFnQixlQUFlO0NBQ3JDLE1BQU0saUJBQWlCLGVBQWU7Q0FDdEMsTUFBTSxvQkFBb0IsZUFBZTtDQUN6QyxNQUFNLDZCQUE2QixlQUFlO0NBQ2xELE1BQU0sdUJBQXVCLGVBQWU7Q0FDNUMsTUFBTSxtQkFBbUIsZUFBZTtDQUN4QyxNQUFNLFlBQVksZ0JBQWdCLGdCQUFnQixPQUFPLElBQUk7Q0FDN0QsTUFBTSxtQkFBbUIsaUJBQWlCO0NBQzFDLElBQUksdUJBQXVCLFNBQVMsR0FBRztFQUNyQyxJQUlFLFdBQVcsSUFBSSxJQUFJLEtBQUssaUJBQWlCLElBQUksSUFBSSxNQUFNLFVBQVUsS0FFakUsVUFBVSxNQUFNLGtCQUNoQjtHQUNBLFVBQVUsSUFBSTtHQUNkLE9BQU87RUFDVDtFQUNBLElBQUksaUJBQWlCO0VBQ3JCLEtBQUssTUFBTSxDQUFDLEdBQUcsTUFBTSxVQUFVLEdBQzdCLElBQUksY0FBYyxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUc7R0FDbkQsaUJBQWlCO0dBQ2pCO0VBQ0Y7RUFFRixJQUFJLENBQUMsZ0JBQWdCO0dBQ25CLFVBQVUsSUFBSTtHQUNkLE9BQU87RUFDVDtDQUNGO0NBQ0EsSUFBSSxTQUFTO0NBQ2IsTUFBTSxXQUFXLElBQUksSUFBSSxVQUFVLEVBQUUsS0FBSyxDQUFDO0NBQzNDLE1BQU0sMEJBQTBCO0VBQzlCLEtBQUssTUFBTSxLQUFLLFVBQ2QsVUFBVSxFQUFFLE9BQU8sQ0FBQztDQUV4QjtDQUNBLE1BQU0saUNBQWlDO0VBQ3JDLElBQUksV0FBVyxJQUFJLElBQUksR0FBRztHQUN4QixNQUFNLGtCQUFrQixDQUFDLGFBQWE7R0FDdEMsa0JBQWtCLGdCQUFnQixPQUFPLElBQUk7R0FDN0MsSUFBSSxpQkFBaUI7SUFDbkIsMEJBQTBCLGdCQUFnQixLQUFLO0lBQy9DLGVBQWUsZ0JBQWdCLEtBQUs7R0FDdEM7RUFDRjtDQUNGO0NBQ0EsTUFBTSxVQUFVLE1BQU07RUFDcEIsSUFBSTtFQUNKLElBQUksTUFBTSxNQUFNO0dBQ2QsTUFBTSxVQUFVLGdCQUFnQixnQkFBZ0IsT0FBTyxDQUFDO0dBQ3hELElBQUksQ0FBQyx1QkFBdUIsT0FBTyxHQUNqQyxJQUFJLGdCQUFnQixDQUFDLEdBQ25CLDJCQUEyQixnQkFBZ0IsT0FBTyxHQUFHLEVBQUUsSUFBSTtRQUUzRCxNQUFNLElBQUksTUFBTSxjQUFjO0dBR2xDLE9BQU8sZ0JBQWdCLE9BQU87RUFDaEM7RUFDQSxNQUFNLFNBQVMsY0FBYyxnQkFBZ0IsT0FBTyxDQUFDO0VBQ3JELElBQUk7R0FDRixPQUFPLGdCQUFnQixNQUFNO0VBQy9CLFVBQVU7R0FDUixTQUFTLE9BQU8sQ0FBQztHQUNqQixVQUFVLEVBQUUsSUFBSSxHQUFHLE9BQU8sQ0FBQztHQUMzQixJQUFJQSxnQkFBYyxVQUFVLENBQUMsR0FDM0IsOEJBQThCLE1BQU0sVUFBVSxHQUFHLE1BQU07R0FFekQsSUFBSSxXQUFXLElBQUksSUFBSSxHQUNyQixDQUFDLE1BQU0sV0FBVyxJQUFJLENBQUMsTUFBTSxRQUFnQixJQUFJLEVBQUUsSUFBSSxJQUFJO0dBRTdELElBQUksQ0FBQyxRQUNILHlCQUF5QjtFQUU3QjtDQUNGO0NBQ0EsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLFVBQVU7RUFDZCxJQUFJLFNBQVM7R0FDWCxJQUFJLENBQUMsWUFDSCxhQUFhLElBQUksZ0JBQWdCO0dBRW5DLE9BQU8sV0FBVztFQUNwQjtFQUNBLElBQUksVUFBVTtHQUNaLEtBQUssWUFBWSxNQUFNLFlBQVksSUFBSSxPQUFPLEtBQUssT0FBTyxjQUN4RCxRQUFRLEtBQ04sK0RBQ0Y7R0FFRixLQUFLLFlBQVksTUFBTSxZQUFZLElBQUksT0FBTyxLQUFLLE9BQU8sZ0JBQWdCLENBQUMsdUJBQXVCLElBQUksR0FDcEcsUUFBUSxLQUFLLHFEQUFxRDtHQUVwRSxJQUFJLENBQUMsV0FBVyx1QkFBdUIsSUFBSSxHQUN6QyxXQUFXLEdBQUcsU0FBUztJQUNyQixLQUFLLFlBQVksTUFBTSxZQUFZLElBQUksT0FBTyxLQUFLLE9BQU8sZ0JBQWdCLFFBQ3hFLFFBQVEsS0FBSywyQ0FBMkM7SUFFMUQsSUFBSSxDQUFDLFFBQ0gsSUFBSTtLQUNGLE9BQU8sZUFBZSxnQkFBZ0IsT0FBTyxNQUFNLElBQUk7SUFDekQsVUFBVTtLQUNSLDBCQUEwQixnQkFBZ0IsS0FBSztLQUMvQyxlQUFlLGdCQUFnQixLQUFLO0lBQ3RDO0dBRUo7R0FFRixPQUFPO0VBQ1Q7Q0FDRjtDQUNBLE1BQU0sa0JBQWtCLFVBQVU7Q0FDbEMsTUFBTSxrQkFBa0IsaUJBQWlCLElBQUksSUFBSSxNQUFNO0NBQ3ZELElBQUk7RUFDRixLQUFLLFlBQVksTUFBTSxZQUFZLElBQUksT0FBTyxLQUFLLE9BQU8sY0FDeEQsaUJBQWlCLE9BQU8sS0FBSztFQUUvQixNQUFNLGlCQUFpQixTQUNyQixnQkFDQSxPQUNBLE1BQ0EsUUFDQSxPQUNGO0VBQ0EsS0FBSyxZQUFZLE1BQU0sWUFBWSxJQUFJLE9BQU8sS0FBSyxPQUFPLGdCQUFnQixpQkFBaUIsSUFBSSxLQUFLLEdBQ2xHLFFBQVEsS0FDTixrRUFDRjtFQUVGLDJCQUEyQixnQkFBZ0IsT0FBTyxNQUFNLGNBQWM7RUFDdEUsSUFBSUEsZ0JBQWMsY0FBYyxHQUFHO0dBQ2pDLHFCQUNFLGdCQUNBLE9BQ0Esc0JBQ00sY0FBYyxPQUFPLEtBQUssSUFBSSxXQUFXLE1BQU0sQ0FDdkQ7R0FDQSxNQUFNLGVBQWU7SUFDbkIsa0JBQWtCO0lBQ2xCLHlCQUF5QjtHQUMzQjtHQUNBLGVBQWUsS0FBSyxRQUFRLE1BQU07RUFDcEMsT0FDRSxrQkFBa0I7RUFFcEIsQ0FBQyxLQUFLLFdBQVcsTUFBTSxRQUFnQixHQUFHLEtBQUssWUFBWSxJQUFJO0VBQy9ELFVBQVUsSUFBSTtFQUNkLE9BQU87Q0FDVCxTQUFTLE9BQU87RUFDZCxJQUFJLHlCQUF5QixLQUFLLEdBQ2hDLE1BQU07RUFFUixPQUFPLFVBQVU7RUFDakIsVUFBVSxJQUFJO0VBQ2QsRUFBRSxVQUFVO0VBQ1osVUFBVSxJQUFJO0VBQ2QsT0FBTztDQUNULFVBQVU7RUFDUixTQUFTO0VBQ1QsSUFBSSxVQUFVLE1BQU0sbUJBQW1CLGlCQUFpQjtHQUN0RCxpQkFBaUIsSUFBSSxNQUFNLFVBQVUsQ0FBQztHQUN0QyxhQUFhLElBQUksSUFBSTtHQUNyQixDQUFDLEtBQUssV0FBVyxNQUFNLFFBQWdCLEdBQUcsS0FBSyxZQUFZLElBQUk7RUFDakU7Q0FDRjtBQUNGO0FBQ0EsSUFBTSx1Q0FBdUMsZ0JBQWdCLE9BQU8sU0FBUztDQUMzRSxNQUFNLGFBQWEsZUFBZTtDQUNsQyxNQUFNLG1CQUFtQixlQUFlO0NBQ3hDLE1BQU0sa0JBQWtCLGVBQWU7Q0FDdkMsTUFBTSxRQUFRLENBQUMsSUFBSTtDQUNuQixPQUFPLE1BQU0sUUFBUTtFQUNuQixNQUFNLElBQUksTUFBTSxJQUFJO0VBQ3BCLE1BQU0sU0FBUyxnQkFBZ0IsZ0JBQWdCLE9BQU8sQ0FBQztFQUN2RCxLQUFLLE1BQU0sS0FBSyw4QkFBOEIsR0FBRyxRQUFRLFVBQVUsR0FBRztHQUNwRSxNQUFNLFNBQVMsZ0JBQWdCLGdCQUFnQixPQUFPLENBQUM7R0FDdkQsSUFBSSxpQkFBaUIsSUFBSSxDQUFDLE1BQU0sT0FBTyxHQUFHO0lBQ3hDLGlCQUFpQixJQUFJLEdBQUcsT0FBTyxDQUFDO0lBQ2hDLE1BQU0sS0FBSyxDQUFDO0dBQ2Q7RUFDRjtDQUNGO0FBQ0Y7QUFDQSxJQUFNLGlDQUFpQyxnQkFBZ0IsT0FBTyxNQUFNLFNBQVM7Q0FDM0UsTUFBTSxlQUFlLGVBQWU7Q0FDcEMsTUFBTSxhQUFhLGVBQWU7Q0FDbEMsTUFBTSxZQUFZLGVBQWU7Q0FDakMsTUFBTSxrQkFBa0IsZUFBZTtDQUN2QyxNQUFNLGlCQUFpQixlQUFlO0NBQ3RDLE1BQU0sNEJBQTRCLGVBQWU7Q0FDakQsTUFBTSxnQkFBZ0IsZUFBZTtDQUNyQyxNQUFNLHVCQUF1QixlQUFlO0NBQzVDLE1BQU0saUJBQWlCLGVBQWU7Q0FDdEMsTUFBTSxvQkFBb0IsZUFBZTtDQUN6QyxNQUFNLDZCQUE2QixlQUFlO0NBQ2xELE1BQU0sbUJBQW1CLGVBQWU7Q0FDeEMsSUFBSSxTQUFTO0NBQ2IsTUFBTSxVQUFVLE1BQU0sZ0JBQWdCLGNBQWMsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDO0NBQzdFLE1BQU0sVUFBVSxHQUFHLEdBQUcsVUFBVTtFQUM5QixJQUFJO0VBQ0osTUFBTSxTQUFTLGdCQUFnQixnQkFBZ0IsT0FBTyxDQUFDO0VBQ3ZELElBQUk7R0FDRixJQUFJLE1BQU0sTUFBTTtJQUNkLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUNwQixNQUFNLElBQUksTUFBTSxtQkFBbUI7SUFFckMsS0FBSyxZQUFZLE1BQU0sWUFBWSxJQUFJLE9BQU8sS0FBSyxPQUFPLGNBQ3hELGlCQUFpQixJQUFJLEtBQUs7SUFFNUIsTUFBTSxrQkFBa0IsT0FBTztJQUMvQixNQUFNLElBQUksTUFBTTtJQUNoQiwyQkFBMkIsZ0JBQWdCLE9BQU8sR0FBRyxDQUFDO0lBQ3RELGtCQUFrQixnQkFBZ0IsT0FBTyxDQUFDO0lBQzFDLElBQUksb0JBQW9CLE9BQU8sR0FBRztLQUNoQyxFQUFFLGlCQUFpQjtLQUNuQixhQUFhLElBQUksQ0FBQztLQUNsQixxQkFBcUIsZ0JBQWdCLE9BQU8sQ0FBQztLQUM3QyxDQUFDLEtBQUssV0FBVyxNQUFNLFFBQWdCLEdBQUcsS0FBSyxZQUFZLENBQUM7SUFDOUQ7SUFDQTtHQUNGLE9BQ0UsT0FBTyxlQUFlLGdCQUFnQixPQUFPLEdBQUcsS0FBSztFQUV6RCxVQUFVO0dBQ1IsSUFBSSxDQUFDLFFBQVE7SUFDWCwwQkFBMEIsZ0JBQWdCLEtBQUs7SUFDL0MsZUFBZSxnQkFBZ0IsS0FBSztHQUN0QztFQUNGO0NBQ0Y7Q0FDQSxJQUFJO0VBQ0YsT0FBTyxVQUFVLGdCQUFnQixPQUFPLE1BQU0sUUFBUSxRQUFRLEdBQUcsSUFBSTtDQUN2RSxVQUFVO0VBQ1IsU0FBUztDQUNYO0FBQ0Y7QUFDQSxJQUFNLG9DQUFvQyxnQkFBZ0IsT0FBTyxTQUFTO0NBQ3hFLElBQUk7Q0FDSixNQUFNLGFBQWEsZUFBZTtDQUNsQyxNQUFNLGVBQWUsZUFBZTtDQUNwQyxNQUFNLGFBQWEsZUFBZTtDQUNsQyxNQUFNLGtCQUFrQixlQUFlO0NBQ3ZDLE1BQU0sdUJBQXVCLGVBQWU7Q0FDNUMsTUFBTSxZQUFZLGVBQWU7Q0FDakMsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxZQUFZLGdCQUFnQixnQkFBZ0IsT0FBTyxJQUFJO0NBQzdELE1BQU0sVUFBVSxXQUFXLElBQUksSUFBSTtDQUNuQyxJQUFJLFdBQVcsVUFBVSxFQUFFLE9BQU8sR0FBRztFQUNuQyxLQUFLLE1BQU0sQ0FBQyxHQUFHLE1BQU0sVUFBVSxHQUM3QixJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxHQUFHO0dBQ3JCLE1BQU0sU0FBUyxnQkFBZ0IsZ0JBQWdCLE9BQU8sQ0FBQztHQUV2RCxVQUQyQixnQkFBZ0IsT0FBTyxDQUMzQyxDQUFDLENBQUMsRUFBRSxJQUFJLElBQUk7R0FDbkIsUUFBUSxFQUFFLElBQUksQ0FBQztHQUNmLElBQUksTUFBTSxPQUFPLEdBQUc7SUFDbEIsYUFBYSxJQUFJLENBQUM7SUFDbEIscUJBQXFCLGdCQUFnQixPQUFPLENBQUM7SUFDN0MsQ0FBQyxLQUFLLFdBQVcsTUFBTSxRQUFnQixHQUFHLEtBQUssWUFBWSxDQUFDO0dBQzlEO0VBQ0Y7RUFFRixLQUFLLE1BQU0sS0FBSyxRQUFRLEdBQ3RCLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLEdBQUc7R0FDdkIsUUFBUSxFQUFFLE9BQU8sQ0FBQztHQUVsQixZQUQ2QixnQkFBZ0IsT0FBTyxDQUM3QyxDQUFDLEVBQTZCLEVBQUUsT0FBTyxJQUFJO0VBQ3BEO0NBRUo7QUFDRjtBQUNBLElBQU0sNEJBQTRCLGdCQUFnQixPQUFPLFNBQVM7Q0FDaEUsSUFBSTtDQUNKLE1BQU0sYUFBYSxlQUFlO0NBQ2xDLE1BQU0saUJBQWlCLGVBQWU7Q0FDdEMsTUFBTSxhQUFhLGVBQWU7Q0FDbEMsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxrQkFBa0IsZUFBZTtDQUN2QyxNQUFNLGlCQUFpQixlQUFlO0NBQ3RDLE1BQU0sNEJBQTRCLGVBQWU7Q0FDakQsTUFBTSxnQkFBZ0IsZUFBZTtDQUNyQyxNQUFNLGlCQUFpQixlQUFlO0NBQ3RDLE1BQU0sWUFBWSxlQUFlO0NBQ2pDLE1BQU0sWUFBWSxnQkFBZ0IsZ0JBQWdCLE9BQU8sSUFBSTtDQUM3RCxJQUFJLFVBQVUsV0FBVyxJQUFJLElBQUk7Q0FDakMsSUFBSSxDQUFDLFNBQVM7RUFDWixjQUFjLGdCQUFnQixPQUFPLElBQUk7RUFDekMsS0FBSyxNQUFNLEtBQUssVUFBVSxFQUFFLEtBQUssR0FFL0IsVUFEMkIsZ0JBQWdCLE9BQU8sQ0FDM0MsQ0FBQyxDQUFDLEVBQUUsSUFBSSxJQUFJO0VBRXJCLFVBQVU7R0FDUixtQkFBbUIsSUFBSSxJQUFJO0dBQzNCLEdBQUcsSUFBSSxJQUFJLFVBQVUsRUFBRSxLQUFLLENBQUM7R0FDN0IsbUJBQW1CLElBQUksSUFBSTtFQUM3QjtFQUNBLFdBQVcsSUFBSSxNQUFNLE9BQU87RUFDNUIsSUFBSSx1QkFBdUIsSUFBSSxLQUFLLFdBQVcsSUFBSSxHQUFHO0dBQ3BELE1BQU0sdUJBQXVCO0lBQzNCLElBQUksU0FBUztJQUNiLE1BQU0sV0FBVyxHQUFHLFNBQVM7S0FDM0IsSUFBSTtNQUNGLE9BQU8sZUFBZSxnQkFBZ0IsT0FBTyxNQUFNLElBQUk7S0FDekQsVUFBVTtNQUNSLElBQUksQ0FBQyxRQUFRO09BQ1gsMEJBQTBCLGdCQUFnQixLQUFLO09BQy9DLGVBQWUsZ0JBQWdCLEtBQUs7TUFDdEM7S0FDRjtJQUNGO0lBQ0EsSUFBSTtLQUNGLE1BQU0sWUFBWSxZQUFZLGdCQUFnQixPQUFPLE1BQU0sT0FBTztLQUNsRSxJQUFJLFdBQ0YsUUFBUSxVQUFVO01BQ2hCLFNBQVM7TUFDVCxJQUFJO09BQ0YsVUFBVTtNQUNaLFVBQVU7T0FDUixTQUFTO01BQ1g7S0FDRjtJQUVKLFVBQVU7S0FDUixTQUFTO0lBQ1g7R0FDRjtHQUNBLGVBQWUsSUFBSSxjQUFjO0VBQ25DO0VBQ0EsQ0FBQyxLQUFLLFdBQVcsTUFBTSxRQUFnQixHQUFHLEtBQUssWUFBWSxJQUFJO0NBQ2pFO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBTSw4QkFBOEIsZ0JBQWdCLE9BQU8sU0FBUztDQUNsRSxJQUFJLElBQUk7Q0FDUixNQUFNLGFBQWEsZUFBZTtDQUNsQyxNQUFNLG1CQUFtQixlQUFlO0NBQ3hDLE1BQU0sYUFBYSxlQUFlO0NBQ2xDLE1BQU0sa0JBQWtCLGVBQWU7Q0FDdkMsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxZQUFZLGdCQUFnQixnQkFBZ0IsT0FBTyxJQUFJO0NBQzdELElBQUksVUFBVSxXQUFXLElBQUksSUFBSTtDQUNqQyxJQUFJLENBQUMsV0FBVyxRQUFRLEVBQUUsTUFDeEIsT0FBTztDQUVULElBQUksY0FBYztDQUNsQixLQUFLLE1BQU0sS0FBSyxRQUFRLEdBQ3RCLEtBQUssS0FBSyxXQUFXLElBQUksQ0FBQyxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsRUFBRSxJQUFJLElBQUksR0FBRztFQUM5RCxjQUFjO0VBQ2Q7Q0FDRjtDQUVGLElBQUksQ0FBQyxhQUFhO0VBQ2hCLElBQUksUUFBUSxHQUNWLGlCQUFpQixJQUFJLFFBQVEsQ0FBQztFQUVoQyxVQUFVLEtBQUs7RUFDZixXQUFXLE9BQU8sSUFBSTtFQUN0QixLQUFLLE1BQU0sS0FBSyxVQUFVLEVBQUUsS0FBSyxHQUUvQixZQUQ2QixnQkFBZ0IsT0FBTyxDQUM3QyxDQUFDLEVBQTZCLEVBQUUsT0FBTyxJQUFJO0VBRXBELENBQUMsS0FBSyxXQUFXLE1BQU0sUUFBZ0IsR0FBRyxLQUFLLFlBQVksSUFBSTtFQUMvRDtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBTSw2Q0FBNkMsZ0JBQWdCLE9BQU8sTUFBTSxtQkFBbUI7Q0FDakcsTUFBTSxrQkFBa0IsZUFBZTtDQUN2QyxNQUFNLGVBQWUsZUFBZTtDQUNwQyxNQUFNLFlBQVksZ0JBQWdCLGdCQUFnQixPQUFPLElBQUk7Q0FDN0QsTUFBTSxlQUFlLE9BQU87Q0FDNUIsTUFBTSxZQUFZLFVBQVU7Q0FDNUIsSUFBSUEsZ0JBQWMsY0FBYyxHQUM5QixLQUFLLE1BQU0sS0FBSyxVQUFVLEVBQUUsS0FBSyxHQUMvQiw4QkFDRSxNQUNBLGdCQUNBLGdCQUFnQixnQkFBZ0IsT0FBTyxDQUFDLENBQzFDO0NBR0osVUFBVSxJQUFJO0NBQ2QsT0FBTyxVQUFVO0NBQ2pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUcsV0FBVyxVQUFVLENBQUMsR0FBRztFQUN2RCxFQUFFLFVBQVU7RUFDWixJQUFJQSxnQkFBYyxTQUFTLEdBQ3pCLGFBQWEsZ0JBQWdCLE9BQU8sU0FBUztDQUVqRDtBQUNGO0FBQ0EsSUFBTSwyQkFBMkIsZ0JBQWdCLE9BQU8sU0FBUztDQUMvRCxNQUFNLGdCQUFnQixlQUFlO0NBQ3JDLE9BQU8sZ0JBQWdCLGNBQWMsZ0JBQWdCLE9BQU8sSUFBSSxDQUFDO0FBQ25FO0FBQ0EsSUFBTSwyQkFBMkIsZ0JBQWdCLE9BQU8sTUFBTSxHQUFHLFNBQVM7Q0FDeEUsTUFBTSxlQUFlLGVBQWU7Q0FDcEMsTUFBTSxpQkFBaUIsZUFBZTtDQUN0QyxNQUFNLDRCQUE0QixlQUFlO0NBQ2pELE1BQU0saUJBQWlCLGVBQWU7Q0FDdEMsTUFBTSx1QkFBdUIsYUFBYTtDQUMxQyxJQUFJO0VBQ0YsT0FBTyxlQUFlLGdCQUFnQixPQUFPLE1BQU0sSUFBSTtDQUN6RCxVQUFVO0VBQ1IsSUFBSSxhQUFhLFNBQVMsc0JBQXNCO0dBQzlDLDBCQUEwQixnQkFBZ0IsS0FBSztHQUMvQyxlQUFlLGdCQUFnQixLQUFLO0VBQ3RDO0NBQ0Y7QUFDRjtBQUNBLElBQU0sMkJBQTJCLGdCQUFnQixPQUFPLE1BQU0sYUFBYTtDQUN6RSxNQUFNLGlCQUFpQixlQUFlO0NBQ3RDLE1BQU0sNEJBQTRCLGVBQWU7Q0FDakQsTUFBTSxZQUFZLGVBQWU7Q0FDakMsTUFBTSxjQUFjLGVBQWU7Q0FFbkMsTUFBTSxZQURVLFVBQVUsZ0JBQWdCLE9BQU8sSUFDekIsQ0FBQyxDQUFDO0NBQzFCLFVBQVUsSUFBSSxRQUFRO0NBQ3RCLDBCQUEwQixnQkFBZ0IsS0FBSztDQUMvQyxlQUFlLGdCQUFnQixLQUFLO0NBQ3BDLGFBQWE7RUFDWCxVQUFVLE9BQU8sUUFBUTtFQUN6QixZQUFZLGdCQUFnQixPQUFPLElBQUk7RUFDdkMsMEJBQTBCLGdCQUFnQixLQUFLO0VBQy9DLGVBQWUsZ0JBQWdCLEtBQUs7Q0FDdEM7QUFDRjtBQUNBLElBQU0sdUNBQXVDLGdCQUFnQixRQUFRLFNBQVMsaUJBQWlCO0NBQzdGLE1BQU0sbUJBQW1CLGVBQWU7Q0FDeEMsSUFBSSxnQkFBZ0IsaUJBQWlCLElBQUksT0FBTztDQUNoRCxJQUFJLENBQUMsZUFBZTtFQUNsQixnQ0FBZ0MsSUFBSSxJQUFJO0VBQ3hDLGlCQUFpQixJQUFJLFNBQVMsYUFBYTtFQUMzQyxNQUFNLGdCQUFnQixpQkFBaUIsT0FBTyxPQUFPO0VBQ3JELFFBQVEsS0FBSyxTQUFTLE9BQU87Q0FDL0I7Q0FDQSxjQUFjLElBQUksWUFBWTtBQUNoQztBQUNBLElBQU0sK0JBQStCLGdCQUFnQixRQUFRLFlBQVk7Q0FHdkUsZUFGd0MsR0FDRixDQUFDLElBQUksT0FDL0IsQ0FBQyxFQUFrQyxTQUFTLE9BQU8sR0FBRyxDQUFDO0FBQ3JFO0FBQ0EsSUFBTSxtQ0FBbUMsSUFBSSxRQUFRO0FBQ3JELFNBQVMsa0JBQWtCLE9BQU87Q0FDaEMsTUFBTSxpQkFBaUIsaUJBQWlCLElBQUksS0FBSztDQUNqRCxLQUFLLFlBQVksTUFBTSxZQUFZLElBQUksT0FBTyxLQUFLLE9BQU8sZ0JBQWdCLENBQUMsZ0JBQ3pFLE1BQU0sSUFBSSxNQUNSLGlFQUNGO0NBRUYsTUFBTSx3QkFBd0IsZUFBZTtDQUM3QyxJQUFJLHVCQUNGLE9BQU8sc0JBQXNCLGdCQUFnQixLQUFLO0NBRXBELE9BQU87QUFDVDtBQUNBLFNBQVMsV0FBVyxHQUFHLHVCQUF1QjtDQUM1QyxNQUFNLFFBQVE7RUFDWixJQUFJLE1BQU07R0FDUixPQUFPLFNBQVMsZ0JBQWdCLE9BQU8sSUFBSTtFQUM3QztFQUNBLElBQUksTUFBTSxHQUFHLE1BQU07R0FDakIsT0FBTyxTQUFTLGdCQUFnQixPQUFPLE1BQU0sR0FBRyxJQUFJO0VBQ3REO0VBQ0EsSUFBSSxNQUFNLFVBQVU7R0FDbEIsT0FBTyxTQUFTLGdCQUFnQixPQUFPLE1BQU0sUUFBUTtFQUN2RDtDQUNGO0NBQ0EsTUFBTSxpQkFBaUI7a0JBRUwsSUFBSSxRQUFRO2tCQUVaLElBQUksUUFBUTtrQkFFWixJQUFJLFFBQVE7a0JBRVosSUFBSSxJQUFJO2tCQUVSLElBQUksSUFBSTtrQkFFUixJQUFJLElBQUk7RUFFeEIsQ0FBQztFQUdEO0VBQ0E7RUFDQTtFQUNBO0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxLQUFLO2tCQUdXLElBQUksUUFBUTtFQUU1QjtFQUNBO0VBRUEsQ0FBQyxDQUFDO0NBQ0osQ0FBQyxDQUFDLEtBQUssSUFBSSxNQUFNLHNCQUFzQixNQUFNLEVBQUU7Q0FDL0MsaUJBQWlCLElBQUksT0FBTyxPQUFPLE9BQU8sY0FBYyxDQUFDO0NBQ3pELE1BQU0sV0FBVyxlQUFlO0NBQ2hDLE1BQU0sV0FBVyxlQUFlO0NBQ2hDLE1BQU0sV0FBVyxlQUFlO0NBQ2hDLE9BQU87QUFDVDs7O0FDcndCQSxJQUFJLFdBQVc7QUFDZixTQUFTLEtBQUssTUFBTSxPQUFPO0NBQ3pCLE1BQU0sTUFBTSxPQUFPLEVBQUU7Q0FDckIsTUFBTSxTQUFTLEVBQ2IsV0FBVztFQUNULFFBQVEsWUFBWSxNQUFNLFlBQVksSUFBSSxPQUFPLEtBQUssT0FBTyxnQkFBZ0IsS0FBSyxhQUFhLE1BQU0sTUFBTSxLQUFLLGFBQWE7Q0FDL0gsRUFDRjtDQUNBLElBQUksT0FBTyxTQUFTLFlBQ2xCLE9BQU8sT0FBTztNQUNUO0VBQ0wsT0FBTyxPQUFPO0VBQ2QsT0FBTyxPQUFPO0VBQ2QsT0FBTyxRQUFRO0NBQ2pCO0NBQ0EsSUFBSSxPQUNGLE9BQU8sUUFBUTtDQUVqQixPQUFPO0FBQ1Q7QUFDQSxTQUFTLFlBQVksS0FBSztDQUN4QixPQUFPLElBQUksSUFBSTtBQUNqQjtBQUNBLFNBQVMsYUFBYSxLQUFLLEtBQUssS0FBSztDQUNuQyxPQUFPLElBQ0wsTUFDQSxPQUFPLFFBQVEsYUFBYSxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksR0FDL0M7QUFDRjtBQUVBLElBQUk7QUFDSixTQUFTLDZCQUE2QixJQUFJO0NBQ3hDLHdCQUF3QixHQUFHLHFCQUFxQjtBQUNsRDtBQUNBLFNBQVMsY0FBYztDQUNyQixJQUFJLHVCQUNGLE9BQU8sc0JBQXNCO0NBRS9CLE9BQU9DLFdBQXdCO0FBQ2pDO0FBQ0EsSUFBSTtBQUNKLFNBQVMsa0JBQWtCO0NBQ3pCLElBQUksQ0FBQyxjQUFjO0VBQ2pCLGVBQWUsWUFBWTtFQUMzQixLQUFLLFlBQVksTUFBTSxZQUFZLElBQUksT0FBTyxLQUFLLE9BQU8sY0FBYztHQUN0RSxXQUFXLDRCQUE0QixXQUFXLDBCQUEwQjtHQUM1RSxJQUFJLFdBQVcsNEJBQTRCLGNBQ3pDLFFBQVEsS0FDTiw4SUFDRjtFQUVKO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7Ozs7QUNuREEsSUFBTSxnQkFBQSxHQUFlQyxhQUFBQSxjQUFBQSxDQUNuQixLQUFLLENBQ1A7QUFDQSxTQUFTLFNBQVMsU0FBUztDQUN6QixNQUFNLFNBQUEsR0FBUUMsYUFBQUEsV0FBQUEsQ0FBVyxZQUFZO0NBQ3JDLFFBQVEsV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLFVBQVUsU0FBUyxnQkFBZ0I7QUFDaEY7QUFDQSxTQUFTLFNBQVMsRUFDaEIsVUFDQSxTQUNDO0NBQ0QsTUFBTSxZQUFBLEdBQVdDLGFBQUFBLE9BQUFBLENBQU8sSUFBSTtDQUM1QixJQUFJLE9BQ0YsUUFBQSxHQUFPQyxhQUFBQSxjQUFBQSxDQUFjLGFBQWEsVUFBVSxFQUFFLE9BQU8sTUFBTSxHQUFHLFFBQVE7Q0FFeEUsSUFBSSxTQUFTLFlBQVksTUFDdkIsU0FBUyxVQUFVLFlBQVk7Q0FFakMsUUFBQSxHQUFPQSxhQUFBQSxjQUFBQSxDQUNMLGFBQWEsVUFDYixFQUdFLE9BQU8sU0FBUyxRQUNsQixHQUNBLFFBQ0Y7QUFDRjtBQUVBLElBQU0saUJBQWlCLE1BQU0sUUFBUSxLQUFLLE9BQU8sS0FBSyxJQUFJLEVBQUUsVUFBVTtBQUN0RSxJQUFNLHVCQUF1QixZQUFZO0NBQ3ZDLElBQUksQ0FBQyxRQUFRLFFBQVE7RUFDbkIsUUFBUSxTQUFTO0VBQ2pCLFFBQVEsTUFDTCxNQUFNO0dBQ0wsUUFBUSxTQUFTO0dBQ2pCLFFBQVEsUUFBUTtFQUNsQixJQUNDLE1BQU07R0FDTCxRQUFRLFNBQVM7R0FDakIsUUFBUSxTQUFTO0VBQ25CLENBQ0Y7Q0FDRjtBQUNGO0FBQ0EsSUFBTSxNQUFBLGFBQVksU0FDaEIsWUFBWTtDQUNaLElBQUksUUFBUSxXQUFXLFdBQ3JCLE1BQU07TUFDRCxJQUFJLFFBQVEsV0FBVyxhQUM1QixPQUFPLFFBQVE7TUFDVixJQUFJLFFBQVEsV0FBVyxZQUM1QixNQUFNLFFBQVE7TUFDVDtFQUNMLG9CQUFvQixPQUFPO0VBQzNCLE1BQU07Q0FDUjtBQUNGO0FBQ0EsSUFBTSx3Q0FBd0MsSUFBSSxRQUFRO0FBQzFELElBQU0sNEJBQTRCLE9BQU8sU0FBUyxhQUFhO0NBQzdELE1BQU0saUJBQWlCQyxrQkFBK0IsS0FBSztDQUMzRCxNQUFNLHVCQUF1QixlQUFlO0NBQzVDLElBQUkscUJBQXFCLHNCQUFzQixJQUFJLE9BQU87Q0FDMUQsSUFBSSxDQUFDLG9CQUFvQjtFQUN2QixxQkFBcUIsSUFBSSxTQUFTLFNBQVMsV0FBVztHQUNwRCxJQUFJLE9BQU87R0FDWCxNQUFNLGVBQWUsUUFBUSxNQUFNO0lBQ2pDLElBQUksU0FBUyxJQUNYLFFBQVEsQ0FBQztHQUViO0dBQ0EsTUFBTSxjQUFjLFFBQVEsTUFBTTtJQUNoQyxJQUFJLFNBQVMsSUFDWCxPQUFPLENBQUM7R0FFWjtHQUNBLE1BQU0sZ0JBQWdCO0lBQ3BCLElBQUk7S0FDRixNQUFNLFlBQVksU0FBUztLQUMzQixJQUFJLGNBQWMsU0FBUyxHQUFHO01BQzVCLHNCQUFzQixJQUFJLFdBQVcsa0JBQWtCO01BQ3ZELE9BQU87TUFDUCxVQUFVLEtBQUssWUFBWSxTQUFTLEdBQUcsV0FBVyxTQUFTLENBQUM7TUFDNUQscUJBQXFCLGdCQUFnQixPQUFPLFdBQVcsT0FBTztLQUNoRSxPQUNFLFFBQVEsU0FBUztJQUVyQixTQUFTLEdBQUc7S0FDVixPQUFPLENBQUM7SUFDVjtHQUNGO0dBQ0EsUUFBUSxLQUFLLFlBQVksT0FBTyxHQUFHLFdBQVcsT0FBTyxDQUFDO0dBQ3RELHFCQUFxQixnQkFBZ0IsT0FBTyxTQUFTLE9BQU87RUFDOUQsQ0FBQztFQUNELHNCQUFzQixJQUFJLFNBQVMsa0JBQWtCO0NBQ3ZEO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxhQUFhLE1BQU0sU0FBUztDQUNuQyxNQUFNLEVBQUUsT0FBTyx3QkFBd0IsZ0JBQWdCLENBQUEsYUFBTyxRQUFRLFdBQVcsQ0FBQztDQUNsRixNQUFNLFFBQVEsU0FBUyxPQUFPO0NBQzlCLE1BQU0sQ0FBQyxDQUFDLGtCQUFrQixrQkFBa0Isa0JBQWtCLGFBQUEsR0FBWUMsYUFBQUEsV0FBQUEsRUFDdkUsU0FBUztFQUNSLE1BQU0sWUFBWSxNQUFNLElBQUksSUFBSTtFQUNoQyxJQUFJLE9BQU8sR0FBRyxLQUFLLElBQUksU0FBUyxLQUFLLEtBQUssT0FBTyxTQUFTLEtBQUssT0FBTyxNQUNwRSxPQUFPO0VBRVQsT0FBTztHQUFDO0dBQVc7R0FBTztFQUFJO0NBQ2hDLEdBQ0EsS0FBSyxTQUNDO0VBQUMsTUFBTSxJQUFJLElBQUk7RUFBRztFQUFPO0NBQUksQ0FDckM7Q0FDQSxJQUFJLFFBQVE7Q0FDWixJQUFJLHFCQUFxQixTQUFTLG9CQUFvQixNQUFNO0VBQzFELFNBQVM7RUFDVCxRQUFRLE1BQU0sSUFBSSxJQUFJO0NBQ3hCO0NBQ0EsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFnQjtFQUNkLE1BQU0sUUFBUSxNQUFNLElBQUksWUFBWTtHQUNsQyxJQUFJLGVBQ0YsSUFBSTtJQUNGLE1BQU0sU0FBUyxNQUFNLElBQUksSUFBSTtJQUM3QixJQUFJLGNBQWMsTUFBTSxHQUN0QixvQkFDRSx5QkFBeUIsT0FBTyxjQUFjLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FDL0Q7R0FFSixTQUFTLEdBQUcsQ0FDWjtHQUVGLElBQUksT0FBTyxVQUFVLFVBQVU7SUFDN0IsUUFBUSxLQUFLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQnBCO0lBQ08sV0FBVyxVQUFVLEtBQUs7SUFDMUI7R0FDRjtHQUNBLFNBQVM7RUFDWCxDQUFDO0VBQ0QsU0FBUztFQUNULE9BQU87Q0FDVCxHQUFHO0VBQUM7RUFBTztFQUFNO0VBQU87Q0FBYSxDQUFDO0NBQ3RDLENBQUEsR0FBQSxhQUFBLGNBQUEsQ0FBYyxLQUFLO0NBQ25CLElBQUksY0FBYyxLQUFLLEdBQUc7RUFDeEIsTUFBTSxVQUFVLHlCQUNkLE9BQ0EsYUFDTSxNQUFNLElBQUksSUFBSSxDQUN0QjtFQUNBLElBQUksZUFDRixvQkFBb0IsT0FBTztFQUU3QixPQUFPLElBQUksT0FBTztDQUNwQjtDQUNBLE9BQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxNQUFNLFNBQVM7Q0FDakMsTUFBTSxRQUFRLFNBQVMsT0FBTztDQVU5QixRQUFBLEdBVGdCQyxhQUFBQSxZQUFBQSxFQUNiLEdBQUcsU0FBUztFQUNYLEtBQUssWUFBWSxNQUFNLFlBQVksSUFBSSxPQUFPLEtBQUssT0FBTyxnQkFBZ0IsRUFBRSxXQUFXLE9BQ3JGLE1BQU0sSUFBSSxNQUFNLG1CQUFtQjtFQUVyQyxPQUFPLE1BQU0sSUFBSSxNQUFNLEdBQUcsSUFBSTtDQUNoQyxHQUNBLENBQUMsT0FBTyxJQUFJLENBRUQ7QUFDZjtBQUVBLFNBQVMsUUFBUSxNQUFNLFNBQVM7Q0FDOUIsT0FBTyxDQUNMLGFBQWEsTUFBTSxPQUFPLEdBRTFCLFdBQVcsTUFBTSxPQUFPLENBQzFCO0FBQ0YifQ==