import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "TSS_INLINE_CSS_ENABLED": "false"};const StrictMode = __vite__cjsImport0_react["StrictMode"]; const Suspense = __vite__cjsImport0_react["Suspense"];const createRoot = __vite__cjsImport2_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f71da48c";
import { RouterProvider } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=f71da48c";
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=f71da48c";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=f71da48c";
import { worker } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/mocks/browsers.ts";
import { router } from "/src/router.ts?t=1785728509668";
import "/src/index.css?t=1785729108373";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/main.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
const queryClient = new QueryClient();
async function enableMocking() {
	if (import.meta.env.DEV) {
		try {
			await worker.start({ onUnhandledRequest: "error" });
		} catch (error) {
			console.error("Failed to start MSW:", error);
		}
	} else {
		// In production, let unhandled requests go through
		await worker.start({ onUnhandledRequest: "bypass" });
	}
}
enableMocking().then(() => {
	createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ _jsxDEV(Suspense, {
			fallback: /* @__PURE__ */ _jsxDEV("div", { children: "Loading..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 29
			}, this),
			children: /* @__PURE__ */ _jsxDEV(RouterProvider, { router }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this));
});

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZLGdCQUFnQjtBQUNyQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGFBQWEsMkJBQTJCO0FBQ2pELFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFFdkIsT0FBTzs7O0FBRVAsTUFBTSxjQUFjLElBQUksWUFBWTtBQUVwQyxlQUFlLGdCQUFnQjtDQUM3QixJQUFJLFlBQVksSUFBSSxLQUFLO0VBQ3ZCLElBQUk7R0FDRixNQUFNLE9BQU8sTUFBTSxFQUFFLG9CQUFvQixRQUFRLENBQUM7RUFDcEQsU0FBUyxPQUFPO0dBQ2QsUUFBUSxNQUFNLHdCQUF3QixLQUFLO0VBQzdDO0NBQ0YsT0FBTzs7RUFFTCxNQUFNLE9BQU8sTUFBTSxFQUFFLG9CQUFvQixTQUFTLENBQUM7Q0FDckQ7QUFDRjtBQUVBLGNBQWMsQ0FBQyxDQUFDLFdBQVc7Q0FDekIsV0FBVyxTQUFTLGVBQWUsTUFBTSxDQUFFLENBQUMsQ0FBQyxPQUMzQyx3QkFBQyxZQUFELFlBQ0Usd0JBQUMscUJBQUQ7RUFBcUIsUUFBUTtZQUMzQix3QkFBQyxVQUFEO0dBQVUsVUFBVSx3QkFBQyxPQUFELFlBQUssYUFBZTs7Ozs7YUFDdEMsd0JBQUMsZ0JBQUQsRUFBd0IsT0FBUzs7Ozs7RUFDekI7Ozs7O0NBQ1M7Ozs7VUFDWDs7OztTQUNkO0FBQ0YsQ0FBQyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJtYWluLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdHJpY3RNb2RlLCBTdXNwZW5zZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgUm91dGVyUHJvdmlkZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXJvdXRlclwiO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XG5pbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcbmltcG9ydCB7IHdvcmtlciB9IGZyb20gXCJAcmVwby9zaGFyZWQvbW9ja3MvYnJvd3NlcnNcIjtcbmltcG9ydCB7IHJvdXRlciB9IGZyb20gXCIuL3JvdXRlclwiO1xuXG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xuXG5jb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpO1xuXG5hc3luYyBmdW5jdGlvbiBlbmFibGVNb2NraW5nKCkge1xuICBpZiAoaW1wb3J0Lm1ldGEuZW52LkRFVikge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB3b3JrZXIuc3RhcnQoeyBvblVuaGFuZGxlZFJlcXVlc3Q6IFwiZXJyb3JcIiB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBzdGFydCBNU1c6XCIsIGVycm9yKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgLy8gSW4gcHJvZHVjdGlvbiwgbGV0IHVuaGFuZGxlZCByZXF1ZXN0cyBnbyB0aHJvdWdoXG4gICAgYXdhaXQgd29ya2VyLnN0YXJ0KHsgb25VbmhhbmRsZWRSZXF1ZXN0OiBcImJ5cGFzc1wiIH0pO1xuICB9XG59XG5cbmVuYWJsZU1vY2tpbmcoKS50aGVuKCgpID0+IHtcbiAgY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIikhKS5yZW5kZXIoXG4gICAgPFN0cmljdE1vZGU+XG4gICAgICA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT5cbiAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8ZGl2PkxvYWRpbmcuLi48L2Rpdj59PlxuICAgICAgICAgIDxSb3V0ZXJQcm92aWRlciByb3V0ZXI9e3JvdXRlcn0gLz5cbiAgICAgICAgPC9TdXNwZW5zZT5cbiAgICAgIDwvUXVlcnlDbGllbnRQcm92aWRlcj5cbiAgICA8L1N0cmljdE1vZGU+LFxuICApO1xufSk7XG4iXX0=