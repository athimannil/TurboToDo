import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Spinner/Spinner.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Spinner/Spinner.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
const Spinner = ({ label }) => /* @__PURE__ */ _jsxDEV("span", {
	className: "inline-flex items-center gap-2",
	children: [
		/* @__PURE__ */ _jsxDEV("span", {
			"aria-hidden": "true",
			className: "size-3.5 animate-spin rounded-full border-2 border-current border-t-transparent"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 5
		}, this),
		label ? /* @__PURE__ */ _jsxDEV("span", {
			className: "text-sm text-muted-foreground",
			children: label
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 7
		}, this) : null,
		/* @__PURE__ */ _jsxDEV("span", {
			className: "sr-only",
			children: "Loading"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 5
		}, this)
	]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 6,
	columnNumber: 3
}, this);
_c = Spinner;
export { Spinner };
var _c;
$RefreshReg$(_c, "Spinner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Spinner/Spinner.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Spinner/Spinner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Spinner/Spinner.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Spinner/Spinner.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFJQSxNQUFNLFdBQVcsRUFBRSxZQUNqQix3QkFBQyxRQUFEO0NBQU0sV0FBVTtXQUFoQjtFQUNFLHdCQUFDLFFBQUQ7R0FDRSxlQUFZO0dBQ1osV0FBVTtFQUNYOzs7OztFQUNBLFFBQ0Msd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaUM7RUFBWTs7OzthQUMzRDtFQUNKLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQVU7RUFBYTs7Ozs7Q0FDbkM7Ozs7Ozs7QUFHUixTQUFTIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNwaW5uZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImludGVyZmFjZSBTcGlubmVyUHJvcHMge1xuICBsYWJlbD86IHN0cmluZztcbn1cblxuY29uc3QgU3Bpbm5lciA9ICh7IGxhYmVsIH06IFNwaW5uZXJQcm9wcykgPT4gKFxuICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICA8c3BhblxuICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgIGNsYXNzTmFtZT1cInNpemUtMy41IGFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLWN1cnJlbnQgYm9yZGVyLXQtdHJhbnNwYXJlbnRcIlxuICAgIC8+XG4gICAge2xhYmVsID8gKFxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57bGFiZWx9PC9zcGFuPlxuICAgICkgOiBudWxsfVxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5Mb2FkaW5nPC9zcGFuPlxuICA8L3NwYW4+XG4pO1xuXG5leHBvcnQgeyBTcGlubmVyIH07XG4iXX0=