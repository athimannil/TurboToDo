import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/CreateTodoForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f71da48c";
import { useCreateTodo } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/hooks.tsx";
import { createTodoSchema } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/validation.ts";
import { Field, Button } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/index.ts";
import { useUsers } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/index.ts?t=1785727715973";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/CreateTodoForm.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
var _s = $RefreshSig$();
const CreateTodoForm = ({ selectedUserId, setSelectedUserId }) => {
	_s();
	const [title, setTitle] = useState("");
	const [description, setDescription] = useState("");
	const [validationError, setValidationError] = useState({});
	const { data: users } = useUsers();
	const createTodoMutation = useCreateTodo();
	const handleSubmit = async (event) => {
		event.preventDefault();
		setValidationError({});
		const result = createTodoSchema.safeParse({
			userId: selectedUserId,
			title,
			description: description || undefined
		});
		if (!result.success) {
			const errors = {};
			result.error.issues.forEach((issue) => {
				if (issue.path[0]) {
					errors[issue.path[0].toString()] = issue.message;
				}
			});
			setValidationError(errors);
			return;
		}
		try {
			await createTodoMutation.mutateAsync(result.data);
			setTitle("");
			setDescription("");
			setValidationError({});
		} catch (error) {}
	};
	return /* @__PURE__ */ _jsxDEV("form", {
		noValidate: true,
		onSubmit: handleSubmit,
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ _jsxDEV(Field, {
				id: "todo-assignee",
				label: "Assignee",
				error: validationError.userId,
				children: (props) => /* @__PURE__ */ _jsxDEV("select", {
					...props,
					name: "todo-assignee",
					"aria-describedby": "user-description",
					className: "w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 aria-invalid:border-destructive",
					value: selectedUserId || "",
					onChange: (event) => setSelectedUserId(event.target.value || null),
					children: [/* @__PURE__ */ _jsxDEV("option", {
						value: "",
						children: "All users"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 13
					}, this), users?.map((user) => /* @__PURE__ */ _jsxDEV("option", {
						value: user.id,
						children: user.username
					}, user.id, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 15
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Field, {
				id: "title",
				label: "Title",
				error: validationError.title,
				children: (props) => /* @__PURE__ */ _jsxDEV("input", {
					...props,
					name: "title",
					type: "text",
					className: "w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 aria-invalid:border-destructive",
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "Enter todo title"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Field, {
				id: "description",
				label: "Description (Optional)",
				error: validationError.description,
				children: (props) => /* @__PURE__ */ _jsxDEV("textarea", {
					...props,
					name: "description",
					className: "w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 aria-invalid:border-destructive min-h-20",
					value: description,
					onChange: (e) => setDescription(e.target.value),
					placeholder: "Enter todo description"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV(Button, {
					type: "submit",
					disabled: createTodoMutation.isPending,
					children: createTodoMutation.isPending ? "Adding..." : "Add todo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-xs text-muted-foreground",
					children: "The item appears in the list immediately and rolls back if the request fails."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 9
				}, this),
				createTodoMutation.isError && /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-destructive",
					children: createTodoMutation.error?.message || "Failed to create todo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 5
	}, this);
};
_s(CreateTodoForm, "9l2WWlKe5p+qDXW6IBA3/rAKJhY=", false, function() {
	return [useUsers, useCreateTodo];
});
_c = CreateTodoForm;
export { CreateTodoForm };
var _c;
$RefreshReg$(_c, "CreateTodoForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/CreateTodoForm.tsx?t=1785728509668";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/CreateTodoForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/CreateTodoForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/CreateTodoForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0M7QUFDekMsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxPQUFPLGNBQWM7QUFDOUIsU0FBUyxnQkFBZ0I7Ozs7QUFPekIsTUFBTSxrQkFBa0IsRUFDdEIsZ0JBQ0Esd0JBQ3lCOztDQUN6QixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBRTVDLENBQUMsQ0FBQztDQUNKLE1BQU0sRUFBRSxNQUFNLFVBQVUsU0FBUztDQUVqQyxNQUFNLHFCQUFxQixjQUFjO0NBRXpDLE1BQU0sZUFBZSxPQUFPLFVBQXFCO0VBQy9DLE1BQU0sZUFBZTtFQUNyQixtQkFBbUIsQ0FBQyxDQUFDO0VBRXJCLE1BQU0sU0FBUyxpQkFBaUIsVUFBVTtHQUN4QyxRQUFRO0dBQ1I7R0FDQSxhQUFhLGVBQWU7RUFDOUIsQ0FBQztFQUVELElBQUksQ0FBQyxPQUFPLFNBQVM7R0FDbkIsTUFBTSxTQUFpQyxDQUFDO0dBQ3hDLE9BQU8sTUFBTSxPQUFPLFNBQVMsVUFBVTtJQUNyQyxJQUFJLE1BQU0sS0FBSyxJQUFJO0tBQ2pCLE9BQU8sTUFBTSxLQUFLLEVBQUUsQ0FBQyxTQUFTLEtBQUssTUFBTTtJQUMzQztHQUNGLENBQUM7R0FDRCxtQkFBbUIsTUFBTTtHQUN6QjtFQUNGO0VBRUEsSUFBSTtHQUNGLE1BQU0sbUJBQW1CLFlBQVksT0FBTyxJQUFJO0dBQ2hELFNBQVMsRUFBRTtHQUNYLGVBQWUsRUFBRTtHQUNqQixtQkFBbUIsQ0FBQyxDQUFDO0VBQ3ZCLFNBQVMsT0FBTyxDQUVoQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxRQUFEO0VBQU07RUFBVyxVQUFVO0VBQWMsV0FBVTtZQUFuRDtHQUNFLHdCQUFDLE9BQUQ7SUFBTyxJQUFHO0lBQWdCLE9BQU07SUFBVyxPQUFPLGdCQUFnQjtlQUM5RCxVQUNBLHdCQUFDLFVBQUQ7S0FDRSxHQUFJO0tBQ0osTUFBSztLQUNMLG9CQUFpQjtLQUNqQixXQUFVO0tBQ1YsT0FBTyxrQkFBa0I7S0FDekIsV0FBVyxVQUFVLGtCQUFrQixNQUFNLE9BQU8sU0FBUyxJQUFJO2VBTm5FLENBUUUsd0JBQUMsVUFBRDtNQUFRLE9BQU07Z0JBQUc7S0FBaUI7Ozs7ZUFDakMsT0FBTyxLQUFLLFNBQ1gsd0JBQUMsVUFBRDtNQUFzQixPQUFPLEtBQUs7Z0JBQy9CLEtBQUs7S0FDQSxHQUZLLEtBQUs7Ozs7WUFFVixDQUNULENBQ0s7Ozs7OztHQUVMOzs7OztHQUVQLHdCQUFDLE9BQUQ7SUFBTyxJQUFHO0lBQVEsT0FBTTtJQUFRLE9BQU8sZ0JBQWdCO2VBQ25ELFVBQ0Esd0JBQUMsU0FBRDtLQUNFLEdBQUk7S0FDSixNQUFLO0tBQ0wsTUFBSztLQUNMLFdBQVU7S0FDVixPQUFPO0tBQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7S0FDeEMsYUFBWTtJQUNiOzs7OztHQUVFOzs7OztHQUVQLHdCQUFDLE9BQUQ7SUFDRSxJQUFHO0lBQ0gsT0FBTTtJQUNOLE9BQU8sZ0JBQWdCO2VBRXJCLFVBQ0Esd0JBQUMsWUFBRDtLQUNFLEdBQUk7S0FDSixNQUFLO0tBQ0wsV0FBVTtLQUNWLE9BQU87S0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztLQUM5QyxhQUFZO0lBQ2I7Ozs7O0dBRUU7Ozs7O0dBQ1Asd0JBQUMsT0FBRDtJQUNFLHdCQUFDLFFBQUQ7S0FBUSxNQUFLO0tBQVMsVUFBVSxtQkFBbUI7ZUFDaEQsbUJBQW1CLFlBQVksY0FBYztJQUN4Qzs7Ozs7SUFDUix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFxQztJQUcvQzs7Ozs7SUFDRixtQkFBbUIsV0FDbEIsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixtQkFBbUIsT0FBTyxXQUFXO0lBQ3JDOzs7OztHQUVGOzs7OztFQUNEOzs7Ozs7QUFFVjs7Ozs7QUFFQSxTQUFTIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNyZWF0ZVRvZG9Gb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdHlwZSBGb3JtRXZlbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUNyZWF0ZVRvZG8gfSBmcm9tIFwiLi4vaG9va3NcIjtcbmltcG9ydCB7IGNyZWF0ZVRvZG9TY2hlbWEgfSBmcm9tIFwiLi4vdmFsaWRhdGlvblwiO1xuaW1wb3J0IHsgRmllbGQsIEJ1dHRvbiB9IGZyb20gXCJAcmVwby9zaGFyZWRcIjtcbmltcG9ydCB7IHVzZVVzZXJzIH0gZnJvbSBcIkByZXBvL3VzZXJzXCI7XG5cbmludGVyZmFjZSBDcmVhdGVUb2RvRm9ybVByb3BzIHtcbiAgc2VsZWN0ZWRVc2VySWQ6IHN0cmluZyB8IG51bGw7XG4gIHNldFNlbGVjdGVkVXNlcklkOiAodXNlcklkOiBzdHJpbmcgfCBudWxsKSA9PiB2b2lkO1xufVxuXG5jb25zdCBDcmVhdGVUb2RvRm9ybSA9ICh7XG4gIHNlbGVjdGVkVXNlcklkLFxuICBzZXRTZWxlY3RlZFVzZXJJZCxcbn06IENyZWF0ZVRvZG9Gb3JtUHJvcHMpID0+IHtcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Rlc2NyaXB0aW9uLCBzZXREZXNjcmlwdGlvbl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3ZhbGlkYXRpb25FcnJvciwgc2V0VmFsaWRhdGlvbkVycm9yXSA9IHVzZVN0YXRlPFxuICAgIFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbiAgPih7fSk7XG4gIGNvbnN0IHsgZGF0YTogdXNlcnMgfSA9IHVzZVVzZXJzKCk7XG5cbiAgY29uc3QgY3JlYXRlVG9kb011dGF0aW9uID0gdXNlQ3JlYXRlVG9kbygpO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChldmVudDogRm9ybUV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRWYWxpZGF0aW9uRXJyb3Ioe30pO1xuXG4gICAgY29uc3QgcmVzdWx0ID0gY3JlYXRlVG9kb1NjaGVtYS5zYWZlUGFyc2Uoe1xuICAgICAgdXNlcklkOiBzZWxlY3RlZFVzZXJJZCxcbiAgICAgIHRpdGxlLFxuICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uIHx8IHVuZGVmaW5lZCxcbiAgICB9KTtcblxuICAgIGlmICghcmVzdWx0LnN1Y2Nlc3MpIHtcbiAgICAgIGNvbnN0IGVycm9yczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICAgICAgcmVzdWx0LmVycm9yLmlzc3Vlcy5mb3JFYWNoKChpc3N1ZSkgPT4ge1xuICAgICAgICBpZiAoaXNzdWUucGF0aFswXSkge1xuICAgICAgICAgIGVycm9yc1tpc3N1ZS5wYXRoWzBdLnRvU3RyaW5nKCldID0gaXNzdWUubWVzc2FnZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBzZXRWYWxpZGF0aW9uRXJyb3IoZXJyb3JzKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgY3JlYXRlVG9kb011dGF0aW9uLm11dGF0ZUFzeW5jKHJlc3VsdC5kYXRhKTtcbiAgICAgIHNldFRpdGxlKFwiXCIpO1xuICAgICAgc2V0RGVzY3JpcHRpb24oXCJcIik7XG4gICAgICBzZXRWYWxpZGF0aW9uRXJyb3Ioe30pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvLyBFcnJvciBpcyBoYW5kbGVkIGJ5IG11dGF0aW9uIHN0YXRlXG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGZvcm0gbm9WYWxpZGF0ZSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00XCI+XG4gICAgICA8RmllbGQgaWQ9XCJ0b2RvLWFzc2lnbmVlXCIgbGFiZWw9XCJBc3NpZ25lZVwiIGVycm9yPXt2YWxpZGF0aW9uRXJyb3IudXNlcklkfT5cbiAgICAgICAgeyhwcm9wcykgPT4gKFxuICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgIHsuLi5wcm9wc31cbiAgICAgICAgICAgIG5hbWU9XCJ0b2RvLWFzc2lnbmVlXCJcbiAgICAgICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9XCJ1c2VyLWRlc2NyaXB0aW9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcHgtMyBweS0yIHRleHQtc20gdGV4dC1mb3JlZ3JvdW5kIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9ycyBwbGFjZWhvbGRlcjp0ZXh0LW11dGVkLWZvcmVncm91bmQgZm9jdXMtdmlzaWJsZTpib3JkZXItcmluZyBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZy80MCBhcmlhLWludmFsaWQ6Ym9yZGVyLWRlc3RydWN0aXZlXCJcbiAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFVzZXJJZCB8fCBcIlwifVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0U2VsZWN0ZWRVc2VySWQoZXZlbnQudGFyZ2V0LnZhbHVlIHx8IG51bGwpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGwgdXNlcnM8L29wdGlvbj5cbiAgICAgICAgICAgIHt1c2Vycz8ubWFwKCh1c2VyKSA9PiAoXG4gICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt1c2VyLmlkfSB2YWx1ZT17dXNlci5pZH0+XG4gICAgICAgICAgICAgICAge3VzZXIudXNlcm5hbWV9XG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICl9XG4gICAgICA8L0ZpZWxkPlxuXG4gICAgICA8RmllbGQgaWQ9XCJ0aXRsZVwiIGxhYmVsPVwiVGl0bGVcIiBlcnJvcj17dmFsaWRhdGlvbkVycm9yLnRpdGxlfT5cbiAgICAgICAgeyhwcm9wcykgPT4gKFxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgey4uLnByb3BzfVxuICAgICAgICAgICAgbmFtZT1cInRpdGxlXCJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcHgtMyBweS0yIHRleHQtc20gdGV4dC1mb3JlZ3JvdW5kIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9ycyBwbGFjZWhvbGRlcjp0ZXh0LW11dGVkLWZvcmVncm91bmQgZm9jdXMtdmlzaWJsZTpib3JkZXItcmluZyBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZy80MCBhcmlhLWludmFsaWQ6Ym9yZGVyLWRlc3RydWN0aXZlXCJcbiAgICAgICAgICAgIHZhbHVlPXt0aXRsZX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGl0bGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0b2RvIHRpdGxlXCJcbiAgICAgICAgICAvPlxuICAgICAgICApfVxuICAgICAgPC9GaWVsZD5cblxuICAgICAgPEZpZWxkXG4gICAgICAgIGlkPVwiZGVzY3JpcHRpb25cIlxuICAgICAgICBsYWJlbD1cIkRlc2NyaXB0aW9uIChPcHRpb25hbClcIlxuICAgICAgICBlcnJvcj17dmFsaWRhdGlvbkVycm9yLmRlc2NyaXB0aW9ufVxuICAgICAgPlxuICAgICAgICB7KHByb3BzKSA9PiAoXG4gICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICB7Li4ucHJvcHN9XG4gICAgICAgICAgICBuYW1lPVwiZGVzY3JpcHRpb25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctY2FyZCBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LWZvcmVncm91bmQgb3V0bGluZS1ub25lIHRyYW5zaXRpb24tY29sb3JzIHBsYWNlaG9sZGVyOnRleHQtbXV0ZWQtZm9yZWdyb3VuZCBmb2N1cy12aXNpYmxlOmJvcmRlci1yaW5nIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nLzQwIGFyaWEtaW52YWxpZDpib3JkZXItZGVzdHJ1Y3RpdmUgbWluLWgtMjBcIlxuICAgICAgICAgICAgdmFsdWU9e2Rlc2NyaXB0aW9ufVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREZXNjcmlwdGlvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRvZG8gZGVzY3JpcHRpb25cIlxuICAgICAgICAgIC8+XG4gICAgICAgICl9XG4gICAgICA8L0ZpZWxkPlxuICAgICAgPGRpdj5cbiAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2NyZWF0ZVRvZG9NdXRhdGlvbi5pc1BlbmRpbmd9PlxuICAgICAgICAgIHtjcmVhdGVUb2RvTXV0YXRpb24uaXNQZW5kaW5nID8gXCJBZGRpbmcuLi5cIiA6IFwiQWRkIHRvZG9cIn1cbiAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICBUaGUgaXRlbSBhcHBlYXJzIGluIHRoZSBsaXN0IGltbWVkaWF0ZWx5IGFuZCByb2xscyBiYWNrIGlmIHRoZSByZXF1ZXN0XG4gICAgICAgICAgZmFpbHMuXG4gICAgICAgIDwvcD5cbiAgICAgICAge2NyZWF0ZVRvZG9NdXRhdGlvbi5pc0Vycm9yICYmIChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZGVzdHJ1Y3RpdmVcIj5cbiAgICAgICAgICAgIHtjcmVhdGVUb2RvTXV0YXRpb24uZXJyb3I/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gY3JlYXRlIHRvZG9cIn1cbiAgICAgICAgICA8L3A+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Zvcm0+XG4gICk7XG59O1xuXG5leHBvcnQgeyBDcmVhdGVUb2RvRm9ybSB9O1xuIl19