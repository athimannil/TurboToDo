import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/users/index.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Panel } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/index.ts";
import { CreateUserForm, AvailableUsers } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/index.ts?t=1785727715973";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/users/index.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
const UsersList = () => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-8",
		children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("h1", {
			className: "text-3xl font-semibold tracking-tight text-foreground",
			children: "Users"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: "Create a new user or select an existing user to view and manage their todos"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]",
			children: [/* @__PURE__ */ _jsxDEV(Panel, {
				title: "Create User",
				description: "Fill out the form to create a new user.",
				children: /* @__PURE__ */ _jsxDEV(CreateUserForm, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(Panel, {
				title: "Existing Users",
				description: "Select a user to view their todos.",
				children: /* @__PURE__ */ _jsxDEV(AvailableUsers, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
};
_c = UsersList;
export default UsersList;
var _c;
$RefreshReg$(_c, "UsersList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/users/index.tsx?t=1785727715973";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/users/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/users/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/users/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsZ0JBQWdCLHNCQUFzQjs7O0FBRS9DLE1BQU0sa0JBQWtCO0NBQ3RCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFVBQUQsYUFDRSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUF3RDtFQUVsRTs7OztZQUNKLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQXFDO0VBRy9DOzs7O1VBQ0c7Ozs7WUFFUix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUNFLE9BQU07SUFDTixhQUFZO2NBRVosd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O0dBQ1o7Ozs7YUFDUCx3QkFBQyxPQUFEO0lBQ0UsT0FBTTtJQUNOLGFBQVk7Y0FFWix3QkFBQyxnQkFBRCxDQUFpQjs7Ozs7R0FDWjs7OztXQUNKOzs7OztVQUNGOzs7Ozs7QUFFVDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQYW5lbCB9IGZyb20gXCJAcmVwby9zaGFyZWRcIjtcbmltcG9ydCB7IENyZWF0ZVVzZXJGb3JtLCBBdmFpbGFibGVVc2VycyB9IGZyb20gXCJAcmVwby91c2Vyc1wiO1xuXG5jb25zdCBVc2Vyc0xpc3QgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC04XCI+XG4gICAgICA8aGVhZGVyPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICBVc2Vyc1xuICAgICAgICA8L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgQ3JlYXRlIGEgbmV3IHVzZXIgb3Igc2VsZWN0IGFuIGV4aXN0aW5nIHVzZXIgdG8gdmlldyBhbmQgbWFuYWdlIHRoZWlyXG4gICAgICAgICAgdG9kb3NcbiAgICAgICAgPC9wPlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNiBsZzpncmlkLWNvbHMtW21pbm1heCgwLDFmcilfbWlubWF4KDAsMS4yZnIpXVwiPlxuICAgICAgICA8UGFuZWxcbiAgICAgICAgICB0aXRsZT1cIkNyZWF0ZSBVc2VyXCJcbiAgICAgICAgICBkZXNjcmlwdGlvbj1cIkZpbGwgb3V0IHRoZSBmb3JtIHRvIGNyZWF0ZSBhIG5ldyB1c2VyLlwiXG4gICAgICAgID5cbiAgICAgICAgICA8Q3JlYXRlVXNlckZvcm0gLz5cbiAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgPFBhbmVsXG4gICAgICAgICAgdGl0bGU9XCJFeGlzdGluZyBVc2Vyc1wiXG4gICAgICAgICAgZGVzY3JpcHRpb249XCJTZWxlY3QgYSB1c2VyIHRvIHZpZXcgdGhlaXIgdG9kb3MuXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxBdmFpbGFibGVVc2VycyAvPlxuICAgICAgICA8L1BhbmVsPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBVc2Vyc0xpc3Q7XG4iXX0=