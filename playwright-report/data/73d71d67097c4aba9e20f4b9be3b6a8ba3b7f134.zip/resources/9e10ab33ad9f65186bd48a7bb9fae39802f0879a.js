import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Header/Header.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=f71da48c";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/components/Header/Header.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
const navLinkProps = {
	className: "rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
	activeProps: { className: "bg-accent text-foreground" }
};
const Header = () => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-background",
		children: /* @__PURE__ */ _jsxDEV("header", {
			className: "border-b border-border bg-card/60 backdrop-blur",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-4",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					className: "font-mono text-sm font-semibold tracking-[0.2em] uppercase",
					children: "TurboToDo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": "Main",
					children: /* @__PURE__ */ _jsxDEV("ul", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							to: "/users",
							...navLinkProps,
							children: "Users"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 17
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							to: "/todos",
							...navLinkProps,
							children: "Todos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 17
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 5
	}, this);
};
_c = Header;
export default Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Header/Header.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/components/Header/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/components/Header/Header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/components/Header/Header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZOzs7QUFFckIsTUFBTSxlQUFlO0NBQ25CLFdBQ0U7Q0FDRixhQUFhLEVBQUUsV0FBVyw0QkFBNEI7QUFDeEQ7QUFFQSxNQUFNLGVBQWU7Q0FDbkIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLFVBQUQ7R0FBUSxXQUFVO2FBQ2hCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQ0UsSUFBRztLQUNILFdBQVU7ZUFDWDtJQUVLOzs7O2NBQ04sd0JBQUMsT0FBRDtLQUFLLGNBQVc7ZUFDZCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQU0sSUFBRztPQUFTLEdBQUk7aUJBQWM7TUFFOUI7Ozs7ZUFDSjs7OztnQkFDSix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUFNLElBQUc7T0FBUyxHQUFJO2lCQUFjO01BRTlCOzs7O2VBQ0o7Ozs7Y0FDRjs7Ozs7O0lBQ0Q7Ozs7WUFDRjs7Ozs7O0VBQ0M7Ozs7O0NBQ0w7Ozs7O0FBRVQ7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIZWFkZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXJvdXRlclwiO1xuXG5jb25zdCBuYXZMaW5rUHJvcHMgPSB7XG4gIGNsYXNzTmFtZTpcbiAgICBcInJvdW5kZWQtbWQgcHgtMyBweS0xLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LW11dGVkLWZvcmVncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctYWNjZW50IGhvdmVyOnRleHQtZm9yZWdyb3VuZCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZ1wiLFxuICBhY3RpdmVQcm9wczogeyBjbGFzc05hbWU6IFwiYmctYWNjZW50IHRleHQtZm9yZWdyb3VuZFwiIH0sXG59IGFzIGNvbnN0O1xuXG5jb25zdCBIZWFkZXIgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1iYWNrZ3JvdW5kXCI+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ib3JkZXIgYmctY2FyZC82MCBiYWNrZHJvcC1ibHVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBmbGV4IG1heC13LTV4bCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHB4LTUgcHktNFwiPlxuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICB0bz1cIi9cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFja2luZy1bMC4yZW1dIHVwcGVyY2FzZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgVHVyYm9Ub0RvXG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDxuYXYgYXJpYS1sYWJlbD1cIk1haW5cIj5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgPExpbmsgdG89XCIvdXNlcnNcIiB7Li4ubmF2TGlua1Byb3BzfT5cbiAgICAgICAgICAgICAgICAgIFVzZXJzXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgPExpbmsgdG89XCIvdG9kb3NcIiB7Li4ubmF2TGlua1Byb3BzfT5cbiAgICAgICAgICAgICAgICAgIFRvZG9zXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICA8L25hdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEhlYWRlcjtcbiJdfQ==