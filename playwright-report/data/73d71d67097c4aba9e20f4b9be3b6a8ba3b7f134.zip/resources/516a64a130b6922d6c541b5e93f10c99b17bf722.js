import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Field/Field.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Field/Field.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
const Field = ({ id, label, hint, error, children }) => {
	const errorId = `${id}-error`;
	const hintId = `${id}-hint`;
	const describedBy = [error ? errorId : null, hint ? hintId : null].filter(Boolean).join(" ");
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-1.5",
		children: [
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: id,
				className: "font-mono text-xs uppercase tracking-widest text-muted-foreground",
				children: label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 7
			}, this),
			children({
				id,
				"aria-invalid": Boolean(error),
				"aria-describedby": describedBy || undefined
			}),
			hint && /* @__PURE__ */ _jsxDEV("p", {
				id: hintId,
				className: "text-xs text-muted-foreground",
				children: hint
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 9
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				id: errorId,
				role: "alert",
				className: "text-xs font-medium text-destructive",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
};
_c = Field;
export { Field };
var _c;
$RefreshReg$(_c, "Field");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Field/Field.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Field/Field.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Field/Field.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Field/Field.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFjQSxNQUFNLFNBQVMsRUFBRSxJQUFJLE9BQU8sTUFBTSxPQUFPLGVBQTJCO0NBQ2xFLE1BQU0sVUFBVSxHQUFHLEdBQUc7Q0FDdEIsTUFBTSxTQUFTLEdBQUcsR0FBRztDQUNyQixNQUFNLGNBQWMsQ0FBQyxRQUFRLFVBQVUsTUFBTSxPQUFPLFNBQVMsSUFBSSxDQUFDLENBQy9ELE9BQU8sT0FBTyxDQUFDLENBQ2YsS0FBSyxHQUFHO0NBQ1gsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsU0FBRDtJQUNFLFNBQVM7SUFDVCxXQUFVO2NBRVQ7R0FDSTs7Ozs7R0FDTixTQUFTO0lBQ1I7SUFDQSxnQkFBZ0IsUUFBUSxLQUFLO0lBQzdCLG9CQUFvQixlQUFlO0dBQ3JDLENBQUM7R0FDQSxRQUNDLHdCQUFDLEtBQUQ7SUFBRyxJQUFJO0lBQVEsV0FBVTtjQUN0QjtHQUNBOzs7OztHQUVKLFNBQ0Msd0JBQUMsS0FBRDtJQUNFLElBQUk7SUFDSixNQUFLO0lBQ0wsV0FBVTtjQUVUO0dBQ0E7Ozs7O0VBRUY7Ozs7OztBQUVUOztBQUVBLFNBQVMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRmllbGQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmludGVyZmFjZSBGaWVsZFByb3BzIHtcbiAgaWQ6IHN0cmluZztcbiAgbGFiZWw6IHN0cmluZztcbiAgaGludD86IHN0cmluZztcbiAgZXJyb3I/OiBzdHJpbmc7XG4gIGNoaWxkcmVuOiAocHJvcHM6IHtcbiAgICBpZDogc3RyaW5nO1xuICAgIFwiYXJpYS1pbnZhbGlkXCI6IGJvb2xlYW47XG4gICAgXCJhcmlhLWRlc2NyaWJlZGJ5XCI/OiBzdHJpbmc7XG4gIH0pID0+IFJlYWN0Tm9kZTtcbn1cblxuY29uc3QgRmllbGQgPSAoeyBpZCwgbGFiZWwsIGhpbnQsIGVycm9yLCBjaGlsZHJlbiB9OiBGaWVsZFByb3BzKSA9PiB7XG4gIGNvbnN0IGVycm9ySWQgPSBgJHtpZH0tZXJyb3JgO1xuICBjb25zdCBoaW50SWQgPSBgJHtpZH0taGludGA7XG4gIGNvbnN0IGRlc2NyaWJlZEJ5ID0gW2Vycm9yID8gZXJyb3JJZCA6IG51bGwsIGhpbnQgPyBoaW50SWQgOiBudWxsXVxuICAgIC5maWx0ZXIoQm9vbGVhbilcbiAgICAuam9pbihcIiBcIik7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgIDxsYWJlbFxuICAgICAgICBodG1sRm9yPXtpZH1cbiAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIlxuICAgICAgPlxuICAgICAgICB7bGFiZWx9XG4gICAgICA8L2xhYmVsPlxuICAgICAge2NoaWxkcmVuKHtcbiAgICAgICAgaWQsXG4gICAgICAgIFwiYXJpYS1pbnZhbGlkXCI6IEJvb2xlYW4oZXJyb3IpLFxuICAgICAgICBcImFyaWEtZGVzY3JpYmVkYnlcIjogZGVzY3JpYmVkQnkgfHwgdW5kZWZpbmVkLFxuICAgICAgfSl9XG4gICAgICB7aGludCAmJiAoXG4gICAgICAgIDxwIGlkPXtoaW50SWR9IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAge2hpbnR9XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8cFxuICAgICAgICAgIGlkPXtlcnJvcklkfVxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWRlc3RydWN0aXZlXCJcbiAgICAgICAgPlxuICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgPC9wPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCB7IEZpZWxkIH07XG4iXX0=