import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/Todos.tsx");const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f71da48c";
import { useTodos, useToggleTodoStatus } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/hooks.tsx";
import { TodoList } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/TodoList.tsx";
import { Button, Spinner } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/index.ts";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/Todos.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
var _s = $RefreshSig$();
const Todos = ({ userId } = {}) => {
	_s();
	const [status, setStatus] = useState("All");
	const filterButtons = [
		"All",
		"Pending",
		"Done"
	];
	const { data: todos, isLoading, isError, error } = useTodos(userId || undefined);
	const toggleMutation = useToggleTodoStatus();
	const handleToggleTodoStatus = (todoId, status) => {
		toggleMutation.mutate({
			todoId,
			status
		});
	};
	const filteredTodos = useMemo(() => {
		if (!todos) return [];
		return todos.filter((todo) => {
			if (status === "All") return true;
			if (status === "Pending") return todo.status === "pending";
			if (status === "Done") return todo.status === "done";
			return true;
		});
	}, [todos, status]);
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV(Spinner, { label: "Loading todos..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 12
		}, this);
	}
	if (isError) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "rounded-md border border-destructive/50 bg-destructive/10 p-4",
			children: /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm text-destructive",
				children: error?.message || "Error loading todos. Please try again later."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this);
	}
	if (!todos || todos.length === 0) {
		return /* @__PURE__ */ _jsxDEV("p", {
			className: "text-sm text-muted-foreground",
			children: "No todos yet. Create one to get started."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col ",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "mb-4 flex items-center gap-2",
			role: "group",
			"aria-label": "Filter by status",
			children: filterButtons.map((value) => /* @__PURE__ */ _jsxDEV(Button, {
				variant: status === value ? "primary" : "outline",
				className: "px-3 py-1 text-xs capitalize",
				"aria-pressed": status === value,
				onClick: () => setStatus(value),
				children: value
			}, value, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 7
		}, this), filteredTodos && filteredTodos.length > 0 ? /* @__PURE__ */ _jsxDEV(TodoList, {
			todos: filteredTodos,
			onToggle: handleToggleTodoStatus,
			isUpdating: toggleMutation.isPending,
			updateTodoId: toggleMutation.variables?.todoId
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("p", {
			className: "text-foreground",
			children: "No todos."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 87,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 5
	}, this);
};
_s(Todos, "q4tefwzxDtdga9IeQbtpjEeY+XE=", false, function() {
	return [useTodos, useToggleTodoStatus];
});
_c = Todos;
export { Todos };
var _c;
$RefreshReg$(_c, "Todos");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/Todos.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/Todos.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/Todos.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/components/Todos.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxTQUFTLGdCQUFnQjtBQUNsQyxTQUFTLFVBQVUsMkJBQTJCO0FBRTlDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsUUFBUSxlQUFlOzs7O0FBTWhDLE1BQU0sU0FBUyxFQUFFLFdBQXVCLENBQUMsTUFBTTs7Q0FDN0MsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFxQyxLQUFLO0NBQ3RFLE1BQU0sZ0JBQWdCO0VBQUM7RUFBTztFQUFXO0NBQU07Q0FFL0MsTUFBTSxFQUNKLE1BQU0sT0FDTixXQUNBLFNBQ0EsVUFDRSxTQUFTLFVBQVUsU0FBUztDQUVoQyxNQUFNLGlCQUFpQixvQkFBb0I7Q0FFM0MsTUFBTSwwQkFBMEIsUUFBZ0IsV0FBdUI7RUFDckUsZUFBZSxPQUFPO0dBQUU7R0FBUTtFQUFPLENBQUM7Q0FDMUM7Q0FFQSxNQUFNLGdCQUFnQixjQUFjO0VBQ2xDLElBQUksQ0FBQyxPQUFPLE9BQU8sQ0FBQztFQUNwQixPQUFPLE1BQU0sUUFBUSxTQUFTO0dBQzVCLElBQUksV0FBVyxPQUFPLE9BQU87R0FDN0IsSUFBSSxXQUFXLFdBQVcsT0FBTyxLQUFLLFdBQVc7R0FDakQsSUFBSSxXQUFXLFFBQVEsT0FBTyxLQUFLLFdBQVc7R0FDOUMsT0FBTztFQUNULENBQUM7Q0FDSCxHQUFHLENBQUMsT0FBTyxNQUFNLENBQUM7Q0FFbEIsSUFBSSxXQUFXO0VBQ2IsT0FBTyx3QkFBQyxTQUFELEVBQVMsT0FBTSxtQkFBb0I7Ozs7O0NBQzVDO0NBRUEsSUFBSSxTQUFTO0VBQ1gsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQ1YsT0FBTyxXQUFXO0dBQ2xCOzs7OztFQUNBOzs7OztDQUVUO0NBRUEsSUFBSSxDQUFDLFNBQVMsTUFBTSxXQUFXLEdBQUc7RUFDaEMsT0FDRSx3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUFnQztFQUUxQzs7Ozs7Q0FFUDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQ7R0FDRSxXQUFVO0dBQ1YsTUFBSztHQUNMLGNBQVc7YUFFVixjQUFjLEtBQUssVUFDbEIsd0JBQUMsUUFBRDtJQUVFLFNBQVMsV0FBVyxRQUFRLFlBQVk7SUFDeEMsV0FBVTtJQUNWLGdCQUFjLFdBQVc7SUFDekIsZUFBZSxVQUFVLEtBQW1DO2NBRTNEO0dBQ0ssR0FQRDs7OztVQU9DLENBQ1Q7RUFDRTs7OztZQUNKLGlCQUFpQixjQUFjLFNBQVMsSUFDdkMsd0JBQUMsVUFBRDtHQUNFLE9BQU87R0FDUCxVQUFVO0dBQ1YsWUFBWSxlQUFlO0dBQzNCLGNBQWMsZUFBZSxXQUFXO0VBQ3pDOzs7O2FBRUQsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBa0I7RUFBWTs7OztVQUUxQzs7Ozs7O0FBRVQ7Ozs7O0FBRUEsU0FBUyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUb2Rvcy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVRvZG9zLCB1c2VUb2dnbGVUb2RvU3RhdHVzIH0gZnJvbSBcIi4uL2hvb2tzXCI7XG5pbXBvcnQgdHlwZSB7IFRvRG9TdGF0dXMgfSBmcm9tIFwiQHJlcG8vc2hhcmVkXCI7XG5pbXBvcnQgeyBUb2RvTGlzdCB9IGZyb20gXCIuL1RvZG9MaXN0XCI7XG5pbXBvcnQgeyBCdXR0b24sIFNwaW5uZXIgfSBmcm9tIFwiQHJlcG8vc2hhcmVkXCI7XG5cbmludGVyZmFjZSBUb2Rvc1Byb3BzIHtcbiAgdXNlcklkPzogc3RyaW5nIHwgbnVsbDtcbn1cblxuY29uc3QgVG9kb3MgPSAoeyB1c2VySWQgfTogVG9kb3NQcm9wcyA9IHt9KSA9PiB7XG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZTxcIkFsbFwiIHwgXCJQZW5kaW5nXCIgfCBcIkRvbmVcIj4oXCJBbGxcIik7XG4gIGNvbnN0IGZpbHRlckJ1dHRvbnMgPSBbXCJBbGxcIiwgXCJQZW5kaW5nXCIsIFwiRG9uZVwiXTtcblxuICBjb25zdCB7XG4gICAgZGF0YTogdG9kb3MsXG4gICAgaXNMb2FkaW5nLFxuICAgIGlzRXJyb3IsXG4gICAgZXJyb3IsXG4gIH0gPSB1c2VUb2Rvcyh1c2VySWQgfHwgdW5kZWZpbmVkKTtcblxuICBjb25zdCB0b2dnbGVNdXRhdGlvbiA9IHVzZVRvZ2dsZVRvZG9TdGF0dXMoKTtcblxuICBjb25zdCBoYW5kbGVUb2dnbGVUb2RvU3RhdHVzID0gKHRvZG9JZDogc3RyaW5nLCBzdGF0dXM6IFRvRG9TdGF0dXMpID0+IHtcbiAgICB0b2dnbGVNdXRhdGlvbi5tdXRhdGUoeyB0b2RvSWQsIHN0YXR1cyB9KTtcbiAgfTtcblxuICBjb25zdCBmaWx0ZXJlZFRvZG9zID0gdXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKCF0b2RvcykgcmV0dXJuIFtdO1xuICAgIHJldHVybiB0b2Rvcy5maWx0ZXIoKHRvZG8pID0+IHtcbiAgICAgIGlmIChzdGF0dXMgPT09IFwiQWxsXCIpIHJldHVybiB0cnVlO1xuICAgICAgaWYgKHN0YXR1cyA9PT0gXCJQZW5kaW5nXCIpIHJldHVybiB0b2RvLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG4gICAgICBpZiAoc3RhdHVzID09PSBcIkRvbmVcIikgcmV0dXJuIHRvZG8uc3RhdHVzID09PSBcImRvbmVcIjtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0pO1xuICB9LCBbdG9kb3MsIHN0YXR1c10pO1xuXG4gIGlmIChpc0xvYWRpbmcpIHtcbiAgICByZXR1cm4gPFNwaW5uZXIgbGFiZWw9XCJMb2FkaW5nIHRvZG9zLi4uXCIgLz47XG4gIH1cblxuICBpZiAoaXNFcnJvcikge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1kZXN0cnVjdGl2ZS81MCBiZy1kZXN0cnVjdGl2ZS8xMCBwLTRcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWRlc3RydWN0aXZlXCI+XG4gICAgICAgICAge2Vycm9yPy5tZXNzYWdlIHx8IFwiRXJyb3IgbG9hZGluZyB0b2Rvcy4gUGxlYXNlIHRyeSBhZ2FpbiBsYXRlci5cIn1cbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGlmICghdG9kb3MgfHwgdG9kb3MubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgIE5vIHRvZG9zIHlldC4gQ3JlYXRlIG9uZSB0byBnZXQgc3RhcnRlZC5cbiAgICAgIDwvcD5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgXCI+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cIm1iLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICByb2xlPVwiZ3JvdXBcIlxuICAgICAgICBhcmlhLWxhYmVsPVwiRmlsdGVyIGJ5IHN0YXR1c1wiXG4gICAgICA+XG4gICAgICAgIHtmaWx0ZXJCdXR0b25zLm1hcCgodmFsdWUpID0+IChcbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBrZXk9e3ZhbHVlfVxuICAgICAgICAgICAgdmFyaWFudD17c3RhdHVzID09PSB2YWx1ZSA/IFwicHJpbWFyeVwiIDogXCJvdXRsaW5lXCJ9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEgdGV4dC14cyBjYXBpdGFsaXplXCJcbiAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17c3RhdHVzID09PSB2YWx1ZX1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0YXR1cyh2YWx1ZSBhcyBcIkFsbFwiIHwgXCJQZW5kaW5nXCIgfCBcIkRvbmVcIil9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3ZhbHVlfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgICAge2ZpbHRlcmVkVG9kb3MgJiYgZmlsdGVyZWRUb2Rvcy5sZW5ndGggPiAwID8gKFxuICAgICAgICA8VG9kb0xpc3RcbiAgICAgICAgICB0b2Rvcz17ZmlsdGVyZWRUb2Rvc31cbiAgICAgICAgICBvblRvZ2dsZT17aGFuZGxlVG9nZ2xlVG9kb1N0YXR1c31cbiAgICAgICAgICBpc1VwZGF0aW5nPXt0b2dnbGVNdXRhdGlvbi5pc1BlbmRpbmd9XG4gICAgICAgICAgdXBkYXRlVG9kb0lkPXt0b2dnbGVNdXRhdGlvbi52YXJpYWJsZXM/LnRvZG9JZH1cbiAgICAgICAgLz5cbiAgICAgICkgOiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZFwiPk5vIHRvZG9zLjwvcD5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgeyBUb2RvcyB9O1xuIl19