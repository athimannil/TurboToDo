import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/CreateUserForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f71da48c";
import { Field, Button } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/index.ts";
import { useCreateUser } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/hooks.ts";
import { createUserSchema } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/validation.ts";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/CreateUserForm.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
var _s = $RefreshSig$();
const CreateUserForm = ({ onSuccess }) => {
	_s();
	const [username, setUsername] = useState("");
	const [validationErrors, setValidationErrors] = useState({});
	const createUserMutation = useCreateUser();
	const handleSubmit = async (event) => {
		event.preventDefault();
		setValidationErrors({});
		const formResult = createUserSchema.safeParse({ username });
		if (!formResult.success) {
			const errors = {};
			formResult.error.issues.forEach((issue) => {
				if (issue.path.length > 0) {
					errors[issue.path[0].toString()] = issue.message;
				}
			});
			setValidationErrors(errors);
			return;
		}
		try {
			const user = await createUserMutation.mutateAsync({ username: formResult.data.username });
			setUsername("");
			setValidationErrors({});
			onSuccess?.(user.id);
		} catch (error) {}
	};
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: handleSubmit,
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ _jsxDEV(Field, {
			id: "username",
			label: "Username",
			hint: "Enter a unique username for the new user.",
			error: validationErrors.username,
			children: (props) => /* @__PURE__ */ _jsxDEV("input", {
				...props,
				name: "username",
				className: "w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 aria-invalid:border-destructive",
				type: "text",
				value: username,
				onChange: (e) => {
					setUsername(e.target.value);
					if (validationErrors.username) {
						setValidationErrors({});
					}
					if (createUserMutation.error) {
						createUserMutation.reset();
					}
				},
				placeholder: "Username",
				autoComplete: "off"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(Button, {
			type: "submit",
			disabled: createUserMutation.isPending,
			children: createUserMutation.isPending ? "Creating..." : "Create User"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 9
		}, this), createUserMutation.isError && /* @__PURE__ */ _jsxDEV("p", {
			className: "mt-2 text-xs text-destructive",
			children: createUserMutation.error instanceof Error ? createUserMutation.error.message : "Failed to create user"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 81,
			columnNumber: 11
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 5
	}, this);
};
_s(CreateUserForm, "tca6M3hyDOhVHFsDpcIHnSVH+3w=", false, function() {
	return [useCreateUser];
});
_c = CreateUserForm;
export { CreateUserForm };
var _c;
$RefreshReg$(_c, "CreateUserForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/CreateUserForm.tsx?t=1785727715973";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/CreateUserForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/CreateUserForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/CreateUserForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBeUIsZ0JBQWdCO0FBQ3pDLFNBQVMsT0FBTyxjQUFjO0FBQzlCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsd0JBQXdCOzs7O0FBRWpDLE1BQU0sa0JBQWtCLEVBQ3RCLGdCQUdJOztDQUNKLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBRTlDLENBQUMsQ0FBQztDQUVKLE1BQU0scUJBQXFCLGNBQWM7Q0FFekMsTUFBTSxlQUFlLE9BQU8sVUFBcUI7RUFDL0MsTUFBTSxlQUFlO0VBQ3JCLG9CQUFvQixDQUFDLENBQUM7RUFFdEIsTUFBTSxhQUFhLGlCQUFpQixVQUFVLEVBQUUsU0FBUyxDQUFDO0VBRTFELElBQUksQ0FBQyxXQUFXLFNBQVM7R0FDdkIsTUFBTSxTQUFpQyxDQUFDO0dBQ3hDLFdBQVcsTUFBTSxPQUFPLFNBQVMsVUFBVTtJQUN6QyxJQUFJLE1BQU0sS0FBSyxTQUFTLEdBQUc7S0FDekIsT0FBTyxNQUFNLEtBQUssRUFBRSxDQUFDLFNBQVMsS0FBSyxNQUFNO0lBQzNDO0dBQ0YsQ0FBQztHQUNELG9CQUFvQixNQUFNO0dBQzFCO0VBQ0Y7RUFFQSxJQUFJO0dBQ0YsTUFBTSxPQUFPLE1BQU0sbUJBQW1CLFlBQVksRUFDaEQsVUFBVSxXQUFXLEtBQUssU0FDNUIsQ0FBQztHQUNELFlBQVksRUFBRTtHQUNkLG9CQUFvQixDQUFDLENBQUM7R0FDdEIsWUFBWSxLQUFLLEVBQUU7RUFDckIsU0FBUyxPQUFPLENBRWhCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxVQUFVO0VBQWMsV0FBVTtZQUF4QyxDQUNFLHdCQUFDLE9BQUQ7R0FDRSxJQUFHO0dBQ0gsT0FBTTtHQUNOLE1BQUs7R0FDTCxPQUFPLGlCQUFpQjtjQUV0QixVQUNBLHdCQUFDLFNBQUQ7SUFDRSxHQUFJO0lBQ0osTUFBSztJQUNMLFdBQVU7SUFDVixNQUFLO0lBQ0wsT0FBTztJQUNQLFdBQVcsTUFBTTtLQUNmLFlBQVksRUFBRSxPQUFPLEtBQUs7S0FDMUIsSUFBSSxpQkFBaUIsVUFBVTtNQUM3QixvQkFBb0IsQ0FBQyxDQUFDO0tBQ3hCO0tBQ0EsSUFBSSxtQkFBbUIsT0FBTztNQUM1QixtQkFBbUIsTUFBTTtLQUMzQjtJQUNGO0lBQ0EsYUFBWTtJQUNaLGNBQWE7R0FDZDs7Ozs7RUFFRTs7OztZQUNQLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO0dBQVEsTUFBSztHQUFTLFVBQVUsbUJBQW1CO2FBQ2hELG1CQUFtQixZQUFZLGdCQUFnQjtFQUMxQzs7OztZQUNQLG1CQUFtQixXQUNsQix3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUNWLG1CQUFtQixpQkFBaUIsUUFDakMsbUJBQW1CLE1BQU0sVUFDekI7RUFDSDs7OztVQUVGOzs7O1VBQ0Q7Ozs7OztBQUVWOzs7OztBQUVBLFNBQVMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ3JlYXRlVXNlckZvcm0udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHR5cGUgRm9ybUV2ZW50LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgRmllbGQsIEJ1dHRvbiB9IGZyb20gXCJAcmVwby9zaGFyZWRcIjtcbmltcG9ydCB7IHVzZUNyZWF0ZVVzZXIgfSBmcm9tIFwiLi4vaG9va3NcIjtcbmltcG9ydCB7IGNyZWF0ZVVzZXJTY2hlbWEgfSBmcm9tIFwiLi4vdmFsaWRhdGlvblwiO1xuXG5jb25zdCBDcmVhdGVVc2VyRm9ybSA9ICh7XG4gIG9uU3VjY2Vzcyxcbn06IHtcbiAgb25TdWNjZXNzPzogKHVzZXJuYW1lOiBzdHJpbmcpID0+IHZvaWQ7XG59KSA9PiB7XG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFt2YWxpZGF0aW9uRXJyb3JzLCBzZXRWYWxpZGF0aW9uRXJyb3JzXSA9IHVzZVN0YXRlPFxuICAgIFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbiAgPih7fSk7XG5cbiAgY29uc3QgY3JlYXRlVXNlck11dGF0aW9uID0gdXNlQ3JlYXRlVXNlcigpO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChldmVudDogRm9ybUV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRWYWxpZGF0aW9uRXJyb3JzKHt9KTtcblxuICAgIGNvbnN0IGZvcm1SZXN1bHQgPSBjcmVhdGVVc2VyU2NoZW1hLnNhZmVQYXJzZSh7IHVzZXJuYW1lIH0pO1xuXG4gICAgaWYgKCFmb3JtUmVzdWx0LnN1Y2Nlc3MpIHtcbiAgICAgIGNvbnN0IGVycm9yczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICAgICAgZm9ybVJlc3VsdC5lcnJvci5pc3N1ZXMuZm9yRWFjaCgoaXNzdWUpID0+IHtcbiAgICAgICAgaWYgKGlzc3VlLnBhdGgubGVuZ3RoID4gMCkge1xuICAgICAgICAgIGVycm9yc1tpc3N1ZS5wYXRoWzBdLnRvU3RyaW5nKCldID0gaXNzdWUubWVzc2FnZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBzZXRWYWxpZGF0aW9uRXJyb3JzKGVycm9ycyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBjcmVhdGVVc2VyTXV0YXRpb24ubXV0YXRlQXN5bmMoe1xuICAgICAgICB1c2VybmFtZTogZm9ybVJlc3VsdC5kYXRhLnVzZXJuYW1lLFxuICAgICAgfSk7XG4gICAgICBzZXRVc2VybmFtZShcIlwiKTtcbiAgICAgIHNldFZhbGlkYXRpb25FcnJvcnMoe30pO1xuICAgICAgb25TdWNjZXNzPy4odXNlci5pZCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIEVycm9yIGlzIGhhbmRsZWQgYnkgbXV0YXRpb24gc3RhdGVcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00XCI+XG4gICAgICA8RmllbGRcbiAgICAgICAgaWQ9XCJ1c2VybmFtZVwiXG4gICAgICAgIGxhYmVsPVwiVXNlcm5hbWVcIlxuICAgICAgICBoaW50PVwiRW50ZXIgYSB1bmlxdWUgdXNlcm5hbWUgZm9yIHRoZSBuZXcgdXNlci5cIlxuICAgICAgICBlcnJvcj17dmFsaWRhdGlvbkVycm9ycy51c2VybmFtZX1cbiAgICAgID5cbiAgICAgICAgeyhwcm9wcykgPT4gKFxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgey4uLnByb3BzfVxuICAgICAgICAgICAgbmFtZT1cInVzZXJuYW1lXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcHgtMyBweS0yIHRleHQtc20gdGV4dC1mb3JlZ3JvdW5kIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9ycyBwbGFjZWhvbGRlcjp0ZXh0LW11dGVkLWZvcmVncm91bmQgZm9jdXMtdmlzaWJsZTpib3JkZXItcmluZyBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZy80MCBhcmlhLWludmFsaWQ6Ym9yZGVyLWRlc3RydWN0aXZlXCJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICBzZXRVc2VybmFtZShlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgIGlmICh2YWxpZGF0aW9uRXJyb3JzLnVzZXJuYW1lKSB7XG4gICAgICAgICAgICAgICAgc2V0VmFsaWRhdGlvbkVycm9ycyh7fSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWYgKGNyZWF0ZVVzZXJNdXRhdGlvbi5lcnJvcikge1xuICAgICAgICAgICAgICAgIGNyZWF0ZVVzZXJNdXRhdGlvbi5yZXNldCgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJVc2VybmFtZVwiXG4gICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgIC8+XG4gICAgICAgICl9XG4gICAgICA8L0ZpZWxkPlxuICAgICAgPGRpdj5cbiAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2NyZWF0ZVVzZXJNdXRhdGlvbi5pc1BlbmRpbmd9PlxuICAgICAgICAgIHtjcmVhdGVVc2VyTXV0YXRpb24uaXNQZW5kaW5nID8gXCJDcmVhdGluZy4uLlwiIDogXCJDcmVhdGUgVXNlclwifVxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAge2NyZWF0ZVVzZXJNdXRhdGlvbi5pc0Vycm9yICYmIChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1kZXN0cnVjdGl2ZVwiPlxuICAgICAgICAgICAge2NyZWF0ZVVzZXJNdXRhdGlvbi5lcnJvciBpbnN0YW5jZW9mIEVycm9yXG4gICAgICAgICAgICAgID8gY3JlYXRlVXNlck11dGF0aW9uLmVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgICAgOiBcIkZhaWxlZCB0byBjcmVhdGUgdXNlclwifVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZm9ybT5cbiAgKTtcbn07XG5cbmV4cG9ydCB7IENyZWF0ZVVzZXJGb3JtIH07XG4iXX0=