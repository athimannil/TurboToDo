import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/index.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=f71da48c";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/index.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
const Home = () => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-10",
		children: /* @__PURE__ */ _jsxDEV("section", { children: [
			/* @__PURE__ */ _jsxDEV("p", {
				className: "font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground",
				children: "Turborepo · React · TypeScript · Vite"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "mt-3 max-w-2xl text-4xl font-semibold tracking-tight text-foreground sm:text-5xl",
				children: "Two features, one composition root."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-4 max-w-2xl text-base text-muted-foreground",
				children: "Users and ToDoItems live in separate packages that never import each other. Routing is TanStack Router, data access is TanStack Query over an in-memory fake api, and creating a todo is optimistic with real rollback."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: "/users",
					className: "inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
					children: "Create a user"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: "/todos",
					className: "inline-flex items-center rounded-md border border-border px-4 py-2 text-sm font-medium transition-colors hover:bg-accent",
					children: "Assign a todo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 9
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
};
_c = Home;
export default Home;
var _c;
$RefreshReg$(_c, "Home");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/apps/web/src/routes/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZOzs7QUFFckIsTUFBTSxhQUFhO0NBQ2pCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxXQUFEO0dBQ0Usd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBcUU7R0FFL0U7Ozs7O0dBQ0gsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBbUY7R0FFN0Y7Ozs7O0dBQ0osd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBaUQ7R0FLM0Q7Ozs7O0dBQ0gsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FDRSxJQUFHO0tBQ0gsV0FBVTtlQUNYO0lBRUs7Ozs7Y0FDTix3QkFBQyxNQUFEO0tBQ0UsSUFBRztLQUNILFdBQVU7ZUFDWDtJQUVLOzs7O1lBQ0g7Ozs7OztFQUNFOzs7OztDQUNOOzs7OztBQUVUOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXJvdXRlclwiO1xuXG5jb25zdCBIb21lID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMTBcIj5cbiAgICAgIDxzZWN0aW9uPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMmVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICBUdXJib3JlcG8gwrcgUmVhY3QgwrcgVHlwZVNjcmlwdCDCtyBWaXRlXG4gICAgICAgIDwvcD5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm10LTMgbWF4LXctMnhsIHRleHQtNHhsIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1mb3JlZ3JvdW5kIHNtOnRleHQtNXhsXCI+XG4gICAgICAgICAgVHdvIGZlYXR1cmVzLCBvbmUgY29tcG9zaXRpb24gcm9vdC5cbiAgICAgICAgPC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCBtYXgtdy0yeGwgdGV4dC1iYXNlIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgIFVzZXJzIGFuZCBUb0RvSXRlbXMgbGl2ZSBpbiBzZXBhcmF0ZSBwYWNrYWdlcyB0aGF0IG5ldmVyIGltcG9ydCBlYWNoXG4gICAgICAgICAgb3RoZXIuIFJvdXRpbmcgaXMgVGFuU3RhY2sgUm91dGVyLCBkYXRhIGFjY2VzcyBpcyBUYW5TdGFjayBRdWVyeSBvdmVyXG4gICAgICAgICAgYW4gaW4tbWVtb3J5IGZha2UgYXBpLCBhbmQgY3JlYXRpbmcgYSB0b2RvIGlzIG9wdGltaXN0aWMgd2l0aCByZWFsXG4gICAgICAgICAgcm9sbGJhY2suXG4gICAgICAgIDwvcD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXggZmxleC13cmFwIGdhcC0zXCI+XG4gICAgICAgICAgPExpbmtcbiAgICAgICAgICAgIHRvPVwiL3VzZXJzXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciByb3VuZGVkLW1kIGJnLXByaW1hcnkgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctcHJpbWFyeS85MFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgQ3JlYXRlIGEgdXNlclxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgdG89XCIvdG9kb3NcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ib3JkZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctYWNjZW50XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBBc3NpZ24gYSB0b2RvXG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEhvbWU7XG4iXX0=