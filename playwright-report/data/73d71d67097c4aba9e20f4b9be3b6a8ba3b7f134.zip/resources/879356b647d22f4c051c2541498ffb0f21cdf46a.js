import { B as invariant$1, C as RequestHandler, I as Emitter$1, L as TypedEvent$1, M as Interceptor$1, N as createRequestId$1, O as BatchInterceptor, R as InternalError, T as HttpResponse, _ as isObject, c as Disposable, j as DeferredPromise$1, k as resolveWebSocketUrl$1, l as HandlersController, m as kConnect, n as isCommonAssetRequest, o as executeHandlers, p as kAutoConnect, r as until$1, s as toReadonlyArray, t as storeResponseCookies, u as InMemoryHandlersController, v as toPublicUrl, z as devUtils } from "/node_modules/.vite/deps/storeResponseCookies-DUYrg6hU.js?v=f71da48c";
//#region ../../node_modules/msw/lib/core/experimental/frames/network-frame.mjs
var NetworkFrame = class {
	constructor(protocol, data) {
		this.protocol = protocol;
		this.data = data;
		this.events = new Emitter$1();
	}
	protocol;
	data;
	events;
};
//#endregion
//#region ../../node_modules/msw/lib/core/experimental/sources/network-source.mjs
var NetworkFrameEvent = class extends TypedEvent$1 {
	frame;
	constructor(type, frame) {
		super(...[type, {}]);
		this.frame = frame;
	}
};
var NetworkSource = class {
	emitter;
	constructor() {
		this.emitter = new Emitter$1();
	}
	async queue(frame) {
		await this.emitter.emitAsPromise(new NetworkFrameEvent("frame", frame));
	}
	on(type, listener, options) {
		this.emitter.on(type, listener, options);
	}
	disable() {
		this.emitter.removeAllListeners();
	}
};
function shouldBypassRequest(request) {
	return !!request.headers.get("accept")?.includes("msw/passthrough");
}
function isPassthroughResponse(response) {
	return response.status === 302 && response.headers.get("x-msw-intention") === "passthrough";
}
function deleteRequestPassthroughHeader(request) {
	const acceptHeader = request.headers.get("accept");
	if (acceptHeader) {
		const nextAcceptHeader = acceptHeader.replace(/(,\s+)?msw\/passthrough/, "");
		if (nextAcceptHeader) request.headers.set("accept", nextAcceptHeader);
		else request.headers.delete("accept");
	}
}
//#endregion
//#region ../../node_modules/msw/lib/core/experimental/frames/http-frame.mjs
var RequestEvent = class extends TypedEvent$1 {
	requestId;
	request;
	constructor(type, data) {
		super(...[type, {}]);
		this.requestId = data.requestId;
		this.request = data.request;
	}
};
var ResponseEvent = class extends TypedEvent$1 {
	requestId;
	request;
	response;
	constructor(type, data) {
		super(...[type, {}]);
		this.requestId = data.requestId;
		this.request = data.request;
		this.response = data.response;
	}
};
var UnhandledExceptionEvent = class extends TypedEvent$1 {
	error;
	requestId;
	request;
	constructor(type, data) {
		super(...[type, {}]);
		this.error = data.error;
		this.requestId = data.requestId;
		this.request = data.request;
	}
};
var HttpNetworkFrame = class extends NetworkFrame {
	constructor(options) {
		const id = options.id || createRequestId$1();
		super("http", {
			id,
			request: options.request
		});
	}
	getHandlers(controller) {
		return controller.getHandlersByKind("request");
	}
	async getUnhandledMessage() {
		const { request } = this.data;
		const url = new URL(request.url);
		const publicUrl = toPublicUrl(url) + url.search;
		const requestBody = request.body == null ? null : await request.clone().text();
		return `intercepted a request without a matching request handler:${`

  \u2022 ${request.method} ${publicUrl}

${requestBody ? `  \u2022 Request body: ${requestBody}

` : ""}`}If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests`;
	}
	async resolve(handlers, onUnhandledFrame, resolutionContext) {
		const { id: requestId, request } = this.data;
		const requestCloneForLogs = resolutionContext?.quiet ? null : request.clone();
		this.events.emit(new RequestEvent("request:start", {
			requestId,
			request
		}));
		if (shouldBypassRequest(request)) {
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			this.passthrough();
			return null;
		}
		const [lookupError, lookupResult] = await until$1(() => {
			return executeHandlers({
				requestId,
				request,
				handlers,
				resolutionContext: {
					baseUrl: resolutionContext?.baseUrl?.toString(),
					quiet: resolutionContext?.quiet
				}
			});
		});
		if (lookupError != null) {
			if (!this.events.emit(new UnhandledExceptionEvent("unhandledException", {
				error: lookupError,
				requestId,
				request
			}))) {
				console.error(lookupError);
				devUtils.error("Encountered an unhandled exception during the handler lookup for \"%s %s\". Please see the original error above.", request.method, request.url);
			}
			this.errorWith(lookupError);
			return null;
		}
		if (lookupResult == null) {
			this.events.emit(new RequestEvent("request:unhandled", {
				requestId,
				request
			}));
			await executeUnhandledFrameHandle(this, onUnhandledFrame).then(() => this.passthrough(), (error) => this.errorWith(error));
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			return false;
		}
		const { response, handler, parsedResult } = lookupResult;
		this.events.emit(new RequestEvent("request:match", {
			requestId,
			request
		}));
		if (response == null) {
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			this.passthrough();
			return null;
		}
		if (isPassthroughResponse(response)) {
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			this.passthrough();
			return null;
		}
		const responseCloneForLogs = resolutionContext?.quiet ? null : response.clone();
		await storeResponseCookies(request, response);
		this.respondWith(response);
		this.events.emit(new RequestEvent("request:end", {
			requestId,
			request
		}));
		if (!resolutionContext?.quiet) handler.log({
			request: requestCloneForLogs,
			response: responseCloneForLogs,
			parsedResult
		});
		return true;
	}
};
//#endregion
//#region ../../node_modules/msw/lib/core/experimental/on-unhandled-frame.mjs
async function executeUnhandledFrameHandle(frame, handle) {
	const printStrategyMessage = async (strategy) => {
		if (strategy === "bypass") return;
		const message = await frame.getUnhandledMessage();
		switch (strategy) {
			case "warn": return devUtils.warn("Warning: %s", message);
			case "error": return devUtils.error("Error: %s", message);
		}
	};
	const applyStrategy = async (strategy) => {
		invariant$1.as(
			InternalError,
			strategy === "bypass" || strategy === "warn" || strategy === "error",
			/**
			* @fixme Rename "onUnhandledRequest" to "onUnhandledFrame" in the error message
			* with the next major release.
			*/
			devUtils.formatMessage("Failed to react to an unhandled network frame: unknown strategy \"%s\". Please provide one of the supported strategies (\"bypass\", \"warn\", \"error\") or a custom callback function as the value of the \"onUnhandledRequest\" option.", strategy)
		);
		if (strategy === "bypass") return;
		await printStrategyMessage(strategy);
		if (strategy === "error") return Promise.reject(new InternalError(devUtils.formatMessage("Cannot bypass a request when using the \"error\" strategy for the \"onUnhandledRequest\" option.")));
	};
	if (typeof handle === "function") return handle({
		frame,
		defaults: {
			warn: printStrategyMessage.bind(null, "warn"),
			/**
			* @note The defaults only print the corresponding messages now.
			* They do not affect the frame resolution (e.g. do not error the frame).
			* That is only for backward compatibility reasons. In the future, these should
			* be an alias to `applyStrategy.bind(null, 'error')` instead.
			*/
			error: printStrategyMessage.bind(null, "error")
		}
	});
	if (frame instanceof HttpNetworkFrame && isCommonAssetRequest(frame.data.request)) return;
	return applyStrategy(handle);
}
//#endregion
//#region ../../node_modules/msw/lib/core/experimental/define-network.mjs
function colorlessPromiseAll(values) {
	const promises = [];
	for (const value of values) if (value instanceof Promise) promises.push(value);
	if (promises.length > 0) return Promise.all(promises).then(() => {});
}
var NetworkReadyState = /* @__PURE__ */ ((NetworkReadyState2) => {
	NetworkReadyState2[NetworkReadyState2["DISABLED"] = 0] = "DISABLED";
	NetworkReadyState2[NetworkReadyState2["ENABLED"] = 1] = "ENABLED";
	return NetworkReadyState2;
})(NetworkReadyState || {});
function defineNetwork(options) {
	let readyState = 0;
	const events = new Emitter$1();
	const disposable = new Disposable();
	const deriveHandlersController = (handlers) => {
		return handlers instanceof HandlersController ? handlers : new InMemoryHandlersController(handlers || []);
	};
	let resolvedOptions = { ...options };
	let handlersController = deriveHandlersController(resolvedOptions.handlers);
	return {
		get readyState() {
			return readyState;
		},
		events,
		configure(options2) {
			invariant$1(readyState === 0, "Failed to call \"configure()\" on the network: cannot configure an already enabled network.");
			if (options2.handlers && !Object.is(options2.handlers, resolvedOptions.handlers)) handlersController = deriveHandlersController(options2.handlers);
			resolvedOptions = {
				...resolvedOptions,
				...options2
			};
		},
		enable() {
			invariant$1(readyState === 0, "Failed to call \"enable\" on the network: already enabled");
			readyState = 1;
			const session = { active: true };
			disposable["subscriptions"].push(() => {
				session.active = false;
			});
			return colorlessPromiseAll(resolvedOptions.sources.map((source) => {
				NetworkSource.prototype.disable.call(source);
				source.on("frame", async ({ frame }) => {
					frame.events.on("*", (event) => {
						if (!session.active) return;
						events.emit(event);
					});
					const handlers = frame.getHandlers(handlersController);
					await frame.resolve(handlers, resolvedOptions.onUnhandledFrame || "warn", resolvedOptions.context);
				});
				return source.enable();
			}));
		},
		disable() {
			invariant$1(readyState === 1, "Failed to call \"disable\" on the network: already disabled");
			readyState = 0;
			disposable.dispose();
			return colorlessPromiseAll(resolvedOptions.sources.map((source) => source.disable()));
		},
		use(...handlers) {
			handlersController.use(handlers);
		},
		resetHandlers(...handlers) {
			handlersController.reset(handlers);
		},
		restoreHandlers() {
			handlersController.restore();
		},
		listHandlers() {
			return toReadonlyArray(handlersController.currentHandlers());
		}
	};
}
//#endregion
//#region ../../node_modules/@mswjs/interceptors/lib/browser/hasConfigurableGlobal-C8zq1MCg.mjs
/**
* Emits an event on the given emitter but executes
* the listeners sequentially. This accounts for asynchronous
* listeners (e.g. those having "sleep" and handling the request).
*/
async function emitAsync$1(emitter, eventName, ...data) {
	const listeners = emitter.listeners(eventName);
	if (listeners.length === 0) return;
	for (const listener of listeners) await listener.apply(emitter, data);
}
var PatchesRegistry$1 = class {
	#replacements = /* @__PURE__ */ new Map();
	applyPatch(owner, key, getNextValue) {
		const ownerReplacements = this.#replacements.get(owner);
		invariant$1(!ownerReplacements?.has(key), `Failed to replace a global value at "${String(key)}": already replaced.`);
		const match = getDeepPropertyDescriptor$1(owner, key);
		if (typeof match === "undefined") {
			console.warn(`Failed to replace a global value at "${String(key)}": not a global value.`);
			return () => {};
		}
		if (match.descriptor.configurable) Object.defineProperty(owner, key, {
			value: getNextValue(owner[key]),
			enumerable: true,
			configurable: true
		});
		else if (match.descriptor.writable) owner[key] = getNextValue(owner[key]);
		else throw new Error(`Failed to patch a non-configurable non-writable property "${key.toString()}"`);
		const restorePatch = () => {
			const currentReplacements = this.#replacements.get(owner);
			if (!currentReplacements?.has(key)) return;
			if (match.owner === owner)
 /**
			* @note Restoring non-configurable properties works as long as "writable: true"
			* and none of the other descriptor properties except for "value" have changed.
			*/
			Object.defineProperty(match.owner, key, match.descriptor);
			else
 /**
			* @todo Delete the proxy property set by the registry.
			* If the match's owner isn't the original owner, the property is likely nested in the prototype.
			* The registry does not meddle with those, they are left intact.
			*/
			Reflect.deleteProperty(owner, key);
			currentReplacements.delete(key);
			if (currentReplacements.size === 0) this.#replacements.delete(owner);
		};
		if (ownerReplacements) ownerReplacements.set(key, restorePatch);
		else this.#replacements.set(owner, /* @__PURE__ */ new Map([[key, restorePatch]]));
		return restorePatch;
	}
	restoreAllPatches() {
		const errors = [];
		for (const [, ownerReplacements] of this.#replacements) for (const [, restorePatch] of ownerReplacements) try {
			restorePatch();
		} catch (error) {
			if (error instanceof Error) errors.push(error);
			else throw error;
		}
		if (errors.length > 0) throw new AggregateError(errors, "FOO!");
	}
};
var patchesRegistry$1 = new PatchesRegistry$1();
/**
* Returns a property descriptor for the given property on the owner.
* Walks down the prototype chain if the property does not exist on the owner.
* Handy for getting a global property descriptor where `globalThis` is
* replaced with a controlled class (e.g. ServiceWorkerGlobalScope).
*/
function getDeepPropertyDescriptor$1(owner, key) {
	let currentOwner = owner;
	let descriptor;
	while (currentOwner) {
		descriptor = Object.getOwnPropertyDescriptor(currentOwner, key);
		if (descriptor) return {
			owner: currentOwner,
			descriptor
		};
		currentOwner = Object.getPrototypeOf(currentOwner);
	}
}
/**
* Returns a boolean indicating whether the given global property
* is defined and is configurable.
*/
function hasConfigurableGlobal$1(propertyName) {
	const match = getDeepPropertyDescriptor$1(globalThis, propertyName);
	if (typeof match === "undefined") return false;
	const { descriptor } = match;
	if (typeof descriptor.get === "function" && typeof descriptor.get() === "undefined") return false;
	if (typeof descriptor.get === "undefined" && descriptor.value == null) return false;
	if (typeof descriptor.set === "undefined" && !descriptor.configurable) {
		console.error(`[MSW] Failed to apply interceptor: the global \`${propertyName}\` property is non-configurable. This is likely an issue with your environment. If you are using a framework, please open an issue about this in their repository.`);
		return false;
	}
	return true;
}
//#endregion
//#region ../../node_modules/@mswjs/interceptors/lib/browser/interceptors/WebSocket/index.mjs
function bindEvent$1(target, event) {
	Object.defineProperties(event, {
		target: {
			value: target,
			enumerable: true,
			writable: true
		},
		currentTarget: {
			value: target,
			enumerable: true,
			writable: true
		}
	});
	return event;
}
var kCancelable$1 = Symbol("kCancelable");
var kDefaultPrevented$1 = Symbol("kDefaultPrevented");
/**
* A `MessageEvent` superset that supports event cancellation
* in Node.js. It's rather non-intrusive so it can be safely
* used in the browser as well.
*
* @see https://github.com/nodejs/node/issues/51767
*/
var CancelableMessageEvent$1 = class extends MessageEvent {
	constructor(type, init) {
		super(type, init);
		this[kCancelable$1] = !!init.cancelable;
		this[kDefaultPrevented$1] = false;
	}
	get cancelable() {
		return this[kCancelable$1];
	}
	set cancelable(nextCancelable) {
		this[kCancelable$1] = nextCancelable;
	}
	get defaultPrevented() {
		return this[kDefaultPrevented$1];
	}
	set defaultPrevented(nextDefaultPrevented) {
		this[kDefaultPrevented$1] = nextDefaultPrevented;
	}
	preventDefault() {
		if (this.cancelable && !this[kDefaultPrevented$1]) this[kDefaultPrevented$1] = true;
	}
};
var CloseEvent$1 = class extends Event {
	constructor(type, init = {}) {
		super(type, init);
		this.code = init.code === void 0 ? 0 : init.code;
		this.reason = init.reason === void 0 ? "" : init.reason;
		this.wasClean = init.wasClean === void 0 ? false : init.wasClean;
	}
};
var CancelableCloseEvent$1 = class extends CloseEvent$1 {
	constructor(type, init = {}) {
		super(type, init);
		this[kCancelable$1] = !!init.cancelable;
		this[kDefaultPrevented$1] = false;
	}
	get cancelable() {
		return this[kCancelable$1];
	}
	set cancelable(nextCancelable) {
		this[kCancelable$1] = nextCancelable;
	}
	get defaultPrevented() {
		return this[kDefaultPrevented$1];
	}
	set defaultPrevented(nextDefaultPrevented) {
		this[kDefaultPrevented$1] = nextDefaultPrevented;
	}
	preventDefault() {
		if (this.cancelable && !this[kDefaultPrevented$1]) this[kDefaultPrevented$1] = true;
	}
};
var kEmitter$1$1 = Symbol("kEmitter");
var kBoundListener$1$1 = Symbol("kBoundListener");
/**
* The WebSocket client instance represents an incoming
* client connection. The user can control the connection,
* send and receive events.
*/
var WebSocketClientConnection$1 = class {
	constructor(socket, transport) {
		this.socket = socket;
		this.transport = transport;
		this.id = createRequestId$1();
		this.url = new URL(socket.url);
		this[kEmitter$1$1] = new EventTarget();
		this.transport.addEventListener("outgoing", (event) => {
			const message = bindEvent$1(this.socket, new CancelableMessageEvent$1("message", {
				data: event.data,
				origin: event.origin,
				cancelable: true
			}));
			this[kEmitter$1$1].dispatchEvent(message);
			if (message.defaultPrevented) event.preventDefault();
		});
		/**
		* Emit the "close" event on the "client" connection
		* whenever the underlying transport is closed.
		* @note "client.close()" does NOT dispatch the "close"
		* event on the WebSocket because it uses non-configurable
		* close status code. Thus, we listen to the transport
		* instead of the WebSocket's "close" event.
		*/
		this.transport.addEventListener("close", (event) => {
			this[kEmitter$1$1].dispatchEvent(bindEvent$1(this.socket, new CloseEvent$1("close", event)));
		});
	}
	/**
	* Listen for the outgoing events from the connected WebSocket client.
	*/
	addEventListener(type, listener, options) {
		if (!Reflect.has(listener, kBoundListener$1$1)) {
			const boundListener = listener.bind(this.socket);
			Object.defineProperty(listener, kBoundListener$1$1, {
				value: boundListener,
				enumerable: false,
				configurable: false
			});
		}
		this[kEmitter$1$1].addEventListener(type, Reflect.get(listener, kBoundListener$1$1), options);
	}
	/**
	* Removes the listener for the given event.
	*/
	removeEventListener(event, listener, options) {
		this[kEmitter$1$1].removeEventListener(event, Reflect.get(listener, kBoundListener$1$1), options);
	}
	/**
	* Send data to the connected client.
	*/
	send(data) {
		this.transport.send(data);
	}
	/**
	* Close the WebSocket connection.
	* @param {number} code A status code (see https://www.rfc-editor.org/rfc/rfc6455#section-7.4.1).
	* @param {string} reason A custom connection close reason.
	*/
	close(code, reason) {
		this.transport.close(code, reason);
	}
};
var WEBSOCKET_CLOSE_CODE_RANGE_ERROR$1 = "InvalidAccessError: close code out of user configurable range";
var kPassthroughPromise$1 = Symbol("kPassthroughPromise");
var kOnSend$1 = Symbol("kOnSend");
var kClose$1 = Symbol("kClose");
var WebSocketOverride$1 = class extends EventTarget {
	static {
		this.CONNECTING = 0;
	}
	static {
		this.OPEN = 1;
	}
	static {
		this.CLOSING = 2;
	}
	static {
		this.CLOSED = 3;
	}
	constructor(url, protocols) {
		super();
		this.CONNECTING = 0;
		this.OPEN = 1;
		this.CLOSING = 2;
		this.CLOSED = 3;
		this._onopen = null;
		this._onmessage = null;
		this._onerror = null;
		this._onclose = null;
		this.url = resolveWebSocketUrl$1(url);
		this.protocol = "";
		this.extensions = "";
		this.binaryType = "blob";
		this.readyState = this.CONNECTING;
		this.bufferedAmount = 0;
		this[kPassthroughPromise$1] = new DeferredPromise$1();
		queueMicrotask(async () => {
			if (await this[kPassthroughPromise$1]) return;
			this.protocol = typeof protocols === "string" ? protocols : Array.isArray(protocols) && protocols.length > 0 ? protocols[0] : "";
			/**
			* @note Check that nothing has prevented this connection
			* (e.g. called `client.close()` in the connection listener).
			* If the connection has been prevented, never dispatch the open event,.
			*/
			if (this.readyState === this.CONNECTING) {
				this.readyState = this.OPEN;
				this.dispatchEvent(bindEvent$1(this, new Event("open")));
			}
		});
	}
	set onopen(listener) {
		this.removeEventListener("open", this._onopen);
		this._onopen = listener;
		if (listener !== null) this.addEventListener("open", listener);
	}
	get onopen() {
		return this._onopen;
	}
	set onmessage(listener) {
		this.removeEventListener("message", this._onmessage);
		this._onmessage = listener;
		if (listener !== null) this.addEventListener("message", listener);
	}
	get onmessage() {
		return this._onmessage;
	}
	set onerror(listener) {
		this.removeEventListener("error", this._onerror);
		this._onerror = listener;
		if (listener !== null) this.addEventListener("error", listener);
	}
	get onerror() {
		return this._onerror;
	}
	set onclose(listener) {
		this.removeEventListener("close", this._onclose);
		this._onclose = listener;
		if (listener !== null) this.addEventListener("close", listener);
	}
	get onclose() {
		return this._onclose;
	}
	/**
	* @see https://websockets.spec.whatwg.org/#ref-for-dom-websocket-send%E2%91%A0
	*/
	send(data) {
		if (this.readyState === this.CONNECTING) {
			this.close();
			throw new DOMException("InvalidStateError");
		}
		if (this.readyState === this.CLOSING || this.readyState === this.CLOSED) return;
		this.bufferedAmount += getDataSize$1(data);
		queueMicrotask(() => {
			this.bufferedAmount = 0;
			/**
			* @note Notify the parent about outgoing data.
			* This notifies the transport and the connection
			* listens to the outgoing data to emit the "message" event.
			*/
			this[kOnSend$1]?.(data);
		});
	}
	close(code = 1e3, reason) {
		invariant$1(code, WEBSOCKET_CLOSE_CODE_RANGE_ERROR$1);
		invariant$1(code === 1e3 || code >= 3e3 && code <= 4999, WEBSOCKET_CLOSE_CODE_RANGE_ERROR$1);
		this[kClose$1](code, reason);
	}
	[kClose$1](code = 1e3, reason, wasClean = true) {
		/**
		* @note Move this check here so that even internal closures,
		* like those triggered by the `server` connection, are not
		* performed twice.
		*/
		if (this.readyState === this.CLOSING || this.readyState === this.CLOSED) return;
		this.readyState = this.CLOSING;
		queueMicrotask(() => {
			this.readyState = this.CLOSED;
			this.dispatchEvent(bindEvent$1(this, new CloseEvent$1("close", {
				code,
				reason,
				wasClean
			})));
			this._onopen = null;
			this._onmessage = null;
			this._onerror = null;
			this._onclose = null;
		});
	}
	addEventListener(type, listener, options) {
		return super.addEventListener(type, listener, options);
	}
	removeEventListener(type, callback, options) {
		return super.removeEventListener(type, callback, options);
	}
};
function getDataSize$1(data) {
	if (typeof data === "string") return data.length;
	if (data instanceof Blob) return data.size;
	return data.byteLength;
}
var kEmitter$2 = Symbol("kEmitter");
var kBoundListener$2 = Symbol("kBoundListener");
var kSend$1 = Symbol("kSend");
/**
* The WebSocket server instance represents the actual production
* WebSocket server connection. It's idle by default but you can
* establish it by calling `server.connect()`.
*/
var WebSocketServerConnection$1 = class {
	constructor(client, transport, createConnection) {
		this.client = client;
		this.transport = transport;
		this.createConnection = createConnection;
		this[kEmitter$2] = new EventTarget();
		this.mockCloseController = new AbortController();
		this.realCloseController = new AbortController();
		this.transport.addEventListener("outgoing", (event) => {
			if (typeof this.realWebSocket === "undefined") return;
			queueMicrotask(() => {
				if (!event.defaultPrevented)
 /**
				* @note Use the internal send mechanism so consumers can tell
				* apart direct user calls to `server.send()` and internal calls.
				* E.g. MSW has to ignore this internal call to log out messages correctly.
				*/
				this[kSend$1](event.data);
			});
		});
		this.transport.addEventListener("incoming", this.handleIncomingMessage.bind(this));
	}
	/**
	* The `WebSocket` instance connected to the original server.
	* Accessing this before calling `server.connect()` will throw.
	*/
	get socket() {
		invariant$1(this.realWebSocket, "Cannot access \"socket\" on the original WebSocket server object: the connection is not open. Did you forget to call `server.connect()`?");
		return this.realWebSocket;
	}
	/**
	* Open connection to the original WebSocket server.
	*/
	connect() {
		invariant$1(!this.realWebSocket || this.realWebSocket.readyState !== WebSocket.OPEN, "Failed to call \"connect()\" on the original WebSocket instance: the connection already open");
		const realWebSocket = this.createConnection();
		realWebSocket.binaryType = this.client.binaryType;
		realWebSocket.addEventListener("open", (event) => {
			this[kEmitter$2].dispatchEvent(bindEvent$1(this.realWebSocket, new Event("open", event)));
		}, { once: true });
		realWebSocket.addEventListener("message", (event) => {
			this.transport.dispatchEvent(bindEvent$1(this.realWebSocket, new MessageEvent("incoming", {
				data: event.data,
				origin: event.origin
			})));
		});
		this.client.addEventListener("close", (event) => {
			this.handleMockClose(event);
		}, { signal: this.mockCloseController.signal });
		realWebSocket.addEventListener("close", (event) => {
			this.handleRealClose(event);
		}, { signal: this.realCloseController.signal });
		realWebSocket.addEventListener("error", () => {
			const errorEvent = bindEvent$1(realWebSocket, new Event("error", { cancelable: true }));
			this[kEmitter$2].dispatchEvent(errorEvent);
			if (!errorEvent.defaultPrevented) this.client.dispatchEvent(bindEvent$1(this.client, new Event("error")));
		});
		this.realWebSocket = realWebSocket;
	}
	/**
	* Listen for the incoming events from the original WebSocket server.
	*/
	addEventListener(event, listener, options) {
		if (!Reflect.has(listener, kBoundListener$2)) {
			const boundListener = listener.bind(this.client);
			Object.defineProperty(listener, kBoundListener$2, {
				value: boundListener,
				enumerable: false
			});
		}
		this[kEmitter$2].addEventListener(event, Reflect.get(listener, kBoundListener$2), options);
	}
	/**
	* Remove the listener for the given event.
	*/
	removeEventListener(event, listener, options) {
		this[kEmitter$2].removeEventListener(event, Reflect.get(listener, kBoundListener$2), options);
	}
	/**
	* Send data to the original WebSocket server.
	* @example
	* server.send('hello')
	* server.send(new Blob(['hello']))
	* server.send(new TextEncoder().encode('hello'))
	*/
	send(data) {
		this[kSend$1](data);
	}
	[kSend$1](data) {
		const { realWebSocket } = this;
		invariant$1(realWebSocket, "Failed to call \"server.send()\" for \"%s\": the connection is not open. Did you forget to call \"server.connect()\"?", this.client.url);
		if (realWebSocket.readyState === WebSocket.CLOSING || realWebSocket.readyState === WebSocket.CLOSED) return;
		if (realWebSocket.readyState === WebSocket.CONNECTING) {
			realWebSocket.addEventListener("open", () => {
				realWebSocket.send(data);
			}, { once: true });
			return;
		}
		realWebSocket.send(data);
	}
	/**
	* Close the actual server connection.
	*/
	close() {
		const { realWebSocket } = this;
		invariant$1(realWebSocket, "Failed to close server connection for \"%s\": the connection is not open. Did you forget to call \"server.connect()\"?", this.client.url);
		this.realCloseController.abort();
		if (realWebSocket.readyState === WebSocket.CLOSING || realWebSocket.readyState === WebSocket.CLOSED) return;
		realWebSocket.close();
		queueMicrotask(() => {
			this[kEmitter$2].dispatchEvent(bindEvent$1(this.realWebSocket, new CancelableCloseEvent$1("close", {
				code: 1e3,
				cancelable: true
			})));
		});
	}
	handleIncomingMessage(event) {
		const messageEvent = bindEvent$1(event.target, new CancelableMessageEvent$1("message", {
			data: event.data,
			origin: event.origin,
			cancelable: true
		}));
		/**
		* @note Emit "message" event on the server connection
		* instance to let the interceptor know about these
		* incoming events from the original server. In that listener,
		* the interceptor can modify or skip the event forwarding
		* to the mock WebSocket instance.
		*/
		this[kEmitter$2].dispatchEvent(messageEvent);
		/**
		* @note Forward the incoming server events to the client.
		* Preventing the default on the message event stops this.
		*/
		if (!messageEvent.defaultPrevented) this.client.dispatchEvent(bindEvent$1(
			/**
			* @note Bind the forwarded original server events
			* to the mock WebSocket instance so it would
			* dispatch them straight away.
			*/
			this.client,
			new MessageEvent("message", {
				data: event.data,
				origin: event.origin
			})
		));
	}
	handleMockClose(_event) {
		if (this.realWebSocket) this.realWebSocket.close();
	}
	handleRealClose(event) {
		this.mockCloseController.abort();
		const closeEvent = bindEvent$1(this.realWebSocket, new CancelableCloseEvent$1("close", {
			code: event.code,
			reason: event.reason,
			wasClean: event.wasClean,
			cancelable: true
		}));
		this[kEmitter$2].dispatchEvent(closeEvent);
		if (!closeEvent.defaultPrevented) this.client[kClose$1](event.code, event.reason);
	}
};
/**
* Abstraction over the given mock `WebSocket` instance that allows
* for controlling that instance (e.g. sending and receiving messages).
*/
var WebSocketClassTransport$1 = class extends EventTarget {
	constructor(socket) {
		super();
		this.socket = socket;
		this.socket.addEventListener("close", (event) => {
			this.dispatchEvent(bindEvent$1(this.socket, new CloseEvent$1("close", event)));
		});
		/**
		* Emit the "outgoing" event on the transport
		* whenever the WebSocket client sends data ("ws.send()").
		*/
		this.socket[kOnSend$1] = (data) => {
			this.dispatchEvent(bindEvent$1(this.socket, new CancelableMessageEvent$1("outgoing", {
				data,
				origin: this.socket.url,
				cancelable: true
			})));
		};
	}
	addEventListener(type, callback, options) {
		return super.addEventListener(type, callback, options);
	}
	dispatchEvent(event) {
		return super.dispatchEvent(event);
	}
	send(data) {
		queueMicrotask(() => {
			if (this.socket.readyState === this.socket.CLOSING || this.socket.readyState === this.socket.CLOSED) return;
			const dispatchEvent = () => {
				this.socket.dispatchEvent(bindEvent$1(
					/**
					* @note Setting this event's "target" to the
					* WebSocket override instance is important.
					* This way it can tell apart original incoming events
					* (must be forwarded to the transport) from the
					* mocked message events like the one below
					* (must be dispatched on the client instance).
					*/
					this.socket,
					new MessageEvent("message", {
						data,
						origin: this.socket.url
					})
				));
			};
			if (this.socket.readyState === this.socket.CONNECTING) this.socket.addEventListener("open", () => {
				dispatchEvent();
			}, { once: true });
			else dispatchEvent();
		});
	}
	close(code, reason) {
		/**
		* @note Call the internal close method directly
		* to allow closing the connection with the status codes
		* that are non-configurable by the user (> 1000 <= 1015).
		*/
		this.socket[kClose$1](code, reason);
	}
};
(class WebSocketInterceptor extends Interceptor$1 {
	static {
		this.symbol = Symbol.for("websocket-interceptor");
	}
	constructor() {
		super(WebSocketInterceptor.symbol);
	}
	checkEnvironment() {
		return hasConfigurableGlobal$1("WebSocket");
	}
	setup() {
		const logger = this.logger.extend("setup");
		const WebSocketProxy = new Proxy(globalThis.WebSocket, { construct: (target, args, newTarget) => {
			const [url, protocols] = args;
			const createConnection = () => {
				return Reflect.construct(target, args, newTarget);
			};
			const socket = new WebSocketOverride$1(url, protocols);
			const transport = new WebSocketClassTransport$1(socket);
			queueMicrotask(async () => {
				try {
					const server = new WebSocketServerConnection$1(socket, transport, createConnection);
					const hasConnectionListeners = this.emitter.listenerCount("connection") > 0;
					await emitAsync$1(this.emitter, "connection", {
						client: new WebSocketClientConnection$1(socket, transport),
						server,
						info: { protocols }
					});
					if (hasConnectionListeners) socket[kPassthroughPromise$1].resolve(false);
					else {
						socket[kPassthroughPromise$1].resolve(true);
						server.connect();
						server.addEventListener("open", () => {
							socket.dispatchEvent(bindEvent$1(socket, new Event("open")));
							if (server["realWebSocket"]) socket.protocol = server["realWebSocket"].protocol;
						});
					}
				} catch (error) {
					/**
					* @note Translate unhandled exceptions during the connection
					* handling (i.e. interceptor exceptions) as WebSocket connection
					* closures with error. This prevents from the exceptions occurring
					* in `queueMicrotask` from being process-wide and uncatchable.
					*/
					if (error instanceof Error) {
						socket.dispatchEvent(new Event("error"));
						if (socket.readyState !== WebSocket.CLOSING && socket.readyState !== WebSocket.CLOSED) socket[kClose$1](1011, error.message, false);
						console.error(error);
					}
				}
			});
			return socket;
		} });
		logger.info("patching global WebSocket...");
		this.subscriptions.push(patchesRegistry$1.applyPatch(globalThis, "WebSocket", () => WebSocketProxy));
		logger.info("global WebSocket patched!", globalThis.WebSocket.name);
	}
});
//#endregion
//#region ../../node_modules/msw/lib/core/experimental/frames/websocket-frame.mjs
var WebSocketConnectionEvent = class extends TypedEvent$1 {
	url;
	protocols;
	constructor(type, data) {
		super(...[type, {}]);
		this.url = data.url;
		this.protocols = data.protocols;
	}
};
var UnhandledWebSocketExceptionEvent = class extends TypedEvent$1 {
	url;
	protocols;
	error;
	constructor(type, data) {
		super(...[type, {}]);
		this.url = data.url;
		this.protocols = data.protocols;
		this.error = data.error;
	}
};
var WebSocketNetworkFrame = class extends NetworkFrame {
	constructor(options) {
		super("ws", { connection: options.connection });
	}
	getHandlers(controller) {
		return controller.getHandlersByKind("websocket");
	}
	async resolve(handlers, onUnhandledFrame, resolutionContext) {
		const { connection } = this.data;
		this.events.emit(new WebSocketConnectionEvent("connection", {
			url: connection.client.url,
			protocols: connection.info.protocols
		}));
		if (handlers.length === 0) {
			await executeUnhandledFrameHandle(this, onUnhandledFrame).then(() => this.passthrough(), (error) => this.errorWith(error));
			return false;
		}
		let hasMatchingHandlers = false;
		for (const handler of handlers) {
			const handlerConnection = await handler.run(connection, {
				baseUrl: resolutionContext?.baseUrl?.toString(),
				/**
				* @note Do not emit the "connection" event when running the handler.
				* Use the run only to get the resolved connection object.
				*/
				[kAutoConnect]: false
			});
			if (!handlerConnection) continue;
			hasMatchingHandlers = true;
			const removeLogger = !resolutionContext?.quiet ? handler.log(connection) : void 0;
			try {
				if (!handler[kConnect](handlerConnection)) removeLogger?.();
			} catch (error) {
				if (!this.events.emit(new UnhandledWebSocketExceptionEvent("unhandledException", {
					error,
					url: connection.client.url,
					protocols: connection.info.protocols
				}))) {
					console.error(error);
					devUtils.error("Encountered an unhandled exception during the handler lookup for \"%s\". Please see the original error above.", connection.client.url);
				}
				throw error;
			}
		}
		if (!hasMatchingHandlers) {
			await executeUnhandledFrameHandle(this, onUnhandledFrame).then(() => this.passthrough(), (error) => this.errorWith(error));
			return false;
		}
		return true;
	}
	async getUnhandledMessage() {
		const { connection } = this.data;
		return `intercepted a WebSocket connection without a matching event handler:${`

  \u2022 ${connection.client.url}

`}If you still wish to intercept this unhandled connection, please create an event handler for it.
Read more: https://mswjs.io/docs/websocket`;
	}
};
//#endregion
//#region ../../node_modules/msw/lib/core/experimental/sources/interceptor-source.mjs
var InterceptorSource = class extends NetworkSource {
	#interceptor;
	#frames;
	constructor(options) {
		super();
		this.#interceptor = new BatchInterceptor({
			name: "interceptor-source",
			interceptors: options.interceptors
		});
		this.#frames = /* @__PURE__ */ new Map();
	}
	enable() {
		this.#interceptor.apply();
		this.#interceptor.on("request", this.#handleRequest.bind(this)).on("response", this.#handleResponse.bind(this)).on("connection", this.#handleWebSocketConnection.bind(this));
	}
	disable() {
		super.disable();
		this.#interceptor.dispose();
		this.#frames.clear();
	}
	async #handleRequest({ requestId, request, controller }) {
		const httpFrame = new InterceptorHttpNetworkFrame({
			id: requestId,
			request,
			controller
		});
		this.#frames.set(requestId, httpFrame);
		await this.queue(httpFrame);
	}
	async #handleResponse({ requestId, request, response, isMockedResponse }) {
		const httpFrame = this.#frames.get(requestId);
		this.#frames.delete(requestId);
		if (httpFrame == null) return;
		queueMicrotask(() => {
			try {
				httpFrame.events.emit(new ResponseEvent(isMockedResponse ? "response:mocked" : "response:bypass", {
					requestId,
					request,
					response
				}));
			} finally {
				httpFrame.events.removeAllListeners();
			}
		});
	}
	async #handleWebSocketConnection(connection) {
		await this.queue(new InterceptorWebSocketNetworkFrame({ connection }));
	}
};
var InterceptorHttpNetworkFrame = class extends HttpNetworkFrame {
	#controller;
	constructor(options) {
		super({
			id: options.id,
			request: options.request
		});
		this.#controller = options.controller;
	}
	passthrough() {
		deleteRequestPassthroughHeader(this.data.request);
	}
	respondWith(response) {
		if (response) this.#controller.respondWith(response);
	}
	errorWith(reason) {
		if (reason instanceof Response) return this.respondWith(reason);
		if (reason instanceof InternalError) this.#controller.errorWith(reason);
		throw reason;
	}
};
var InterceptorWebSocketNetworkFrame = class extends WebSocketNetworkFrame {
	constructor(args) {
		super({ connection: args.connection });
		args.connection.client.addEventListener("close", () => {
			this.events.removeAllListeners();
		}, { once: true });
	}
	errorWith(reason) {
		if (reason instanceof Error) {
			const { client } = this.data.connection;
			const errorEvent = new Event("error");
			Object.defineProperty(errorEvent, "cause", {
				enumerable: true,
				configurable: false,
				value: reason
			});
			client.socket.dispatchEvent(errorEvent);
		}
	}
	passthrough() {
		this.data.connection.server.connect();
	}
};
//#endregion
//#region ../../node_modules/msw/lib/core/experimental/compat.mjs
function fromLegacyOnUnhandledRequest(getLegacyValue) {
	return ({ frame, defaults }) => {
		const legacyOnUnhandledRequestStrategy = getLegacyValue();
		if (legacyOnUnhandledRequestStrategy == null) return;
		if (typeof legacyOnUnhandledRequestStrategy === "function") {
			const request = frame instanceof HttpNetworkFrame ? frame.data.request : frame instanceof WebSocketNetworkFrame ? new Request(frame.data.connection.client.url, { headers: {
				connection: "upgrade",
				upgrade: "websocket"
			} }) : null;
			invariant$1(request != null, "Failed to coerce a network frame to a legacy `onUnhandledRequest` strategy: unknown frame protocol \"%s\"", frame.protocol);
			return legacyOnUnhandledRequestStrategy(request, {
				warning: defaults.warn,
				error: defaults.error
			});
		}
		return executeUnhandledFrameHandle(frame, legacyOnUnhandledRequestStrategy);
	};
}
//#endregion
//#region ../../node_modules/msw/lib/core/utils/toResponseInit.mjs
function toResponseInit(response) {
	return {
		status: response.status,
		statusText: response.statusText,
		headers: Object.fromEntries(response.headers.entries())
	};
}
//#endregion
//#region ../../node_modules/msw/lib/browser/index.mjs
var POSITIONALS_EXP = /(%?)(%([sdijo]))/g;
function serializePositional(positional, flag) {
	switch (flag) {
		case "s": return positional;
		case "d":
		case "i": return Number(positional);
		case "j": return JSON.stringify(positional);
		case "o": {
			if (typeof positional === "string") return positional;
			const json = JSON.stringify(positional);
			if (json === "{}" || json === "[]" || /^\[object .+?\]$/.test(json)) return positional;
			return json;
		}
	}
}
function format(message, ...positionals) {
	if (positionals.length === 0) return message;
	let positionalIndex = 0;
	let formattedMessage = message.replace(POSITIONALS_EXP, (match, isEscaped, _, flag) => {
		const positional = positionals[positionalIndex];
		const value = serializePositional(positional, flag);
		if (!isEscaped) {
			positionalIndex++;
			return value;
		}
		return match;
	});
	if (positionalIndex < positionals.length) formattedMessage += ` ${positionals.slice(positionalIndex).join(" ")}`;
	formattedMessage = formattedMessage.replace(/%{2,2}/g, "%");
	return formattedMessage;
}
var STACK_FRAMES_TO_IGNORE = 2;
function cleanErrorStack(error2) {
	if (!error2.stack) return;
	const nextStack = error2.stack.split("\n");
	nextStack.splice(1, STACK_FRAMES_TO_IGNORE);
	error2.stack = nextStack.join("\n");
}
var InvariantError = class extends Error {
	constructor(message, ...positionals) {
		super(message);
		this.message = message;
		this.name = "Invariant Violation";
		this.message = format(message, ...positionals);
		cleanErrorStack(this);
	}
};
var invariant = (predicate, message, ...positionals) => {
	if (!predicate) throw new InvariantError(message, ...positionals);
};
invariant.as = (ErrorConstructor, predicate, message, ...positionals) => {
	if (!predicate) {
		const formatMessage = positionals.length === 0 ? message : format(message, ...positionals);
		let error2;
		try {
			error2 = Reflect.construct(ErrorConstructor, [formatMessage]);
		} catch (err) {
			error2 = ErrorConstructor(formatMessage);
		}
		throw error2;
	}
};
function isNodeProcess() {
	if (typeof navigator !== "undefined" && navigator.product === "ReactNative") return true;
	if (typeof process !== "undefined") {
		const type = process.type;
		if (type === "renderer" || type === "worker") return false;
		return !!(process.versions && process.versions.node);
	}
	return false;
}
var __defProp = Object.defineProperty;
var __export = (target, all) => {
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
};
var colors_exports = {};
__export(colors_exports, {
	blue: () => blue,
	gray: () => gray,
	green: () => green,
	red: () => red,
	yellow: () => yellow
});
function yellow(text) {
	return `\x1B[33m${text}\x1B[0m`;
}
function blue(text) {
	return `\x1B[34m${text}\x1B[0m`;
}
function gray(text) {
	return `\x1B[90m${text}\x1B[0m`;
}
function red(text) {
	return `\x1B[31m${text}\x1B[0m`;
}
function green(text) {
	return `\x1B[32m${text}\x1B[0m`;
}
var IS_NODE = isNodeProcess();
var Logger = class {
	constructor(name) {
		this.name = name;
		this.prefix = `[${this.name}]`;
		const LOGGER_NAME = getVariable("DEBUG");
		const LOGGER_LEVEL = getVariable("LOG_LEVEL");
		if (LOGGER_NAME === "1" || LOGGER_NAME === "true" || typeof LOGGER_NAME !== "undefined" && this.name.startsWith(LOGGER_NAME)) {
			this.debug = isDefinedAndNotEquals(LOGGER_LEVEL, "debug") ? noop : this.debug;
			this.info = isDefinedAndNotEquals(LOGGER_LEVEL, "info") ? noop : this.info;
			this.success = isDefinedAndNotEquals(LOGGER_LEVEL, "success") ? noop : this.success;
			this.warning = isDefinedAndNotEquals(LOGGER_LEVEL, "warning") ? noop : this.warning;
			this.error = isDefinedAndNotEquals(LOGGER_LEVEL, "error") ? noop : this.error;
		} else {
			this.info = noop;
			this.success = noop;
			this.warning = noop;
			this.error = noop;
			this.only = noop;
		}
	}
	prefix;
	extend(domain) {
		return new Logger(`${this.name}:${domain}`);
	}
	/**
	* Print a debug message.
	* @example
	* logger.debug('no duplicates found, creating a document...')
	*/
	debug(message, ...positionals) {
		this.logEntry({
			level: "debug",
			message: gray(message),
			positionals,
			prefix: this.prefix,
			colors: { prefix: "gray" }
		});
	}
	/**
	* Print an info message.
	* @example
	* logger.info('start parsing...')
	*/
	info(message, ...positionals) {
		this.logEntry({
			level: "info",
			message,
			positionals,
			prefix: this.prefix,
			colors: { prefix: "blue" }
		});
		const performance2 = new PerformanceEntry();
		return (message2, ...positionals2) => {
			performance2.measure();
			this.logEntry({
				level: "info",
				message: `${message2} ${gray(`${performance2.deltaTime}ms`)}`,
				positionals: positionals2,
				prefix: this.prefix,
				colors: { prefix: "blue" }
			});
		};
	}
	/**
	* Print a success message.
	* @example
	* logger.success('successfully created document')
	*/
	success(message, ...positionals) {
		this.logEntry({
			level: "info",
			message,
			positionals,
			prefix: `\u2714 ${this.prefix}`,
			colors: {
				timestamp: "green",
				prefix: "green"
			}
		});
	}
	/**
	* Print a warning.
	* @example
	* logger.warning('found legacy document format')
	*/
	warning(message, ...positionals) {
		this.logEntry({
			level: "warning",
			message,
			positionals,
			prefix: `\u26A0 ${this.prefix}`,
			colors: {
				timestamp: "yellow",
				prefix: "yellow"
			}
		});
	}
	/**
	* Print an error message.
	* @example
	* logger.error('something went wrong')
	*/
	error(message, ...positionals) {
		this.logEntry({
			level: "error",
			message,
			positionals,
			prefix: `\u2716 ${this.prefix}`,
			colors: {
				timestamp: "red",
				prefix: "red"
			}
		});
	}
	/**
	* Execute the given callback only when the logging is enabled.
	* This is skipped in its entirety and has no runtime cost otherwise.
	* This executes regardless of the log level.
	* @example
	* logger.only(() => {
	*   logger.info('additional info')
	* })
	*/
	only(callback) {
		callback();
	}
	createEntry(level, message) {
		return {
			timestamp: /* @__PURE__ */ new Date(),
			level,
			message
		};
	}
	logEntry(args) {
		const { level, message, prefix, colors: customColors, positionals = [] } = args;
		const entry = this.createEntry(level, message);
		const timestampColor = customColors?.timestamp || "gray";
		const prefixColor = customColors?.prefix || "gray";
		const colorize = {
			timestamp: colors_exports[timestampColor],
			prefix: colors_exports[prefixColor]
		};
		this.getWriter(level)([colorize.timestamp(this.formatTimestamp(entry.timestamp))].concat(prefix != null ? colorize.prefix(prefix) : []).concat(serializeInput(message)).join(" "), ...positionals.map(serializeInput));
	}
	formatTimestamp(timestamp) {
		return `${timestamp.toLocaleTimeString("en-GB")}:${timestamp.getMilliseconds()}`;
	}
	getWriter(level) {
		switch (level) {
			case "debug":
			case "success":
			case "info": return log;
			case "warning": return warn;
			case "error": return error;
		}
	}
};
var PerformanceEntry = class {
	startTime;
	endTime;
	deltaTime;
	constructor() {
		this.startTime = performance.now();
	}
	measure() {
		this.endTime = performance.now();
		const deltaTime = this.endTime - this.startTime;
		this.deltaTime = deltaTime.toFixed(2);
	}
};
var noop = () => void 0;
function log(message, ...positionals) {
	if (IS_NODE) {
		process.stdout.write(format(message, ...positionals) + "\n");
		return;
	}
	console.log(message, ...positionals);
}
function warn(message, ...positionals) {
	if (IS_NODE) {
		process.stderr.write(format(message, ...positionals) + "\n");
		return;
	}
	console.warn(message, ...positionals);
}
function error(message, ...positionals) {
	if (IS_NODE) {
		process.stderr.write(format(message, ...positionals) + "\n");
		return;
	}
	console.error(message, ...positionals);
}
function getVariable(variableName) {
	if (IS_NODE) return process.env[variableName];
	return globalThis[variableName]?.toString();
}
function isDefinedAndNotEquals(value, expected) {
	return value !== void 0 && value !== expected;
}
function serializeInput(message) {
	if (typeof message === "undefined") return "undefined";
	if (message === null) return "null";
	if (typeof message === "string") return message;
	if (typeof message === "object") return JSON.stringify(message);
	return message.toString();
}
var MemoryLeakError = class extends Error {
	constructor(emitter, type, count) {
		super(`Possible EventEmitter memory leak detected. ${count} ${type.toString()} listeners added. Use emitter.setMaxListeners() to increase limit`);
		this.emitter = emitter;
		this.type = type;
		this.count = count;
		this.name = "MaxListenersExceededWarning";
	}
};
var _Emitter = class {
	static listenerCount(emitter, eventName) {
		return emitter.listenerCount(eventName);
	}
	constructor() {
		this.events = /* @__PURE__ */ new Map();
		this.maxListeners = _Emitter.defaultMaxListeners;
		this.hasWarnedAboutPotentialMemoryLeak = false;
	}
	_emitInternalEvent(internalEventName, eventName, listener) {
		this.emit(internalEventName, ...[eventName, listener]);
	}
	_getListeners(eventName) {
		return Array.prototype.concat.apply([], this.events.get(eventName)) || [];
	}
	_removeListener(listeners, listener) {
		const index = listeners.indexOf(listener);
		if (index > -1) listeners.splice(index, 1);
		return [];
	}
	_wrapOnceListener(eventName, listener) {
		const onceListener = (...data) => {
			this.removeListener(eventName, onceListener);
			return listener.apply(this, data);
		};
		Object.defineProperty(onceListener, "name", { value: listener.name });
		return onceListener;
	}
	setMaxListeners(maxListeners) {
		this.maxListeners = maxListeners;
		return this;
	}
	/**
	* Returns the current max listener value for the `Emitter` which is
	* either set by `emitter.setMaxListeners(n)` or defaults to
	* `Emitter.defaultMaxListeners`.
	*/
	getMaxListeners() {
		return this.maxListeners;
	}
	/**
	* Returns an array listing the events for which the emitter has registered listeners.
	* The values in the array will be strings or Symbols.
	*/
	eventNames() {
		return Array.from(this.events.keys());
	}
	/**
	* Synchronously calls each of the listeners registered for the event named `eventName`,
	* in the order they were registered, passing the supplied arguments to each.
	* Returns `true` if the event has listeners, `false` otherwise.
	*
	* @example
	* const emitter = new Emitter<{ hello: [string] }>()
	* emitter.emit('hello', 'John')
	*/
	emit(eventName, ...data) {
		const listeners = this._getListeners(eventName);
		listeners.forEach((listener) => {
			listener.apply(this, data);
		});
		return listeners.length > 0;
	}
	addListener(eventName, listener) {
		this._emitInternalEvent("newListener", eventName, listener);
		const nextListeners = this._getListeners(eventName).concat(listener);
		this.events.set(eventName, nextListeners);
		if (this.maxListeners > 0 && this.listenerCount(eventName) > this.maxListeners && !this.hasWarnedAboutPotentialMemoryLeak) {
			this.hasWarnedAboutPotentialMemoryLeak = true;
			const memoryLeakWarning = new MemoryLeakError(this, eventName, this.listenerCount(eventName));
			console.warn(memoryLeakWarning);
		}
		return this;
	}
	on(eventName, listener) {
		return this.addListener(eventName, listener);
	}
	once(eventName, listener) {
		return this.addListener(eventName, this._wrapOnceListener(eventName, listener));
	}
	prependListener(eventName, listener) {
		const listeners = this._getListeners(eventName);
		if (listeners.length > 0) {
			const nextListeners = [listener].concat(listeners);
			this.events.set(eventName, nextListeners);
		} else this.events.set(eventName, listeners.concat(listener));
		return this;
	}
	prependOnceListener(eventName, listener) {
		return this.prependListener(eventName, this._wrapOnceListener(eventName, listener));
	}
	removeListener(eventName, listener) {
		const listeners = this._getListeners(eventName);
		if (listeners.length > 0) {
			this._removeListener(listeners, listener);
			this.events.set(eventName, listeners);
			this._emitInternalEvent("removeListener", eventName, listener);
		}
		return this;
	}
	/**
	* Alias for `emitter.removeListener()`.
	*
	* @example
	* emitter.off('hello', listener)
	*/
	off(eventName, listener) {
		return this.removeListener(eventName, listener);
	}
	removeAllListeners(eventName) {
		if (eventName) this.events.delete(eventName);
		else this.events.clear();
		return this;
	}
	/**
	* Returns a copy of the array of listeners for the event named `eventName`.
	*/
	listeners(eventName) {
		return Array.from(this._getListeners(eventName));
	}
	/**
	* Returns the number of listeners listening to the event named `eventName`.
	*/
	listenerCount(eventName) {
		return this._getListeners(eventName).length;
	}
	rawListeners(eventName) {
		return this.listeners(eventName);
	}
};
var Emitter = _Emitter;
Emitter.defaultMaxListeners = 10;
var INTERNAL_REQUEST_ID_HEADER_NAME = "x-interceptors-internal-request-id";
function getGlobalSymbol(symbol) {
	return globalThis[symbol] || void 0;
}
function setGlobalSymbol(symbol, value) {
	globalThis[symbol] = value;
}
function deleteGlobalSymbol(symbol) {
	delete globalThis[symbol];
}
var InterceptorReadyState = /* @__PURE__ */ (function(InterceptorReadyState$1) {
	InterceptorReadyState$1["INACTIVE"] = "INACTIVE";
	InterceptorReadyState$1["APPLYING"] = "APPLYING";
	InterceptorReadyState$1["APPLIED"] = "APPLIED";
	InterceptorReadyState$1["DISPOSING"] = "DISPOSING";
	InterceptorReadyState$1["DISPOSED"] = "DISPOSED";
	return InterceptorReadyState$1;
})({});
var Interceptor = class {
	constructor(symbol) {
		this.symbol = symbol;
		this.readyState = InterceptorReadyState.INACTIVE;
		this.emitter = new Emitter();
		this.subscriptions = [];
		this.logger = new Logger(symbol.description);
		this.emitter.setMaxListeners(0);
		this.logger.info("constructing the interceptor...");
	}
	/**
	* Determine if this interceptor can be applied
	* in the current environment.
	*/
	checkEnvironment() {
		return true;
	}
	/**
	* Apply this interceptor to the current process.
	* Returns an already running interceptor instance if it's present.
	*/
	apply() {
		const logger = this.logger.extend("apply");
		logger.info("applying the interceptor...");
		if (this.readyState === InterceptorReadyState.APPLIED) {
			logger.info("intercepted already applied!");
			return;
		}
		if (!this.checkEnvironment()) {
			logger.info("the interceptor cannot be applied in this environment!");
			return;
		}
		this.readyState = InterceptorReadyState.APPLYING;
		const runningInstance = this.getInstance();
		if (runningInstance) {
			logger.info("found a running instance, reusing...");
			this.on = (event, listener) => {
				logger.info("proxying the \"%s\" listener", event);
				runningInstance.emitter.addListener(event, listener);
				this.subscriptions.push(() => {
					runningInstance.emitter.removeListener(event, listener);
					logger.info("removed proxied \"%s\" listener!", event);
				});
				return this;
			};
			this.readyState = InterceptorReadyState.APPLIED;
			return;
		}
		logger.info("no running instance found, setting up a new instance...");
		this.setup();
		this.setInstance();
		this.readyState = InterceptorReadyState.APPLIED;
	}
	/**
	* Setup the module augments and stubs necessary for this interceptor.
	* This method is not run if there's a running interceptor instance
	* to prevent instantiating an interceptor multiple times.
	*/
	setup() {}
	/**
	* Listen to the interceptor's public events.
	*/
	on(event, listener) {
		const logger = this.logger.extend("on");
		if (this.readyState === InterceptorReadyState.DISPOSING || this.readyState === InterceptorReadyState.DISPOSED) {
			logger.info("cannot listen to events, already disposed!");
			return this;
		}
		logger.info("adding \"%s\" event listener:", event, listener);
		this.emitter.on(event, listener);
		return this;
	}
	once(event, listener) {
		this.emitter.once(event, listener);
		return this;
	}
	off(event, listener) {
		this.emitter.off(event, listener);
		return this;
	}
	removeAllListeners(event) {
		this.emitter.removeAllListeners(event);
		return this;
	}
	/**
	* Disposes of any side-effects this interceptor has introduced.
	*/
	dispose() {
		const logger = this.logger.extend("dispose");
		if (this.readyState === InterceptorReadyState.DISPOSED) {
			logger.info("cannot dispose, already disposed!");
			return;
		}
		logger.info("disposing the interceptor...");
		this.readyState = InterceptorReadyState.DISPOSING;
		if (!this.getInstance()) {
			logger.info("no interceptors running, skipping dispose...");
			return;
		}
		this.clearInstance();
		logger.info("global symbol deleted:", getGlobalSymbol(this.symbol));
		if (this.subscriptions.length > 0) {
			logger.info("disposing of %d subscriptions...", this.subscriptions.length);
			for (const dispose of this.subscriptions) dispose();
			this.subscriptions = [];
			logger.info("disposed of all subscriptions!", this.subscriptions.length);
		}
		this.emitter.removeAllListeners();
		logger.info("destroyed the listener!");
		this.readyState = InterceptorReadyState.DISPOSED;
	}
	getInstance() {
		const instance = getGlobalSymbol(this.symbol);
		this.logger.info("retrieved global instance:", instance?.constructor?.name);
		return instance;
	}
	setInstance() {
		setGlobalSymbol(this.symbol, this);
		this.logger.info("set global instance!", this.symbol.description);
	}
	clearInstance() {
		deleteGlobalSymbol(this.symbol);
		this.logger.info("cleared global instance!", this.symbol.description);
	}
};
function createRequestId() {
	return Math.random().toString(16).slice(2);
}
function resolveWebSocketUrl(url) {
	if (typeof url === "string") return resolveWebSocketUrl(new URL(url, typeof location !== "undefined" ? location.href : void 0));
	if (url.protocol === "http:") url.protocol = "ws:";
	else if (url.protocol === "https:") url.protocol = "wss:";
	if (url.protocol !== "ws:" && url.protocol !== "wss:") throw new SyntaxError(`Failed to construct 'WebSocket': The URL's scheme must be either 'http', 'https', 'ws', or 'wss'. '${url.protocol}' is not allowed.`);
	if (url.hash !== "") throw new SyntaxError(`Failed to construct 'WebSocket': The URL contains a fragment identifier ('${url.hash}'). Fragment identifiers are not allowed in WebSocket URLs.`);
	return url.href;
}
async function emitAsync(emitter, eventName, ...data) {
	const listeners = emitter.listeners(eventName);
	if (listeners.length === 0) return;
	for (const listener of listeners) await listener.apply(emitter, data);
}
var PatchesRegistry = class {
	#replacements = /* @__PURE__ */ new Map();
	applyPatch(owner, key, getNextValue) {
		const ownerReplacements = this.#replacements.get(owner);
		invariant(!ownerReplacements?.has(key), `Failed to replace a global value at "${String(key)}": already replaced.`);
		const match = getDeepPropertyDescriptor(owner, key);
		if (typeof match === "undefined") {
			console.warn(`Failed to replace a global value at "${String(key)}": not a global value.`);
			return () => {};
		}
		if (match.descriptor.configurable) Object.defineProperty(owner, key, {
			value: getNextValue(owner[key]),
			enumerable: true,
			configurable: true
		});
		else if (match.descriptor.writable) owner[key] = getNextValue(owner[key]);
		else throw new Error(`Failed to patch a non-configurable non-writable property "${key.toString()}"`);
		const restorePatch = () => {
			const currentReplacements = this.#replacements.get(owner);
			if (!currentReplacements?.has(key)) return;
			if (match.owner === owner) Object.defineProperty(match.owner, key, match.descriptor);
			else Reflect.deleteProperty(owner, key);
			currentReplacements.delete(key);
			if (currentReplacements.size === 0) this.#replacements.delete(owner);
		};
		if (ownerReplacements) ownerReplacements.set(key, restorePatch);
		else this.#replacements.set(owner, /* @__PURE__ */ new Map([[key, restorePatch]]));
		return restorePatch;
	}
	restoreAllPatches() {
		const errors = [];
		for (const [, ownerReplacements] of this.#replacements) for (const [, restorePatch] of ownerReplacements) try {
			restorePatch();
		} catch (error2) {
			if (error2 instanceof Error) errors.push(error2);
			else throw error2;
		}
		if (errors.length > 0) throw new AggregateError(errors, "FOO!");
	}
};
var patchesRegistry = new PatchesRegistry();
function getDeepPropertyDescriptor(owner, key) {
	let currentOwner = owner;
	let descriptor;
	while (currentOwner) {
		descriptor = Object.getOwnPropertyDescriptor(currentOwner, key);
		if (descriptor) return {
			owner: currentOwner,
			descriptor
		};
		currentOwner = Object.getPrototypeOf(currentOwner);
	}
}
function hasConfigurableGlobal(propertyName) {
	const match = getDeepPropertyDescriptor(globalThis, propertyName);
	if (typeof match === "undefined") return false;
	const { descriptor } = match;
	if (typeof descriptor.get === "function" && typeof descriptor.get() === "undefined") return false;
	if (typeof descriptor.get === "undefined" && descriptor.value == null) return false;
	if (typeof descriptor.set === "undefined" && !descriptor.configurable) {
		console.error(`[MSW] Failed to apply interceptor: the global \`${propertyName}\` property is non-configurable. This is likely an issue with your environment. If you are using a framework, please open an issue about this in their repository.`);
		return false;
	}
	return true;
}
function createDeferredExecutor() {
	const executor = (resolve, reject) => {
		executor.state = "pending";
		executor.resolve = (data) => {
			if (executor.state !== "pending") return;
			executor.result = data;
			const onFulfilled = (value) => {
				executor.state = "fulfilled";
				return value;
			};
			return resolve(data instanceof Promise ? data : Promise.resolve(data).then(onFulfilled));
		};
		executor.reject = (reason) => {
			if (executor.state !== "pending") return;
			queueMicrotask(() => {
				executor.state = "rejected";
			});
			return reject(executor.rejectionReason = reason);
		};
	};
	return executor;
}
var DeferredPromise = class extends Promise {
	#executor;
	resolve;
	reject;
	constructor(executor = null) {
		const deferredExecutor = createDeferredExecutor();
		super((originalResolve, originalReject) => {
			deferredExecutor(originalResolve, originalReject);
			executor?.(deferredExecutor.resolve, deferredExecutor.reject);
		});
		this.#executor = deferredExecutor;
		this.resolve = this.#executor.resolve;
		this.reject = this.#executor.reject;
	}
	get state() {
		return this.#executor.state;
	}
	get rejectionReason() {
		return this.#executor.rejectionReason;
	}
	then(onFulfilled, onRejected) {
		return this.#decorate(super.then(onFulfilled, onRejected));
	}
	catch(onRejected) {
		return this.#decorate(super.catch(onRejected));
	}
	finally(onfinally) {
		return this.#decorate(super.finally(onfinally));
	}
	#decorate(promise) {
		return Object.defineProperties(promise, {
			resolve: {
				configurable: true,
				value: this.resolve
			},
			reject: {
				configurable: true,
				value: this.reject
			}
		});
	}
};
function bindEvent(target, event) {
	Object.defineProperties(event, {
		target: {
			value: target,
			enumerable: true,
			writable: true
		},
		currentTarget: {
			value: target,
			enumerable: true,
			writable: true
		}
	});
	return event;
}
var kCancelable = /* @__PURE__ */ Symbol("kCancelable");
var kDefaultPrevented = /* @__PURE__ */ Symbol("kDefaultPrevented");
var CancelableMessageEvent = class extends MessageEvent {
	constructor(type, init) {
		super(type, init);
		this[kCancelable] = !!init.cancelable;
		this[kDefaultPrevented] = false;
	}
	get cancelable() {
		return this[kCancelable];
	}
	set cancelable(nextCancelable) {
		this[kCancelable] = nextCancelable;
	}
	get defaultPrevented() {
		return this[kDefaultPrevented];
	}
	set defaultPrevented(nextDefaultPrevented) {
		this[kDefaultPrevented] = nextDefaultPrevented;
	}
	preventDefault() {
		if (this.cancelable && !this[kDefaultPrevented]) this[kDefaultPrevented] = true;
	}
};
var CloseEvent = class extends Event {
	constructor(type, init = {}) {
		super(type, init);
		this.code = init.code === void 0 ? 0 : init.code;
		this.reason = init.reason === void 0 ? "" : init.reason;
		this.wasClean = init.wasClean === void 0 ? false : init.wasClean;
	}
};
var CancelableCloseEvent = class extends CloseEvent {
	constructor(type, init = {}) {
		super(type, init);
		this[kCancelable] = !!init.cancelable;
		this[kDefaultPrevented] = false;
	}
	get cancelable() {
		return this[kCancelable];
	}
	set cancelable(nextCancelable) {
		this[kCancelable] = nextCancelable;
	}
	get defaultPrevented() {
		return this[kDefaultPrevented];
	}
	set defaultPrevented(nextDefaultPrevented) {
		this[kDefaultPrevented] = nextDefaultPrevented;
	}
	preventDefault() {
		if (this.cancelable && !this[kDefaultPrevented]) this[kDefaultPrevented] = true;
	}
};
var kEmitter$1 = /* @__PURE__ */ Symbol("kEmitter");
var kBoundListener$1 = /* @__PURE__ */ Symbol("kBoundListener");
var WebSocketClientConnection = class {
	constructor(socket, transport) {
		this.socket = socket;
		this.transport = transport;
		this.id = createRequestId();
		this.url = new URL(socket.url);
		this[kEmitter$1] = new EventTarget();
		this.transport.addEventListener("outgoing", (event) => {
			const message = bindEvent(this.socket, new CancelableMessageEvent("message", {
				data: event.data,
				origin: event.origin,
				cancelable: true
			}));
			this[kEmitter$1].dispatchEvent(message);
			if (message.defaultPrevented) event.preventDefault();
		});
		this.transport.addEventListener("close", (event) => {
			this[kEmitter$1].dispatchEvent(bindEvent(this.socket, new CloseEvent("close", event)));
		});
	}
	/**
	* Listen for the outgoing events from the connected WebSocket client.
	*/
	addEventListener(type, listener, options) {
		if (!Reflect.has(listener, kBoundListener$1)) {
			const boundListener = listener.bind(this.socket);
			Object.defineProperty(listener, kBoundListener$1, {
				value: boundListener,
				enumerable: false,
				configurable: false
			});
		}
		this[kEmitter$1].addEventListener(type, Reflect.get(listener, kBoundListener$1), options);
	}
	/**
	* Removes the listener for the given event.
	*/
	removeEventListener(event, listener, options) {
		this[kEmitter$1].removeEventListener(event, Reflect.get(listener, kBoundListener$1), options);
	}
	/**
	* Send data to the connected client.
	*/
	send(data) {
		this.transport.send(data);
	}
	/**
	* Close the WebSocket connection.
	* @param {number} code A status code (see https://www.rfc-editor.org/rfc/rfc6455#section-7.4.1).
	* @param {string} reason A custom connection close reason.
	*/
	close(code, reason) {
		this.transport.close(code, reason);
	}
};
var WEBSOCKET_CLOSE_CODE_RANGE_ERROR = "InvalidAccessError: close code out of user configurable range";
var kPassthroughPromise = /* @__PURE__ */ Symbol("kPassthroughPromise");
var kOnSend = /* @__PURE__ */ Symbol("kOnSend");
var kClose = /* @__PURE__ */ Symbol("kClose");
var WebSocketOverride = class extends EventTarget {
	static {
		this.CONNECTING = 0;
	}
	static {
		this.OPEN = 1;
	}
	static {
		this.CLOSING = 2;
	}
	static {
		this.CLOSED = 3;
	}
	constructor(url, protocols) {
		super();
		this.CONNECTING = 0;
		this.OPEN = 1;
		this.CLOSING = 2;
		this.CLOSED = 3;
		this._onopen = null;
		this._onmessage = null;
		this._onerror = null;
		this._onclose = null;
		this.url = resolveWebSocketUrl(url);
		this.protocol = "";
		this.extensions = "";
		this.binaryType = "blob";
		this.readyState = this.CONNECTING;
		this.bufferedAmount = 0;
		this[kPassthroughPromise] = new DeferredPromise();
		queueMicrotask(async () => {
			if (await this[kPassthroughPromise]) return;
			this.protocol = typeof protocols === "string" ? protocols : Array.isArray(protocols) && protocols.length > 0 ? protocols[0] : "";
			if (this.readyState === this.CONNECTING) {
				this.readyState = this.OPEN;
				this.dispatchEvent(bindEvent(this, new Event("open")));
			}
		});
	}
	set onopen(listener) {
		this.removeEventListener("open", this._onopen);
		this._onopen = listener;
		if (listener !== null) this.addEventListener("open", listener);
	}
	get onopen() {
		return this._onopen;
	}
	set onmessage(listener) {
		this.removeEventListener("message", this._onmessage);
		this._onmessage = listener;
		if (listener !== null) this.addEventListener("message", listener);
	}
	get onmessage() {
		return this._onmessage;
	}
	set onerror(listener) {
		this.removeEventListener("error", this._onerror);
		this._onerror = listener;
		if (listener !== null) this.addEventListener("error", listener);
	}
	get onerror() {
		return this._onerror;
	}
	set onclose(listener) {
		this.removeEventListener("close", this._onclose);
		this._onclose = listener;
		if (listener !== null) this.addEventListener("close", listener);
	}
	get onclose() {
		return this._onclose;
	}
	/**
	* @see https://websockets.spec.whatwg.org/#ref-for-dom-websocket-send%E2%91%A0
	*/
	send(data) {
		if (this.readyState === this.CONNECTING) {
			this.close();
			throw new DOMException("InvalidStateError");
		}
		if (this.readyState === this.CLOSING || this.readyState === this.CLOSED) return;
		this.bufferedAmount += getDataSize(data);
		queueMicrotask(() => {
			this.bufferedAmount = 0;
			this[kOnSend]?.(data);
		});
	}
	close(code = 1e3, reason) {
		invariant(code, WEBSOCKET_CLOSE_CODE_RANGE_ERROR);
		invariant(code === 1e3 || code >= 3e3 && code <= 4999, WEBSOCKET_CLOSE_CODE_RANGE_ERROR);
		this[kClose](code, reason);
	}
	[kClose](code = 1e3, reason, wasClean = true) {
		if (this.readyState === this.CLOSING || this.readyState === this.CLOSED) return;
		this.readyState = this.CLOSING;
		queueMicrotask(() => {
			this.readyState = this.CLOSED;
			this.dispatchEvent(bindEvent(this, new CloseEvent("close", {
				code,
				reason,
				wasClean
			})));
			this._onopen = null;
			this._onmessage = null;
			this._onerror = null;
			this._onclose = null;
		});
	}
	addEventListener(type, listener, options) {
		return super.addEventListener(type, listener, options);
	}
	removeEventListener(type, callback, options) {
		return super.removeEventListener(type, callback, options);
	}
};
function getDataSize(data) {
	if (typeof data === "string") return data.length;
	if (data instanceof Blob) return data.size;
	return data.byteLength;
}
var kEmitter = /* @__PURE__ */ Symbol("kEmitter");
var kBoundListener = /* @__PURE__ */ Symbol("kBoundListener");
var kSend = /* @__PURE__ */ Symbol("kSend");
var WebSocketServerConnection = class {
	constructor(client, transport, createConnection) {
		this.client = client;
		this.transport = transport;
		this.createConnection = createConnection;
		this[kEmitter] = new EventTarget();
		this.mockCloseController = new AbortController();
		this.realCloseController = new AbortController();
		this.transport.addEventListener("outgoing", (event) => {
			if (typeof this.realWebSocket === "undefined") return;
			queueMicrotask(() => {
				if (!event.defaultPrevented) this[kSend](event.data);
			});
		});
		this.transport.addEventListener("incoming", this.handleIncomingMessage.bind(this));
	}
	/**
	* The `WebSocket` instance connected to the original server.
	* Accessing this before calling `server.connect()` will throw.
	*/
	get socket() {
		invariant(this.realWebSocket, "Cannot access \"socket\" on the original WebSocket server object: the connection is not open. Did you forget to call `server.connect()`?");
		return this.realWebSocket;
	}
	/**
	* Open connection to the original WebSocket server.
	*/
	connect() {
		invariant(!this.realWebSocket || this.realWebSocket.readyState !== WebSocket.OPEN, "Failed to call \"connect()\" on the original WebSocket instance: the connection already open");
		const realWebSocket = this.createConnection();
		realWebSocket.binaryType = this.client.binaryType;
		realWebSocket.addEventListener("open", (event) => {
			this[kEmitter].dispatchEvent(bindEvent(this.realWebSocket, new Event("open", event)));
		}, { once: true });
		realWebSocket.addEventListener("message", (event) => {
			this.transport.dispatchEvent(bindEvent(this.realWebSocket, new MessageEvent("incoming", {
				data: event.data,
				origin: event.origin
			})));
		});
		this.client.addEventListener("close", (event) => {
			this.handleMockClose(event);
		}, { signal: this.mockCloseController.signal });
		realWebSocket.addEventListener("close", (event) => {
			this.handleRealClose(event);
		}, { signal: this.realCloseController.signal });
		realWebSocket.addEventListener("error", () => {
			const errorEvent = bindEvent(realWebSocket, new Event("error", { cancelable: true }));
			this[kEmitter].dispatchEvent(errorEvent);
			if (!errorEvent.defaultPrevented) this.client.dispatchEvent(bindEvent(this.client, new Event("error")));
		});
		this.realWebSocket = realWebSocket;
	}
	/**
	* Listen for the incoming events from the original WebSocket server.
	*/
	addEventListener(event, listener, options) {
		if (!Reflect.has(listener, kBoundListener)) {
			const boundListener = listener.bind(this.client);
			Object.defineProperty(listener, kBoundListener, {
				value: boundListener,
				enumerable: false
			});
		}
		this[kEmitter].addEventListener(event, Reflect.get(listener, kBoundListener), options);
	}
	/**
	* Remove the listener for the given event.
	*/
	removeEventListener(event, listener, options) {
		this[kEmitter].removeEventListener(event, Reflect.get(listener, kBoundListener), options);
	}
	/**
	* Send data to the original WebSocket server.
	* @example
	* server.send('hello')
	* server.send(new Blob(['hello']))
	* server.send(new TextEncoder().encode('hello'))
	*/
	send(data) {
		this[kSend](data);
	}
	[kSend](data) {
		const { realWebSocket } = this;
		invariant(realWebSocket, "Failed to call \"server.send()\" for \"%s\": the connection is not open. Did you forget to call \"server.connect()\"?", this.client.url);
		if (realWebSocket.readyState === WebSocket.CLOSING || realWebSocket.readyState === WebSocket.CLOSED) return;
		if (realWebSocket.readyState === WebSocket.CONNECTING) {
			realWebSocket.addEventListener("open", () => {
				realWebSocket.send(data);
			}, { once: true });
			return;
		}
		realWebSocket.send(data);
	}
	/**
	* Close the actual server connection.
	*/
	close() {
		const { realWebSocket } = this;
		invariant(realWebSocket, "Failed to close server connection for \"%s\": the connection is not open. Did you forget to call \"server.connect()\"?", this.client.url);
		this.realCloseController.abort();
		if (realWebSocket.readyState === WebSocket.CLOSING || realWebSocket.readyState === WebSocket.CLOSED) return;
		realWebSocket.close();
		queueMicrotask(() => {
			this[kEmitter].dispatchEvent(bindEvent(this.realWebSocket, new CancelableCloseEvent("close", {
				code: 1e3,
				cancelable: true
			})));
		});
	}
	handleIncomingMessage(event) {
		const messageEvent = bindEvent(event.target, new CancelableMessageEvent("message", {
			data: event.data,
			origin: event.origin,
			cancelable: true
		}));
		this[kEmitter].dispatchEvent(messageEvent);
		if (!messageEvent.defaultPrevented) this.client.dispatchEvent(bindEvent(
			/**
			* @note Bind the forwarded original server events
			* to the mock WebSocket instance so it would
			* dispatch them straight away.
			*/
			this.client,
			new MessageEvent("message", {
				data: event.data,
				origin: event.origin
			})
		));
	}
	handleMockClose(_event) {
		if (this.realWebSocket) this.realWebSocket.close();
	}
	handleRealClose(event) {
		this.mockCloseController.abort();
		const closeEvent = bindEvent(this.realWebSocket, new CancelableCloseEvent("close", {
			code: event.code,
			reason: event.reason,
			wasClean: event.wasClean,
			cancelable: true
		}));
		this[kEmitter].dispatchEvent(closeEvent);
		if (!closeEvent.defaultPrevented) this.client[kClose](event.code, event.reason);
	}
};
var WebSocketClassTransport = class extends EventTarget {
	constructor(socket) {
		super();
		this.socket = socket;
		this.socket.addEventListener("close", (event) => {
			this.dispatchEvent(bindEvent(this.socket, new CloseEvent("close", event)));
		});
		this.socket[kOnSend] = (data) => {
			this.dispatchEvent(bindEvent(this.socket, new CancelableMessageEvent("outgoing", {
				data,
				origin: this.socket.url,
				cancelable: true
			})));
		};
	}
	addEventListener(type, callback, options) {
		return super.addEventListener(type, callback, options);
	}
	dispatchEvent(event) {
		return super.dispatchEvent(event);
	}
	send(data) {
		queueMicrotask(() => {
			if (this.socket.readyState === this.socket.CLOSING || this.socket.readyState === this.socket.CLOSED) return;
			const dispatchEvent = () => {
				this.socket.dispatchEvent(bindEvent(
					/**
					* @note Setting this event's "target" to the
					* WebSocket override instance is important.
					* This way it can tell apart original incoming events
					* (must be forwarded to the transport) from the
					* mocked message events like the one below
					* (must be dispatched on the client instance).
					*/
					this.socket,
					new MessageEvent("message", {
						data,
						origin: this.socket.url
					})
				));
			};
			if (this.socket.readyState === this.socket.CONNECTING) this.socket.addEventListener("open", () => {
				dispatchEvent();
			}, { once: true });
			else dispatchEvent();
		});
	}
	close(code, reason) {
		this.socket[kClose](code, reason);
	}
};
var WebSocketInterceptor = class WebSocketInterceptor2 extends Interceptor {
	static {
		this.symbol = /* @__PURE__ */ Symbol.for("websocket-interceptor");
	}
	constructor() {
		super(WebSocketInterceptor2.symbol);
	}
	checkEnvironment() {
		return hasConfigurableGlobal("WebSocket");
	}
	setup() {
		const logger = this.logger.extend("setup");
		const WebSocketProxy = new Proxy(globalThis.WebSocket, { construct: (target, args, newTarget) => {
			const [url, protocols] = args;
			const createConnection = () => {
				return Reflect.construct(target, args, newTarget);
			};
			const socket = new WebSocketOverride(url, protocols);
			const transport = new WebSocketClassTransport(socket);
			queueMicrotask(async () => {
				try {
					const server = new WebSocketServerConnection(socket, transport, createConnection);
					const hasConnectionListeners = this.emitter.listenerCount("connection") > 0;
					await emitAsync(this.emitter, "connection", {
						client: new WebSocketClientConnection(socket, transport),
						server,
						info: { protocols }
					});
					if (hasConnectionListeners) socket[kPassthroughPromise].resolve(false);
					else {
						socket[kPassthroughPromise].resolve(true);
						server.connect();
						server.addEventListener("open", () => {
							socket.dispatchEvent(bindEvent(socket, new Event("open")));
							if (server["realWebSocket"]) socket.protocol = server["realWebSocket"].protocol;
						});
					}
				} catch (error2) {
					if (error2 instanceof Error) {
						socket.dispatchEvent(new Event("error"));
						if (socket.readyState !== WebSocket.CLOSING && socket.readyState !== WebSocket.CLOSED) socket[kClose](1011, error2.message, false);
						console.error(error2);
					}
				}
			});
			return socket;
		} });
		logger.info("patching global WebSocket...");
		this.subscriptions.push(patchesRegistry.applyPatch(globalThis, "WebSocket", () => WebSocketProxy));
		logger.info("global WebSocket patched!", globalThis.WebSocket.name);
	}
};
function supportsServiceWorker() {
	return typeof navigator !== "undefined" && "serviceWorker" in navigator && typeof location !== "undefined" && location.protocol !== "file:";
}
function supportsReadableStreamTransfer() {
	try {
		const stream = new ReadableStream({ start: (controller) => controller.close() });
		new MessageChannel().port1.postMessage(stream, [stream]);
		return true;
	} catch {
		return false;
	}
}
function createDeferredExecutor2() {
	const executor = ((resolve, reject) => {
		executor.state = "pending";
		executor.resolve = (data) => {
			if (executor.state !== "pending") return;
			executor.result = data;
			const onFulfilled = (value) => {
				executor.state = "fulfilled";
				return value;
			};
			return resolve(data instanceof Promise ? data : Promise.resolve(data).then(onFulfilled));
		};
		executor.reject = (reason) => {
			if (executor.state !== "pending") return;
			queueMicrotask(() => {
				executor.state = "rejected";
			});
			return reject(executor.rejectionReason = reason);
		};
	});
	return executor;
}
var DeferredPromise2 = class extends Promise {
	#executor;
	resolve;
	reject;
	constructor(executor = null) {
		const deferredExecutor = createDeferredExecutor2();
		super((originalResolve, originalReject) => {
			deferredExecutor(originalResolve, originalReject);
			executor?.(deferredExecutor.resolve, deferredExecutor.reject);
		});
		this.#executor = deferredExecutor;
		this.resolve = this.#executor.resolve;
		this.reject = this.#executor.reject;
	}
	get state() {
		return this.#executor.state;
	}
	get rejectionReason() {
		return this.#executor.rejectionReason;
	}
	then(onFulfilled, onRejected) {
		return this.#decorate(super.then(onFulfilled, onRejected));
	}
	catch(onRejected) {
		return this.#decorate(super.catch(onRejected));
	}
	finally(onfinally) {
		return this.#decorate(super.finally(onfinally));
	}
	#decorate(promise) {
		return Object.defineProperties(promise, {
			resolve: {
				configurable: true,
				value: this.resolve
			},
			reject: {
				configurable: true,
				value: this.reject
			}
		});
	}
};
var InterceptorError = class InterceptorError2 extends Error {
	constructor(message) {
		super(message);
		this.name = "InterceptorError";
		Object.setPrototypeOf(this, InterceptorError2.prototype);
	}
};
var RequestController = class RequestController2 {
	static {
		this.PENDING = 0;
	}
	static {
		this.PASSTHROUGH = 1;
	}
	static {
		this.RESPONSE = 2;
	}
	static {
		this.ERROR = 3;
	}
	constructor(request, source) {
		this.request = request;
		this.source = source;
		this.readyState = RequestController2.PENDING;
		this.handled = new DeferredPromise();
	}
	get #handled() {
		return this.handled;
	}
	/**
	* Perform this request as-is.
	*/
	async passthrough() {
		invariant.as(InterceptorError, this.readyState === RequestController2.PENDING, "Failed to passthrough the \"%s %s\" request: the request has already been handled", this.request.method, this.request.url);
		this.readyState = RequestController2.PASSTHROUGH;
		await this.source.passthrough();
		this.#handled.resolve();
	}
	/**
	* Respond to this request with the given `Response` instance.
	*
	* @example
	* controller.respondWith(new Response())
	* controller.respondWith(Response.json({ id }))
	* controller.respondWith(Response.error())
	*/
	respondWith(response) {
		invariant.as(InterceptorError, this.readyState === RequestController2.PENDING, "Failed to respond to the \"%s %s\" request with \"%d %s\": the request has already been handled (%d)", this.request.method, this.request.url, response.status, response.statusText || "OK", this.readyState);
		this.readyState = RequestController2.RESPONSE;
		this.#handled.resolve();
		this.source.respondWith(response);
	}
	/**
	* Error this request with the given reason.
	*
	* @example
	* controller.errorWith()
	* controller.errorWith(new Error('Oops!'))
	* controller.errorWith({ message: 'Oops!'})
	*/
	errorWith(reason) {
		invariant.as(InterceptorError, this.readyState === RequestController2.PENDING, "Failed to error the \"%s %s\" request with \"%s\": the request has already been handled (%d)", this.request.method, this.request.url, reason?.toString(), this.readyState);
		this.readyState = RequestController2.ERROR;
		this.source.errorWith(reason);
		this.#handled.resolve();
	}
};
function canParseUrl(url) {
	try {
		new URL(url);
		return true;
	} catch (_error) {
		return false;
	}
}
function getValueBySymbol(symbolName, source) {
	const symbol = Object.getOwnPropertySymbols(source).find((symbol$1) => {
		return symbol$1.description === symbolName;
	});
	if (symbol) return Reflect.get(source, symbol);
}
var FetchRequest = class FetchRequest2 extends Request {
	static #resolveProperty(input, init = {}, key) {
		return init[key] ?? (input instanceof Request ? input[key] : void 0);
	}
	/**
	* Check if the given request method is configurable.
	* @see https://fetch.spec.whatwg.org/#methods
	*/
	static isConfigurableMethod(method) {
		return method !== "CONNECT" && method !== "TRACE" && method !== "TRACK";
	}
	static isMethodWithBody(method) {
		return method !== "HEAD" && method !== "GET" && FetchRequest2.isConfigurableMethod(method);
	}
	/**
	* Check if the given request `mode` is configurable.
	* @see https://fetch.spec.whatwg.org/#concept-request-mode
	*/
	static isConfigurableMode(mode) {
		return mode !== "navigate" && mode !== "websocket" && mode !== "webtransport";
	}
	constructor(input, init) {
		const method = FetchRequest2.#resolveProperty(input, init, "method") || "GET";
		const safeMethod = FetchRequest2.isConfigurableMethod(method) ? method : "GET";
		const hasExplicitBody = init != null && "body" in init;
		const bodyInit = !FetchRequest2.isMethodWithBody(method) ? { body: void 0 } : hasExplicitBody ? { body: init.body } : {};
		const mode = FetchRequest2.#resolveProperty(input, init, "mode") ?? void 0;
		const safeMode = FetchRequest2.isConfigurableMode(mode) ? mode : void 0;
		super(input, {
			...init || {},
			method: safeMethod,
			mode: safeMode,
			duplex: init?.duplex ?? (FetchRequest2.isMethodWithBody(method) ? "half" : void 0),
			...bodyInit
		});
		if (method !== safeMethod) this.#setInternalProperty("method", method);
		if (method === "CONNECT") {
			const url = new URL(input instanceof Request ? input.url : input);
			let authority;
			if (url.protocol === "localhost:") authority = url.href;
			else authority = url.pathname.replace(/^\/+/, "");
			Object.defineProperty(this, "url", {
				get: () => authority,
				enumerable: true,
				configurable: true
			});
		}
		if (mode != null && mode !== safeMode) this.#setInternalProperty("mode", mode);
	}
	#setInternalProperty(key, value) {
		const internalState = getValueBySymbol("state", this);
		if (internalState) Reflect.set(internalState, key, value);
		else Object.defineProperty(this, key, {
			value,
			enumerable: true,
			configurable: true,
			writable: false
		});
	}
};
var kStatus = /* @__PURE__ */ Symbol("kStatus");
var kUrl = /* @__PURE__ */ Symbol("kUrl");
var FetchResponse = class FetchResponse2 extends Response {
	static {
		this.STATUS_CODES_WITHOUT_BODY = [
			101,
			103,
			204,
			205,
			304
		];
	}
	static {
		this.STATUS_CODES_WITH_REDIRECT = [
			301,
			302,
			303,
			307,
			308
		];
	}
	static isConfigurableStatusCode(status) {
		return status >= 200 && status <= 599;
	}
	static isRedirectResponse(status) {
		return FetchResponse2.STATUS_CODES_WITH_REDIRECT.includes(status);
	}
	/**
	* Returns a boolean indicating whether the given response status
	* code represents a response that can have a body.
	*/
	static isResponseWithBody(status) {
		return !FetchResponse2.STATUS_CODES_WITHOUT_BODY.includes(status);
	}
	static setStatus(status, response) {
		const internalState = getValueBySymbol("state", response);
		if (internalState) internalState.status = status;
		else Object.defineProperty(response, "status", {
			value: status,
			enumerable: true,
			configurable: true,
			writable: false
		});
		Object.defineProperty(response, kStatus, {
			value: status,
			enumerable: false
		});
	}
	static setUrl(url, response) {
		if (!url || url === "about:" || !canParseUrl(url)) return;
		const state = getValueBySymbol("state", response);
		if (state) state.urlList.push(new URL(url));
		else Object.defineProperty(response, "url", {
			value: url,
			enumerable: true,
			configurable: true,
			writable: false
		});
		Object.defineProperty(response, kUrl, {
			value: url,
			enumerable: false
		});
	}
	/**
	* Parses the given raw HTTP headers into a Fetch API `Headers` instance.
	*/
	static parseRawHeaders(rawHeaders) {
		const headers = new Headers();
		for (let line = 0; line < rawHeaders.length; line += 2) headers.append(rawHeaders[line], rawHeaders[line + 1]);
		return headers;
	}
	/**
	* Safely clones the given `Response`.
	* Coerces response clone exceptions into 500 mocked responses.
	* Handy in the environments that introduce arbitrary response
	* cloning restrictions, like "101 Switching Protocols" cloning
	* in "miniflare".
	*/
	static clone(response) {
		try {
			return response.clone();
		} catch (error2) {
			return Response.json(error2 instanceof Error ? {
				name: error2.name,
				message: error2.message,
				stack: error2.stack
			} : {}, {
				status: 500,
				statusText: "Unclonable Response"
			});
		}
	}
	constructor(body, init = {}) {
		const status = init.status ?? 200;
		const safeStatus = FetchResponse2.isConfigurableStatusCode(status) ? status : 200;
		const finalBody = FetchResponse2.isResponseWithBody(status) ? body : null;
		super(finalBody, {
			status: safeStatus,
			statusText: init.statusText,
			headers: init.headers
		});
		if (status !== safeStatus) FetchResponse2.setStatus(status, this);
		FetchResponse2.setUrl(init.url, this);
	}
	clone() {
		const clonedResponse = super.clone();
		const customStatus = Reflect.get(this, kStatus);
		if (customStatus) FetchResponse2.setStatus(customStatus, clonedResponse);
		const customUrl = Reflect.get(this, kUrl);
		if (customUrl) FetchResponse2.setUrl(customUrl, clonedResponse);
		return clonedResponse;
	}
};
var kRawRequest = /* @__PURE__ */ Symbol("kRawRequest");
function setRawRequest(request, rawRequest) {
	Reflect.set(request, kRawRequest, rawRequest);
}
var encoder = new TextEncoder();
function encodeBuffer(text) {
	return encoder.encode(text);
}
function decodeBuffer(buffer, encoding) {
	return new TextDecoder(encoding).decode(buffer);
}
function toArrayBuffer(array) {
	return array.buffer.slice(array.byteOffset, array.byteOffset + array.byteLength);
}
async function until(callback) {
	try {
		return [null, await callback().catch((error2) => {
			throw error2;
		})];
	} catch (error2) {
		return [error2, null];
	}
}
function getAbsoluteWorkerUrl(workerUrl) {
	return new URL(workerUrl, location.href).href;
}
function getWorkerByRegistration(registration, absoluteWorkerUrl, findWorker) {
	return [
		registration.active,
		registration.installing,
		registration.waiting
	].filter((state) => {
		return state != null;
	}).find((worker2) => {
		return findWorker(worker2.scriptURL, absoluteWorkerUrl);
	}) || null;
}
var getWorkerInstance = async (url, options = {}, findWorker) => {
	const absoluteWorkerUrl = getAbsoluteWorkerUrl(url);
	const mockRegistrations = await navigator.serviceWorker.getRegistrations().then((registrations) => registrations.filter((registration) => getWorkerByRegistration(registration, absoluteWorkerUrl, findWorker)));
	if (!navigator.serviceWorker.controller && mockRegistrations.length > 0) location.reload();
	const [existingRegistration] = mockRegistrations;
	if (existingRegistration) {
		existingRegistration.update();
		return [getWorkerByRegistration(existingRegistration, absoluteWorkerUrl, findWorker), existingRegistration];
	}
	const [registrationError, registrationResult] = await until(async () => {
		const registration = await navigator.serviceWorker.register(url, options);
		return [getWorkerByRegistration(registration, absoluteWorkerUrl, findWorker), registration];
	});
	if (registrationError) {
		if (registrationError.message.includes("(404)")) {
			const scopeUrl = new URL(options?.scope || "/", location.href);
			throw new Error(devUtils.formatMessage(`Failed to register a Service Worker for scope ('${scopeUrl.href}') with script ('${absoluteWorkerUrl}'): Service Worker script does not exist at the given path.

Did you forget to run "npx msw init <PUBLIC_DIR>"?

Learn more about creating the Service Worker script: https://mswjs.io/docs/cli/init`));
		}
		throw new Error(devUtils.formatMessage("Failed to register the Service Worker:\n\n%s", registrationError.message));
	}
	return registrationResult;
};
var LensList = class {
	#list;
	#lens;
	constructor() {
		this.#list = [];
		this.#lens = /* @__PURE__ */ new Map();
	}
	get [Symbol.iterator]() {
		return this.#list[Symbol.iterator].bind(this.#list);
	}
	entries() {
		return this.#lens.entries();
	}
	/**
	* Return an order-sensitive list of values by the given key.
	*/
	get(key) {
		return this.#lens.get(key) || [];
	}
	/**
	* Return an order-sensitive list of all values.
	*/
	getAll() {
		return this.#list.map(([, value]) => value);
	}
	/**
	* Append a new value to the given key.
	*/
	append(key, value) {
		this.#list.push([key, value]);
		this.#openLens(key, (list) => list.push(value));
	}
	/**
	* Prepend a new value to the given key.
	*/
	prepend(key, value) {
		this.#list.unshift([key, value]);
		this.#openLens(key, (list) => list.unshift(value));
	}
	/**
	* Delete the value belonging to the given key.
	* Returns `true` if the value was present and removed, `false` otherwise.
	*/
	delete(key, value) {
		if (this.size === 0) return false;
		const values = this.#lens.get(key);
		if (!values) return false;
		const index = values.indexOf(value);
		if (index === -1) return false;
		values.splice(index, 1);
		this.#list.splice(this.#list.findIndex((item) => item[0] === key && item[1] === value), 1);
		return true;
	}
	/**
	* Delete all values belogning to the given key.
	*/
	deleteAll(key) {
		if (this.size === 0) return;
		this.#list = this.#list.filter((item) => item[0] !== key);
		this.#lens.delete(key);
	}
	get size() {
		return this.#list.length;
	}
	clear() {
		if (this.size === 0) return;
		this.#list.length = 0;
		this.#lens.clear();
	}
	#openLens(key, setter) {
		setter(this.#lens.get(key) || this.#lens.set(key, []).get(key));
	}
};
var kDefaultPrevented2 = /* @__PURE__ */ Symbol("kDefaultPrevented");
var kPropagationStopped = /* @__PURE__ */ Symbol("kPropagationStopped");
var kImmediatePropagationStopped = /* @__PURE__ */ Symbol("kImmediatePropagationStopped");
var TypedEvent = class extends MessageEvent {
	/**
	* @note Keep a placeholder property with the return type
	* because the type must be set somewhere in order to be
	* correctly associated and inferred from the event.
	*/
	#returnType;
	[kDefaultPrevented2];
	[kPropagationStopped];
	[kImmediatePropagationStopped];
	constructor(...args) {
		super(args[0], args[1]);
		this[kDefaultPrevented2] = false;
	}
	get defaultPrevented() {
		return this[kDefaultPrevented2];
	}
	preventDefault() {
		super.preventDefault();
		this[kDefaultPrevented2] = true;
	}
	stopImmediatePropagation() {
		super.stopImmediatePropagation();
		this[kImmediatePropagationStopped] = true;
	}
};
var Emitter2 = class {
	#listeners;
	#listenerOptions;
	#listenerAbortCleanups;
	#typelessListeners;
	#hookListeners;
	#hookListenerOptions;
	#hookListenerAbortCleanups;
	hooks;
	constructor() {
		this.#listeners = new LensList();
		this.#listenerOptions = /* @__PURE__ */ new WeakMap();
		this.#listenerAbortCleanups = /* @__PURE__ */ new WeakMap();
		this.#typelessListeners = /* @__PURE__ */ new WeakSet();
		this.#hookListeners = new LensList();
		this.#hookListenerOptions = /* @__PURE__ */ new WeakMap();
		this.#hookListenerAbortCleanups = /* @__PURE__ */ new WeakMap();
		this.hooks = {
			on: (hook, callback, options) => {
				if (options?.signal?.aborted) return;
				if (options?.once) {
					const original = callback;
					const wrapper = ((...args) => {
						this.#deleteHookListener(hook, wrapper);
						return original(...args);
					});
					callback = wrapper;
				}
				this.#hookListeners.append(hook, callback);
				if (options) this.#hookListenerOptions.set(callback, options);
				if (options?.signal) {
					const { signal } = options;
					const onAbort = () => {
						this.#deleteHookListener(hook, callback);
					};
					signal.addEventListener("abort", onAbort, { once: true });
					this.#hookListenerAbortCleanups.set(callback, () => {
						signal.removeEventListener("abort", onAbort);
					});
				}
			},
			removeListener: (hook, callback) => {
				this.#deleteHookListener(hook, callback);
			}
		};
	}
	#deleteHookListener(hook, callback) {
		this.#hookListeners.delete(hook, callback);
		const cleanup = this.#hookListenerAbortCleanups.get(callback);
		if (cleanup) {
			cleanup();
			this.#hookListenerAbortCleanups.delete(callback);
		}
	}
	#deleteListener(type, listener) {
		const removed = this.#listeners.delete(type, listener);
		const cleanup = this.#listenerAbortCleanups.get(listener);
		if (cleanup) {
			cleanup();
			this.#listenerAbortCleanups.delete(listener);
		}
		return removed;
	}
	/**
	* Adds a listener for the given event type.
	*/
	on(type, listener, options) {
		this.#addListener(type, listener, options);
		return this;
	}
	/**
	* Adds a one-time listener for the given event type.
	*/
	once(type, listener, options) {
		return this.on(type, listener, {
			...options || {},
			once: true
		});
	}
	/**
	* Prepends a listener for the given event type.
	*/
	earlyOn(type, listener, options) {
		this.#addListener(type, listener, options, "prepend");
		return this;
	}
	/**
	* Prepends a one-time listener for the given event type.
	*/
	earlyOnce(type, listener, options) {
		return this.earlyOn(type, listener, {
			...options || {},
			once: true
		});
	}
	/**
	* Emits the given typed event.
	*
	* @returns {boolean} Returns `true` if the event had any listeners, `false` otherwise.
	*/
	emit(event) {
		if (this.#listeners.size === 0) return false;
		const hasListeners = this.listenerCount(event.type) > 0;
		const proxiedEvent = this.#proxyEvent(event);
		for (const listener of this.#matchListeners(event.type)) {
			if (proxiedEvent.event[kPropagationStopped] != null && proxiedEvent.event[kPropagationStopped] !== this) {
				proxiedEvent.revoke();
				return false;
			}
			if (proxiedEvent.event[kImmediatePropagationStopped]) break;
			this.#callListener(proxiedEvent.event, listener);
		}
		proxiedEvent.revoke();
		return hasListeners;
	}
	/**
	* Emits the given typed event and returns a promise that resolves
	* when all the listeners for that event have settled.
	*
	* @returns {Promise<Array<Emitter.ListenerReturnType>>} A promise that resolves
	* with the return values of all listeners.
	*/
	async emitAsPromise(event) {
		if (this.#listeners.size === 0) return [];
		const pendingListeners = [];
		const proxiedEvent = this.#proxyEvent(event);
		for (const listener of this.#matchListeners(event.type)) {
			if (proxiedEvent.event[kPropagationStopped] != null && proxiedEvent.event[kPropagationStopped] !== this) {
				proxiedEvent.revoke();
				return [];
			}
			if (proxiedEvent.event[kImmediatePropagationStopped]) break;
			const returnValue = await Promise.resolve(this.#callListener(proxiedEvent.event, listener));
			if (!this.#isTypelessListener(listener)) pendingListeners.push(returnValue);
		}
		proxiedEvent.revoke();
		return Promise.allSettled(pendingListeners).then((results) => {
			return results.map((result) => result.status === "fulfilled" ? result.value : result.reason);
		});
	}
	/**
	* Emits the given event and returns a generator that yields
	* the result of each listener in the order of their registration.
	* This way, you stop exhausting the listeners once you get the expected value.
	*/
	*emitAsGenerator(event) {
		if (this.#listeners.size === 0) return;
		const proxiedEvent = this.#proxyEvent(event);
		for (const listener of this.#matchListeners(event.type)) {
			if (proxiedEvent.event[kPropagationStopped] != null && proxiedEvent.event[kPropagationStopped] !== this) {
				proxiedEvent.revoke();
				return;
			}
			if (proxiedEvent.event[kImmediatePropagationStopped]) break;
			const returnValue = this.#callListener(proxiedEvent.event, listener);
			if (!this.#isTypelessListener(listener)) yield returnValue;
		}
		proxiedEvent.revoke();
	}
	/**
	* Removes a listener for the given event type.
	*/
	removeListener(type, listener) {
		const options = this.#listenerOptions.get(listener);
		if (!this.#deleteListener(type, listener)) return;
		for (const hook of this.#hookListeners.get("removeListener").slice()) hook(type, listener, options);
	}
	/**
	* Removes all listeners for the given event type.
	* If no event type is provided, removes all existing listeners.
	*/
	removeAllListeners(type) {
		if (type == null) {
			for (const [listenerType, listeners$1] of this.#listeners.entries()) while (listeners$1.length > 0) this.removeListener(listenerType, listeners$1[0]);
			for (const [hookType, hookListener] of [...this.#hookListeners]) if (!this.#hookListenerOptions.get(hookListener)?.persist) this.#deleteHookListener(hookType, hookListener);
			return;
		}
		const listeners = this.listeners(type);
		while (listeners.length > 0) this.removeListener(type, listeners[0]);
	}
	/**
	* Returns the list of listeners for the given event type.
	* If no even type is provided, returns all listeners.
	*/
	listeners(type) {
		if (type == null) return this.#listeners.getAll();
		return this.#listeners.get(type);
	}
	/**
	* Returns the number of listeners for the given event type.
	* If no even type is provided, returns the total number of listeners.
	*/
	listenerCount(type) {
		if (type == null) return this.#listeners.size;
		return this.listeners(type).length;
	}
	#addListener(type, listener, options, insertMode = "append") {
		if (options?.signal?.aborted) return;
		for (const hook of this.#hookListeners.get("newListener").slice()) hook(type, listener, options);
		if (type === "*") this.#typelessListeners.add(listener);
		if (insertMode === "prepend") this.#listeners.prepend(type, listener);
		else this.#listeners.append(type, listener);
		if (options) {
			this.#listenerOptions.set(listener, options);
			if (options.signal) {
				const { signal } = options;
				const onAbort = () => {
					this.removeListener(type, listener);
				};
				signal.addEventListener("abort", onAbort, { once: true });
				this.#listenerAbortCleanups.set(listener, () => {
					signal.removeEventListener("abort", onAbort);
				});
			}
		}
	}
	#proxyEvent(event) {
		const { stopPropagation } = event;
		event.stopPropagation = () => {
			event[kPropagationStopped] = this;
			stopPropagation.call(event);
		};
		return {
			event,
			revoke() {
				event.stopPropagation = stopPropagation;
			}
		};
	}
	#callListener(event, listener) {
		for (const hook of this.#hookListeners.get("beforeEmit").slice()) if (hook(event) === false) return;
		const returnValue = listener.call(this, event);
		const options = this.#listenerOptions.get(listener);
		if (options?.once) {
			const type = this.#isTypelessListener(listener) ? "*" : event.type;
			if (this.#deleteListener(type, listener)) for (const hook of this.#hookListeners.get("removeListener").slice()) hook(type, listener, options);
		}
		return returnValue;
	}
	/**
	* Return a list of all event listeners relevant for the given event type.
	* This includes the explicit event listeners and also typeless event listeners.
	*
	* @note Snapshot the matching listeners before yielding. Listeners can add or
	* remove other listeners during emission (e.g. `earlyOn` unshifts `#list`),
	* which would otherwise shift the live iterator and re-yield prior entries.
	*/
	*#matchListeners(type) {
		const snapshot = [];
		for (const [key, listener] of this.#listeners) if (key === "*" || key === type) snapshot.push(listener);
		yield* snapshot;
	}
	#isTypelessListener(listener) {
		return this.#typelessListeners.has(listener);
	}
};
var SUPPORTS_SERVICE_WORKER = supportsServiceWorker();
var WorkerEvent = class extends TypedEvent {
	#workerEvent;
	constructor(workerEvent) {
		const type = workerEvent.data.type;
		const data = workerEvent.data.payload;
		super(type, { data });
		this.#workerEvent = workerEvent;
	}
	get ports() {
		return this.#workerEvent.ports;
	}
	/**
	* Reply directly to this event using its `MessagePort`.
	*/
	postMessage(type, ...rest) {
		this.#workerEvent.ports[0].postMessage({
			type,
			data: rest[0]
		}, { transfer: rest[1] });
	}
};
var WorkerChannel = class extends Emitter2 {
	#getWorker;
	#controller;
	constructor(options) {
		super();
		invariant(SUPPORTS_SERVICE_WORKER, "Failed to open a WorkerChannel: Service Worker is not supported in this environment.");
		this.#getWorker = options.getWorker;
		this.#controller = new AbortController();
		navigator.serviceWorker.addEventListener("message", async (event) => {
			const worker = await this.#getWorker();
			if (event.source != null && event.source !== worker) return;
			if (event.data && isObject(event.data) && "type" in event.data) this.emit(new WorkerEvent(event));
		}, { signal: this.#controller.signal });
	}
	/**
	* Send data to the Service Worker controlling this client.
	* This triggers the `message` event listener on ServiceWorkerGlobalScope.
	*/
	postMessage(type) {
		invariant(SUPPORTS_SERVICE_WORKER, "Failed to post message on a WorkerChannel: the Service Worker API is unavailable in this environment. This is likely an issue with MSW. Please report it on GitHub: https://github.com/mswjs/msw/issues");
		this.#getWorker().then((worker) => {
			worker.postMessage(type);
		});
	}
	/**
	* Terminal teardown. Removes the `navigator.serviceWorker` message listener
	* and all emitter subscriptions. The channel is not usable afterwards.
	*/
	terminate() {
		this.#controller.abort();
		this.removeAllListeners();
	}
};
function pruneGetRequestBody(request) {
	if (["HEAD", "GET"].includes(request.method)) return;
	return request.body;
}
function deserializeRequest(serializedRequest) {
	return new Request(serializedRequest.url, {
		...serializedRequest,
		body: pruneGetRequestBody(serializedRequest)
	});
}
function validateWorkerScope(registration) {
	if (!location.href.startsWith(registration.scope)) devUtils.warn(`Cannot intercept requests on this page because it's outside of the worker's scope ("${registration.scope}"). If you wish to mock API requests on this page, you must resolve this scope issue.

- (Recommended) Register the worker at the root level ("/") of your application.
- Set the "Service-Worker-Allowed" response header to allow out-of-scope workers.`);
}
function shouldInvalidateWorker(prevOptions, nextOptions) {
	return prevOptions.findWorker !== nextOptions.findWorker || prevOptions.serviceWorker.url !== nextOptions.serviceWorker.url || JSON.stringify(prevOptions.serviceWorker.options) !== JSON.stringify(nextOptions.serviceWorker.options);
}
var ServiceWorkerSource = class _ServiceWorkerSource extends NetworkSource {
	static #current;
	/**
	* Create a new Service Worker source or reuse an existing one.
	* These sources act as a singleton and only get recreated if the options change.
	*/
	static async from(options) {
		if (_ServiceWorkerSource.#current == null) _ServiceWorkerSource.#current = new _ServiceWorkerSource(options);
		else if (shouldInvalidateWorker(_ServiceWorkerSource.#current.#options, options)) {
			await _ServiceWorkerSource.#current.terminate();
			_ServiceWorkerSource.#current = new _ServiceWorkerSource(options);
		}
		return _ServiceWorkerSource.#current;
	}
	#options;
	#frames;
	#channel;
	#listenerController;
	#clientPromise;
	#keepAliveInterval;
	#stoppedAt;
	workerPromise;
	constructor(options) {
		super();
		invariant(supportsServiceWorker(), "Failed to use Service Worker as the network source: the Service Worker API is not supported in this environment");
		this.#options = options;
		this.#frames = /* @__PURE__ */ new Map();
		this.workerPromise = new DeferredPromise2();
		this.#channel = new WorkerChannel({ getWorker: () => this.workerPromise.then(([worker]) => worker) });
	}
	async enable() {
		if (this.workerPromise.state === "fulfilled" && typeof this.#stoppedAt == "undefined") {
			devUtils.warn("Found a redundant \"worker.start()\" call. Note that starting the worker while mocking is already enabled will have no effect. Consider removing this \"worker.start()\" call.");
			return this.workerPromise.then(([, registration2]) => registration2);
		}
		this.#stoppedAt = void 0;
		this.#channel.removeAllListeners();
		this.#frames.clear();
		this.#listenerController = new AbortController();
		const [worker, registration] = await this.#startWorker();
		if (worker.state !== "activated") {
			const controller = new AbortController();
			const activationPromise = new DeferredPromise2();
			activationPromise.then(() => controller.abort());
			worker.addEventListener("statechange", () => {
				if (worker.state === "activated") activationPromise.resolve();
			}, { signal: controller.signal });
			await activationPromise;
		}
		this.#channel.postMessage("MOCK_ACTIVATE");
		const clientConfirmationPromise = new DeferredPromise2();
		this.#clientPromise = clientConfirmationPromise;
		this.#channel.once("MOCKING_ENABLED", (event) => {
			clientConfirmationPromise.resolve(event.data.client);
		});
		await clientConfirmationPromise;
		if (!this.#options.quiet) this.#printStartMessage();
		return registration;
	}
	disable() {
		if (typeof this.#stoppedAt !== "undefined") {
			devUtils.warn(`Found a redundant "worker.stop()" call. Notice that stopping the worker after it has already been stopped has no effect. Consider removing this "worker.stop()" call.`);
			return;
		}
		this.#stoppedAt = Date.now();
		this.#listenerController?.abort();
		this.#listenerController = void 0;
		this.#channel.postMessage("CLIENT_CLOSED");
		if (!this.#options.quiet) this.#printStopMessage();
	}
	/**
	* Terminal teardown. Unregisters the Service Worker, tears down the channel,
	* and clears timers. Called when the singleton is being replaced with one
	* that has different options. The instance is not usable afterwards.
	*/
	async terminate() {
		if (this.#keepAliveInterval != null) {
			clearInterval(this.#keepAliveInterval);
			this.#keepAliveInterval = void 0;
		}
		this.#frames.clear();
		this.#channel.terminate();
		this.#listenerController?.abort();
		this.#listenerController = void 0;
		if (this.workerPromise.state === "fulfilled") {
			const [, registration] = await this.workerPromise;
			await registration.unregister();
		}
		if (_ServiceWorkerSource.#current === this) _ServiceWorkerSource.#current = void 0;
	}
	async #startWorker() {
		if (this.#keepAliveInterval) clearInterval(this.#keepAliveInterval);
		const workerUrl = this.#options.serviceWorker.url;
		const [worker, registration] = await getWorkerInstance(workerUrl, this.#options.serviceWorker.options, this.#options.findWorker || this.#defaultFindWorker);
		if (worker == null) {
			const missingWorkerMessage = this.#options?.findWorker ? devUtils.formatMessage(`Failed to locate the Service Worker registration using a custom "findWorker" predicate.

Please ensure that the custom predicate properly locates the Service Worker registration at "%s".
More details: https://mswjs.io/docs/api/setup-worker/start#findworker
     `, workerUrl) : devUtils.formatMessage(`Failed to locate the Service Worker registration.

This most likely means that the worker script URL "%s" cannot resolve against the actual public hostname (%s). This may happen if your application runs behind a proxy, or has a dynamic hostname.

Please consider using a custom "serviceWorker.url" option to point to the actual worker script location, or a custom "findWorker" option to resolve the Service Worker registration manually. More details: https://mswjs.io/docs/api/setup-worker/start`, workerUrl, location.host);
			throw new Error(missingWorkerMessage);
		}
		if (this.workerPromise.state === "pending") this.workerPromise.resolve([worker, registration]);
		else this.workerPromise = new DeferredPromise2((resolve) => {
			resolve([worker, registration]);
		});
		this.#channel.on("REQUEST", this.#handleRequest.bind(this));
		this.#channel.on("RESPONSE", this.#handleResponse.bind(this));
		window.addEventListener("beforeunload", () => {
			if (worker.state !== "redundant") this.#channel.postMessage("CLIENT_CLOSED");
			clearInterval(this.#keepAliveInterval);
			window.postMessage({ type: "msw/worker:stop" });
		}, { signal: this.#listenerController?.signal });
		await this.#checkWorkerIntegrity().catch((error2) => {
			devUtils.error("Error while checking the worker script integrity. Please report this on GitHub (https://github.com/mswjs/msw/issues) and include the original error below.");
			console.error(error2);
		});
		this.#keepAliveInterval = window.setInterval(() => {
			this.#channel.postMessage("KEEPALIVE_REQUEST");
		}, 5e3);
		if (!this.#options.quiet) validateWorkerScope(registration);
		return [worker, registration];
	}
	async #handleRequest(event) {
		if (this.#stoppedAt && event.data.interceptedAt > this.#stoppedAt) return event.postMessage("PASSTHROUGH");
		const request = deserializeRequest(event.data);
		RequestHandler.cache.set(request, request.clone());
		const frame = new ServiceWorkerHttpNetworkFrame({
			event,
			request
		});
		this.#frames.set(event.data.id, frame);
		await this.queue(frame);
	}
	async #handleResponse(event) {
		const { request, response, isMockedResponse } = event.data;
		const frame = this.#frames.get(request.id);
		if (response.type?.includes("opaque")) {
			this.#frames.delete(request.id);
			frame?.events.removeAllListeners();
			return;
		}
		this.#frames.delete(request.id);
		if (frame == null) return;
		const fetchRequest = deserializeRequest(request);
		const fetchResponse = response.status === 0 ? Response.error() : new FetchResponse(
			/**
			* Responses may be streams here, but when we create a response object
			* with null-body status codes, like 204, 205, 304 Response will
			* throw when passed a non-null body, so ensure it's null here
			* for those codes
			*/
			FetchResponse.isResponseWithBody(response.status) ? response.body : null,
			{
				...response,
				/**
				* Set response URL if it's not set already.
				* @see https://github.com/mswjs/msw/issues/2030
				* @see https://developer.mozilla.org/en-US/docs/Web/API/Response/url
				*/
				url: request.url
			}
		);
		try {
			frame.events.emit(new ResponseEvent(isMockedResponse ? "response:mocked" : "response:bypass", {
				requestId: frame.data.id,
				request: fetchRequest,
				response: fetchResponse,
				isMockedResponse
			}));
		} finally {
			frame.events.removeAllListeners();
		}
	}
	#defaultFindWorker = (workerUrl, mockServiceWorkerUrl) => {
		return workerUrl === mockServiceWorkerUrl;
	};
	async #checkWorkerIntegrity() {
		const integrityCheckPromise = new DeferredPromise2();
		this.#channel.postMessage("INTEGRITY_CHECK_REQUEST");
		this.#channel.once("INTEGRITY_CHECK_RESPONSE", (event) => {
			const { checksum, packageVersion } = event.data;
			if (checksum !== "03cb67ac84128e63d7cd722a6e5b7f1e") devUtils.warn(`The currently registered Service Worker has been generated by a different version of MSW (${packageVersion}) and may not be fully compatible with the installed version.

It's recommended you update your worker script by running this command:

  \u2022 npx msw init <PUBLIC_DIR>

You can also automate this process and make the worker script update automatically upon the library installations. Read more: https://mswjs.io/docs/cli/init.`);
			integrityCheckPromise.resolve();
		});
		return integrityCheckPromise;
	}
	async #printStartMessage() {
		if (this.workerPromise.state === "rejected") return;
		invariant(this.#clientPromise != null, "[ServiceWorkerSource] Failed to print a start message: client confirmation not received");
		const client = await this.#clientPromise;
		const [worker, registration] = await this.workerPromise;
		console.groupCollapsed(`%c${devUtils.formatMessage("Mocking enabled.")}`, "color:orangered;font-weight:bold;");
		console.log("%cDocumentation: %chttps://mswjs.io/docs", "font-weight:bold", "font-weight:normal");
		console.log("Found an issue? https://github.com/mswjs/msw/issues");
		console.log("Worker script URL:", worker.scriptURL);
		console.log("Worker scope:", registration.scope);
		if (client) console.log("Client ID: %s (%s)", client.id, client.frameType);
		console.groupEnd();
	}
	#printStopMessage() {
		console.log(`%c${devUtils.formatMessage("Mocking disabled.")}`, "color:orangered;font-weight:bold;");
	}
};
var ServiceWorkerHttpNetworkFrame = class extends HttpNetworkFrame {
	#event;
	constructor(options) {
		super({ request: options.request });
		this.#event = options.event;
	}
	passthrough() {
		this.#event.postMessage("PASSTHROUGH");
	}
	respondWith(response) {
		if (response) this.#respondWith(response);
	}
	errorWith(reason) {
		if (reason instanceof Response) return this.respondWith(reason);
		devUtils.warn(`Uncaught exception in the request handler for "%s %s". This exception has been gracefully handled as a 500 response, however, it's strongly recommended to resolve this error, as it indicates a mistake in your code. If you wish to mock an error response, please see this guide: https://mswjs.io/docs/http/mocking-responses/error-responses`, this.data.request.method, this.data.request.url);
		const error2 = reason instanceof Error ? reason : new Error(reason?.toString() || "Request failure");
		this.respondWith(HttpResponse.json({
			name: error2.name,
			message: error2.message,
			stack: error2.stack
		}, {
			status: 500,
			statusText: "Request Handler Error"
		}));
	}
	async #respondWith(response) {
		let responseBody;
		let transfer;
		const responseInit = toResponseInit(response);
		if (supportsReadableStreamTransfer()) {
			responseBody = response.body;
			transfer = response.body == null ? void 0 : [response.body];
		} else responseBody = response.body == null ? null : await response.clone().arrayBuffer();
		this.#event.postMessage("MOCK_RESPONSE", {
			...responseInit,
			body: responseBody
		}, transfer);
	}
};
var until2 = async (promise) => {
	try {
		return {
			error: null,
			data: await promise().catch((error2) => {
				throw error2;
			})
		};
	} catch (error2) {
		return {
			error: error2,
			data: null
		};
	}
};
function isObject2(value, loose = false) {
	return loose ? Object.prototype.toString.call(value).startsWith("[object ") : Object.prototype.toString.call(value) === "[object Object]";
}
function isPropertyAccessible(obj, key) {
	try {
		obj[key];
		return true;
	} catch {
		return false;
	}
}
function createServerErrorResponse(body) {
	return new Response(JSON.stringify(body instanceof Error ? {
		name: body.name,
		message: body.message,
		stack: body.stack
	} : body), {
		status: 500,
		statusText: "Unhandled Exception",
		headers: { "Content-Type": "application/json" }
	});
}
function isResponseError(response) {
	return response != null && response instanceof Response && isPropertyAccessible(response, "type") && response.type === "error";
}
function isResponseLike(value) {
	return isObject2(value, true) && isPropertyAccessible(value, "status") && isPropertyAccessible(value, "statusText") && isPropertyAccessible(value, "bodyUsed");
}
function isNodeLikeError(error2) {
	if (error2 == null) return false;
	if (!(error2 instanceof Error)) return false;
	return "code" in error2 && "errno" in error2;
}
async function handleRequest(options) {
	const handleResponse = async (response) => {
		if (response instanceof Error) {
			await options.controller.errorWith(response);
			return true;
		}
		if (isResponseError(response)) {
			await options.controller.respondWith(response);
			return true;
		}
		if (isResponseLike(response)) {
			await options.controller.respondWith(response);
			return true;
		}
		if (isObject2(response)) {
			await options.controller.errorWith(response);
			return true;
		}
		return false;
	};
	const handleResponseError = async (error2) => {
		if (error2 instanceof InterceptorError) throw result.error;
		if (isNodeLikeError(error2)) {
			await options.controller.errorWith(error2);
			return true;
		}
		if (error2 instanceof Response) return await handleResponse(error2);
		return false;
	};
	const requestAbortPromise = new DeferredPromise();
	const onAbort = () => {
		requestAbortPromise.reject(options.request.signal?.reason);
	};
	if (options.request.signal) {
		if (options.request.signal.aborted) {
			await options.controller.errorWith(options.request.signal.reason);
			return;
		}
		options.request.signal.addEventListener("abort", onAbort, { once: true });
	}
	const result = await until2(async () => {
		const requestListenersPromise = emitAsync(options.emitter, "request", {
			requestId: options.requestId,
			request: options.request,
			controller: options.controller
		});
		await Promise.race([
			requestAbortPromise,
			requestListenersPromise,
			options.controller.handled
		]);
	});
	options.request.signal?.removeEventListener("abort", onAbort);
	if (requestAbortPromise.state === "rejected") {
		await options.controller.errorWith(requestAbortPromise.rejectionReason);
		return;
	}
	if (result.error) {
		if (await handleResponseError(result.error)) return;
		if (options.emitter.listenerCount("unhandledException") > 0) {
			const unhandledExceptionController = new RequestController(options.request, {
				passthrough() {},
				async respondWith(response) {
					await handleResponse(response);
				},
				async errorWith(reason) {
					await options.controller.errorWith(reason);
				}
			});
			await emitAsync(options.emitter, "unhandledException", {
				error: result.error,
				request: options.request,
				requestId: options.requestId,
				controller: unhandledExceptionController
			});
			if (unhandledExceptionController.readyState !== RequestController.PENDING) return;
		}
		await options.controller.respondWith(createServerErrorResponse(result.error));
		return;
	}
	if (options.controller.readyState === RequestController.PENDING) return await options.controller.passthrough();
	return options.controller.handled;
}
function createNetworkError(cause) {
	return Object.assign(/* @__PURE__ */ new TypeError("Failed to fetch"), { cause });
}
var REQUEST_BODY_HEADERS = [
	"content-encoding",
	"content-language",
	"content-location",
	"content-type",
	"content-length"
];
var kRedirectCount = /* @__PURE__ */ Symbol("kRedirectCount");
async function followFetchRedirect(request, response) {
	if (response.status !== 303 && request.body != null) return Promise.reject(createNetworkError());
	const requestUrl = new URL(request.url);
	let locationUrl;
	try {
		locationUrl = new URL(response.headers.get("location"), request.url);
	} catch (error2) {
		return Promise.reject(createNetworkError(error2));
	}
	if (!(locationUrl.protocol === "http:" || locationUrl.protocol === "https:")) return Promise.reject(createNetworkError("URL scheme must be a HTTP(S) scheme"));
	if (Reflect.get(request, kRedirectCount) > 20) return Promise.reject(createNetworkError("redirect count exceeded"));
	Object.defineProperty(request, kRedirectCount, { value: (Reflect.get(request, kRedirectCount) || 0) + 1 });
	if (request.mode === "cors" && (locationUrl.username || locationUrl.password) && !sameOrigin(requestUrl, locationUrl)) return Promise.reject(createNetworkError("cross origin not allowed for request mode \"cors\""));
	const requestInit = {};
	if ([301, 302].includes(response.status) && request.method === "POST" || response.status === 303 && !["HEAD", "GET"].includes(request.method)) {
		requestInit.method = "GET";
		requestInit.body = null;
		REQUEST_BODY_HEADERS.forEach((headerName) => {
			request.headers.delete(headerName);
		});
	}
	if (!sameOrigin(requestUrl, locationUrl)) {
		request.headers.delete("authorization");
		request.headers.delete("proxy-authorization");
		request.headers.delete("cookie");
		request.headers.delete("host");
	}
	requestInit.headers = request.headers;
	const finalResponse = await fetch(new Request(locationUrl, requestInit));
	Object.defineProperty(finalResponse, "redirected", {
		value: true,
		configurable: true
	});
	return finalResponse;
}
function sameOrigin(left, right) {
	if (left.origin === right.origin && left.origin === "null") return true;
	if (left.protocol === right.protocol && left.hostname === right.hostname && left.port === right.port) return true;
	return false;
}
var BrotliDecompressionStream = class extends TransformStream {
	constructor() {
		console.warn("[Interceptors]: Brotli decompression of response streams is not supported in the browser");
		super({ transform(chunk, controller) {
			controller.enqueue(chunk);
		} });
	}
};
var PipelineStream = class extends TransformStream {
	constructor(transformStreams, ...strategies) {
		super({}, ...strategies);
		const readable = [super.readable, ...transformStreams].reduce((readable$1, transform) => readable$1.pipeThrough(transform));
		Object.defineProperty(this, "readable", { get() {
			return readable;
		} });
	}
};
function parseContentEncoding(contentEncoding) {
	return contentEncoding.toLowerCase().split(",").map((coding) => coding.trim());
}
function createDecompressionStream(contentEncoding) {
	if (contentEncoding === "") return null;
	const codings = parseContentEncoding(contentEncoding);
	if (codings.length === 0) return null;
	return new PipelineStream(codings.reduceRight((transformers, coding) => {
		if (coding === "gzip" || coding === "x-gzip") return transformers.concat(new DecompressionStream("gzip"));
		else if (coding === "deflate") return transformers.concat(new DecompressionStream("deflate"));
		else if (coding === "br") return transformers.concat(new BrotliDecompressionStream());
		else transformers.length = 0;
		return transformers;
	}, []));
}
function decompressResponse(response) {
	if (response.body === null) return null;
	const decompressionStream = createDecompressionStream(response.headers.get("content-encoding") || "");
	if (!decompressionStream) return null;
	response.body.pipeTo(decompressionStream.writable);
	return decompressionStream.readable;
}
var FetchInterceptor = class FetchInterceptor2 extends Interceptor {
	static {
		this.symbol = /* @__PURE__ */ Symbol.for("fetch-interceptor");
	}
	constructor() {
		super(FetchInterceptor2.symbol);
	}
	checkEnvironment() {
		return hasConfigurableGlobal("fetch");
	}
	async setup() {
		const logger = this.logger.extend("setup");
		const pureFetch = globalThis.fetch;
		const fetchProxy = async (input, init) => {
			const requestId = createRequestId();
			const request = new FetchRequest(typeof input === "string" && typeof location !== "undefined" && !canParseUrl(input) ? new URL(input, location.href) : input, init);
			if (input instanceof Request) setRawRequest(request, input);
			const responsePromise = new DeferredPromise();
			const controller = new RequestController(request, {
				passthrough: async () => {
					this.logger.info("request has not been handled, passthrough...");
					const requestCloneForResponseEvent = request.clone();
					const { error: responseError, data: originalResponse } = await until2(() => pureFetch(request));
					if (responseError) return responsePromise.reject(responseError);
					this.logger.info("original fetch performed", originalResponse);
					if (this.emitter.listenerCount("response") > 0) {
						this.logger.info("emitting the \"response\" event...");
						const responseClone = FetchResponse.clone(originalResponse);
						await emitAsync(this.emitter, "response", {
							response: responseClone,
							isMockedResponse: false,
							request: requestCloneForResponseEvent,
							requestId
						});
					}
					responsePromise.resolve(originalResponse);
				},
				respondWith: async (rawResponse) => {
					if (isResponseError(rawResponse)) {
						this.logger.info("request has errored!", { response: rawResponse });
						responsePromise.reject(createNetworkError(rawResponse));
						return;
					}
					this.logger.info("received mocked response!", { rawResponse });
					const response = new FetchResponse(decompressResponse(rawResponse) || rawResponse.body, {
						url: request.url,
						status: rawResponse.status,
						statusText: rawResponse.statusText,
						headers: rawResponse.headers
					});
					if (FetchResponse.isRedirectResponse(response.status)) {
						if (request.redirect === "error") {
							responsePromise.reject(createNetworkError("unexpected redirect"));
							return;
						}
						if (request.redirect === "follow") {
							followFetchRedirect(request, response).then((response$1) => {
								responsePromise.resolve(response$1);
							}, (reason) => {
								responsePromise.reject(reason);
							});
							return;
						}
					}
					if (this.emitter.listenerCount("response") > 0) {
						this.logger.info("emitting the \"response\" event...");
						await emitAsync(this.emitter, "response", {
							response: FetchResponse.clone(response),
							isMockedResponse: true,
							request,
							requestId
						});
					}
					responsePromise.resolve(response);
				},
				errorWith: (reason) => {
					this.logger.info("request has been aborted!", { reason });
					responsePromise.reject(reason);
				}
			});
			this.logger.info("[%s] %s", request.method, request.url);
			this.logger.info("awaiting for the mocked response...");
			this.logger.info("emitting the \"request\" event for %s listener(s)...", this.emitter.listenerCount("request"));
			await handleRequest({
				request,
				requestId,
				emitter: this.emitter,
				controller
			});
			return responsePromise;
		};
		logger.info("patching global fetch...");
		this.subscriptions.push(patchesRegistry.applyPatch(globalThis, "fetch", () => fetchProxy));
		logger.info("global fetch patched!", globalThis.fetch.name);
	}
};
function concatArrayBuffer(left, right) {
	const result = new Uint8Array(left.byteLength + right.byteLength);
	result.set(left, 0);
	result.set(right, left.byteLength);
	return result;
}
var EventPolyfill = class {
	constructor(type, options) {
		this.NONE = 0;
		this.CAPTURING_PHASE = 1;
		this.AT_TARGET = 2;
		this.BUBBLING_PHASE = 3;
		this.type = "";
		this.srcElement = null;
		this.currentTarget = null;
		this.eventPhase = 0;
		this.isTrusted = true;
		this.composed = false;
		this.cancelable = true;
		this.defaultPrevented = false;
		this.bubbles = true;
		this.lengthComputable = true;
		this.loaded = 0;
		this.total = 0;
		this.cancelBubble = false;
		this.returnValue = true;
		this.type = type;
		this.target = options?.target || null;
		this.currentTarget = options?.currentTarget || null;
		this.timeStamp = Date.now();
	}
	composedPath() {
		return [];
	}
	initEvent(type, bubbles, cancelable) {
		this.type = type;
		this.bubbles = !!bubbles;
		this.cancelable = !!cancelable;
	}
	preventDefault() {
		this.defaultPrevented = true;
	}
	stopPropagation() {}
	stopImmediatePropagation() {}
};
var ProgressEventPolyfill = class extends EventPolyfill {
	constructor(type, init) {
		super(type);
		this.lengthComputable = init?.lengthComputable || false;
		this.composed = init?.composed || false;
		this.loaded = init?.loaded || 0;
		this.total = init?.total || 0;
	}
};
var SUPPORTS_PROGRESS_EVENT = typeof ProgressEvent !== "undefined";
function createEvent(target, type, init) {
	const progressEvents = [
		"error",
		"progress",
		"loadstart",
		"loadend",
		"load",
		"timeout",
		"abort"
	];
	const ProgressEventClass = SUPPORTS_PROGRESS_EVENT ? ProgressEvent : ProgressEventPolyfill;
	return progressEvents.includes(type) ? new ProgressEventClass(type, {
		lengthComputable: true,
		loaded: init?.loaded || 0,
		total: init?.total || 0
	}) : new EventPolyfill(type, {
		target,
		currentTarget: target
	});
}
function findPropertySource(target, propertyName) {
	if (!(propertyName in target)) return null;
	if (Object.prototype.hasOwnProperty.call(target, propertyName)) return target;
	const prototype = Reflect.getPrototypeOf(target);
	return prototype ? findPropertySource(prototype, propertyName) : null;
}
function createProxy(target, options) {
	return new Proxy(target, optionsToProxyHandler(options));
}
function optionsToProxyHandler(options) {
	const { constructorCall, methodCall, getProperty, setProperty } = options;
	const handler = {};
	if (typeof constructorCall !== "undefined") handler.construct = function(target, args, newTarget) {
		const next = Reflect.construct.bind(null, target, args, newTarget);
		return constructorCall.call(newTarget, args, next);
	};
	handler.set = function(target, propertyName, nextValue) {
		const next = () => {
			const propertySource = findPropertySource(target, propertyName) || target;
			const ownDescriptors = Reflect.getOwnPropertyDescriptor(propertySource, propertyName);
			if (typeof ownDescriptors?.set !== "undefined") {
				ownDescriptors.set.apply(target, [nextValue]);
				return true;
			}
			return Reflect.defineProperty(propertySource, propertyName, {
				writable: true,
				enumerable: true,
				configurable: true,
				value: nextValue
			});
		};
		if (typeof setProperty !== "undefined") return setProperty.call(target, [propertyName, nextValue], next);
		return next();
	};
	handler.get = function(target, propertyName, receiver) {
		const next = () => target[propertyName];
		const value = typeof getProperty !== "undefined" ? getProperty.call(target, [propertyName, receiver], next) : next();
		if (typeof value === "function") return (...args) => {
			const next$1 = value.bind(target, ...args);
			if (typeof methodCall !== "undefined") return methodCall.call(target, [propertyName, args], next$1);
			return next$1();
		};
		return value;
	};
	return handler;
}
function isDomParserSupportedType(type) {
	return [
		"application/xhtml+xml",
		"application/xml",
		"image/svg+xml",
		"text/html",
		"text/xml"
	].some((supportedType) => {
		return type.startsWith(supportedType);
	});
}
function parseJson(data) {
	try {
		return JSON.parse(data);
	} catch (_) {
		return null;
	}
}
function createResponse(request, body) {
	return new FetchResponse(FetchResponse.isResponseWithBody(request.status) ? body : null, {
		url: request.responseURL,
		status: request.status,
		statusText: request.statusText,
		headers: createHeadersFromXMLHttpRequestHeaders(request.getAllResponseHeaders())
	});
}
function createHeadersFromXMLHttpRequestHeaders(headersString) {
	const headers = new Headers();
	const lines = headersString.split(/[\r\n]+/);
	for (const line of lines) {
		if (line.trim() === "") continue;
		const [name, ...parts] = line.split(": ");
		const value = parts.join(": ");
		headers.append(name, value);
	}
	return headers;
}
async function getBodyByteLength(input) {
	const explicitContentLength = input.headers.get("content-length");
	if (explicitContentLength != null && explicitContentLength !== "") return Number(explicitContentLength);
	return (await input.arrayBuffer()).byteLength;
}
var kIsRequestHandled = /* @__PURE__ */ Symbol("kIsRequestHandled");
var IS_NODE2 = isNodeProcess();
var kFetchRequest = /* @__PURE__ */ Symbol("kFetchRequest");
var XMLHttpRequestController = class {
	constructor(initialRequest, logger) {
		this.initialRequest = initialRequest;
		this.logger = logger;
		this.method = "GET";
		this.url = null;
		this[kIsRequestHandled] = false;
		this.events = /* @__PURE__ */ new Map();
		this.uploadEvents = /* @__PURE__ */ new Map();
		this.requestId = createRequestId();
		this.requestHeaders = new Headers();
		this.responseBuffer = /* @__PURE__ */ new Uint8Array();
		this.request = createProxy(initialRequest, {
			setProperty: ([propertyName, nextValue], invoke) => {
				switch (propertyName) {
					case "ontimeout": {
						const eventName = propertyName.slice(2);
						this.request.addEventListener(eventName, nextValue);
						return invoke();
					}
					default: return invoke();
				}
			},
			methodCall: ([methodName, args], invoke) => {
				switch (methodName) {
					case "open": {
						const [method, url] = args;
						if (typeof url === "undefined") {
							this.method = "GET";
							this.url = toAbsoluteUrl(method);
						} else {
							this.method = method;
							this.url = toAbsoluteUrl(url);
						}
						this.logger = this.logger.extend(`${this.method} ${this.url.href}`);
						this.logger.info("open", this.method, this.url.href);
						return invoke();
					}
					case "addEventListener": {
						const [eventName, listener] = args;
						this.registerEvent(eventName, listener);
						this.logger.info("addEventListener", eventName, listener);
						return invoke();
					}
					case "setRequestHeader": {
						const [name, value] = args;
						this.requestHeaders.set(name, value);
						this.logger.info("setRequestHeader", name, value);
						return invoke();
					}
					case "send": {
						const [body] = args;
						this.request.addEventListener("load", () => {
							if (typeof this.onResponse !== "undefined") {
								const fetchResponse = createResponse(
									this.request,
									/**
									* The `response` property is the right way to read
									* the ambiguous response body, as the request's "responseType" may differ.
									* @see https://xhr.spec.whatwg.org/#the-response-attribute
									*/
									this.request.response
								);
								this.onResponse.call(this, {
									response: fetchResponse,
									isMockedResponse: this[kIsRequestHandled],
									request: fetchRequest,
									requestId: this.requestId
								});
							}
						});
						const requestBody = typeof body === "string" ? encodeBuffer(body) : body;
						const fetchRequest = this.toFetchApiRequest(requestBody);
						this[kFetchRequest] = fetchRequest.clone();
						queueMicrotask(() => {
							(this.onRequest?.call(this, {
								request: fetchRequest,
								requestId: this.requestId
							}) || Promise.resolve()).finally(() => {
								if (!this[kIsRequestHandled]) {
									this.logger.info("request callback settled but request has not been handled (readystate %d), performing as-is...", this.request.readyState);
									if (IS_NODE2) this.request.setRequestHeader(INTERNAL_REQUEST_ID_HEADER_NAME, this.requestId);
									return invoke();
								}
							});
						});
						break;
					}
					default: return invoke();
				}
			}
		});
		define(this.request, "upload", createProxy(this.request.upload, {
			setProperty: ([propertyName, nextValue], invoke) => {
				switch (propertyName) {
					case "onloadstart":
					case "onprogress":
					case "onaboart":
					case "onerror":
					case "onload":
					case "ontimeout":
					case "onloadend": {
						const eventName = propertyName.slice(2);
						this.registerUploadEvent(eventName, nextValue);
					}
				}
				return invoke();
			},
			methodCall: ([methodName, args], invoke) => {
				switch (methodName) {
					case "addEventListener": {
						const [eventName, listener] = args;
						this.registerUploadEvent(eventName, listener);
						this.logger.info("upload.addEventListener", eventName, listener);
						return invoke();
					}
				}
			}
		}));
	}
	registerEvent(eventName, listener) {
		const nextEvents = (this.events.get(eventName) || []).concat(listener);
		this.events.set(eventName, nextEvents);
		this.logger.info("registered event \"%s\"", eventName, listener);
	}
	registerUploadEvent(eventName, listener) {
		const nextEvents = (this.uploadEvents.get(eventName) || []).concat(listener);
		this.uploadEvents.set(eventName, nextEvents);
		this.logger.info("registered upload event \"%s\"", eventName, listener);
	}
	/**
	* Responds to the current request with the given
	* Fetch API `Response` instance.
	*/
	async respondWith(response) {
		this[kIsRequestHandled] = true;
		if (this[kFetchRequest]) {
			const totalRequestBodyLength = await getBodyByteLength(this[kFetchRequest]);
			this.trigger("loadstart", this.request.upload, {
				loaded: 0,
				total: totalRequestBodyLength
			});
			this.trigger("progress", this.request.upload, {
				loaded: totalRequestBodyLength,
				total: totalRequestBodyLength
			});
			this.trigger("load", this.request.upload, {
				loaded: totalRequestBodyLength,
				total: totalRequestBodyLength
			});
			this.trigger("loadend", this.request.upload, {
				loaded: totalRequestBodyLength,
				total: totalRequestBodyLength
			});
		}
		this.logger.info("responding with a mocked response: %d %s", response.status, response.statusText);
		define(this.request, "status", response.status);
		define(this.request, "statusText", response.statusText);
		define(this.request, "responseURL", this.url.href);
		this.request.getResponseHeader = new Proxy(this.request.getResponseHeader, { apply: (_, __, args) => {
			this.logger.info("getResponseHeader", args[0]);
			if (this.request.readyState < this.request.HEADERS_RECEIVED) {
				this.logger.info("headers not received yet, returning null");
				return null;
			}
			const headerValue = response.headers.get(args[0]);
			this.logger.info("resolved response header \"%s\" to", args[0], headerValue);
			return headerValue;
		} });
		this.request.getAllResponseHeaders = new Proxy(this.request.getAllResponseHeaders, { apply: () => {
			this.logger.info("getAllResponseHeaders");
			if (this.request.readyState < this.request.HEADERS_RECEIVED) {
				this.logger.info("headers not received yet, returning empty string");
				return "";
			}
			const allHeaders = Array.from(response.headers.entries()).map(([headerName, headerValue]) => {
				return `${headerName}: ${headerValue}`;
			}).join("\r\n");
			this.logger.info("resolved all response headers to", allHeaders);
			return allHeaders;
		} });
		Object.defineProperties(this.request, {
			response: {
				enumerable: true,
				configurable: false,
				get: () => this.response
			},
			responseText: {
				enumerable: true,
				configurable: false,
				get: () => this.responseText
			},
			responseXML: {
				enumerable: true,
				configurable: false,
				get: () => this.responseXML
			}
		});
		const totalResponseBodyLength = await getBodyByteLength(response.clone());
		this.logger.info("calculated response body length", totalResponseBodyLength);
		this.trigger("loadstart", this.request, {
			loaded: 0,
			total: totalResponseBodyLength
		});
		this.setReadyState(this.request.HEADERS_RECEIVED);
		this.setReadyState(this.request.LOADING);
		const finalizeResponse = () => {
			this.logger.info("finalizing the mocked response...");
			this.setReadyState(this.request.DONE);
			this.trigger("load", this.request, {
				loaded: this.responseBuffer.byteLength,
				total: totalResponseBodyLength
			});
			this.trigger("loadend", this.request, {
				loaded: this.responseBuffer.byteLength,
				total: totalResponseBodyLength
			});
		};
		if (response.body) {
			this.logger.info("mocked response has body, streaming...");
			const reader = response.body.getReader();
			const readNextResponseBodyChunk = async () => {
				const { value, done } = await reader.read();
				if (done) {
					this.logger.info("response body stream done!");
					finalizeResponse();
					return;
				}
				if (value) {
					this.logger.info("read response body chunk:", value);
					this.responseBuffer = concatArrayBuffer(this.responseBuffer, value);
					this.trigger("progress", this.request, {
						loaded: this.responseBuffer.byteLength,
						total: totalResponseBodyLength
					});
				}
				readNextResponseBodyChunk();
			};
			readNextResponseBodyChunk();
		} else finalizeResponse();
	}
	responseBufferToText() {
		return decodeBuffer(this.responseBuffer);
	}
	get response() {
		this.logger.info("getResponse (responseType: %s)", this.request.responseType);
		if (this.request.readyState !== this.request.DONE) return null;
		switch (this.request.responseType) {
			case "json": {
				const responseJson = parseJson(this.responseBufferToText());
				this.logger.info("resolved response JSON", responseJson);
				return responseJson;
			}
			case "arraybuffer": {
				const arrayBuffer = toArrayBuffer(this.responseBuffer);
				this.logger.info("resolved response ArrayBuffer", arrayBuffer);
				return arrayBuffer;
			}
			case "blob": {
				const mimeType = this.request.getResponseHeader("Content-Type") || "text/plain";
				const responseBlob = new Blob([this.responseBufferToText()], { type: mimeType });
				this.logger.info("resolved response Blob (mime type: %s)", responseBlob, mimeType);
				return responseBlob;
			}
			default: {
				const responseText = this.responseBufferToText();
				this.logger.info("resolving \"%s\" response type as text", this.request.responseType, responseText);
				return responseText;
			}
		}
	}
	get responseText() {
		invariant(this.request.responseType === "" || this.request.responseType === "text", "InvalidStateError: The object is in invalid state.");
		if (this.request.readyState !== this.request.LOADING && this.request.readyState !== this.request.DONE) return "";
		const responseText = this.responseBufferToText();
		this.logger.info("getResponseText: \"%s\"", responseText);
		return responseText;
	}
	get responseXML() {
		invariant(this.request.responseType === "" || this.request.responseType === "document", "InvalidStateError: The object is in invalid state.");
		if (this.request.readyState !== this.request.DONE) return null;
		const contentType = this.request.getResponseHeader("Content-Type") || "";
		if (typeof DOMParser === "undefined") {
			console.warn("Cannot retrieve XMLHttpRequest response body as XML: DOMParser is not defined. You are likely using an environment that is not browser or does not polyfill browser globals correctly.");
			return null;
		}
		if (isDomParserSupportedType(contentType)) return new DOMParser().parseFromString(this.responseBufferToText(), contentType);
		return null;
	}
	errorWith(error2) {
		this[kIsRequestHandled] = true;
		this.logger.info("responding with an error");
		this.setReadyState(this.request.DONE);
		this.trigger("error", this.request);
		this.trigger("loadend", this.request);
	}
	/**
	* Transitions this request's `readyState` to the given one.
	*/
	setReadyState(nextReadyState) {
		this.logger.info("setReadyState: %d -> %d", this.request.readyState, nextReadyState);
		if (this.request.readyState === nextReadyState) {
			this.logger.info("ready state identical, skipping transition...");
			return;
		}
		define(this.request, "readyState", nextReadyState);
		this.logger.info("set readyState to: %d", nextReadyState);
		if (nextReadyState !== this.request.UNSENT) {
			this.logger.info("triggering \"readystatechange\" event...");
			this.trigger("readystatechange", this.request);
		}
	}
	/**
	* Triggers given event on the `XMLHttpRequest` instance.
	*/
	trigger(eventName, target, options) {
		const callback = target[`on${eventName}`];
		const event = createEvent(target, eventName, options);
		this.logger.info("trigger \"%s\"", eventName, options || "");
		if (typeof callback === "function") {
			this.logger.info("found a direct \"%s\" callback, calling...", eventName);
			callback.call(target, event);
		}
		const events = target instanceof XMLHttpRequestUpload ? this.uploadEvents : this.events;
		for (const [registeredEventName, listeners] of events) if (registeredEventName === eventName) {
			this.logger.info("found %d listener(s) for \"%s\" event, calling...", listeners.length, eventName);
			listeners.forEach((listener) => listener.call(target, event));
		}
	}
	/**
	* Converts this `XMLHttpRequest` instance into a Fetch API `Request` instance.
	*/
	toFetchApiRequest(body) {
		this.logger.info("converting request to a Fetch API Request...");
		const resolvedBody = body instanceof Document ? body.documentElement.innerText : body;
		const fetchRequest = new FetchRequest(this.url.href, {
			method: this.method,
			headers: this.requestHeaders,
			credentials: this.request.withCredentials ? "include" : "same-origin",
			body: ["GET", "HEAD"].includes(this.method.toUpperCase()) ? null : resolvedBody
		});
		define(fetchRequest, "headers", createProxy(fetchRequest.headers, { methodCall: ([methodName, args], invoke) => {
			switch (methodName) {
				case "append":
				case "set": {
					const [headerName, headerValue] = args;
					this.request.setRequestHeader(headerName, headerValue);
					break;
				}
				case "delete": {
					const [headerName] = args;
					console.warn(`XMLHttpRequest: Cannot remove a "${headerName}" header from the Fetch API representation of the "${fetchRequest.method} ${fetchRequest.url}" request. XMLHttpRequest headers cannot be removed.`);
					break;
				}
			}
			return invoke();
		} }));
		setRawRequest(fetchRequest, this.request);
		this.logger.info("converted request to a Fetch API Request!", fetchRequest);
		return fetchRequest;
	}
};
function toAbsoluteUrl(url) {
	if (typeof location === "undefined") return new URL(url);
	return new URL(url.toString(), location.href);
}
function define(target, property, value) {
	Reflect.defineProperty(target, property, {
		writable: true,
		enumerable: true,
		value
	});
}
function createXMLHttpRequestProxy({ emitter, logger }) {
	return new Proxy(globalThis.XMLHttpRequest, { construct(target, args, newTarget) {
		logger.info("constructed new XMLHttpRequest");
		const originalRequest = Reflect.construct(target, args, newTarget);
		const prototypeDescriptors = Object.getOwnPropertyDescriptors(target.prototype);
		for (const propertyName in prototypeDescriptors) Reflect.defineProperty(originalRequest, propertyName, prototypeDescriptors[propertyName]);
		const xhrRequestController = new XMLHttpRequestController(originalRequest, logger);
		xhrRequestController.onRequest = async function({ request, requestId }) {
			const controller = new RequestController(request, {
				passthrough: () => {
					this.logger.info("no mocked response received, performing request as-is...");
				},
				respondWith: async (response) => {
					if (isResponseError(response)) {
						this.errorWith(/* @__PURE__ */ new TypeError("Network error"));
						return;
					}
					await this.respondWith(response);
				},
				errorWith: (reason) => {
					this.logger.info("request errored!", { error: reason });
					if (reason instanceof Error) this.errorWith(reason);
				}
			});
			this.logger.info("awaiting mocked response...");
			this.logger.info("emitting the \"request\" event for %s listener(s)...", emitter.listenerCount("request"));
			await handleRequest({
				request,
				requestId,
				controller,
				emitter
			});
		};
		xhrRequestController.onResponse = async function({ response, isMockedResponse, request, requestId }) {
			this.logger.info("emitting the \"response\" event for %s listener(s)...", emitter.listenerCount("response"));
			emitter.emit("response", {
				response,
				isMockedResponse,
				request,
				requestId
			});
		};
		return xhrRequestController.request;
	} });
}
var XMLHttpRequestInterceptor = class XMLHttpRequestInterceptor2 extends Interceptor {
	static {
		this.symbol = /* @__PURE__ */ Symbol.for("xhr-interceptor");
	}
	constructor() {
		super(XMLHttpRequestInterceptor2.symbol);
	}
	checkEnvironment() {
		return hasConfigurableGlobal("XMLHttpRequest");
	}
	setup() {
		const logger = this.logger.extend("setup");
		logger.info("patching global XMLHttpRequest...");
		this.subscriptions.push(patchesRegistry.applyPatch(globalThis, "XMLHttpRequest", () => {
			return createXMLHttpRequestProxy({
				emitter: this.emitter,
				logger: this.logger
			});
		}));
		logger.info("global XMLHttpRequest patched!", globalThis.XMLHttpRequest.name);
	}
};
var FallbackHttpSource = class extends InterceptorSource {
	constructor(options) {
		super({ interceptors: [new XMLHttpRequestInterceptor(), new FetchInterceptor()] });
		this.options = options;
	}
	options;
	enable() {
		super.enable();
		if (!this.options.quiet) this.#printStartMessage();
	}
	disable() {
		super.disable();
		if (!this.options.quiet) this.#printStopMessage();
	}
	#printStartMessage() {
		console.groupCollapsed(`%c${devUtils.formatMessage("Mocking enabled (fallback mode).")}`, "color:orangered;font-weight:bold;");
		console.log("%cDocumentation: %chttps://mswjs.io/docs", "font-weight:bold", "font-weight:normal");
		console.log("Found an issue? https://github.com/mswjs/msw/issues");
		console.groupEnd();
	}
	#printStopMessage() {
		console.log(`%c${devUtils.formatMessage("Mocking disabled.")}`, "color:orangered;font-weight:bold;");
	}
};
var DEFAULT_WORKER_URL = "/mockServiceWorker.js";
function setupWorker(...handlers) {
	invariant(!isNodeProcess(), devUtils.formatMessage("Failed to execute `setupWorker` in a non-browser environment"));
	const network = defineNetwork({
		sources: [],
		handlers
	});
	return {
		async start(options) {
			if (options?.waitUntilReady != null) devUtils.warn(`The "waitUntilReady" option has been deprecated. Please remove it from this "worker.start()" call. Follow the recommended Browser integration (https://mswjs.io/docs/integrations/browser) to eliminate any race conditions between the Service Worker registration and any requests made by your application on initial render.`);
			if (network.readyState === NetworkReadyState.ENABLED) {
				devUtils.warn("Found a redundant \"worker.start()\" call. Note that starting the worker while mocking is already enabled will have no effect. Consider removing this \"worker.start()\" call.");
				return;
			}
			const httpSource = supportsServiceWorker() ? await ServiceWorkerSource.from({
				serviceWorker: {
					url: options?.serviceWorker?.url?.toString() || DEFAULT_WORKER_URL,
					options: options?.serviceWorker?.options
				},
				findWorker: options?.findWorker,
				quiet: options?.quiet
			}) : new FallbackHttpSource({ quiet: options?.quiet });
			network.configure({
				sources: [httpSource, new InterceptorSource({ interceptors: [new WebSocketInterceptor()] })],
				onUnhandledFrame: fromLegacyOnUnhandledRequest(() => {
					return options?.onUnhandledRequest || "warn";
				}),
				context: { quiet: options?.quiet }
			});
			await network.enable();
			if (httpSource instanceof ServiceWorkerSource) {
				const [, registration] = await httpSource.workerPromise;
				return registration;
			}
		},
		stop() {
			if (network.readyState === NetworkReadyState.DISABLED) {
				devUtils.warn(`Found a redundant "worker.stop()" call. Notice that stopping the worker after it has already been stopped has no effect. Consider removing this "worker.stop()" call.`);
				return;
			}
			network.disable();
			window.postMessage({ type: "msw/worker:stop" });
		},
		events: network.events,
		use: network.use.bind(network),
		resetHandlers: network.resetHandlers.bind(network),
		restoreHandlers: network.restoreHandlers.bind(network),
		listHandlers: network.listHandlers.bind(network)
	};
}
var SetupWorkerApi = class {
	start;
	stop;
	use;
	resetHandlers;
	restoreHandlers;
	listHandlers;
	events;
	constructor() {
		const worker = setupWorker();
		this.start = worker.start.bind(worker);
		this.stop = worker.stop.bind(worker);
		this.use = worker.use.bind(worker);
		this.resetHandlers = worker.resetHandlers.bind(worker);
		this.restoreHandlers = worker.restoreHandlers.bind(worker);
		this.listHandlers = worker.listHandlers.bind(worker);
		this.events = worker.events;
	}
};
//#endregion
export { SetupWorkerApi, setupWorker };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXN3X2Jyb3dzZXIuanMiLCJuYW1lcyI6WyJFbWl0dGVyIiwiVHlwZWRFdmVudCIsIkVtaXR0ZXIiLCJUeXBlZEV2ZW50IiwiY3JlYXRlUmVxdWVzdElkIiwidW50aWwiLCJFbWl0dGVyIiwiZW1pdEFzeW5jIiwiUGF0Y2hlc1JlZ2lzdHJ5IiwiI3JlcGxhY2VtZW50cyIsImdldERlZXBQcm9wZXJ0eURlc2NyaXB0b3IiLCJwYXRjaGVzUmVnaXN0cnkiLCJoYXNDb25maWd1cmFibGVHbG9iYWwiLCJiaW5kRXZlbnQiLCJrQ2FuY2VsYWJsZSIsImtEZWZhdWx0UHJldmVudGVkIiwiQ2FuY2VsYWJsZU1lc3NhZ2VFdmVudCIsIkNsb3NlRXZlbnQiLCJDYW5jZWxhYmxlQ2xvc2VFdmVudCIsImtFbWl0dGVyJDEiLCJrQm91bmRMaXN0ZW5lciQxIiwiV2ViU29ja2V0Q2xpZW50Q29ubmVjdGlvbiIsImNyZWF0ZVJlcXVlc3RJZCIsIldFQlNPQ0tFVF9DTE9TRV9DT0RFX1JBTkdFX0VSUk9SIiwia1Bhc3N0aHJvdWdoUHJvbWlzZSIsImtPblNlbmQiLCJrQ2xvc2UiLCJXZWJTb2NrZXRPdmVycmlkZSIsInJlc29sdmVXZWJTb2NrZXRVcmwiLCJEZWZlcnJlZFByb21pc2UiLCJnZXREYXRhU2l6ZSIsImtFbWl0dGVyIiwia0JvdW5kTGlzdGVuZXIiLCJrU2VuZCIsIldlYlNvY2tldFNlcnZlckNvbm5lY3Rpb24iLCJXZWJTb2NrZXRDbGFzc1RyYW5zcG9ydCIsIldlYlNvY2tldEludGVyY2VwdG9yIiwiSW50ZXJjZXB0b3IiLCJoYXNDb25maWd1cmFibGVHbG9iYWwiLCJlbWl0QXN5bmMiLCJwYXRjaGVzUmVnaXN0cnkiLCJUeXBlZEV2ZW50IiwiI2ludGVyY2VwdG9yIiwiI2ZyYW1lcyIsIiNoYW5kbGVSZXF1ZXN0IiwiI2hhbmRsZVJlc3BvbnNlIiwiI2hhbmRsZVdlYlNvY2tldENvbm5lY3Rpb24iLCIjY29udHJvbGxlciIsIiNyZXBsYWNlbWVudHMiLCIjZXhlY3V0b3IiLCIjZGVjb3JhdGUiLCIjaGFuZGxlZCIsIiNyZXNvbHZlUHJvcGVydHkiLCIjc2V0SW50ZXJuYWxQcm9wZXJ0eSIsIiNsaXN0IiwiI2xlbnMiLCIjb3BlbkxlbnMiLCIjbGlzdGVuZXJzIiwiI2xpc3RlbmVyT3B0aW9ucyIsIiNsaXN0ZW5lckFib3J0Q2xlYW51cHMiLCIjdHlwZWxlc3NMaXN0ZW5lcnMiLCIjaG9va0xpc3RlbmVycyIsIiNob29rTGlzdGVuZXJPcHRpb25zIiwiI2hvb2tMaXN0ZW5lckFib3J0Q2xlYW51cHMiLCIjZGVsZXRlSG9va0xpc3RlbmVyIiwiI2FkZExpc3RlbmVyIiwiI3Byb3h5RXZlbnQiLCIjbWF0Y2hMaXN0ZW5lcnMiLCIjY2FsbExpc3RlbmVyIiwiI2lzVHlwZWxlc3NMaXN0ZW5lciIsIiNkZWxldGVMaXN0ZW5lciIsIiN3b3JrZXJFdmVudCIsIiNnZXRXb3JrZXIiLCIjY29udHJvbGxlciIsIiNjdXJyZW50IiwiI29wdGlvbnMiLCIjZnJhbWVzIiwiI2NoYW5uZWwiLCIjc3RvcHBlZEF0IiwiI2xpc3RlbmVyQ29udHJvbGxlciIsIiNzdGFydFdvcmtlciIsIiNjbGllbnRQcm9taXNlIiwiI3ByaW50U3RhcnRNZXNzYWdlIiwiI3ByaW50U3RvcE1lc3NhZ2UiLCIja2VlcEFsaXZlSW50ZXJ2YWwiLCIjZGVmYXVsdEZpbmRXb3JrZXIiLCJkZXZVdGlsczMiLCIjaGFuZGxlUmVxdWVzdCIsIiNoYW5kbGVSZXNwb25zZSIsIiNjaGVja1dvcmtlckludGVncml0eSIsIiNldmVudCIsIiNyZXNwb25kV2l0aCIsImRldlV0aWxzNCIsImRldlV0aWxzNSIsIkludGVyY2VwdG9yU291cmNlMiJdLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvZXhwZXJpbWVudGFsL2ZyYW1lcy9uZXR3b3JrLWZyYW1lLm1qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvZXhwZXJpbWVudGFsL3NvdXJjZXMvbmV0d29yay1zb3VyY2UubWpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS9leHBlcmltZW50YWwvcmVxdWVzdC11dGlscy5tanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2V4cGVyaW1lbnRhbC9mcmFtZXMvaHR0cC1mcmFtZS5tanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2V4cGVyaW1lbnRhbC9vbi11bmhhbmRsZWQtZnJhbWUubWpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS9leHBlcmltZW50YWwvZGVmaW5lLW5ldHdvcmsubWpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0Btc3dqcy9pbnRlcmNlcHRvcnMvbGliL2Jyb3dzZXIvaGFzQ29uZmlndXJhYmxlR2xvYmFsLUM4enExTUNnLm1qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL2ludGVyY2VwdG9ycy9XZWJTb2NrZXQvaW5kZXgubWpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS9leHBlcmltZW50YWwvZnJhbWVzL3dlYnNvY2tldC1mcmFtZS5tanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2V4cGVyaW1lbnRhbC9zb3VyY2VzL2ludGVyY2VwdG9yLXNvdXJjZS5tanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2V4cGVyaW1lbnRhbC9jb21wYXQubWpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy90b1Jlc3BvbnNlSW5pdC5tanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbXN3L2xpYi9icm93c2VyL2luZGV4Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFbWl0dGVyIH0gZnJvbSBcInJldHRpbWVcIjtcbmNsYXNzIE5ldHdvcmtGcmFtZSB7XG4gIGNvbnN0cnVjdG9yKHByb3RvY29sLCBkYXRhKSB7XG4gICAgdGhpcy5wcm90b2NvbCA9IHByb3RvY29sO1xuICAgIHRoaXMuZGF0YSA9IGRhdGE7XG4gICAgdGhpcy5ldmVudHMgPSBuZXcgRW1pdHRlcigpO1xuICB9XG4gIHByb3RvY29sO1xuICBkYXRhO1xuICBldmVudHM7XG59XG5leHBvcnQge1xuICBOZXR3b3JrRnJhbWVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1uZXR3b3JrLWZyYW1lLm1qcy5tYXAiLCJpbXBvcnQgeyBFbWl0dGVyLCBUeXBlZEV2ZW50IH0gZnJvbSBcInJldHRpbWVcIjtcbmltcG9ydCB7XG59IGZyb20gJy4uL2ZyYW1lcy9uZXR3b3JrLWZyYW1lLm1qcyc7XG5jbGFzcyBOZXR3b3JrRnJhbWVFdmVudCBleHRlbmRzIFR5cGVkRXZlbnQge1xuICBmcmFtZTtcbiAgY29uc3RydWN0b3IodHlwZSwgZnJhbWUpIHtcbiAgICBzdXBlciguLi5bdHlwZSwge31dKTtcbiAgICB0aGlzLmZyYW1lID0gZnJhbWU7XG4gIH1cbn1cbmNsYXNzIE5ldHdvcmtTb3VyY2Uge1xuICBlbWl0dGVyO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmVtaXR0ZXIgPSBuZXcgRW1pdHRlcigpO1xuICB9XG4gIGFzeW5jIHF1ZXVlKGZyYW1lKSB7XG4gICAgYXdhaXQgdGhpcy5lbWl0dGVyLmVtaXRBc1Byb21pc2UoXG4gICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIFRyb3VibGUgaGFuZGxpbmcgYSBjb25kaXRpb25hbCB0eXBlIHBhcmFtZXRlci5cbiAgICAgIG5ldyBOZXR3b3JrRnJhbWVFdmVudChcImZyYW1lXCIsIGZyYW1lKVxuICAgICk7XG4gIH1cbiAgb24odHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcbiAgICB0aGlzLmVtaXR0ZXIub24odHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpO1xuICB9XG4gIGRpc2FibGUoKSB7XG4gICAgdGhpcy5lbWl0dGVyLnJlbW92ZUFsbExpc3RlbmVycygpO1xuICB9XG59XG5leHBvcnQge1xuICBOZXR3b3JrU291cmNlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bmV0d29yay1zb3VyY2UubWpzLm1hcCIsImNvbnN0IFJFUVVFU1RfSU5URU5USU9OX0hFQURFUl9OQU1FID0gXCJ4LW1zdy1pbnRlbnRpb25cIjtcbnZhciBSZXF1ZXN0SW50ZW50aW9uID0gLyogQF9fUFVSRV9fICovICgoUmVxdWVzdEludGVudGlvbjIpID0+IHtcbiAgUmVxdWVzdEludGVudGlvbjJbXCJwYXNzdGhyb3VnaFwiXSA9IFwicGFzc3Rocm91Z2hcIjtcbiAgcmV0dXJuIFJlcXVlc3RJbnRlbnRpb24yO1xufSkoUmVxdWVzdEludGVudGlvbiB8fCB7fSk7XG5mdW5jdGlvbiBzaG91bGRCeXBhc3NSZXF1ZXN0KHJlcXVlc3QpIHtcbiAgcmV0dXJuICEhcmVxdWVzdC5oZWFkZXJzLmdldChcImFjY2VwdFwiKT8uaW5jbHVkZXMoXCJtc3cvcGFzc3Rocm91Z2hcIik7XG59XG5mdW5jdGlvbiBpc1Bhc3N0aHJvdWdoUmVzcG9uc2UocmVzcG9uc2UpIHtcbiAgcmV0dXJuIHJlc3BvbnNlLnN0YXR1cyA9PT0gMzAyICYmIHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFJFUVVFU1RfSU5URU5USU9OX0hFQURFUl9OQU1FKSA9PT0gXCJwYXNzdGhyb3VnaFwiIC8qIHBhc3N0aHJvdWdoICovO1xufVxuZnVuY3Rpb24gZGVsZXRlUmVxdWVzdFBhc3N0aHJvdWdoSGVhZGVyKHJlcXVlc3QpIHtcbiAgY29uc3QgYWNjZXB0SGVhZGVyID0gcmVxdWVzdC5oZWFkZXJzLmdldChcImFjY2VwdFwiKTtcbiAgaWYgKGFjY2VwdEhlYWRlcikge1xuICAgIGNvbnN0IG5leHRBY2NlcHRIZWFkZXIgPSBhY2NlcHRIZWFkZXIucmVwbGFjZSgvKCxcXHMrKT9tc3dcXC9wYXNzdGhyb3VnaC8sIFwiXCIpO1xuICAgIGlmIChuZXh0QWNjZXB0SGVhZGVyKSB7XG4gICAgICByZXF1ZXN0LmhlYWRlcnMuc2V0KFwiYWNjZXB0XCIsIG5leHRBY2NlcHRIZWFkZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXF1ZXN0LmhlYWRlcnMuZGVsZXRlKFwiYWNjZXB0XCIpO1xuICAgIH1cbiAgfVxufVxuZXhwb3J0IHtcbiAgUkVRVUVTVF9JTlRFTlRJT05fSEVBREVSX05BTUUsXG4gIFJlcXVlc3RJbnRlbnRpb24sXG4gIGRlbGV0ZVJlcXVlc3RQYXNzdGhyb3VnaEhlYWRlcixcbiAgaXNQYXNzdGhyb3VnaFJlc3BvbnNlLFxuICBzaG91bGRCeXBhc3NSZXF1ZXN0XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVxdWVzdC11dGlscy5tanMubWFwIiwiaW1wb3J0IHsgVHlwZWRFdmVudCB9IGZyb20gXCJyZXR0aW1lXCI7XG5pbXBvcnQgeyB1bnRpbCB9IGZyb20gXCJ1bnRpbC1hc3luY1wiO1xuaW1wb3J0IHsgY3JlYXRlUmVxdWVzdElkIH0gZnJvbSBcIkBtc3dqcy9pbnRlcmNlcHRvcnNcIjtcbmltcG9ydCB7XG4gIE5ldHdvcmtGcmFtZVxufSBmcm9tICcuL25ldHdvcmstZnJhbWUubWpzJztcbmltcG9ydCB7IHRvUHVibGljVXJsIH0gZnJvbSAnLi4vLi4vdXRpbHMvcmVxdWVzdC90b1B1YmxpY1VybC5tanMnO1xuaW1wb3J0IHsgZXhlY3V0ZUhhbmRsZXJzIH0gZnJvbSAnLi4vLi4vdXRpbHMvZXhlY3V0ZUhhbmRsZXJzLm1qcyc7XG5pbXBvcnQgeyBzdG9yZVJlc3BvbnNlQ29va2llcyB9IGZyb20gJy4uLy4uL3V0aWxzL3JlcXVlc3Qvc3RvcmVSZXNwb25zZUNvb2tpZXMubWpzJztcbmltcG9ydCB7IGlzUGFzc3Rocm91Z2hSZXNwb25zZSwgc2hvdWxkQnlwYXNzUmVxdWVzdCB9IGZyb20gJy4uL3JlcXVlc3QtdXRpbHMubWpzJztcbmltcG9ydCB7IGRldlV0aWxzIH0gZnJvbSAnLi4vLi4vdXRpbHMvaW50ZXJuYWwvZGV2VXRpbHMubWpzJztcbmltcG9ydCB7XG4gIGV4ZWN1dGVVbmhhbmRsZWRGcmFtZUhhbmRsZVxufSBmcm9tICcuLi9vbi11bmhhbmRsZWQtZnJhbWUubWpzJztcbmltcG9ydCB7fSBmcm9tICcuLi9oYW5kbGVycy1jb250cm9sbGVyLm1qcyc7XG5pbXBvcnQge30gZnJvbSAnLi4vLi4vaGFuZGxlcnMvUmVxdWVzdEhhbmRsZXIubWpzJztcbmNsYXNzIFJlcXVlc3RFdmVudCBleHRlbmRzIFR5cGVkRXZlbnQge1xuICByZXF1ZXN0SWQ7XG4gIHJlcXVlc3Q7XG4gIGNvbnN0cnVjdG9yKHR5cGUsIGRhdGEpIHtcbiAgICBzdXBlciguLi5bdHlwZSwge31dKTtcbiAgICB0aGlzLnJlcXVlc3RJZCA9IGRhdGEucmVxdWVzdElkO1xuICAgIHRoaXMucmVxdWVzdCA9IGRhdGEucmVxdWVzdDtcbiAgfVxufVxuY2xhc3MgUmVzcG9uc2VFdmVudCBleHRlbmRzIFR5cGVkRXZlbnQge1xuICByZXF1ZXN0SWQ7XG4gIHJlcXVlc3Q7XG4gIHJlc3BvbnNlO1xuICBjb25zdHJ1Y3Rvcih0eXBlLCBkYXRhKSB7XG4gICAgc3VwZXIoLi4uW3R5cGUsIHt9XSk7XG4gICAgdGhpcy5yZXF1ZXN0SWQgPSBkYXRhLnJlcXVlc3RJZDtcbiAgICB0aGlzLnJlcXVlc3QgPSBkYXRhLnJlcXVlc3Q7XG4gICAgdGhpcy5yZXNwb25zZSA9IGRhdGEucmVzcG9uc2U7XG4gIH1cbn1cbmNsYXNzIFVuaGFuZGxlZEV4Y2VwdGlvbkV2ZW50IGV4dGVuZHMgVHlwZWRFdmVudCB7XG4gIGVycm9yO1xuICByZXF1ZXN0SWQ7XG4gIHJlcXVlc3Q7XG4gIGNvbnN0cnVjdG9yKHR5cGUsIGRhdGEpIHtcbiAgICBzdXBlciguLi5bdHlwZSwge31dKTtcbiAgICB0aGlzLmVycm9yID0gZGF0YS5lcnJvcjtcbiAgICB0aGlzLnJlcXVlc3RJZCA9IGRhdGEucmVxdWVzdElkO1xuICAgIHRoaXMucmVxdWVzdCA9IGRhdGEucmVxdWVzdDtcbiAgfVxufVxuY2xhc3MgSHR0cE5ldHdvcmtGcmFtZSBleHRlbmRzIE5ldHdvcmtGcmFtZSB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICBjb25zdCBpZCA9IG9wdGlvbnMuaWQgfHwgY3JlYXRlUmVxdWVzdElkKCk7XG4gICAgc3VwZXIoXCJodHRwXCIsIHsgaWQsIHJlcXVlc3Q6IG9wdGlvbnMucmVxdWVzdCB9KTtcbiAgfVxuICBnZXRIYW5kbGVycyhjb250cm9sbGVyKSB7XG4gICAgcmV0dXJuIGNvbnRyb2xsZXIuZ2V0SGFuZGxlcnNCeUtpbmQoXCJyZXF1ZXN0XCIpO1xuICB9XG4gIGFzeW5jIGdldFVuaGFuZGxlZE1lc3NhZ2UoKSB7XG4gICAgY29uc3QgeyByZXF1ZXN0IH0gPSB0aGlzLmRhdGE7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChyZXF1ZXN0LnVybCk7XG4gICAgY29uc3QgcHVibGljVXJsID0gdG9QdWJsaWNVcmwodXJsKSArIHVybC5zZWFyY2g7XG4gICAgY29uc3QgcmVxdWVzdEJvZHkgPSByZXF1ZXN0LmJvZHkgPT0gbnVsbCA/IG51bGwgOiBhd2FpdCByZXF1ZXN0LmNsb25lKCkudGV4dCgpO1xuICAgIGNvbnN0IGRldGFpbHMgPSBgXG5cbiAgXFx1MjAyMiAke3JlcXVlc3QubWV0aG9kfSAke3B1YmxpY1VybH1cblxuJHtyZXF1ZXN0Qm9keSA/IGAgIFxcdTIwMjIgUmVxdWVzdCBib2R5OiAke3JlcXVlc3RCb2R5fVxuXG5gIDogXCJcIn1gO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBgaW50ZXJjZXB0ZWQgYSByZXF1ZXN0IHdpdGhvdXQgYSBtYXRjaGluZyByZXF1ZXN0IGhhbmRsZXI6JHtkZXRhaWxzfUlmIHlvdSBzdGlsbCB3aXNoIHRvIGludGVyY2VwdCB0aGlzIHVuaGFuZGxlZCByZXF1ZXN0LCBwbGVhc2UgY3JlYXRlIGEgcmVxdWVzdCBoYW5kbGVyIGZvciBpdC5cblJlYWQgbW9yZTogaHR0cHM6Ly9tc3dqcy5pby9kb2NzL2h0dHAvaW50ZXJjZXB0aW5nLXJlcXVlc3RzYDtcbiAgICByZXR1cm4gbWVzc2FnZTtcbiAgfVxuICBhc3luYyByZXNvbHZlKGhhbmRsZXJzLCBvblVuaGFuZGxlZEZyYW1lLCByZXNvbHV0aW9uQ29udGV4dCkge1xuICAgIGNvbnN0IHsgaWQ6IHJlcXVlc3RJZCwgcmVxdWVzdCB9ID0gdGhpcy5kYXRhO1xuICAgIGNvbnN0IHJlcXVlc3RDbG9uZUZvckxvZ3MgPSByZXNvbHV0aW9uQ29udGV4dD8ucXVpZXQgPyBudWxsIDogcmVxdWVzdC5jbG9uZSgpO1xuICAgIHRoaXMuZXZlbnRzLmVtaXQobmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6c3RhcnRcIiwgeyByZXF1ZXN0SWQsIHJlcXVlc3QgfSkpO1xuICAgIGlmIChzaG91bGRCeXBhc3NSZXF1ZXN0KHJlcXVlc3QpKSB7XG4gICAgICB0aGlzLmV2ZW50cy5lbWl0KG5ldyBSZXF1ZXN0RXZlbnQoXCJyZXF1ZXN0OmVuZFwiLCB7IHJlcXVlc3RJZCwgcmVxdWVzdCB9KSk7XG4gICAgICB0aGlzLnBhc3N0aHJvdWdoKCk7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgW2xvb2t1cEVycm9yLCBsb29rdXBSZXN1bHRdID0gYXdhaXQgdW50aWwoKCkgPT4ge1xuICAgICAgcmV0dXJuIGV4ZWN1dGVIYW5kbGVycyh7XG4gICAgICAgIHJlcXVlc3RJZCxcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgaGFuZGxlcnMsXG4gICAgICAgIHJlc29sdXRpb25Db250ZXh0OiB7XG4gICAgICAgICAgYmFzZVVybDogcmVzb2x1dGlvbkNvbnRleHQ/LmJhc2VVcmw/LnRvU3RyaW5nKCksXG4gICAgICAgICAgcXVpZXQ6IHJlc29sdXRpb25Db250ZXh0Py5xdWlldFxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICBpZiAobG9va3VwRXJyb3IgIT0gbnVsbCkge1xuICAgICAgaWYgKCF0aGlzLmV2ZW50cy5lbWl0KFxuICAgICAgICBuZXcgVW5oYW5kbGVkRXhjZXB0aW9uRXZlbnQoXCJ1bmhhbmRsZWRFeGNlcHRpb25cIiwge1xuICAgICAgICAgIGVycm9yOiBsb29rdXBFcnJvcixcbiAgICAgICAgICByZXF1ZXN0SWQsXG4gICAgICAgICAgcmVxdWVzdFxuICAgICAgICB9KVxuICAgICAgKSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKGxvb2t1cEVycm9yKTtcbiAgICAgICAgZGV2VXRpbHMuZXJyb3IoXG4gICAgICAgICAgJ0VuY291bnRlcmVkIGFuIHVuaGFuZGxlZCBleGNlcHRpb24gZHVyaW5nIHRoZSBoYW5kbGVyIGxvb2t1cCBmb3IgXCIlcyAlc1wiLiBQbGVhc2Ugc2VlIHRoZSBvcmlnaW5hbCBlcnJvciBhYm92ZS4nLFxuICAgICAgICAgIHJlcXVlc3QubWV0aG9kLFxuICAgICAgICAgIHJlcXVlc3QudXJsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICB0aGlzLmVycm9yV2l0aChsb29rdXBFcnJvcik7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKGxvb2t1cFJlc3VsdCA9PSBudWxsKSB7XG4gICAgICB0aGlzLmV2ZW50cy5lbWl0KFxuICAgICAgICBuZXcgUmVxdWVzdEV2ZW50KFwicmVxdWVzdDp1bmhhbmRsZWRcIiwge1xuICAgICAgICAgIHJlcXVlc3RJZCxcbiAgICAgICAgICByZXF1ZXN0XG4gICAgICAgIH0pXG4gICAgICApO1xuICAgICAgYXdhaXQgZXhlY3V0ZVVuaGFuZGxlZEZyYW1lSGFuZGxlKHRoaXMsIG9uVW5oYW5kbGVkRnJhbWUpLnRoZW4oXG4gICAgICAgICgpID0+IHRoaXMucGFzc3Rocm91Z2goKSxcbiAgICAgICAgKGVycm9yKSA9PiB0aGlzLmVycm9yV2l0aChlcnJvcilcbiAgICAgICk7XG4gICAgICB0aGlzLmV2ZW50cy5lbWl0KFxuICAgICAgICBuZXcgUmVxdWVzdEV2ZW50KFwicmVxdWVzdDplbmRcIiwge1xuICAgICAgICAgIHJlcXVlc3RJZCxcbiAgICAgICAgICByZXF1ZXN0XG4gICAgICAgIH0pXG4gICAgICApO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCB7IHJlc3BvbnNlLCBoYW5kbGVyLCBwYXJzZWRSZXN1bHQgfSA9IGxvb2t1cFJlc3VsdDtcbiAgICB0aGlzLmV2ZW50cy5lbWl0KFxuICAgICAgbmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6bWF0Y2hcIiwge1xuICAgICAgICByZXF1ZXN0SWQsXG4gICAgICAgIHJlcXVlc3RcbiAgICAgIH0pXG4gICAgKTtcbiAgICBpZiAocmVzcG9uc2UgPT0gbnVsbCkge1xuICAgICAgdGhpcy5ldmVudHMuZW1pdChcbiAgICAgICAgbmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6ZW5kXCIsIHtcbiAgICAgICAgICByZXF1ZXN0SWQsXG4gICAgICAgICAgcmVxdWVzdFxuICAgICAgICB9KVxuICAgICAgKTtcbiAgICAgIHRoaXMucGFzc3Rocm91Z2goKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAoaXNQYXNzdGhyb3VnaFJlc3BvbnNlKHJlc3BvbnNlKSkge1xuICAgICAgdGhpcy5ldmVudHMuZW1pdChcbiAgICAgICAgbmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6ZW5kXCIsIHtcbiAgICAgICAgICByZXF1ZXN0SWQsXG4gICAgICAgICAgcmVxdWVzdFxuICAgICAgICB9KVxuICAgICAgKTtcbiAgICAgIHRoaXMucGFzc3Rocm91Z2goKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCByZXNwb25zZUNsb25lRm9yTG9ncyA9IHJlc29sdXRpb25Db250ZXh0Py5xdWlldCA/IG51bGwgOiByZXNwb25zZS5jbG9uZSgpO1xuICAgIGF3YWl0IHN0b3JlUmVzcG9uc2VDb29raWVzKHJlcXVlc3QsIHJlc3BvbnNlKTtcbiAgICB0aGlzLnJlc3BvbmRXaXRoKHJlc3BvbnNlKTtcbiAgICB0aGlzLmV2ZW50cy5lbWl0KFxuICAgICAgbmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6ZW5kXCIsIHtcbiAgICAgICAgcmVxdWVzdElkLFxuICAgICAgICByZXF1ZXN0XG4gICAgICB9KVxuICAgICk7XG4gICAgaWYgKCFyZXNvbHV0aW9uQ29udGV4dD8ucXVpZXQpIHtcbiAgICAgIGhhbmRsZXIubG9nKHtcbiAgICAgICAgcmVxdWVzdDogcmVxdWVzdENsb25lRm9yTG9ncyxcbiAgICAgICAgcmVzcG9uc2U6IHJlc3BvbnNlQ2xvbmVGb3JMb2dzLFxuICAgICAgICBwYXJzZWRSZXN1bHRcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufVxuZXhwb3J0IHtcbiAgSHR0cE5ldHdvcmtGcmFtZSxcbiAgUmVxdWVzdEV2ZW50LFxuICBSZXNwb25zZUV2ZW50LFxuICBVbmhhbmRsZWRFeGNlcHRpb25FdmVudFxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWh0dHAtZnJhbWUubWpzLm1hcCIsImltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCJvdXR2YXJpYW50XCI7XG5pbXBvcnQgeyBpc0NvbW1vbkFzc2V0UmVxdWVzdCB9IGZyb20gJy4uL2lzQ29tbW9uQXNzZXRSZXF1ZXN0Lm1qcyc7XG5pbXBvcnQgeyBkZXZVdGlscywgSW50ZXJuYWxFcnJvciB9IGZyb20gJy4uL3V0aWxzL2ludGVybmFsL2RldlV0aWxzLm1qcyc7XG5pbXBvcnQgeyBIdHRwTmV0d29ya0ZyYW1lIH0gZnJvbSAnLi9mcmFtZXMvaHR0cC1mcmFtZS5tanMnO1xuaW1wb3J0IHt9IGZyb20gJy4vZnJhbWVzL25ldHdvcmstZnJhbWUubWpzJztcbmFzeW5jIGZ1bmN0aW9uIGV4ZWN1dGVVbmhhbmRsZWRGcmFtZUhhbmRsZShmcmFtZSwgaGFuZGxlKSB7XG4gIGNvbnN0IHByaW50U3RyYXRlZ3lNZXNzYWdlID0gYXN5bmMgKHN0cmF0ZWd5KSA9PiB7XG4gICAgaWYgKHN0cmF0ZWd5ID09PSBcImJ5cGFzc1wiKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG1lc3NhZ2UgPSBhd2FpdCBmcmFtZS5nZXRVbmhhbmRsZWRNZXNzYWdlKCk7XG4gICAgc3dpdGNoIChzdHJhdGVneSkge1xuICAgICAgY2FzZSBcIndhcm5cIjoge1xuICAgICAgICByZXR1cm4gZGV2VXRpbHMud2FybihcIldhcm5pbmc6ICVzXCIsIG1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgY2FzZSBcImVycm9yXCI6IHtcbiAgICAgICAgcmV0dXJuIGRldlV0aWxzLmVycm9yKFwiRXJyb3I6ICVzXCIsIG1lc3NhZ2UpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgY29uc3QgYXBwbHlTdHJhdGVneSA9IGFzeW5jIChzdHJhdGVneSkgPT4ge1xuICAgIGludmFyaWFudC5hcyhcbiAgICAgIEludGVybmFsRXJyb3IsXG4gICAgICBzdHJhdGVneSA9PT0gXCJieXBhc3NcIiB8fCBzdHJhdGVneSA9PT0gXCJ3YXJuXCIgfHwgc3RyYXRlZ3kgPT09IFwiZXJyb3JcIixcbiAgICAgIC8qKlxuICAgICAgICogQGZpeG1lIFJlbmFtZSBcIm9uVW5oYW5kbGVkUmVxdWVzdFwiIHRvIFwib25VbmhhbmRsZWRGcmFtZVwiIGluIHRoZSBlcnJvciBtZXNzYWdlXG4gICAgICAgKiB3aXRoIHRoZSBuZXh0IG1ham9yIHJlbGVhc2UuXG4gICAgICAgKi9cbiAgICAgIGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXG4gICAgICAgICdGYWlsZWQgdG8gcmVhY3QgdG8gYW4gdW5oYW5kbGVkIG5ldHdvcmsgZnJhbWU6IHVua25vd24gc3RyYXRlZ3kgXCIlc1wiLiBQbGVhc2UgcHJvdmlkZSBvbmUgb2YgdGhlIHN1cHBvcnRlZCBzdHJhdGVnaWVzIChcImJ5cGFzc1wiLCBcIndhcm5cIiwgXCJlcnJvclwiKSBvciBhIGN1c3RvbSBjYWxsYmFjayBmdW5jdGlvbiBhcyB0aGUgdmFsdWUgb2YgdGhlIFwib25VbmhhbmRsZWRSZXF1ZXN0XCIgb3B0aW9uLicsXG4gICAgICAgIHN0cmF0ZWd5XG4gICAgICApXG4gICAgKTtcbiAgICBpZiAoc3RyYXRlZ3kgPT09IFwiYnlwYXNzXCIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYXdhaXQgcHJpbnRTdHJhdGVneU1lc3NhZ2Uoc3RyYXRlZ3kpO1xuICAgIGlmIChzdHJhdGVneSA9PT0gXCJlcnJvclwiKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoXG4gICAgICAgIG5ldyBJbnRlcm5hbEVycm9yKFxuICAgICAgICAgIGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXG4gICAgICAgICAgICAnQ2Fubm90IGJ5cGFzcyBhIHJlcXVlc3Qgd2hlbiB1c2luZyB0aGUgXCJlcnJvclwiIHN0cmF0ZWd5IGZvciB0aGUgXCJvblVuaGFuZGxlZFJlcXVlc3RcIiBvcHRpb24uJ1xuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKTtcbiAgICB9XG4gIH07XG4gIGlmICh0eXBlb2YgaGFuZGxlID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICByZXR1cm4gaGFuZGxlKHtcbiAgICAgIGZyYW1lLFxuICAgICAgZGVmYXVsdHM6IHtcbiAgICAgICAgd2FybjogcHJpbnRTdHJhdGVneU1lc3NhZ2UuYmluZChudWxsLCBcIndhcm5cIiksXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBAbm90ZSBUaGUgZGVmYXVsdHMgb25seSBwcmludCB0aGUgY29ycmVzcG9uZGluZyBtZXNzYWdlcyBub3cuXG4gICAgICAgICAqIFRoZXkgZG8gbm90IGFmZmVjdCB0aGUgZnJhbWUgcmVzb2x1dGlvbiAoZS5nLiBkbyBub3QgZXJyb3IgdGhlIGZyYW1lKS5cbiAgICAgICAgICogVGhhdCBpcyBvbmx5IGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5IHJlYXNvbnMuIEluIHRoZSBmdXR1cmUsIHRoZXNlIHNob3VsZFxuICAgICAgICAgKiBiZSBhbiBhbGlhcyB0byBgYXBwbHlTdHJhdGVneS5iaW5kKG51bGwsICdlcnJvcicpYCBpbnN0ZWFkLlxuICAgICAgICAgKi9cbiAgICAgICAgZXJyb3I6IHByaW50U3RyYXRlZ3lNZXNzYWdlLmJpbmQobnVsbCwgXCJlcnJvclwiKVxuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIGlmIChmcmFtZSBpbnN0YW5jZW9mIEh0dHBOZXR3b3JrRnJhbWUgJiYgaXNDb21tb25Bc3NldFJlcXVlc3QoZnJhbWUuZGF0YS5yZXF1ZXN0KSkge1xuICAgIHJldHVybjtcbiAgfVxuICByZXR1cm4gYXBwbHlTdHJhdGVneShoYW5kbGUpO1xufVxuZXhwb3J0IHtcbiAgZXhlY3V0ZVVuaGFuZGxlZEZyYW1lSGFuZGxlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9b24tdW5oYW5kbGVkLWZyYW1lLm1qcy5tYXAiLCJpbXBvcnQgeyBpbnZhcmlhbnQgfSBmcm9tIFwib3V0dmFyaWFudFwiO1xuaW1wb3J0IHsgRW1pdHRlciB9IGZyb20gXCJyZXR0aW1lXCI7XG5pbXBvcnQge1xuICBOZXR3b3JrU291cmNlXG59IGZyb20gJy4vc291cmNlcy9uZXR3b3JrLXNvdXJjZS5tanMnO1xuaW1wb3J0IHt9IGZyb20gJy4vZnJhbWVzL25ldHdvcmstZnJhbWUubWpzJztcbmltcG9ydCB7fSBmcm9tICcuL29uLXVuaGFuZGxlZC1mcmFtZS5tanMnO1xuaW1wb3J0IHtcbiAgSGFuZGxlcnNDb250cm9sbGVyLFxuICBJbk1lbW9yeUhhbmRsZXJzQ29udHJvbGxlclxufSBmcm9tICcuL2hhbmRsZXJzLWNvbnRyb2xsZXIubWpzJztcbmltcG9ydCB7IHRvUmVhZG9ubHlBcnJheSB9IGZyb20gJy4uL3V0aWxzL2ludGVybmFsL3RvUmVhZG9ubHlBcnJheS5tanMnO1xuaW1wb3J0IHsgRGlzcG9zYWJsZSB9IGZyb20gJy4uL3V0aWxzL2ludGVybmFsL0Rpc3Bvc2FibGUubWpzJztcbmZ1bmN0aW9uIGNvbG9ybGVzc1Byb21pc2VBbGwodmFsdWVzKSB7XG4gIGNvbnN0IHByb21pc2VzID0gW107XG4gIGZvciAoY29uc3QgdmFsdWUgb2YgdmFsdWVzKSB7XG4gICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgUHJvbWlzZSkge1xuICAgICAgcHJvbWlzZXMucHVzaCh2YWx1ZSk7XG4gICAgfVxuICB9XG4gIGlmIChwcm9taXNlcy5sZW5ndGggPiAwKSB7XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzKS50aGVuKCgpID0+IHtcbiAgICB9KTtcbiAgfVxufVxudmFyIE5ldHdvcmtSZWFkeVN0YXRlID0gLyogQF9fUFVSRV9fICovICgoTmV0d29ya1JlYWR5U3RhdGUyKSA9PiB7XG4gIE5ldHdvcmtSZWFkeVN0YXRlMltOZXR3b3JrUmVhZHlTdGF0ZTJbXCJESVNBQkxFRFwiXSA9IDBdID0gXCJESVNBQkxFRFwiO1xuICBOZXR3b3JrUmVhZHlTdGF0ZTJbTmV0d29ya1JlYWR5U3RhdGUyW1wiRU5BQkxFRFwiXSA9IDFdID0gXCJFTkFCTEVEXCI7XG4gIHJldHVybiBOZXR3b3JrUmVhZHlTdGF0ZTI7XG59KShOZXR3b3JrUmVhZHlTdGF0ZSB8fCB7fSk7XG5mdW5jdGlvbiBkZWZpbmVOZXR3b3JrKG9wdGlvbnMpIHtcbiAgbGV0IHJlYWR5U3RhdGUgPSAwIC8qIERJU0FCTEVEICovO1xuICBjb25zdCBldmVudHMgPSBuZXcgRW1pdHRlcigpO1xuICBjb25zdCBkaXNwb3NhYmxlID0gbmV3IERpc3Bvc2FibGUoKTtcbiAgY29uc3QgZGVyaXZlSGFuZGxlcnNDb250cm9sbGVyID0gKGhhbmRsZXJzKSA9PiB7XG4gICAgcmV0dXJuIGhhbmRsZXJzIGluc3RhbmNlb2YgSGFuZGxlcnNDb250cm9sbGVyID8gaGFuZGxlcnMgOiBuZXcgSW5NZW1vcnlIYW5kbGVyc0NvbnRyb2xsZXIoaGFuZGxlcnMgfHwgW10pO1xuICB9O1xuICBsZXQgcmVzb2x2ZWRPcHRpb25zID0ge1xuICAgIC4uLm9wdGlvbnNcbiAgfTtcbiAgbGV0IGhhbmRsZXJzQ29udHJvbGxlciA9IGRlcml2ZUhhbmRsZXJzQ29udHJvbGxlcihyZXNvbHZlZE9wdGlvbnMuaGFuZGxlcnMpO1xuICByZXR1cm4ge1xuICAgIGdldCByZWFkeVN0YXRlKCkge1xuICAgICAgcmV0dXJuIHJlYWR5U3RhdGU7XG4gICAgfSxcbiAgICBldmVudHMsXG4gICAgY29uZmlndXJlKG9wdGlvbnMyKSB7XG4gICAgICBpbnZhcmlhbnQoXG4gICAgICAgIHJlYWR5U3RhdGUgPT09IDAgLyogRElTQUJMRUQgKi8sXG4gICAgICAgICdGYWlsZWQgdG8gY2FsbCBcImNvbmZpZ3VyZSgpXCIgb24gdGhlIG5ldHdvcms6IGNhbm5vdCBjb25maWd1cmUgYW4gYWxyZWFkeSBlbmFibGVkIG5ldHdvcmsuJ1xuICAgICAgKTtcbiAgICAgIGlmIChvcHRpb25zMi5oYW5kbGVycyAmJiAhT2JqZWN0LmlzKG9wdGlvbnMyLmhhbmRsZXJzLCByZXNvbHZlZE9wdGlvbnMuaGFuZGxlcnMpKSB7XG4gICAgICAgIGhhbmRsZXJzQ29udHJvbGxlciA9IGRlcml2ZUhhbmRsZXJzQ29udHJvbGxlcihvcHRpb25zMi5oYW5kbGVycyk7XG4gICAgICB9XG4gICAgICByZXNvbHZlZE9wdGlvbnMgPSB7XG4gICAgICAgIC4uLnJlc29sdmVkT3B0aW9ucyxcbiAgICAgICAgLi4ub3B0aW9uczJcbiAgICAgIH07XG4gICAgfSxcbiAgICBlbmFibGUoKSB7XG4gICAgICBpbnZhcmlhbnQoXG4gICAgICAgIHJlYWR5U3RhdGUgPT09IDAgLyogRElTQUJMRUQgKi8sXG4gICAgICAgICdGYWlsZWQgdG8gY2FsbCBcImVuYWJsZVwiIG9uIHRoZSBuZXR3b3JrOiBhbHJlYWR5IGVuYWJsZWQnXG4gICAgICApO1xuICAgICAgcmVhZHlTdGF0ZSA9IDEgLyogRU5BQkxFRCAqLztcbiAgICAgIGNvbnN0IHNlc3Npb24gPSB7IGFjdGl2ZTogdHJ1ZSB9O1xuICAgICAgZGlzcG9zYWJsZVtcInN1YnNjcmlwdGlvbnNcIl0ucHVzaCgoKSA9PiB7XG4gICAgICAgIHNlc3Npb24uYWN0aXZlID0gZmFsc2U7XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IHJlc29sdmVkT3B0aW9ucy5zb3VyY2VzLm1hcCgoc291cmNlKSA9PiB7XG4gICAgICAgIE5ldHdvcmtTb3VyY2UucHJvdG90eXBlLmRpc2FibGUuY2FsbChzb3VyY2UpO1xuICAgICAgICBzb3VyY2Uub24oXCJmcmFtZVwiLCBhc3luYyAoeyBmcmFtZSB9KSA9PiB7XG4gICAgICAgICAgZnJhbWUuZXZlbnRzLm9uKFwiKlwiLCAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIGlmICghc2Vzc2lvbi5hY3RpdmUpIHtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZXZlbnRzLmVtaXQoZXZlbnQpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbnN0IGhhbmRsZXJzID0gZnJhbWUuZ2V0SGFuZGxlcnMoaGFuZGxlcnNDb250cm9sbGVyKTtcbiAgICAgICAgICBhd2FpdCBmcmFtZS5yZXNvbHZlKFxuICAgICAgICAgICAgaGFuZGxlcnMsXG4gICAgICAgICAgICByZXNvbHZlZE9wdGlvbnMub25VbmhhbmRsZWRGcmFtZSB8fCBcIndhcm5cIixcbiAgICAgICAgICAgIHJlc29sdmVkT3B0aW9ucy5jb250ZXh0XG4gICAgICAgICAgKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBzb3VyY2UuZW5hYmxlKCk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBjb2xvcmxlc3NQcm9taXNlQWxsKHJlc3VsdCk7XG4gICAgfSxcbiAgICBkaXNhYmxlKCkge1xuICAgICAgaW52YXJpYW50KFxuICAgICAgICByZWFkeVN0YXRlID09PSAxIC8qIEVOQUJMRUQgKi8sXG4gICAgICAgICdGYWlsZWQgdG8gY2FsbCBcImRpc2FibGVcIiBvbiB0aGUgbmV0d29yazogYWxyZWFkeSBkaXNhYmxlZCdcbiAgICAgICk7XG4gICAgICByZWFkeVN0YXRlID0gMCAvKiBESVNBQkxFRCAqLztcbiAgICAgIGRpc3Bvc2FibGUuZGlzcG9zZSgpO1xuICAgICAgcmV0dXJuIGNvbG9ybGVzc1Byb21pc2VBbGwoXG4gICAgICAgIHJlc29sdmVkT3B0aW9ucy5zb3VyY2VzLm1hcCgoc291cmNlKSA9PiBzb3VyY2UuZGlzYWJsZSgpKVxuICAgICAgKTtcbiAgICB9LFxuICAgIHVzZSguLi5oYW5kbGVycykge1xuICAgICAgaGFuZGxlcnNDb250cm9sbGVyLnVzZShoYW5kbGVycyk7XG4gICAgfSxcbiAgICByZXNldEhhbmRsZXJzKC4uLmhhbmRsZXJzKSB7XG4gICAgICBoYW5kbGVyc0NvbnRyb2xsZXIucmVzZXQoaGFuZGxlcnMpO1xuICAgIH0sXG4gICAgcmVzdG9yZUhhbmRsZXJzKCkge1xuICAgICAgaGFuZGxlcnNDb250cm9sbGVyLnJlc3RvcmUoKTtcbiAgICB9LFxuICAgIGxpc3RIYW5kbGVycygpIHtcbiAgICAgIHJldHVybiB0b1JlYWRvbmx5QXJyYXkoaGFuZGxlcnNDb250cm9sbGVyLmN1cnJlbnRIYW5kbGVycygpKTtcbiAgICB9XG4gIH07XG59XG5leHBvcnQge1xuICBOZXR3b3JrUmVhZHlTdGF0ZSxcbiAgZGVmaW5lTmV0d29ya1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRlZmluZS1uZXR3b3JrLm1qcy5tYXAiLCJpbXBvcnQgeyBpbnZhcmlhbnQgfSBmcm9tIFwib3V0dmFyaWFudFwiO1xuXG4vLyNyZWdpb24gc3JjL3V0aWxzL2VtaXRBc3luYy50c1xuLyoqXG4qIEVtaXRzIGFuIGV2ZW50IG9uIHRoZSBnaXZlbiBlbWl0dGVyIGJ1dCBleGVjdXRlc1xuKiB0aGUgbGlzdGVuZXJzIHNlcXVlbnRpYWxseS4gVGhpcyBhY2NvdW50cyBmb3IgYXN5bmNocm9ub3VzXG4qIGxpc3RlbmVycyAoZS5nLiB0aG9zZSBoYXZpbmcgXCJzbGVlcFwiIGFuZCBoYW5kbGluZyB0aGUgcmVxdWVzdCkuXG4qL1xuYXN5bmMgZnVuY3Rpb24gZW1pdEFzeW5jKGVtaXR0ZXIsIGV2ZW50TmFtZSwgLi4uZGF0YSkge1xuXHRjb25zdCBsaXN0ZW5lcnMgPSBlbWl0dGVyLmxpc3RlbmVycyhldmVudE5hbWUpO1xuXHRpZiAobGlzdGVuZXJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXHRmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIGxpc3RlbmVycykgYXdhaXQgbGlzdGVuZXIuYXBwbHkoZW1pdHRlciwgZGF0YSk7XG59XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9wYXRjaGVzUmVnaXN0cnkudHNcbnZhciBQYXRjaGVzUmVnaXN0cnkgPSBjbGFzcyB7XG5cdCNyZXBsYWNlbWVudHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRhcHBseVBhdGNoKG93bmVyLCBrZXksIGdldE5leHRWYWx1ZSkge1xuXHRcdGNvbnN0IG93bmVyUmVwbGFjZW1lbnRzID0gdGhpcy4jcmVwbGFjZW1lbnRzLmdldChvd25lcik7XG5cdFx0aW52YXJpYW50KCFvd25lclJlcGxhY2VtZW50cz8uaGFzKGtleSksIGBGYWlsZWQgdG8gcmVwbGFjZSBhIGdsb2JhbCB2YWx1ZSBhdCBcIiR7U3RyaW5nKGtleSl9XCI6IGFscmVhZHkgcmVwbGFjZWQuYCk7XG5cdFx0Y29uc3QgbWF0Y2ggPSBnZXREZWVwUHJvcGVydHlEZXNjcmlwdG9yKG93bmVyLCBrZXkpO1xuXHRcdGlmICh0eXBlb2YgbWF0Y2ggPT09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdGNvbnNvbGUud2FybihgRmFpbGVkIHRvIHJlcGxhY2UgYSBnbG9iYWwgdmFsdWUgYXQgXCIke1N0cmluZyhrZXkpfVwiOiBub3QgYSBnbG9iYWwgdmFsdWUuYCk7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge307XG5cdFx0fVxuXHRcdGlmIChtYXRjaC5kZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSkgT2JqZWN0LmRlZmluZVByb3BlcnR5KG93bmVyLCBrZXksIHtcblx0XHRcdHZhbHVlOiBnZXROZXh0VmFsdWUob3duZXJba2V5XSksXG5cdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdFx0fSk7XG5cdFx0ZWxzZSBpZiAobWF0Y2guZGVzY3JpcHRvci53cml0YWJsZSkgb3duZXJba2V5XSA9IGdldE5leHRWYWx1ZShvd25lcltrZXldKTtcblx0XHRlbHNlIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIHBhdGNoIGEgbm9uLWNvbmZpZ3VyYWJsZSBub24td3JpdGFibGUgcHJvcGVydHkgXCIke2tleS50b1N0cmluZygpfVwiYCk7XG5cdFx0Y29uc3QgcmVzdG9yZVBhdGNoID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgY3VycmVudFJlcGxhY2VtZW50cyA9IHRoaXMuI3JlcGxhY2VtZW50cy5nZXQob3duZXIpO1xuXHRcdFx0aWYgKCFjdXJyZW50UmVwbGFjZW1lbnRzPy5oYXMoa2V5KSkgcmV0dXJuO1xuXHRcdFx0aWYgKG1hdGNoLm93bmVyID09PSBvd25lcilcbiAvKipcblx0XHRcdCogQG5vdGUgUmVzdG9yaW5nIG5vbi1jb25maWd1cmFibGUgcHJvcGVydGllcyB3b3JrcyBhcyBsb25nIGFzIFwid3JpdGFibGU6IHRydWVcIlxuXHRcdFx0KiBhbmQgbm9uZSBvZiB0aGUgb3RoZXIgZGVzY3JpcHRvciBwcm9wZXJ0aWVzIGV4Y2VwdCBmb3IgXCJ2YWx1ZVwiIGhhdmUgY2hhbmdlZC5cblx0XHRcdCovXG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobWF0Y2gub3duZXIsIGtleSwgbWF0Y2guZGVzY3JpcHRvcik7XG5cdFx0XHRlbHNlXG4gLyoqXG5cdFx0XHQqIEB0b2RvIERlbGV0ZSB0aGUgcHJveHkgcHJvcGVydHkgc2V0IGJ5IHRoZSByZWdpc3RyeS5cblx0XHRcdCogSWYgdGhlIG1hdGNoJ3Mgb3duZXIgaXNuJ3QgdGhlIG9yaWdpbmFsIG93bmVyLCB0aGUgcHJvcGVydHkgaXMgbGlrZWx5IG5lc3RlZCBpbiB0aGUgcHJvdG90eXBlLlxuXHRcdFx0KiBUaGUgcmVnaXN0cnkgZG9lcyBub3QgbWVkZGxlIHdpdGggdGhvc2UsIHRoZXkgYXJlIGxlZnQgaW50YWN0LlxuXHRcdFx0Ki9cblx0XHRcdFJlZmxlY3QuZGVsZXRlUHJvcGVydHkob3duZXIsIGtleSk7XG5cdFx0XHRjdXJyZW50UmVwbGFjZW1lbnRzLmRlbGV0ZShrZXkpO1xuXHRcdFx0aWYgKGN1cnJlbnRSZXBsYWNlbWVudHMuc2l6ZSA9PT0gMCkgdGhpcy4jcmVwbGFjZW1lbnRzLmRlbGV0ZShvd25lcik7XG5cdFx0fTtcblx0XHRpZiAob3duZXJSZXBsYWNlbWVudHMpIG93bmVyUmVwbGFjZW1lbnRzLnNldChrZXksIHJlc3RvcmVQYXRjaCk7XG5cdFx0ZWxzZSB0aGlzLiNyZXBsYWNlbWVudHMuc2V0KG93bmVyLCBuZXcgTWFwKFtba2V5LCByZXN0b3JlUGF0Y2hdXSkpO1xuXHRcdHJldHVybiByZXN0b3JlUGF0Y2g7XG5cdH1cblx0cmVzdG9yZUFsbFBhdGNoZXMoKSB7XG5cdFx0Y29uc3QgZXJyb3JzID0gW107XG5cdFx0Zm9yIChjb25zdCBbLCBvd25lclJlcGxhY2VtZW50c10gb2YgdGhpcy4jcmVwbGFjZW1lbnRzKSBmb3IgKGNvbnN0IFssIHJlc3RvcmVQYXRjaF0gb2Ygb3duZXJSZXBsYWNlbWVudHMpIHRyeSB7XG5cdFx0XHRyZXN0b3JlUGF0Y2goKTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIGVycm9ycy5wdXNoKGVycm9yKTtcblx0XHRcdGVsc2UgdGhyb3cgZXJyb3I7XG5cdFx0fVxuXHRcdGlmIChlcnJvcnMubGVuZ3RoID4gMCkgdGhyb3cgbmV3IEFnZ3JlZ2F0ZUVycm9yKGVycm9ycywgXCJGT08hXCIpO1xuXHR9XG59O1xuY29uc3QgcGF0Y2hlc1JlZ2lzdHJ5ID0gbmV3IFBhdGNoZXNSZWdpc3RyeSgpO1xuLyoqXG4qIFJldHVybnMgYSBwcm9wZXJ0eSBkZXNjcmlwdG9yIGZvciB0aGUgZ2l2ZW4gcHJvcGVydHkgb24gdGhlIG93bmVyLlxuKiBXYWxrcyBkb3duIHRoZSBwcm90b3R5cGUgY2hhaW4gaWYgdGhlIHByb3BlcnR5IGRvZXMgbm90IGV4aXN0IG9uIHRoZSBvd25lci5cbiogSGFuZHkgZm9yIGdldHRpbmcgYSBnbG9iYWwgcHJvcGVydHkgZGVzY3JpcHRvciB3aGVyZSBgZ2xvYmFsVGhpc2AgaXNcbiogcmVwbGFjZWQgd2l0aCBhIGNvbnRyb2xsZWQgY2xhc3MgKGUuZy4gU2VydmljZVdvcmtlckdsb2JhbFNjb3BlKS5cbiovXG5mdW5jdGlvbiBnZXREZWVwUHJvcGVydHlEZXNjcmlwdG9yKG93bmVyLCBrZXkpIHtcblx0bGV0IGN1cnJlbnRPd25lciA9IG93bmVyO1xuXHRsZXQgZGVzY3JpcHRvcjtcblx0d2hpbGUgKGN1cnJlbnRPd25lcikge1xuXHRcdGRlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGN1cnJlbnRPd25lciwga2V5KTtcblx0XHRpZiAoZGVzY3JpcHRvcikgcmV0dXJuIHtcblx0XHRcdG93bmVyOiBjdXJyZW50T3duZXIsXG5cdFx0XHRkZXNjcmlwdG9yXG5cdFx0fTtcblx0XHRjdXJyZW50T3duZXIgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YoY3VycmVudE93bmVyKTtcblx0fVxufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvaGFzQ29uZmlndXJhYmxlR2xvYmFsLnRzXG4vKipcbiogUmV0dXJucyBhIGJvb2xlYW4gaW5kaWNhdGluZyB3aGV0aGVyIHRoZSBnaXZlbiBnbG9iYWwgcHJvcGVydHlcbiogaXMgZGVmaW5lZCBhbmQgaXMgY29uZmlndXJhYmxlLlxuKi9cbmZ1bmN0aW9uIGhhc0NvbmZpZ3VyYWJsZUdsb2JhbChwcm9wZXJ0eU5hbWUpIHtcblx0Y29uc3QgbWF0Y2ggPSBnZXREZWVwUHJvcGVydHlEZXNjcmlwdG9yKGdsb2JhbFRoaXMsIHByb3BlcnR5TmFtZSk7XG5cdGlmICh0eXBlb2YgbWF0Y2ggPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBmYWxzZTtcblx0Y29uc3QgeyBkZXNjcmlwdG9yIH0gPSBtYXRjaDtcblx0aWYgKHR5cGVvZiBkZXNjcmlwdG9yLmdldCA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiBkZXNjcmlwdG9yLmdldCgpID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gZmFsc2U7XG5cdGlmICh0eXBlb2YgZGVzY3JpcHRvci5nZXQgPT09IFwidW5kZWZpbmVkXCIgJiYgZGVzY3JpcHRvci52YWx1ZSA9PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdGlmICh0eXBlb2YgZGVzY3JpcHRvci5zZXQgPT09IFwidW5kZWZpbmVkXCIgJiYgIWRlc2NyaXB0b3IuY29uZmlndXJhYmxlKSB7XG5cdFx0Y29uc29sZS5lcnJvcihgW01TV10gRmFpbGVkIHRvIGFwcGx5IGludGVyY2VwdG9yOiB0aGUgZ2xvYmFsIFxcYCR7cHJvcGVydHlOYW1lfVxcYCBwcm9wZXJ0eSBpcyBub24tY29uZmlndXJhYmxlLiBUaGlzIGlzIGxpa2VseSBhbiBpc3N1ZSB3aXRoIHlvdXIgZW52aXJvbm1lbnQuIElmIHlvdSBhcmUgdXNpbmcgYSBmcmFtZXdvcmssIHBsZWFzZSBvcGVuIGFuIGlzc3VlIGFib3V0IHRoaXMgaW4gdGhlaXIgcmVwb3NpdG9yeS5gKTtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblx0cmV0dXJuIHRydWU7XG59XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcGF0Y2hlc1JlZ2lzdHJ5IGFzIG4sIGVtaXRBc3luYyBhcyByLCBoYXNDb25maWd1cmFibGVHbG9iYWwgYXMgdCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aGFzQ29uZmlndXJhYmxlR2xvYmFsLUM4enExTUNnLm1qcy5tYXAiLCJpbXBvcnQgeyByIGFzIEludGVyY2VwdG9yLCB0IGFzIGNyZWF0ZVJlcXVlc3RJZCB9IGZyb20gXCIuLi8uLi9jcmVhdGVSZXF1ZXN0SWQtRFlDc0ZIT2kubWpzXCI7XG5pbXBvcnQgeyB0IGFzIHJlc29sdmVXZWJTb2NrZXRVcmwgfSBmcm9tIFwiLi4vLi4vcmVzb2x2ZVdlYlNvY2tldFVybC1DODMteDlpRS5tanNcIjtcbmltcG9ydCB7IG4gYXMgcGF0Y2hlc1JlZ2lzdHJ5LCByIGFzIGVtaXRBc3luYywgdCBhcyBoYXNDb25maWd1cmFibGVHbG9iYWwgfSBmcm9tIFwiLi4vLi4vaGFzQ29uZmlndXJhYmxlR2xvYmFsLUM4enExTUNnLm1qc1wiO1xuaW1wb3J0IHsgRGVmZXJyZWRQcm9taXNlIH0gZnJvbSBcIkBvcGVuLWRyYWZ0L2RlZmVycmVkLXByb21pc2VcIjtcbmltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCJvdXR2YXJpYW50XCI7XG5cbi8vI3JlZ2lvbiBzcmMvaW50ZXJjZXB0b3JzL1dlYlNvY2tldC91dGlscy9iaW5kRXZlbnQudHNcbmZ1bmN0aW9uIGJpbmRFdmVudCh0YXJnZXQsIGV2ZW50KSB7XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGV2ZW50LCB7XG5cdFx0dGFyZ2V0OiB7XG5cdFx0XHR2YWx1ZTogdGFyZ2V0LFxuXHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdHdyaXRhYmxlOiB0cnVlXG5cdFx0fSxcblx0XHRjdXJyZW50VGFyZ2V0OiB7XG5cdFx0XHR2YWx1ZTogdGFyZ2V0LFxuXHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdHdyaXRhYmxlOiB0cnVlXG5cdFx0fVxuXHR9KTtcblx0cmV0dXJuIGV2ZW50O1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaW50ZXJjZXB0b3JzL1dlYlNvY2tldC91dGlscy9ldmVudHMudHNcbmNvbnN0IGtDYW5jZWxhYmxlID0gU3ltYm9sKFwia0NhbmNlbGFibGVcIik7XG5jb25zdCBrRGVmYXVsdFByZXZlbnRlZCA9IFN5bWJvbChcImtEZWZhdWx0UHJldmVudGVkXCIpO1xuLyoqXG4qIEEgYE1lc3NhZ2VFdmVudGAgc3VwZXJzZXQgdGhhdCBzdXBwb3J0cyBldmVudCBjYW5jZWxsYXRpb25cbiogaW4gTm9kZS5qcy4gSXQncyByYXRoZXIgbm9uLWludHJ1c2l2ZSBzbyBpdCBjYW4gYmUgc2FmZWx5XG4qIHVzZWQgaW4gdGhlIGJyb3dzZXIgYXMgd2VsbC5cbipcbiogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbm9kZWpzL25vZGUvaXNzdWVzLzUxNzY3XG4qL1xudmFyIENhbmNlbGFibGVNZXNzYWdlRXZlbnQgPSBjbGFzcyBleHRlbmRzIE1lc3NhZ2VFdmVudCB7XG5cdGNvbnN0cnVjdG9yKHR5cGUsIGluaXQpIHtcblx0XHRzdXBlcih0eXBlLCBpbml0KTtcblx0XHR0aGlzW2tDYW5jZWxhYmxlXSA9ICEhaW5pdC5jYW5jZWxhYmxlO1xuXHRcdHRoaXNba0RlZmF1bHRQcmV2ZW50ZWRdID0gZmFsc2U7XG5cdH1cblx0Z2V0IGNhbmNlbGFibGUoKSB7XG5cdFx0cmV0dXJuIHRoaXNba0NhbmNlbGFibGVdO1xuXHR9XG5cdHNldCBjYW5jZWxhYmxlKG5leHRDYW5jZWxhYmxlKSB7XG5cdFx0dGhpc1trQ2FuY2VsYWJsZV0gPSBuZXh0Q2FuY2VsYWJsZTtcblx0fVxuXHRnZXQgZGVmYXVsdFByZXZlbnRlZCgpIHtcblx0XHRyZXR1cm4gdGhpc1trRGVmYXVsdFByZXZlbnRlZF07XG5cdH1cblx0c2V0IGRlZmF1bHRQcmV2ZW50ZWQobmV4dERlZmF1bHRQcmV2ZW50ZWQpIHtcblx0XHR0aGlzW2tEZWZhdWx0UHJldmVudGVkXSA9IG5leHREZWZhdWx0UHJldmVudGVkO1xuXHR9XG5cdHByZXZlbnREZWZhdWx0KCkge1xuXHRcdGlmICh0aGlzLmNhbmNlbGFibGUgJiYgIXRoaXNba0RlZmF1bHRQcmV2ZW50ZWRdKSB0aGlzW2tEZWZhdWx0UHJldmVudGVkXSA9IHRydWU7XG5cdH1cbn07XG52YXIgQ2xvc2VFdmVudCA9IGNsYXNzIGV4dGVuZHMgRXZlbnQge1xuXHRjb25zdHJ1Y3Rvcih0eXBlLCBpbml0ID0ge30pIHtcblx0XHRzdXBlcih0eXBlLCBpbml0KTtcblx0XHR0aGlzLmNvZGUgPSBpbml0LmNvZGUgPT09IHZvaWQgMCA/IDAgOiBpbml0LmNvZGU7XG5cdFx0dGhpcy5yZWFzb24gPSBpbml0LnJlYXNvbiA9PT0gdm9pZCAwID8gXCJcIiA6IGluaXQucmVhc29uO1xuXHRcdHRoaXMud2FzQ2xlYW4gPSBpbml0Lndhc0NsZWFuID09PSB2b2lkIDAgPyBmYWxzZSA6IGluaXQud2FzQ2xlYW47XG5cdH1cbn07XG52YXIgQ2FuY2VsYWJsZUNsb3NlRXZlbnQgPSBjbGFzcyBleHRlbmRzIENsb3NlRXZlbnQge1xuXHRjb25zdHJ1Y3Rvcih0eXBlLCBpbml0ID0ge30pIHtcblx0XHRzdXBlcih0eXBlLCBpbml0KTtcblx0XHR0aGlzW2tDYW5jZWxhYmxlXSA9ICEhaW5pdC5jYW5jZWxhYmxlO1xuXHRcdHRoaXNba0RlZmF1bHRQcmV2ZW50ZWRdID0gZmFsc2U7XG5cdH1cblx0Z2V0IGNhbmNlbGFibGUoKSB7XG5cdFx0cmV0dXJuIHRoaXNba0NhbmNlbGFibGVdO1xuXHR9XG5cdHNldCBjYW5jZWxhYmxlKG5leHRDYW5jZWxhYmxlKSB7XG5cdFx0dGhpc1trQ2FuY2VsYWJsZV0gPSBuZXh0Q2FuY2VsYWJsZTtcblx0fVxuXHRnZXQgZGVmYXVsdFByZXZlbnRlZCgpIHtcblx0XHRyZXR1cm4gdGhpc1trRGVmYXVsdFByZXZlbnRlZF07XG5cdH1cblx0c2V0IGRlZmF1bHRQcmV2ZW50ZWQobmV4dERlZmF1bHRQcmV2ZW50ZWQpIHtcblx0XHR0aGlzW2tEZWZhdWx0UHJldmVudGVkXSA9IG5leHREZWZhdWx0UHJldmVudGVkO1xuXHR9XG5cdHByZXZlbnREZWZhdWx0KCkge1xuXHRcdGlmICh0aGlzLmNhbmNlbGFibGUgJiYgIXRoaXNba0RlZmF1bHRQcmV2ZW50ZWRdKSB0aGlzW2tEZWZhdWx0UHJldmVudGVkXSA9IHRydWU7XG5cdH1cbn07XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvV2ViU29ja2V0L1dlYlNvY2tldENsaWVudENvbm5lY3Rpb24udHNcbmNvbnN0IGtFbWl0dGVyJDEgPSBTeW1ib2woXCJrRW1pdHRlclwiKTtcbmNvbnN0IGtCb3VuZExpc3RlbmVyJDEgPSBTeW1ib2woXCJrQm91bmRMaXN0ZW5lclwiKTtcbnZhciBXZWJTb2NrZXRDbGllbnRDb25uZWN0aW9uUHJvdG9jb2wgPSBjbGFzcyB7fTtcbi8qKlxuKiBUaGUgV2ViU29ja2V0IGNsaWVudCBpbnN0YW5jZSByZXByZXNlbnRzIGFuIGluY29taW5nXG4qIGNsaWVudCBjb25uZWN0aW9uLiBUaGUgdXNlciBjYW4gY29udHJvbCB0aGUgY29ubmVjdGlvbixcbiogc2VuZCBhbmQgcmVjZWl2ZSBldmVudHMuXG4qL1xudmFyIFdlYlNvY2tldENsaWVudENvbm5lY3Rpb24gPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKHNvY2tldCwgdHJhbnNwb3J0KSB7XG5cdFx0dGhpcy5zb2NrZXQgPSBzb2NrZXQ7XG5cdFx0dGhpcy50cmFuc3BvcnQgPSB0cmFuc3BvcnQ7XG5cdFx0dGhpcy5pZCA9IGNyZWF0ZVJlcXVlc3RJZCgpO1xuXHRcdHRoaXMudXJsID0gbmV3IFVSTChzb2NrZXQudXJsKTtcblx0XHR0aGlzW2tFbWl0dGVyJDFdID0gbmV3IEV2ZW50VGFyZ2V0KCk7XG5cdFx0dGhpcy50cmFuc3BvcnQuYWRkRXZlbnRMaXN0ZW5lcihcIm91dGdvaW5nXCIsIChldmVudCkgPT4ge1xuXHRcdFx0Y29uc3QgbWVzc2FnZSA9IGJpbmRFdmVudCh0aGlzLnNvY2tldCwgbmV3IENhbmNlbGFibGVNZXNzYWdlRXZlbnQoXCJtZXNzYWdlXCIsIHtcblx0XHRcdFx0ZGF0YTogZXZlbnQuZGF0YSxcblx0XHRcdFx0b3JpZ2luOiBldmVudC5vcmlnaW4sXG5cdFx0XHRcdGNhbmNlbGFibGU6IHRydWVcblx0XHRcdH0pKTtcblx0XHRcdHRoaXNba0VtaXR0ZXIkMV0uZGlzcGF0Y2hFdmVudChtZXNzYWdlKTtcblx0XHRcdGlmIChtZXNzYWdlLmRlZmF1bHRQcmV2ZW50ZWQpIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cdFx0fSk7XG5cdFx0LyoqXG5cdFx0KiBFbWl0IHRoZSBcImNsb3NlXCIgZXZlbnQgb24gdGhlIFwiY2xpZW50XCIgY29ubmVjdGlvblxuXHRcdCogd2hlbmV2ZXIgdGhlIHVuZGVybHlpbmcgdHJhbnNwb3J0IGlzIGNsb3NlZC5cblx0XHQqIEBub3RlIFwiY2xpZW50LmNsb3NlKClcIiBkb2VzIE5PVCBkaXNwYXRjaCB0aGUgXCJjbG9zZVwiXG5cdFx0KiBldmVudCBvbiB0aGUgV2ViU29ja2V0IGJlY2F1c2UgaXQgdXNlcyBub24tY29uZmlndXJhYmxlXG5cdFx0KiBjbG9zZSBzdGF0dXMgY29kZS4gVGh1cywgd2UgbGlzdGVuIHRvIHRoZSB0cmFuc3BvcnRcblx0XHQqIGluc3RlYWQgb2YgdGhlIFdlYlNvY2tldCdzIFwiY2xvc2VcIiBldmVudC5cblx0XHQqL1xuXHRcdHRoaXMudHJhbnNwb3J0LmFkZEV2ZW50TGlzdGVuZXIoXCJjbG9zZVwiLCAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXNba0VtaXR0ZXIkMV0uZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcy5zb2NrZXQsIG5ldyBDbG9zZUV2ZW50KFwiY2xvc2VcIiwgZXZlbnQpKSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogTGlzdGVuIGZvciB0aGUgb3V0Z29pbmcgZXZlbnRzIGZyb20gdGhlIGNvbm5lY3RlZCBXZWJTb2NrZXQgY2xpZW50LlxuXHQqL1xuXHRhZGRFdmVudExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKSB7XG5cdFx0aWYgKCFSZWZsZWN0LmhhcyhsaXN0ZW5lciwga0JvdW5kTGlzdGVuZXIkMSkpIHtcblx0XHRcdGNvbnN0IGJvdW5kTGlzdGVuZXIgPSBsaXN0ZW5lci5iaW5kKHRoaXMuc29ja2V0KTtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShsaXN0ZW5lciwga0JvdW5kTGlzdGVuZXIkMSwge1xuXHRcdFx0XHR2YWx1ZTogYm91bmRMaXN0ZW5lcixcblx0XHRcdFx0ZW51bWVyYWJsZTogZmFsc2UsXG5cdFx0XHRcdGNvbmZpZ3VyYWJsZTogZmFsc2Vcblx0XHRcdH0pO1xuXHRcdH1cblx0XHR0aGlzW2tFbWl0dGVyJDFdLmFkZEV2ZW50TGlzdGVuZXIodHlwZSwgUmVmbGVjdC5nZXQobGlzdGVuZXIsIGtCb3VuZExpc3RlbmVyJDEpLCBvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBSZW1vdmVzIHRoZSBsaXN0ZW5lciBmb3IgdGhlIGdpdmVuIGV2ZW50LlxuXHQqL1xuXHRyZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50LCBsaXN0ZW5lciwgb3B0aW9ucykge1xuXHRcdHRoaXNba0VtaXR0ZXIkMV0ucmVtb3ZlRXZlbnRMaXN0ZW5lcihldmVudCwgUmVmbGVjdC5nZXQobGlzdGVuZXIsIGtCb3VuZExpc3RlbmVyJDEpLCBvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBTZW5kIGRhdGEgdG8gdGhlIGNvbm5lY3RlZCBjbGllbnQuXG5cdCovXG5cdHNlbmQoZGF0YSkge1xuXHRcdHRoaXMudHJhbnNwb3J0LnNlbmQoZGF0YSk7XG5cdH1cblx0LyoqXG5cdCogQ2xvc2UgdGhlIFdlYlNvY2tldCBjb25uZWN0aW9uLlxuXHQqIEBwYXJhbSB7bnVtYmVyfSBjb2RlIEEgc3RhdHVzIGNvZGUgKHNlZSBodHRwczovL3d3dy5yZmMtZWRpdG9yLm9yZy9yZmMvcmZjNjQ1NSNzZWN0aW9uLTcuNC4xKS5cblx0KiBAcGFyYW0ge3N0cmluZ30gcmVhc29uIEEgY3VzdG9tIGNvbm5lY3Rpb24gY2xvc2UgcmVhc29uLlxuXHQqL1xuXHRjbG9zZShjb2RlLCByZWFzb24pIHtcblx0XHR0aGlzLnRyYW5zcG9ydC5jbG9zZShjb2RlLCByZWFzb24pO1xuXHR9XG59O1xuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaW50ZXJjZXB0b3JzL1dlYlNvY2tldC9XZWJTb2NrZXRPdmVycmlkZS50c1xuY29uc3QgV0VCU09DS0VUX0NMT1NFX0NPREVfUkFOR0VfRVJST1IgPSBcIkludmFsaWRBY2Nlc3NFcnJvcjogY2xvc2UgY29kZSBvdXQgb2YgdXNlciBjb25maWd1cmFibGUgcmFuZ2VcIjtcbmNvbnN0IGtQYXNzdGhyb3VnaFByb21pc2UgPSBTeW1ib2woXCJrUGFzc3Rocm91Z2hQcm9taXNlXCIpO1xuY29uc3Qga09uU2VuZCA9IFN5bWJvbChcImtPblNlbmRcIik7XG5jb25zdCBrQ2xvc2UgPSBTeW1ib2woXCJrQ2xvc2VcIik7XG52YXIgV2ViU29ja2V0T3ZlcnJpZGUgPSBjbGFzcyBleHRlbmRzIEV2ZW50VGFyZ2V0IHtcblx0c3RhdGljIHtcblx0XHR0aGlzLkNPTk5FQ1RJTkcgPSAwO1xuXHR9XG5cdHN0YXRpYyB7XG5cdFx0dGhpcy5PUEVOID0gMTtcblx0fVxuXHRzdGF0aWMge1xuXHRcdHRoaXMuQ0xPU0lORyA9IDI7XG5cdH1cblx0c3RhdGljIHtcblx0XHR0aGlzLkNMT1NFRCA9IDM7XG5cdH1cblx0Y29uc3RydWN0b3IodXJsLCBwcm90b2NvbHMpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuQ09OTkVDVElORyA9IDA7XG5cdFx0dGhpcy5PUEVOID0gMTtcblx0XHR0aGlzLkNMT1NJTkcgPSAyO1xuXHRcdHRoaXMuQ0xPU0VEID0gMztcblx0XHR0aGlzLl9vbm9wZW4gPSBudWxsO1xuXHRcdHRoaXMuX29ubWVzc2FnZSA9IG51bGw7XG5cdFx0dGhpcy5fb25lcnJvciA9IG51bGw7XG5cdFx0dGhpcy5fb25jbG9zZSA9IG51bGw7XG5cdFx0dGhpcy51cmwgPSByZXNvbHZlV2ViU29ja2V0VXJsKHVybCk7XG5cdFx0dGhpcy5wcm90b2NvbCA9IFwiXCI7XG5cdFx0dGhpcy5leHRlbnNpb25zID0gXCJcIjtcblx0XHR0aGlzLmJpbmFyeVR5cGUgPSBcImJsb2JcIjtcblx0XHR0aGlzLnJlYWR5U3RhdGUgPSB0aGlzLkNPTk5FQ1RJTkc7XG5cdFx0dGhpcy5idWZmZXJlZEFtb3VudCA9IDA7XG5cdFx0dGhpc1trUGFzc3Rocm91Z2hQcm9taXNlXSA9IG5ldyBEZWZlcnJlZFByb21pc2UoKTtcblx0XHRxdWV1ZU1pY3JvdGFzayhhc3luYyAoKSA9PiB7XG5cdFx0XHRpZiAoYXdhaXQgdGhpc1trUGFzc3Rocm91Z2hQcm9taXNlXSkgcmV0dXJuO1xuXHRcdFx0dGhpcy5wcm90b2NvbCA9IHR5cGVvZiBwcm90b2NvbHMgPT09IFwic3RyaW5nXCIgPyBwcm90b2NvbHMgOiBBcnJheS5pc0FycmF5KHByb3RvY29scykgJiYgcHJvdG9jb2xzLmxlbmd0aCA+IDAgPyBwcm90b2NvbHNbMF0gOiBcIlwiO1xuXHRcdFx0LyoqXG5cdFx0XHQqIEBub3RlIENoZWNrIHRoYXQgbm90aGluZyBoYXMgcHJldmVudGVkIHRoaXMgY29ubmVjdGlvblxuXHRcdFx0KiAoZS5nLiBjYWxsZWQgYGNsaWVudC5jbG9zZSgpYCBpbiB0aGUgY29ubmVjdGlvbiBsaXN0ZW5lcikuXG5cdFx0XHQqIElmIHRoZSBjb25uZWN0aW9uIGhhcyBiZWVuIHByZXZlbnRlZCwgbmV2ZXIgZGlzcGF0Y2ggdGhlIG9wZW4gZXZlbnQsLlxuXHRcdFx0Ki9cblx0XHRcdGlmICh0aGlzLnJlYWR5U3RhdGUgPT09IHRoaXMuQ09OTkVDVElORykge1xuXHRcdFx0XHR0aGlzLnJlYWR5U3RhdGUgPSB0aGlzLk9QRU47XG5cdFx0XHRcdHRoaXMuZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcywgbmV3IEV2ZW50KFwib3BlblwiKSkpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cdHNldCBvbm9wZW4obGlzdGVuZXIpIHtcblx0XHR0aGlzLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJvcGVuXCIsIHRoaXMuX29ub3Blbik7XG5cdFx0dGhpcy5fb25vcGVuID0gbGlzdGVuZXI7XG5cdFx0aWYgKGxpc3RlbmVyICE9PSBudWxsKSB0aGlzLmFkZEV2ZW50TGlzdGVuZXIoXCJvcGVuXCIsIGxpc3RlbmVyKTtcblx0fVxuXHRnZXQgb25vcGVuKCkge1xuXHRcdHJldHVybiB0aGlzLl9vbm9wZW47XG5cdH1cblx0c2V0IG9ubWVzc2FnZShsaXN0ZW5lcikge1xuXHRcdHRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgdGhpcy5fb25tZXNzYWdlKTtcblx0XHR0aGlzLl9vbm1lc3NhZ2UgPSBsaXN0ZW5lcjtcblx0XHRpZiAobGlzdGVuZXIgIT09IG51bGwpIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgbGlzdGVuZXIpO1xuXHR9XG5cdGdldCBvbm1lc3NhZ2UoKSB7XG5cdFx0cmV0dXJuIHRoaXMuX29ubWVzc2FnZTtcblx0fVxuXHRzZXQgb25lcnJvcihsaXN0ZW5lcikge1xuXHRcdHRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIHRoaXMuX29uZXJyb3IpO1xuXHRcdHRoaXMuX29uZXJyb3IgPSBsaXN0ZW5lcjtcblx0XHRpZiAobGlzdGVuZXIgIT09IG51bGwpIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIGxpc3RlbmVyKTtcblx0fVxuXHRnZXQgb25lcnJvcigpIHtcblx0XHRyZXR1cm4gdGhpcy5fb25lcnJvcjtcblx0fVxuXHRzZXQgb25jbG9zZShsaXN0ZW5lcikge1xuXHRcdHRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNsb3NlXCIsIHRoaXMuX29uY2xvc2UpO1xuXHRcdHRoaXMuX29uY2xvc2UgPSBsaXN0ZW5lcjtcblx0XHRpZiAobGlzdGVuZXIgIT09IG51bGwpIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcihcImNsb3NlXCIsIGxpc3RlbmVyKTtcblx0fVxuXHRnZXQgb25jbG9zZSgpIHtcblx0XHRyZXR1cm4gdGhpcy5fb25jbG9zZTtcblx0fVxuXHQvKipcblx0KiBAc2VlIGh0dHBzOi8vd2Vic29ja2V0cy5zcGVjLndoYXR3Zy5vcmcvI3JlZi1mb3ItZG9tLXdlYnNvY2tldC1zZW5kJUUyJTkxJUEwXG5cdCovXG5cdHNlbmQoZGF0YSkge1xuXHRcdGlmICh0aGlzLnJlYWR5U3RhdGUgPT09IHRoaXMuQ09OTkVDVElORykge1xuXHRcdFx0dGhpcy5jbG9zZSgpO1xuXHRcdFx0dGhyb3cgbmV3IERPTUV4Y2VwdGlvbihcIkludmFsaWRTdGF0ZUVycm9yXCIpO1xuXHRcdH1cblx0XHRpZiAodGhpcy5yZWFkeVN0YXRlID09PSB0aGlzLkNMT1NJTkcgfHwgdGhpcy5yZWFkeVN0YXRlID09PSB0aGlzLkNMT1NFRCkgcmV0dXJuO1xuXHRcdHRoaXMuYnVmZmVyZWRBbW91bnQgKz0gZ2V0RGF0YVNpemUoZGF0YSk7XG5cdFx0cXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuXHRcdFx0dGhpcy5idWZmZXJlZEFtb3VudCA9IDA7XG5cdFx0XHQvKipcblx0XHRcdCogQG5vdGUgTm90aWZ5IHRoZSBwYXJlbnQgYWJvdXQgb3V0Z29pbmcgZGF0YS5cblx0XHRcdCogVGhpcyBub3RpZmllcyB0aGUgdHJhbnNwb3J0IGFuZCB0aGUgY29ubmVjdGlvblxuXHRcdFx0KiBsaXN0ZW5zIHRvIHRoZSBvdXRnb2luZyBkYXRhIHRvIGVtaXQgdGhlIFwibWVzc2FnZVwiIGV2ZW50LlxuXHRcdFx0Ki9cblx0XHRcdHRoaXNba09uU2VuZF0/LihkYXRhKTtcblx0XHR9KTtcblx0fVxuXHRjbG9zZShjb2RlID0gMWUzLCByZWFzb24pIHtcblx0XHRpbnZhcmlhbnQoY29kZSwgV0VCU09DS0VUX0NMT1NFX0NPREVfUkFOR0VfRVJST1IpO1xuXHRcdGludmFyaWFudChjb2RlID09PSAxZTMgfHwgY29kZSA+PSAzZTMgJiYgY29kZSA8PSA0OTk5LCBXRUJTT0NLRVRfQ0xPU0VfQ09ERV9SQU5HRV9FUlJPUik7XG5cdFx0dGhpc1trQ2xvc2VdKGNvZGUsIHJlYXNvbik7XG5cdH1cblx0W2tDbG9zZV0oY29kZSA9IDFlMywgcmVhc29uLCB3YXNDbGVhbiA9IHRydWUpIHtcblx0XHQvKipcblx0XHQqIEBub3RlIE1vdmUgdGhpcyBjaGVjayBoZXJlIHNvIHRoYXQgZXZlbiBpbnRlcm5hbCBjbG9zdXJlcyxcblx0XHQqIGxpa2UgdGhvc2UgdHJpZ2dlcmVkIGJ5IHRoZSBgc2VydmVyYCBjb25uZWN0aW9uLCBhcmUgbm90XG5cdFx0KiBwZXJmb3JtZWQgdHdpY2UuXG5cdFx0Ki9cblx0XHRpZiAodGhpcy5yZWFkeVN0YXRlID09PSB0aGlzLkNMT1NJTkcgfHwgdGhpcy5yZWFkeVN0YXRlID09PSB0aGlzLkNMT1NFRCkgcmV0dXJuO1xuXHRcdHRoaXMucmVhZHlTdGF0ZSA9IHRoaXMuQ0xPU0lORztcblx0XHRxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0XHR0aGlzLnJlYWR5U3RhdGUgPSB0aGlzLkNMT1NFRDtcblx0XHRcdHRoaXMuZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcywgbmV3IENsb3NlRXZlbnQoXCJjbG9zZVwiLCB7XG5cdFx0XHRcdGNvZGUsXG5cdFx0XHRcdHJlYXNvbixcblx0XHRcdFx0d2FzQ2xlYW5cblx0XHRcdH0pKSk7XG5cdFx0XHR0aGlzLl9vbm9wZW4gPSBudWxsO1xuXHRcdFx0dGhpcy5fb25tZXNzYWdlID0gbnVsbDtcblx0XHRcdHRoaXMuX29uZXJyb3IgPSBudWxsO1xuXHRcdFx0dGhpcy5fb25jbG9zZSA9IG51bGw7XG5cdFx0fSk7XG5cdH1cblx0YWRkRXZlbnRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucykge1xuXHRcdHJldHVybiBzdXBlci5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKTtcblx0fVxuXHRyZW1vdmVFdmVudExpc3RlbmVyKHR5cGUsIGNhbGxiYWNrLCBvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHN1cGVyLnJlbW92ZUV2ZW50TGlzdGVuZXIodHlwZSwgY2FsbGJhY2ssIG9wdGlvbnMpO1xuXHR9XG59O1xuZnVuY3Rpb24gZ2V0RGF0YVNpemUoZGF0YSkge1xuXHRpZiAodHlwZW9mIGRhdGEgPT09IFwic3RyaW5nXCIpIHJldHVybiBkYXRhLmxlbmd0aDtcblx0aWYgKGRhdGEgaW5zdGFuY2VvZiBCbG9iKSByZXR1cm4gZGF0YS5zaXplO1xuXHRyZXR1cm4gZGF0YS5ieXRlTGVuZ3RoO1xufVxuXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaW50ZXJjZXB0b3JzL1dlYlNvY2tldC9XZWJTb2NrZXRTZXJ2ZXJDb25uZWN0aW9uLnRzXG5jb25zdCBrRW1pdHRlciA9IFN5bWJvbChcImtFbWl0dGVyXCIpO1xuY29uc3Qga0JvdW5kTGlzdGVuZXIgPSBTeW1ib2woXCJrQm91bmRMaXN0ZW5lclwiKTtcbmNvbnN0IGtTZW5kID0gU3ltYm9sKFwia1NlbmRcIik7XG52YXIgV2ViU29ja2V0U2VydmVyQ29ubmVjdGlvblByb3RvY29sID0gY2xhc3Mge307XG4vKipcbiogVGhlIFdlYlNvY2tldCBzZXJ2ZXIgaW5zdGFuY2UgcmVwcmVzZW50cyB0aGUgYWN0dWFsIHByb2R1Y3Rpb25cbiogV2ViU29ja2V0IHNlcnZlciBjb25uZWN0aW9uLiBJdCdzIGlkbGUgYnkgZGVmYXVsdCBidXQgeW91IGNhblxuKiBlc3RhYmxpc2ggaXQgYnkgY2FsbGluZyBgc2VydmVyLmNvbm5lY3QoKWAuXG4qL1xudmFyIFdlYlNvY2tldFNlcnZlckNvbm5lY3Rpb24gPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKGNsaWVudCwgdHJhbnNwb3J0LCBjcmVhdGVDb25uZWN0aW9uKSB7XG5cdFx0dGhpcy5jbGllbnQgPSBjbGllbnQ7XG5cdFx0dGhpcy50cmFuc3BvcnQgPSB0cmFuc3BvcnQ7XG5cdFx0dGhpcy5jcmVhdGVDb25uZWN0aW9uID0gY3JlYXRlQ29ubmVjdGlvbjtcblx0XHR0aGlzW2tFbWl0dGVyXSA9IG5ldyBFdmVudFRhcmdldCgpO1xuXHRcdHRoaXMubW9ja0Nsb3NlQ29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHR0aGlzLnJlYWxDbG9zZUNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdFx0dGhpcy50cmFuc3BvcnQuYWRkRXZlbnRMaXN0ZW5lcihcIm91dGdvaW5nXCIsIChldmVudCkgPT4ge1xuXHRcdFx0aWYgKHR5cGVvZiB0aGlzLnJlYWxXZWJTb2NrZXQgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcblx0XHRcdHF1ZXVlTWljcm90YXNrKCgpID0+IHtcblx0XHRcdFx0aWYgKCFldmVudC5kZWZhdWx0UHJldmVudGVkKVxuIC8qKlxuXHRcdFx0XHQqIEBub3RlIFVzZSB0aGUgaW50ZXJuYWwgc2VuZCBtZWNoYW5pc20gc28gY29uc3VtZXJzIGNhbiB0ZWxsXG5cdFx0XHRcdCogYXBhcnQgZGlyZWN0IHVzZXIgY2FsbHMgdG8gYHNlcnZlci5zZW5kKClgIGFuZCBpbnRlcm5hbCBjYWxscy5cblx0XHRcdFx0KiBFLmcuIE1TVyBoYXMgdG8gaWdub3JlIHRoaXMgaW50ZXJuYWwgY2FsbCB0byBsb2cgb3V0IG1lc3NhZ2VzIGNvcnJlY3RseS5cblx0XHRcdFx0Ki9cblx0XHRcdFx0dGhpc1trU2VuZF0oZXZlbnQuZGF0YSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHR0aGlzLnRyYW5zcG9ydC5hZGRFdmVudExpc3RlbmVyKFwiaW5jb21pbmdcIiwgdGhpcy5oYW5kbGVJbmNvbWluZ01lc3NhZ2UuYmluZCh0aGlzKSk7XG5cdH1cblx0LyoqXG5cdCogVGhlIGBXZWJTb2NrZXRgIGluc3RhbmNlIGNvbm5lY3RlZCB0byB0aGUgb3JpZ2luYWwgc2VydmVyLlxuXHQqIEFjY2Vzc2luZyB0aGlzIGJlZm9yZSBjYWxsaW5nIGBzZXJ2ZXIuY29ubmVjdCgpYCB3aWxsIHRocm93LlxuXHQqL1xuXHRnZXQgc29ja2V0KCkge1xuXHRcdGludmFyaWFudCh0aGlzLnJlYWxXZWJTb2NrZXQsIFwiQ2Fubm90IGFjY2VzcyBcXFwic29ja2V0XFxcIiBvbiB0aGUgb3JpZ2luYWwgV2ViU29ja2V0IHNlcnZlciBvYmplY3Q6IHRoZSBjb25uZWN0aW9uIGlzIG5vdCBvcGVuLiBEaWQgeW91IGZvcmdldCB0byBjYWxsIGBzZXJ2ZXIuY29ubmVjdCgpYD9cIik7XG5cdFx0cmV0dXJuIHRoaXMucmVhbFdlYlNvY2tldDtcblx0fVxuXHQvKipcblx0KiBPcGVuIGNvbm5lY3Rpb24gdG8gdGhlIG9yaWdpbmFsIFdlYlNvY2tldCBzZXJ2ZXIuXG5cdCovXG5cdGNvbm5lY3QoKSB7XG5cdFx0aW52YXJpYW50KCF0aGlzLnJlYWxXZWJTb2NrZXQgfHwgdGhpcy5yZWFsV2ViU29ja2V0LnJlYWR5U3RhdGUgIT09IFdlYlNvY2tldC5PUEVOLCBcIkZhaWxlZCB0byBjYWxsIFxcXCJjb25uZWN0KClcXFwiIG9uIHRoZSBvcmlnaW5hbCBXZWJTb2NrZXQgaW5zdGFuY2U6IHRoZSBjb25uZWN0aW9uIGFscmVhZHkgb3BlblwiKTtcblx0XHRjb25zdCByZWFsV2ViU29ja2V0ID0gdGhpcy5jcmVhdGVDb25uZWN0aW9uKCk7XG5cdFx0cmVhbFdlYlNvY2tldC5iaW5hcnlUeXBlID0gdGhpcy5jbGllbnQuYmluYXJ5VHlwZTtcblx0XHRyZWFsV2ViU29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoXCJvcGVuXCIsIChldmVudCkgPT4ge1xuXHRcdFx0dGhpc1trRW1pdHRlcl0uZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcy5yZWFsV2ViU29ja2V0LCBuZXcgRXZlbnQoXCJvcGVuXCIsIGV2ZW50KSkpO1xuXHRcdH0sIHsgb25jZTogdHJ1ZSB9KTtcblx0XHRyZWFsV2ViU29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIChldmVudCkgPT4ge1xuXHRcdFx0dGhpcy50cmFuc3BvcnQuZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcy5yZWFsV2ViU29ja2V0LCBuZXcgTWVzc2FnZUV2ZW50KFwiaW5jb21pbmdcIiwge1xuXHRcdFx0XHRkYXRhOiBldmVudC5kYXRhLFxuXHRcdFx0XHRvcmlnaW46IGV2ZW50Lm9yaWdpblxuXHRcdFx0fSkpKTtcblx0XHR9KTtcblx0XHR0aGlzLmNsaWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xvc2VcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHR0aGlzLmhhbmRsZU1vY2tDbG9zZShldmVudCk7XG5cdFx0fSwgeyBzaWduYWw6IHRoaXMubW9ja0Nsb3NlQ29udHJvbGxlci5zaWduYWwgfSk7XG5cdFx0cmVhbFdlYlNvY2tldC5hZGRFdmVudExpc3RlbmVyKFwiY2xvc2VcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHR0aGlzLmhhbmRsZVJlYWxDbG9zZShldmVudCk7XG5cdFx0fSwgeyBzaWduYWw6IHRoaXMucmVhbENsb3NlQ29udHJvbGxlci5zaWduYWwgfSk7XG5cdFx0cmVhbFdlYlNvY2tldC5hZGRFdmVudExpc3RlbmVyKFwiZXJyb3JcIiwgKCkgPT4ge1xuXHRcdFx0Y29uc3QgZXJyb3JFdmVudCA9IGJpbmRFdmVudChyZWFsV2ViU29ja2V0LCBuZXcgRXZlbnQoXCJlcnJvclwiLCB7IGNhbmNlbGFibGU6IHRydWUgfSkpO1xuXHRcdFx0dGhpc1trRW1pdHRlcl0uZGlzcGF0Y2hFdmVudChlcnJvckV2ZW50KTtcblx0XHRcdGlmICghZXJyb3JFdmVudC5kZWZhdWx0UHJldmVudGVkKSB0aGlzLmNsaWVudC5kaXNwYXRjaEV2ZW50KGJpbmRFdmVudCh0aGlzLmNsaWVudCwgbmV3IEV2ZW50KFwiZXJyb3JcIikpKTtcblx0XHR9KTtcblx0XHR0aGlzLnJlYWxXZWJTb2NrZXQgPSByZWFsV2ViU29ja2V0O1xuXHR9XG5cdC8qKlxuXHQqIExpc3RlbiBmb3IgdGhlIGluY29taW5nIGV2ZW50cyBmcm9tIHRoZSBvcmlnaW5hbCBXZWJTb2NrZXQgc2VydmVyLlxuXHQqL1xuXHRhZGRFdmVudExpc3RlbmVyKGV2ZW50LCBsaXN0ZW5lciwgb3B0aW9ucykge1xuXHRcdGlmICghUmVmbGVjdC5oYXMobGlzdGVuZXIsIGtCb3VuZExpc3RlbmVyKSkge1xuXHRcdFx0Y29uc3QgYm91bmRMaXN0ZW5lciA9IGxpc3RlbmVyLmJpbmQodGhpcy5jbGllbnQpO1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGxpc3RlbmVyLCBrQm91bmRMaXN0ZW5lciwge1xuXHRcdFx0XHR2YWx1ZTogYm91bmRMaXN0ZW5lcixcblx0XHRcdFx0ZW51bWVyYWJsZTogZmFsc2Vcblx0XHRcdH0pO1xuXHRcdH1cblx0XHR0aGlzW2tFbWl0dGVyXS5hZGRFdmVudExpc3RlbmVyKGV2ZW50LCBSZWZsZWN0LmdldChsaXN0ZW5lciwga0JvdW5kTGlzdGVuZXIpLCBvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBSZW1vdmUgdGhlIGxpc3RlbmVyIGZvciB0aGUgZ2l2ZW4gZXZlbnQuXG5cdCovXG5cdHJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnQsIGxpc3RlbmVyLCBvcHRpb25zKSB7XG5cdFx0dGhpc1trRW1pdHRlcl0ucmVtb3ZlRXZlbnRMaXN0ZW5lcihldmVudCwgUmVmbGVjdC5nZXQobGlzdGVuZXIsIGtCb3VuZExpc3RlbmVyKSwgb3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogU2VuZCBkYXRhIHRvIHRoZSBvcmlnaW5hbCBXZWJTb2NrZXQgc2VydmVyLlxuXHQqIEBleGFtcGxlXG5cdCogc2VydmVyLnNlbmQoJ2hlbGxvJylcblx0KiBzZXJ2ZXIuc2VuZChuZXcgQmxvYihbJ2hlbGxvJ10pKVxuXHQqIHNlcnZlci5zZW5kKG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZSgnaGVsbG8nKSlcblx0Ki9cblx0c2VuZChkYXRhKSB7XG5cdFx0dGhpc1trU2VuZF0oZGF0YSk7XG5cdH1cblx0W2tTZW5kXShkYXRhKSB7XG5cdFx0Y29uc3QgeyByZWFsV2ViU29ja2V0IH0gPSB0aGlzO1xuXHRcdGludmFyaWFudChyZWFsV2ViU29ja2V0LCBcIkZhaWxlZCB0byBjYWxsIFxcXCJzZXJ2ZXIuc2VuZCgpXFxcIiBmb3IgXFxcIiVzXFxcIjogdGhlIGNvbm5lY3Rpb24gaXMgbm90IG9wZW4uIERpZCB5b3UgZm9yZ2V0IHRvIGNhbGwgXFxcInNlcnZlci5jb25uZWN0KClcXFwiP1wiLCB0aGlzLmNsaWVudC51cmwpO1xuXHRcdGlmIChyZWFsV2ViU29ja2V0LnJlYWR5U3RhdGUgPT09IFdlYlNvY2tldC5DTE9TSU5HIHx8IHJlYWxXZWJTb2NrZXQucmVhZHlTdGF0ZSA9PT0gV2ViU29ja2V0LkNMT1NFRCkgcmV0dXJuO1xuXHRcdGlmIChyZWFsV2ViU29ja2V0LnJlYWR5U3RhdGUgPT09IFdlYlNvY2tldC5DT05ORUNUSU5HKSB7XG5cdFx0XHRyZWFsV2ViU29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoXCJvcGVuXCIsICgpID0+IHtcblx0XHRcdFx0cmVhbFdlYlNvY2tldC5zZW5kKGRhdGEpO1xuXHRcdFx0fSwgeyBvbmNlOiB0cnVlIH0pO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRyZWFsV2ViU29ja2V0LnNlbmQoZGF0YSk7XG5cdH1cblx0LyoqXG5cdCogQ2xvc2UgdGhlIGFjdHVhbCBzZXJ2ZXIgY29ubmVjdGlvbi5cblx0Ki9cblx0Y2xvc2UoKSB7XG5cdFx0Y29uc3QgeyByZWFsV2ViU29ja2V0IH0gPSB0aGlzO1xuXHRcdGludmFyaWFudChyZWFsV2ViU29ja2V0LCBcIkZhaWxlZCB0byBjbG9zZSBzZXJ2ZXIgY29ubmVjdGlvbiBmb3IgXFxcIiVzXFxcIjogdGhlIGNvbm5lY3Rpb24gaXMgbm90IG9wZW4uIERpZCB5b3UgZm9yZ2V0IHRvIGNhbGwgXFxcInNlcnZlci5jb25uZWN0KClcXFwiP1wiLCB0aGlzLmNsaWVudC51cmwpO1xuXHRcdHRoaXMucmVhbENsb3NlQ29udHJvbGxlci5hYm9ydCgpO1xuXHRcdGlmIChyZWFsV2ViU29ja2V0LnJlYWR5U3RhdGUgPT09IFdlYlNvY2tldC5DTE9TSU5HIHx8IHJlYWxXZWJTb2NrZXQucmVhZHlTdGF0ZSA9PT0gV2ViU29ja2V0LkNMT1NFRCkgcmV0dXJuO1xuXHRcdHJlYWxXZWJTb2NrZXQuY2xvc2UoKTtcblx0XHRxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0XHR0aGlzW2tFbWl0dGVyXS5kaXNwYXRjaEV2ZW50KGJpbmRFdmVudCh0aGlzLnJlYWxXZWJTb2NrZXQsIG5ldyBDYW5jZWxhYmxlQ2xvc2VFdmVudChcImNsb3NlXCIsIHtcblx0XHRcdFx0Y29kZTogMWUzLFxuXHRcdFx0XHRjYW5jZWxhYmxlOiB0cnVlXG5cdFx0XHR9KSkpO1xuXHRcdH0pO1xuXHR9XG5cdGhhbmRsZUluY29taW5nTWVzc2FnZShldmVudCkge1xuXHRcdGNvbnN0IG1lc3NhZ2VFdmVudCA9IGJpbmRFdmVudChldmVudC50YXJnZXQsIG5ldyBDYW5jZWxhYmxlTWVzc2FnZUV2ZW50KFwibWVzc2FnZVwiLCB7XG5cdFx0XHRkYXRhOiBldmVudC5kYXRhLFxuXHRcdFx0b3JpZ2luOiBldmVudC5vcmlnaW4sXG5cdFx0XHRjYW5jZWxhYmxlOiB0cnVlXG5cdFx0fSkpO1xuXHRcdC8qKlxuXHRcdCogQG5vdGUgRW1pdCBcIm1lc3NhZ2VcIiBldmVudCBvbiB0aGUgc2VydmVyIGNvbm5lY3Rpb25cblx0XHQqIGluc3RhbmNlIHRvIGxldCB0aGUgaW50ZXJjZXB0b3Iga25vdyBhYm91dCB0aGVzZVxuXHRcdCogaW5jb21pbmcgZXZlbnRzIGZyb20gdGhlIG9yaWdpbmFsIHNlcnZlci4gSW4gdGhhdCBsaXN0ZW5lcixcblx0XHQqIHRoZSBpbnRlcmNlcHRvciBjYW4gbW9kaWZ5IG9yIHNraXAgdGhlIGV2ZW50IGZvcndhcmRpbmdcblx0XHQqIHRvIHRoZSBtb2NrIFdlYlNvY2tldCBpbnN0YW5jZS5cblx0XHQqL1xuXHRcdHRoaXNba0VtaXR0ZXJdLmRpc3BhdGNoRXZlbnQobWVzc2FnZUV2ZW50KTtcblx0XHQvKipcblx0XHQqIEBub3RlIEZvcndhcmQgdGhlIGluY29taW5nIHNlcnZlciBldmVudHMgdG8gdGhlIGNsaWVudC5cblx0XHQqIFByZXZlbnRpbmcgdGhlIGRlZmF1bHQgb24gdGhlIG1lc3NhZ2UgZXZlbnQgc3RvcHMgdGhpcy5cblx0XHQqL1xuXHRcdGlmICghbWVzc2FnZUV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHRoaXMuY2xpZW50LmRpc3BhdGNoRXZlbnQoYmluZEV2ZW50KFxuXHRcdFx0LyoqXG5cdFx0XHQqIEBub3RlIEJpbmQgdGhlIGZvcndhcmRlZCBvcmlnaW5hbCBzZXJ2ZXIgZXZlbnRzXG5cdFx0XHQqIHRvIHRoZSBtb2NrIFdlYlNvY2tldCBpbnN0YW5jZSBzbyBpdCB3b3VsZFxuXHRcdFx0KiBkaXNwYXRjaCB0aGVtIHN0cmFpZ2h0IGF3YXkuXG5cdFx0XHQqL1xuXHRcdFx0dGhpcy5jbGllbnQsXG5cdFx0XHRuZXcgTWVzc2FnZUV2ZW50KFwibWVzc2FnZVwiLCB7XG5cdFx0XHRcdGRhdGE6IGV2ZW50LmRhdGEsXG5cdFx0XHRcdG9yaWdpbjogZXZlbnQub3JpZ2luXG5cdFx0XHR9KVxuXHRcdCkpO1xuXHR9XG5cdGhhbmRsZU1vY2tDbG9zZShfZXZlbnQpIHtcblx0XHRpZiAodGhpcy5yZWFsV2ViU29ja2V0KSB0aGlzLnJlYWxXZWJTb2NrZXQuY2xvc2UoKTtcblx0fVxuXHRoYW5kbGVSZWFsQ2xvc2UoZXZlbnQpIHtcblx0XHR0aGlzLm1vY2tDbG9zZUNvbnRyb2xsZXIuYWJvcnQoKTtcblx0XHRjb25zdCBjbG9zZUV2ZW50ID0gYmluZEV2ZW50KHRoaXMucmVhbFdlYlNvY2tldCwgbmV3IENhbmNlbGFibGVDbG9zZUV2ZW50KFwiY2xvc2VcIiwge1xuXHRcdFx0Y29kZTogZXZlbnQuY29kZSxcblx0XHRcdHJlYXNvbjogZXZlbnQucmVhc29uLFxuXHRcdFx0d2FzQ2xlYW46IGV2ZW50Lndhc0NsZWFuLFxuXHRcdFx0Y2FuY2VsYWJsZTogdHJ1ZVxuXHRcdH0pKTtcblx0XHR0aGlzW2tFbWl0dGVyXS5kaXNwYXRjaEV2ZW50KGNsb3NlRXZlbnQpO1xuXHRcdGlmICghY2xvc2VFdmVudC5kZWZhdWx0UHJldmVudGVkKSB0aGlzLmNsaWVudFtrQ2xvc2VdKGV2ZW50LmNvZGUsIGV2ZW50LnJlYXNvbik7XG5cdH1cbn07XG5cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvV2ViU29ja2V0L1dlYlNvY2tldENsYXNzVHJhbnNwb3J0LnRzXG4vKipcbiogQWJzdHJhY3Rpb24gb3ZlciB0aGUgZ2l2ZW4gbW9jayBgV2ViU29ja2V0YCBpbnN0YW5jZSB0aGF0IGFsbG93c1xuKiBmb3IgY29udHJvbGxpbmcgdGhhdCBpbnN0YW5jZSAoZS5nLiBzZW5kaW5nIGFuZCByZWNlaXZpbmcgbWVzc2FnZXMpLlxuKi9cbnZhciBXZWJTb2NrZXRDbGFzc1RyYW5zcG9ydCA9IGNsYXNzIGV4dGVuZHMgRXZlbnRUYXJnZXQge1xuXHRjb25zdHJ1Y3Rvcihzb2NrZXQpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuc29ja2V0ID0gc29ja2V0O1xuXHRcdHRoaXMuc29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoXCJjbG9zZVwiLCAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXMuZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcy5zb2NrZXQsIG5ldyBDbG9zZUV2ZW50KFwiY2xvc2VcIiwgZXZlbnQpKSk7XG5cdFx0fSk7XG5cdFx0LyoqXG5cdFx0KiBFbWl0IHRoZSBcIm91dGdvaW5nXCIgZXZlbnQgb24gdGhlIHRyYW5zcG9ydFxuXHRcdCogd2hlbmV2ZXIgdGhlIFdlYlNvY2tldCBjbGllbnQgc2VuZHMgZGF0YSAoXCJ3cy5zZW5kKClcIikuXG5cdFx0Ki9cblx0XHR0aGlzLnNvY2tldFtrT25TZW5kXSA9IChkYXRhKSA9PiB7XG5cdFx0XHR0aGlzLmRpc3BhdGNoRXZlbnQoYmluZEV2ZW50KHRoaXMuc29ja2V0LCBuZXcgQ2FuY2VsYWJsZU1lc3NhZ2VFdmVudChcIm91dGdvaW5nXCIsIHtcblx0XHRcdFx0ZGF0YSxcblx0XHRcdFx0b3JpZ2luOiB0aGlzLnNvY2tldC51cmwsXG5cdFx0XHRcdGNhbmNlbGFibGU6IHRydWVcblx0XHRcdH0pKSk7XG5cdFx0fTtcblx0fVxuXHRhZGRFdmVudExpc3RlbmVyKHR5cGUsIGNhbGxiYWNrLCBvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHN1cGVyLmFkZEV2ZW50TGlzdGVuZXIodHlwZSwgY2FsbGJhY2ssIG9wdGlvbnMpO1xuXHR9XG5cdGRpc3BhdGNoRXZlbnQoZXZlbnQpIHtcblx0XHRyZXR1cm4gc3VwZXIuZGlzcGF0Y2hFdmVudChldmVudCk7XG5cdH1cblx0c2VuZChkYXRhKSB7XG5cdFx0cXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuXHRcdFx0aWYgKHRoaXMuc29ja2V0LnJlYWR5U3RhdGUgPT09IHRoaXMuc29ja2V0LkNMT1NJTkcgfHwgdGhpcy5zb2NrZXQucmVhZHlTdGF0ZSA9PT0gdGhpcy5zb2NrZXQuQ0xPU0VEKSByZXR1cm47XG5cdFx0XHRjb25zdCBkaXNwYXRjaEV2ZW50ID0gKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnNvY2tldC5kaXNwYXRjaEV2ZW50KGJpbmRFdmVudChcblx0XHRcdFx0XHQvKipcblx0XHRcdFx0XHQqIEBub3RlIFNldHRpbmcgdGhpcyBldmVudCdzIFwidGFyZ2V0XCIgdG8gdGhlXG5cdFx0XHRcdFx0KiBXZWJTb2NrZXQgb3ZlcnJpZGUgaW5zdGFuY2UgaXMgaW1wb3J0YW50LlxuXHRcdFx0XHRcdCogVGhpcyB3YXkgaXQgY2FuIHRlbGwgYXBhcnQgb3JpZ2luYWwgaW5jb21pbmcgZXZlbnRzXG5cdFx0XHRcdFx0KiAobXVzdCBiZSBmb3J3YXJkZWQgdG8gdGhlIHRyYW5zcG9ydCkgZnJvbSB0aGVcblx0XHRcdFx0XHQqIG1vY2tlZCBtZXNzYWdlIGV2ZW50cyBsaWtlIHRoZSBvbmUgYmVsb3dcblx0XHRcdFx0XHQqIChtdXN0IGJlIGRpc3BhdGNoZWQgb24gdGhlIGNsaWVudCBpbnN0YW5jZSkuXG5cdFx0XHRcdFx0Ki9cblx0XHRcdFx0XHR0aGlzLnNvY2tldCxcblx0XHRcdFx0XHRuZXcgTWVzc2FnZUV2ZW50KFwibWVzc2FnZVwiLCB7XG5cdFx0XHRcdFx0XHRkYXRhLFxuXHRcdFx0XHRcdFx0b3JpZ2luOiB0aGlzLnNvY2tldC51cmxcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHQpKTtcblx0XHRcdH07XG5cdFx0XHRpZiAodGhpcy5zb2NrZXQucmVhZHlTdGF0ZSA9PT0gdGhpcy5zb2NrZXQuQ09OTkVDVElORykgdGhpcy5zb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcihcIm9wZW5cIiwgKCkgPT4ge1xuXHRcdFx0XHRkaXNwYXRjaEV2ZW50KCk7XG5cdFx0XHR9LCB7IG9uY2U6IHRydWUgfSk7XG5cdFx0XHRlbHNlIGRpc3BhdGNoRXZlbnQoKTtcblx0XHR9KTtcblx0fVxuXHRjbG9zZShjb2RlLCByZWFzb24pIHtcblx0XHQvKipcblx0XHQqIEBub3RlIENhbGwgdGhlIGludGVybmFsIGNsb3NlIG1ldGhvZCBkaXJlY3RseVxuXHRcdCogdG8gYWxsb3cgY2xvc2luZyB0aGUgY29ubmVjdGlvbiB3aXRoIHRoZSBzdGF0dXMgY29kZXNcblx0XHQqIHRoYXQgYXJlIG5vbi1jb25maWd1cmFibGUgYnkgdGhlIHVzZXIgKD4gMTAwMCA8PSAxMDE1KS5cblx0XHQqL1xuXHRcdHRoaXMuc29ja2V0W2tDbG9zZV0oY29kZSwgcmVhc29uKTtcblx0fVxufTtcblxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9XZWJTb2NrZXQvaW5kZXgudHNcbi8qKlxuKiBJbnRlcmNlcHQgdGhlIG91dGdvaW5nIFdlYlNvY2tldCBjb25uZWN0aW9ucyBjcmVhdGVkIHVzaW5nXG4qIHRoZSBnbG9iYWwgYFdlYlNvY2tldGAgY2xhc3MuXG4qL1xudmFyIFdlYlNvY2tldEludGVyY2VwdG9yID0gY2xhc3MgV2ViU29ja2V0SW50ZXJjZXB0b3IgZXh0ZW5kcyBJbnRlcmNlcHRvciB7XG5cdHN0YXRpYyB7XG5cdFx0dGhpcy5zeW1ib2wgPSBTeW1ib2wuZm9yKFwid2Vic29ja2V0LWludGVyY2VwdG9yXCIpO1xuXHR9XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHN1cGVyKFdlYlNvY2tldEludGVyY2VwdG9yLnN5bWJvbCk7XG5cdH1cblx0Y2hlY2tFbnZpcm9ubWVudCgpIHtcblx0XHRyZXR1cm4gaGFzQ29uZmlndXJhYmxlR2xvYmFsKFwiV2ViU29ja2V0XCIpO1xuXHR9XG5cdHNldHVwKCkge1xuXHRcdGNvbnN0IGxvZ2dlciA9IHRoaXMubG9nZ2VyLmV4dGVuZChcInNldHVwXCIpO1xuXHRcdGNvbnN0IFdlYlNvY2tldFByb3h5ID0gbmV3IFByb3h5KGdsb2JhbFRoaXMuV2ViU29ja2V0LCB7IGNvbnN0cnVjdDogKHRhcmdldCwgYXJncywgbmV3VGFyZ2V0KSA9PiB7XG5cdFx0XHRjb25zdCBbdXJsLCBwcm90b2NvbHNdID0gYXJncztcblx0XHRcdGNvbnN0IGNyZWF0ZUNvbm5lY3Rpb24gPSAoKSA9PiB7XG5cdFx0XHRcdHJldHVybiBSZWZsZWN0LmNvbnN0cnVjdCh0YXJnZXQsIGFyZ3MsIG5ld1RhcmdldCk7XG5cdFx0XHR9O1xuXHRcdFx0Y29uc3Qgc29ja2V0ID0gbmV3IFdlYlNvY2tldE92ZXJyaWRlKHVybCwgcHJvdG9jb2xzKTtcblx0XHRcdGNvbnN0IHRyYW5zcG9ydCA9IG5ldyBXZWJTb2NrZXRDbGFzc1RyYW5zcG9ydChzb2NrZXQpO1xuXHRcdFx0cXVldWVNaWNyb3Rhc2soYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IHNlcnZlciA9IG5ldyBXZWJTb2NrZXRTZXJ2ZXJDb25uZWN0aW9uKHNvY2tldCwgdHJhbnNwb3J0LCBjcmVhdGVDb25uZWN0aW9uKTtcblx0XHRcdFx0XHRjb25zdCBoYXNDb25uZWN0aW9uTGlzdGVuZXJzID0gdGhpcy5lbWl0dGVyLmxpc3RlbmVyQ291bnQoXCJjb25uZWN0aW9uXCIpID4gMDtcblx0XHRcdFx0XHRhd2FpdCBlbWl0QXN5bmModGhpcy5lbWl0dGVyLCBcImNvbm5lY3Rpb25cIiwge1xuXHRcdFx0XHRcdFx0Y2xpZW50OiBuZXcgV2ViU29ja2V0Q2xpZW50Q29ubmVjdGlvbihzb2NrZXQsIHRyYW5zcG9ydCksXG5cdFx0XHRcdFx0XHRzZXJ2ZXIsXG5cdFx0XHRcdFx0XHRpbmZvOiB7IHByb3RvY29scyB9XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0aWYgKGhhc0Nvbm5lY3Rpb25MaXN0ZW5lcnMpIHNvY2tldFtrUGFzc3Rocm91Z2hQcm9taXNlXS5yZXNvbHZlKGZhbHNlKTtcblx0XHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHRcdHNvY2tldFtrUGFzc3Rocm91Z2hQcm9taXNlXS5yZXNvbHZlKHRydWUpO1xuXHRcdFx0XHRcdFx0c2VydmVyLmNvbm5lY3QoKTtcblx0XHRcdFx0XHRcdHNlcnZlci5hZGRFdmVudExpc3RlbmVyKFwib3BlblwiLCAoKSA9PiB7XG5cdFx0XHRcdFx0XHRcdHNvY2tldC5kaXNwYXRjaEV2ZW50KGJpbmRFdmVudChzb2NrZXQsIG5ldyBFdmVudChcIm9wZW5cIikpKTtcblx0XHRcdFx0XHRcdFx0aWYgKHNlcnZlcltcInJlYWxXZWJTb2NrZXRcIl0pIHNvY2tldC5wcm90b2NvbCA9IHNlcnZlcltcInJlYWxXZWJTb2NrZXRcIl0ucHJvdG9jb2w7XG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRcdFx0LyoqXG5cdFx0XHRcdFx0KiBAbm90ZSBUcmFuc2xhdGUgdW5oYW5kbGVkIGV4Y2VwdGlvbnMgZHVyaW5nIHRoZSBjb25uZWN0aW9uXG5cdFx0XHRcdFx0KiBoYW5kbGluZyAoaS5lLiBpbnRlcmNlcHRvciBleGNlcHRpb25zKSBhcyBXZWJTb2NrZXQgY29ubmVjdGlvblxuXHRcdFx0XHRcdCogY2xvc3VyZXMgd2l0aCBlcnJvci4gVGhpcyBwcmV2ZW50cyBmcm9tIHRoZSBleGNlcHRpb25zIG9jY3VycmluZ1xuXHRcdFx0XHRcdCogaW4gYHF1ZXVlTWljcm90YXNrYCBmcm9tIGJlaW5nIHByb2Nlc3Mtd2lkZSBhbmQgdW5jYXRjaGFibGUuXG5cdFx0XHRcdFx0Ki9cblx0XHRcdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikge1xuXHRcdFx0XHRcdFx0c29ja2V0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiZXJyb3JcIikpO1xuXHRcdFx0XHRcdFx0aWYgKHNvY2tldC5yZWFkeVN0YXRlICE9PSBXZWJTb2NrZXQuQ0xPU0lORyAmJiBzb2NrZXQucmVhZHlTdGF0ZSAhPT0gV2ViU29ja2V0LkNMT1NFRCkgc29ja2V0W2tDbG9zZV0oMTAxMSwgZXJyb3IubWVzc2FnZSwgZmFsc2UpO1xuXHRcdFx0XHRcdFx0Y29uc29sZS5lcnJvcihlcnJvcik7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBzb2NrZXQ7XG5cdFx0fSB9KTtcblx0XHRsb2dnZXIuaW5mbyhcInBhdGNoaW5nIGdsb2JhbCBXZWJTb2NrZXQuLi5cIik7XG5cdFx0dGhpcy5zdWJzY3JpcHRpb25zLnB1c2gocGF0Y2hlc1JlZ2lzdHJ5LmFwcGx5UGF0Y2goZ2xvYmFsVGhpcywgXCJXZWJTb2NrZXRcIiwgKCkgPT4gV2ViU29ja2V0UHJveHkpKTtcblx0XHRsb2dnZXIuaW5mbyhcImdsb2JhbCBXZWJTb2NrZXQgcGF0Y2hlZCFcIiwgZ2xvYmFsVGhpcy5XZWJTb2NrZXQubmFtZSk7XG5cdH1cbn07XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQ2FuY2VsYWJsZUNsb3NlRXZlbnQsIENhbmNlbGFibGVNZXNzYWdlRXZlbnQsIENsb3NlRXZlbnQsIFdlYlNvY2tldENsaWVudENvbm5lY3Rpb24sIFdlYlNvY2tldENsaWVudENvbm5lY3Rpb25Qcm90b2NvbCwgV2ViU29ja2V0SW50ZXJjZXB0b3IsIFdlYlNvY2tldFNlcnZlckNvbm5lY3Rpb24sIFdlYlNvY2tldFNlcnZlckNvbm5lY3Rpb25Qcm90b2NvbCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcCIsImltcG9ydCB7IFR5cGVkRXZlbnQgfSBmcm9tIFwicmV0dGltZVwiO1xuaW1wb3J0IHt9IGZyb20gXCJAbXN3anMvaW50ZXJjZXB0b3JzL1dlYlNvY2tldFwiO1xuaW1wb3J0IHtcbiAga0Nvbm5lY3QsXG4gIGtBdXRvQ29ubmVjdFxufSBmcm9tICcuLi8uLi9oYW5kbGVycy9XZWJTb2NrZXRIYW5kbGVyLm1qcyc7XG5pbXBvcnQge1xuICBOZXR3b3JrRnJhbWVcbn0gZnJvbSAnLi9uZXR3b3JrLWZyYW1lLm1qcyc7XG5pbXBvcnQge1xuICBleGVjdXRlVW5oYW5kbGVkRnJhbWVIYW5kbGVcbn0gZnJvbSAnLi4vb24tdW5oYW5kbGVkLWZyYW1lLm1qcyc7XG5pbXBvcnQgeyBkZXZVdGlscyB9IGZyb20gJy4uLy4uL3V0aWxzL2ludGVybmFsL2RldlV0aWxzLm1qcyc7XG5pbXBvcnQge30gZnJvbSAnLi4vaGFuZGxlcnMtY29udHJvbGxlci5tanMnO1xuY2xhc3MgV2ViU29ja2V0Q29ubmVjdGlvbkV2ZW50IGV4dGVuZHMgVHlwZWRFdmVudCB7XG4gIHVybDtcbiAgcHJvdG9jb2xzO1xuICBjb25zdHJ1Y3Rvcih0eXBlLCBkYXRhKSB7XG4gICAgc3VwZXIoLi4uW3R5cGUsIHt9XSk7XG4gICAgdGhpcy51cmwgPSBkYXRhLnVybDtcbiAgICB0aGlzLnByb3RvY29scyA9IGRhdGEucHJvdG9jb2xzO1xuICB9XG59XG5jbGFzcyBVbmhhbmRsZWRXZWJTb2NrZXRFeGNlcHRpb25FdmVudCBleHRlbmRzIFR5cGVkRXZlbnQge1xuICB1cmw7XG4gIHByb3RvY29scztcbiAgZXJyb3I7XG4gIGNvbnN0cnVjdG9yKHR5cGUsIGRhdGEpIHtcbiAgICBzdXBlciguLi5bdHlwZSwge31dKTtcbiAgICB0aGlzLnVybCA9IGRhdGEudXJsO1xuICAgIHRoaXMucHJvdG9jb2xzID0gZGF0YS5wcm90b2NvbHM7XG4gICAgdGhpcy5lcnJvciA9IGRhdGEuZXJyb3I7XG4gIH1cbn1cbmNsYXNzIFdlYlNvY2tldE5ldHdvcmtGcmFtZSBleHRlbmRzIE5ldHdvcmtGcmFtZSB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICBzdXBlcihcIndzXCIsIHtcbiAgICAgIGNvbm5lY3Rpb246IG9wdGlvbnMuY29ubmVjdGlvblxuICAgIH0pO1xuICB9XG4gIGdldEhhbmRsZXJzKGNvbnRyb2xsZXIpIHtcbiAgICByZXR1cm4gY29udHJvbGxlci5nZXRIYW5kbGVyc0J5S2luZChcIndlYnNvY2tldFwiKTtcbiAgfVxuICBhc3luYyByZXNvbHZlKGhhbmRsZXJzLCBvblVuaGFuZGxlZEZyYW1lLCByZXNvbHV0aW9uQ29udGV4dCkge1xuICAgIGNvbnN0IHsgY29ubmVjdGlvbiB9ID0gdGhpcy5kYXRhO1xuICAgIHRoaXMuZXZlbnRzLmVtaXQoXG4gICAgICBuZXcgV2ViU29ja2V0Q29ubmVjdGlvbkV2ZW50KFwiY29ubmVjdGlvblwiLCB7XG4gICAgICAgIHVybDogY29ubmVjdGlvbi5jbGllbnQudXJsLFxuICAgICAgICBwcm90b2NvbHM6IGNvbm5lY3Rpb24uaW5mby5wcm90b2NvbHNcbiAgICAgIH0pXG4gICAgKTtcbiAgICBpZiAoaGFuZGxlcnMubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCBleGVjdXRlVW5oYW5kbGVkRnJhbWVIYW5kbGUodGhpcywgb25VbmhhbmRsZWRGcmFtZSkudGhlbihcbiAgICAgICAgKCkgPT4gdGhpcy5wYXNzdGhyb3VnaCgpLFxuICAgICAgICAoZXJyb3IpID0+IHRoaXMuZXJyb3JXaXRoKGVycm9yKVxuICAgICAgKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgbGV0IGhhc01hdGNoaW5nSGFuZGxlcnMgPSBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IGhhbmRsZXIgb2YgaGFuZGxlcnMpIHtcbiAgICAgIGNvbnN0IGhhbmRsZXJDb25uZWN0aW9uID0gYXdhaXQgaGFuZGxlci5ydW4oY29ubmVjdGlvbiwge1xuICAgICAgICBiYXNlVXJsOiByZXNvbHV0aW9uQ29udGV4dD8uYmFzZVVybD8udG9TdHJpbmcoKSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIEBub3RlIERvIG5vdCBlbWl0IHRoZSBcImNvbm5lY3Rpb25cIiBldmVudCB3aGVuIHJ1bm5pbmcgdGhlIGhhbmRsZXIuXG4gICAgICAgICAqIFVzZSB0aGUgcnVuIG9ubHkgdG8gZ2V0IHRoZSByZXNvbHZlZCBjb25uZWN0aW9uIG9iamVjdC5cbiAgICAgICAgICovXG4gICAgICAgIFtrQXV0b0Nvbm5lY3RdOiBmYWxzZVxuICAgICAgfSk7XG4gICAgICBpZiAoIWhhbmRsZXJDb25uZWN0aW9uKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaGFzTWF0Y2hpbmdIYW5kbGVycyA9IHRydWU7XG4gICAgICBjb25zdCByZW1vdmVMb2dnZXIgPSAhcmVzb2x1dGlvbkNvbnRleHQ/LnF1aWV0ID8gaGFuZGxlci5sb2coY29ubmVjdGlvbikgOiB2b2lkIDA7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoIWhhbmRsZXJba0Nvbm5lY3RdKGhhbmRsZXJDb25uZWN0aW9uKSkge1xuICAgICAgICAgIHJlbW92ZUxvZ2dlcj8uKCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmICghdGhpcy5ldmVudHMuZW1pdChcbiAgICAgICAgICBuZXcgVW5oYW5kbGVkV2ViU29ja2V0RXhjZXB0aW9uRXZlbnQoXCJ1bmhhbmRsZWRFeGNlcHRpb25cIiwge1xuICAgICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgICB1cmw6IGNvbm5lY3Rpb24uY2xpZW50LnVybCxcbiAgICAgICAgICAgIHByb3RvY29sczogY29ubmVjdGlvbi5pbmZvLnByb3RvY29sc1xuICAgICAgICAgIH0pXG4gICAgICAgICkpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgICBkZXZVdGlscy5lcnJvcihcbiAgICAgICAgICAgICdFbmNvdW50ZXJlZCBhbiB1bmhhbmRsZWQgZXhjZXB0aW9uIGR1cmluZyB0aGUgaGFuZGxlciBsb29rdXAgZm9yIFwiJXNcIi4gUGxlYXNlIHNlZSB0aGUgb3JpZ2luYWwgZXJyb3IgYWJvdmUuJyxcbiAgICAgICAgICAgIGNvbm5lY3Rpb24uY2xpZW50LnVybFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghaGFzTWF0Y2hpbmdIYW5kbGVycykge1xuICAgICAgYXdhaXQgZXhlY3V0ZVVuaGFuZGxlZEZyYW1lSGFuZGxlKHRoaXMsIG9uVW5oYW5kbGVkRnJhbWUpLnRoZW4oXG4gICAgICAgICgpID0+IHRoaXMucGFzc3Rocm91Z2goKSxcbiAgICAgICAgKGVycm9yKSA9PiB0aGlzLmVycm9yV2l0aChlcnJvcilcbiAgICAgICk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIGdldFVuaGFuZGxlZE1lc3NhZ2UoKSB7XG4gICAgY29uc3QgeyBjb25uZWN0aW9uIH0gPSB0aGlzLmRhdGE7XG4gICAgY29uc3QgZGV0YWlscyA9IGBcblxuICBcXHUyMDIyICR7Y29ubmVjdGlvbi5jbGllbnQudXJsfVxuXG5gO1xuICAgIHJldHVybiBgaW50ZXJjZXB0ZWQgYSBXZWJTb2NrZXQgY29ubmVjdGlvbiB3aXRob3V0IGEgbWF0Y2hpbmcgZXZlbnQgaGFuZGxlcjoke2RldGFpbHN9SWYgeW91IHN0aWxsIHdpc2ggdG8gaW50ZXJjZXB0IHRoaXMgdW5oYW5kbGVkIGNvbm5lY3Rpb24sIHBsZWFzZSBjcmVhdGUgYW4gZXZlbnQgaGFuZGxlciBmb3IgaXQuXG5SZWFkIG1vcmU6IGh0dHBzOi8vbXN3anMuaW8vZG9jcy93ZWJzb2NrZXRgO1xuICB9XG59XG5leHBvcnQge1xuICBXZWJTb2NrZXROZXR3b3JrRnJhbWVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD13ZWJzb2NrZXQtZnJhbWUubWpzLm1hcCIsImltcG9ydCB7IEJhdGNoSW50ZXJjZXB0b3IgfSBmcm9tIFwiQG1zd2pzL2ludGVyY2VwdG9yc1wiO1xuaW1wb3J0IHsgTmV0d29ya1NvdXJjZSB9IGZyb20gJy4vbmV0d29yay1zb3VyY2UubWpzJztcbmltcG9ydCB7IEludGVybmFsRXJyb3IgfSBmcm9tICcuLi8uLi91dGlscy9pbnRlcm5hbC9kZXZVdGlscy5tanMnO1xuaW1wb3J0IHsgSHR0cE5ldHdvcmtGcmFtZSwgUmVzcG9uc2VFdmVudCB9IGZyb20gJy4uL2ZyYW1lcy9odHRwLWZyYW1lLm1qcyc7XG5pbXBvcnQgeyBXZWJTb2NrZXROZXR3b3JrRnJhbWUgfSBmcm9tICcuLi9mcmFtZXMvd2Vic29ja2V0LWZyYW1lLm1qcyc7XG5pbXBvcnQgeyBkZWxldGVSZXF1ZXN0UGFzc3Rocm91Z2hIZWFkZXIgfSBmcm9tICcuLi9yZXF1ZXN0LXV0aWxzLm1qcyc7XG5jbGFzcyBJbnRlcmNlcHRvclNvdXJjZSBleHRlbmRzIE5ldHdvcmtTb3VyY2Uge1xuICAjaW50ZXJjZXB0b3I7XG4gICNmcmFtZXM7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuI2ludGVyY2VwdG9yID0gbmV3IEJhdGNoSW50ZXJjZXB0b3Ioe1xuICAgICAgbmFtZTogXCJpbnRlcmNlcHRvci1zb3VyY2VcIixcbiAgICAgIGludGVyY2VwdG9yczogb3B0aW9ucy5pbnRlcmNlcHRvcnNcbiAgICB9KTtcbiAgICB0aGlzLiNmcmFtZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICB9XG4gIGVuYWJsZSgpIHtcbiAgICB0aGlzLiNpbnRlcmNlcHRvci5hcHBseSgpO1xuICAgIHRoaXMuI2ludGVyY2VwdG9yLm9uKFwicmVxdWVzdFwiLCB0aGlzLiNoYW5kbGVSZXF1ZXN0LmJpbmQodGhpcykpLm9uKFwicmVzcG9uc2VcIiwgdGhpcy4jaGFuZGxlUmVzcG9uc2UuYmluZCh0aGlzKSkub24oXCJjb25uZWN0aW9uXCIsIHRoaXMuI2hhbmRsZVdlYlNvY2tldENvbm5lY3Rpb24uYmluZCh0aGlzKSk7XG4gIH1cbiAgZGlzYWJsZSgpIHtcbiAgICBzdXBlci5kaXNhYmxlKCk7XG4gICAgdGhpcy4jaW50ZXJjZXB0b3IuZGlzcG9zZSgpO1xuICAgIHRoaXMuI2ZyYW1lcy5jbGVhcigpO1xuICB9XG4gIGFzeW5jICNoYW5kbGVSZXF1ZXN0KHtcbiAgICByZXF1ZXN0SWQsXG4gICAgcmVxdWVzdCxcbiAgICBjb250cm9sbGVyXG4gIH0pIHtcbiAgICBjb25zdCBodHRwRnJhbWUgPSBuZXcgSW50ZXJjZXB0b3JIdHRwTmV0d29ya0ZyYW1lKHtcbiAgICAgIGlkOiByZXF1ZXN0SWQsXG4gICAgICByZXF1ZXN0LFxuICAgICAgY29udHJvbGxlclxuICAgIH0pO1xuICAgIHRoaXMuI2ZyYW1lcy5zZXQocmVxdWVzdElkLCBodHRwRnJhbWUpO1xuICAgIGF3YWl0IHRoaXMucXVldWUoaHR0cEZyYW1lKTtcbiAgfVxuICBhc3luYyAjaGFuZGxlUmVzcG9uc2Uoe1xuICAgIHJlcXVlc3RJZCxcbiAgICByZXF1ZXN0LFxuICAgIHJlc3BvbnNlLFxuICAgIGlzTW9ja2VkUmVzcG9uc2VcbiAgfSkge1xuICAgIGNvbnN0IGh0dHBGcmFtZSA9IHRoaXMuI2ZyYW1lcy5nZXQocmVxdWVzdElkKTtcbiAgICB0aGlzLiNmcmFtZXMuZGVsZXRlKHJlcXVlc3RJZCk7XG4gICAgaWYgKGh0dHBGcmFtZSA9PSBudWxsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGh0dHBGcmFtZS5ldmVudHMuZW1pdChcbiAgICAgICAgICBuZXcgUmVzcG9uc2VFdmVudChcbiAgICAgICAgICAgIGlzTW9ja2VkUmVzcG9uc2UgPyBcInJlc3BvbnNlOm1vY2tlZFwiIDogXCJyZXNwb25zZTpieXBhc3NcIixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgcmVxdWVzdElkLFxuICAgICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgICByZXNwb25zZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGh0dHBGcmFtZS5ldmVudHMucmVtb3ZlQWxsTGlzdGVuZXJzKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgYXN5bmMgI2hhbmRsZVdlYlNvY2tldENvbm5lY3Rpb24oY29ubmVjdGlvbikge1xuICAgIGF3YWl0IHRoaXMucXVldWUoXG4gICAgICBuZXcgSW50ZXJjZXB0b3JXZWJTb2NrZXROZXR3b3JrRnJhbWUoe1xuICAgICAgICBjb25uZWN0aW9uXG4gICAgICB9KVxuICAgICk7XG4gIH1cbn1cbmNsYXNzIEludGVyY2VwdG9ySHR0cE5ldHdvcmtGcmFtZSBleHRlbmRzIEh0dHBOZXR3b3JrRnJhbWUge1xuICAjY29udHJvbGxlcjtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHN1cGVyKHtcbiAgICAgIGlkOiBvcHRpb25zLmlkLFxuICAgICAgcmVxdWVzdDogb3B0aW9ucy5yZXF1ZXN0XG4gICAgfSk7XG4gICAgdGhpcy4jY29udHJvbGxlciA9IG9wdGlvbnMuY29udHJvbGxlcjtcbiAgfVxuICBwYXNzdGhyb3VnaCgpIHtcbiAgICBkZWxldGVSZXF1ZXN0UGFzc3Rocm91Z2hIZWFkZXIodGhpcy5kYXRhLnJlcXVlc3QpO1xuICB9XG4gIHJlc3BvbmRXaXRoKHJlc3BvbnNlKSB7XG4gICAgaWYgKHJlc3BvbnNlKSB7XG4gICAgICB0aGlzLiNjb250cm9sbGVyLnJlc3BvbmRXaXRoKHJlc3BvbnNlKTtcbiAgICB9XG4gIH1cbiAgZXJyb3JXaXRoKHJlYXNvbikge1xuICAgIGlmIChyZWFzb24gaW5zdGFuY2VvZiBSZXNwb25zZSkge1xuICAgICAgcmV0dXJuIHRoaXMucmVzcG9uZFdpdGgocmVhc29uKTtcbiAgICB9XG4gICAgaWYgKHJlYXNvbiBpbnN0YW5jZW9mIEludGVybmFsRXJyb3IpIHtcbiAgICAgIHRoaXMuI2NvbnRyb2xsZXIuZXJyb3JXaXRoKHJlYXNvbik7XG4gICAgfVxuICAgIHRocm93IHJlYXNvbjtcbiAgfVxufVxuY2xhc3MgSW50ZXJjZXB0b3JXZWJTb2NrZXROZXR3b3JrRnJhbWUgZXh0ZW5kcyBXZWJTb2NrZXROZXR3b3JrRnJhbWUge1xuICBjb25zdHJ1Y3RvcihhcmdzKSB7XG4gICAgc3VwZXIoeyBjb25uZWN0aW9uOiBhcmdzLmNvbm5lY3Rpb24gfSk7XG4gICAgYXJncy5jb25uZWN0aW9uLmNsaWVudC5hZGRFdmVudExpc3RlbmVyKFxuICAgICAgXCJjbG9zZVwiLFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLmV2ZW50cy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG9uY2U6IHRydWVcbiAgICAgIH1cbiAgICApO1xuICB9XG4gIGVycm9yV2l0aChyZWFzb24pIHtcbiAgICBpZiAocmVhc29uIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgIGNvbnN0IHsgY2xpZW50IH0gPSB0aGlzLmRhdGEuY29ubmVjdGlvbjtcbiAgICAgIGNvbnN0IGVycm9yRXZlbnQgPSBuZXcgRXZlbnQoXCJlcnJvclwiKTtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlcnJvckV2ZW50LCBcImNhdXNlXCIsIHtcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiBmYWxzZSxcbiAgICAgICAgdmFsdWU6IHJlYXNvblxuICAgICAgfSk7XG4gICAgICBjbGllbnQuc29ja2V0LmRpc3BhdGNoRXZlbnQoZXJyb3JFdmVudCk7XG4gICAgfVxuICB9XG4gIHBhc3N0aHJvdWdoKCkge1xuICAgIHRoaXMuZGF0YS5jb25uZWN0aW9uLnNlcnZlci5jb25uZWN0KCk7XG4gIH1cbn1cbmV4cG9ydCB7XG4gIEludGVyY2VwdG9yU291cmNlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW50ZXJjZXB0b3Itc291cmNlLm1qcy5tYXAiLCJpbXBvcnQgeyBpbnZhcmlhbnQgfSBmcm9tIFwib3V0dmFyaWFudFwiO1xuaW1wb3J0IHt9IGZyb20gJy4uL3V0aWxzL3JlcXVlc3Qvb25VbmhhbmRsZWRSZXF1ZXN0Lm1qcyc7XG5pbXBvcnQge1xuICBleGVjdXRlVW5oYW5kbGVkRnJhbWVIYW5kbGVcbn0gZnJvbSAnLi9vbi11bmhhbmRsZWQtZnJhbWUubWpzJztcbmltcG9ydCB7IEh0dHBOZXR3b3JrRnJhbWUgfSBmcm9tICcuL2ZyYW1lcy9odHRwLWZyYW1lLm1qcyc7XG5pbXBvcnQgeyBXZWJTb2NrZXROZXR3b3JrRnJhbWUgfSBmcm9tICcuL2ZyYW1lcy93ZWJzb2NrZXQtZnJhbWUubWpzJztcbmZ1bmN0aW9uIGZyb21MZWdhY3lPblVuaGFuZGxlZFJlcXVlc3QoZ2V0TGVnYWN5VmFsdWUpIHtcbiAgcmV0dXJuICh7IGZyYW1lLCBkZWZhdWx0cyB9KSA9PiB7XG4gICAgY29uc3QgbGVnYWN5T25VbmhhbmRsZWRSZXF1ZXN0U3RyYXRlZ3kgPSBnZXRMZWdhY3lWYWx1ZSgpO1xuICAgIGlmIChsZWdhY3lPblVuaGFuZGxlZFJlcXVlc3RTdHJhdGVneSA9PSBudWxsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0eXBlb2YgbGVnYWN5T25VbmhhbmRsZWRSZXF1ZXN0U3RyYXRlZ3kgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgY29uc3QgcmVxdWVzdCA9IGZyYW1lIGluc3RhbmNlb2YgSHR0cE5ldHdvcmtGcmFtZSA/IGZyYW1lLmRhdGEucmVxdWVzdCA6IGZyYW1lIGluc3RhbmNlb2YgV2ViU29ja2V0TmV0d29ya0ZyYW1lID8gbmV3IFJlcXVlc3QoZnJhbWUuZGF0YS5jb25uZWN0aW9uLmNsaWVudC51cmwsIHtcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIGNvbm5lY3Rpb246IFwidXBncmFkZVwiLFxuICAgICAgICAgIHVwZ3JhZGU6IFwid2Vic29ja2V0XCJcbiAgICAgICAgfVxuICAgICAgfSkgOiBudWxsO1xuICAgICAgaW52YXJpYW50KFxuICAgICAgICByZXF1ZXN0ICE9IG51bGwsXG4gICAgICAgICdGYWlsZWQgdG8gY29lcmNlIGEgbmV0d29yayBmcmFtZSB0byBhIGxlZ2FjeSBgb25VbmhhbmRsZWRSZXF1ZXN0YCBzdHJhdGVneTogdW5rbm93biBmcmFtZSBwcm90b2NvbCBcIiVzXCInLFxuICAgICAgICBmcmFtZS5wcm90b2NvbFxuICAgICAgKTtcbiAgICAgIHJldHVybiBsZWdhY3lPblVuaGFuZGxlZFJlcXVlc3RTdHJhdGVneShyZXF1ZXN0LCB7XG4gICAgICAgIHdhcm5pbmc6IGRlZmF1bHRzLndhcm4sXG4gICAgICAgIGVycm9yOiBkZWZhdWx0cy5lcnJvclxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBleGVjdXRlVW5oYW5kbGVkRnJhbWVIYW5kbGUoZnJhbWUsIGxlZ2FjeU9uVW5oYW5kbGVkUmVxdWVzdFN0cmF0ZWd5KTtcbiAgfTtcbn1cbmV4cG9ydCB7XG4gIGZyb21MZWdhY3lPblVuaGFuZGxlZFJlcXVlc3Rcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb21wYXQubWpzLm1hcCIsImZ1bmN0aW9uIHRvUmVzcG9uc2VJbml0KHJlc3BvbnNlKSB7XG4gIHJldHVybiB7XG4gICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXG4gICAgc3RhdHVzVGV4dDogcmVzcG9uc2Uuc3RhdHVzVGV4dCxcbiAgICBoZWFkZXJzOiBPYmplY3QuZnJvbUVudHJpZXMocmVzcG9uc2UuaGVhZGVycy5lbnRyaWVzKCkpXG4gIH07XG59XG5leHBvcnQge1xuICB0b1Jlc3BvbnNlSW5pdFxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXRvUmVzcG9uc2VJbml0Lm1qcy5tYXAiLCIvLyBub2RlX21vZHVsZXMvLnBucG0vb3V0dmFyaWFudEAxLjQuMy9ub2RlX21vZHVsZXMvb3V0dmFyaWFudC9saWIvaW5kZXgubWpzXG52YXIgUE9TSVRJT05BTFNfRVhQID0gLyglPykoJShbc2Rpam9dKSkvZztcbmZ1bmN0aW9uIHNlcmlhbGl6ZVBvc2l0aW9uYWwocG9zaXRpb25hbCwgZmxhZykge1xuICBzd2l0Y2ggKGZsYWcpIHtcbiAgICBjYXNlIFwic1wiOlxuICAgICAgcmV0dXJuIHBvc2l0aW9uYWw7XG4gICAgY2FzZSBcImRcIjpcbiAgICBjYXNlIFwiaVwiOlxuICAgICAgcmV0dXJuIE51bWJlcihwb3NpdGlvbmFsKTtcbiAgICBjYXNlIFwialwiOlxuICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHBvc2l0aW9uYWwpO1xuICAgIGNhc2UgXCJvXCI6IHtcbiAgICAgIGlmICh0eXBlb2YgcG9zaXRpb25hbCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXR1cm4gcG9zaXRpb25hbDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGpzb24gPSBKU09OLnN0cmluZ2lmeShwb3NpdGlvbmFsKTtcbiAgICAgIGlmIChqc29uID09PSBcInt9XCIgfHwganNvbiA9PT0gXCJbXVwiIHx8IC9eXFxbb2JqZWN0IC4rP1xcXSQvLnRlc3QoanNvbikpIHtcbiAgICAgICAgcmV0dXJuIHBvc2l0aW9uYWw7XG4gICAgICB9XG4gICAgICByZXR1cm4ganNvbjtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGZvcm1hdChtZXNzYWdlLCAuLi5wb3NpdGlvbmFscykge1xuICBpZiAocG9zaXRpb25hbHMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIG1lc3NhZ2U7XG4gIH1cbiAgbGV0IHBvc2l0aW9uYWxJbmRleCA9IDA7XG4gIGxldCBmb3JtYXR0ZWRNZXNzYWdlID0gbWVzc2FnZS5yZXBsYWNlKFxuICAgIFBPU0lUSU9OQUxTX0VYUCxcbiAgICAobWF0Y2gsIGlzRXNjYXBlZCwgXywgZmxhZykgPT4ge1xuICAgICAgY29uc3QgcG9zaXRpb25hbCA9IHBvc2l0aW9uYWxzW3Bvc2l0aW9uYWxJbmRleF07XG4gICAgICBjb25zdCB2YWx1ZSA9IHNlcmlhbGl6ZVBvc2l0aW9uYWwocG9zaXRpb25hbCwgZmxhZyk7XG4gICAgICBpZiAoIWlzRXNjYXBlZCkge1xuICAgICAgICBwb3NpdGlvbmFsSW5kZXgrKztcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG1hdGNoO1xuICAgIH1cbiAgKTtcbiAgaWYgKHBvc2l0aW9uYWxJbmRleCA8IHBvc2l0aW9uYWxzLmxlbmd0aCkge1xuICAgIGZvcm1hdHRlZE1lc3NhZ2UgKz0gYCAke3Bvc2l0aW9uYWxzLnNsaWNlKHBvc2l0aW9uYWxJbmRleCkuam9pbihcIiBcIil9YDtcbiAgfVxuICBmb3JtYXR0ZWRNZXNzYWdlID0gZm9ybWF0dGVkTWVzc2FnZS5yZXBsYWNlKC8lezIsMn0vZywgXCIlXCIpO1xuICByZXR1cm4gZm9ybWF0dGVkTWVzc2FnZTtcbn1cbnZhciBTVEFDS19GUkFNRVNfVE9fSUdOT1JFID0gMjtcbmZ1bmN0aW9uIGNsZWFuRXJyb3JTdGFjayhlcnJvcjIpIHtcbiAgaWYgKCFlcnJvcjIuc3RhY2spIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgbmV4dFN0YWNrID0gZXJyb3IyLnN0YWNrLnNwbGl0KFwiXFxuXCIpO1xuICBuZXh0U3RhY2suc3BsaWNlKDEsIFNUQUNLX0ZSQU1FU19UT19JR05PUkUpO1xuICBlcnJvcjIuc3RhY2sgPSBuZXh0U3RhY2suam9pbihcIlxcblwiKTtcbn1cbnZhciBJbnZhcmlhbnRFcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlLCAuLi5wb3NpdGlvbmFscykge1xuICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgIHRoaXMubWVzc2FnZSA9IG1lc3NhZ2U7XG4gICAgdGhpcy5uYW1lID0gXCJJbnZhcmlhbnQgVmlvbGF0aW9uXCI7XG4gICAgdGhpcy5tZXNzYWdlID0gZm9ybWF0KG1lc3NhZ2UsIC4uLnBvc2l0aW9uYWxzKTtcbiAgICBjbGVhbkVycm9yU3RhY2sodGhpcyk7XG4gIH1cbn07XG52YXIgaW52YXJpYW50ID0gKHByZWRpY2F0ZSwgbWVzc2FnZSwgLi4ucG9zaXRpb25hbHMpID0+IHtcbiAgaWYgKCFwcmVkaWNhdGUpIHtcbiAgICB0aHJvdyBuZXcgSW52YXJpYW50RXJyb3IobWVzc2FnZSwgLi4ucG9zaXRpb25hbHMpO1xuICB9XG59O1xuaW52YXJpYW50LmFzID0gKEVycm9yQ29uc3RydWN0b3IsIHByZWRpY2F0ZSwgbWVzc2FnZSwgLi4ucG9zaXRpb25hbHMpID0+IHtcbiAgaWYgKCFwcmVkaWNhdGUpIHtcbiAgICBjb25zdCBmb3JtYXRNZXNzYWdlID0gcG9zaXRpb25hbHMubGVuZ3RoID09PSAwID8gbWVzc2FnZSA6IGZvcm1hdChtZXNzYWdlLCAuLi5wb3NpdGlvbmFscyk7XG4gICAgbGV0IGVycm9yMjtcbiAgICB0cnkge1xuICAgICAgZXJyb3IyID0gUmVmbGVjdC5jb25zdHJ1Y3QoRXJyb3JDb25zdHJ1Y3RvciwgW1xuICAgICAgICBmb3JtYXRNZXNzYWdlXG4gICAgICBdKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGVycm9yMiA9IEVycm9yQ29uc3RydWN0b3IoZm9ybWF0TWVzc2FnZSk7XG4gICAgfVxuICAgIHRocm93IGVycm9yMjtcbiAgfVxufTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2lzLW5vZGUtcHJvY2Vzc0AxLjIuMC9ub2RlX21vZHVsZXMvaXMtbm9kZS1wcm9jZXNzL2xpYi9pbmRleC5tanNcbmZ1bmN0aW9uIGlzTm9kZVByb2Nlc3MoKSB7XG4gIGlmICh0eXBlb2YgbmF2aWdhdG9yICE9PSBcInVuZGVmaW5lZFwiICYmIG5hdmlnYXRvci5wcm9kdWN0ID09PSBcIlJlYWN0TmF0aXZlXCIpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAodHlwZW9mIHByb2Nlc3MgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBjb25zdCB0eXBlID0gcHJvY2Vzcy50eXBlO1xuICAgIGlmICh0eXBlID09PSBcInJlbmRlcmVyXCIgfHwgdHlwZSA9PT0gXCJ3b3JrZXJcIikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gISEocHJvY2Vzcy52ZXJzaW9ucyAmJiBwcm9jZXNzLnZlcnNpb25zLm5vZGUpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0BvcGVuLWRyYWZ0K2xvZ2dlckAwLjMuMC9ub2RlX21vZHVsZXMvQG9wZW4tZHJhZnQvbG9nZ2VyL2xpYi9pbmRleC5tanNcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19leHBvcnQgPSAodGFyZ2V0LCBhbGwpID0+IHtcbiAgZm9yICh2YXIgbmFtZSBpbiBhbGwpXG4gICAgX19kZWZQcm9wKHRhcmdldCwgbmFtZSwgeyBnZXQ6IGFsbFtuYW1lXSwgZW51bWVyYWJsZTogdHJ1ZSB9KTtcbn07XG52YXIgY29sb3JzX2V4cG9ydHMgPSB7fTtcbl9fZXhwb3J0KGNvbG9yc19leHBvcnRzLCB7XG4gIGJsdWU6ICgpID0+IGJsdWUsXG4gIGdyYXk6ICgpID0+IGdyYXksXG4gIGdyZWVuOiAoKSA9PiBncmVlbixcbiAgcmVkOiAoKSA9PiByZWQsXG4gIHllbGxvdzogKCkgPT4geWVsbG93XG59KTtcbmZ1bmN0aW9uIHllbGxvdyh0ZXh0KSB7XG4gIHJldHVybiBgXFx4MUJbMzNtJHt0ZXh0fVxceDFCWzBtYDtcbn1cbmZ1bmN0aW9uIGJsdWUodGV4dCkge1xuICByZXR1cm4gYFxceDFCWzM0bSR7dGV4dH1cXHgxQlswbWA7XG59XG5mdW5jdGlvbiBncmF5KHRleHQpIHtcbiAgcmV0dXJuIGBcXHgxQls5MG0ke3RleHR9XFx4MUJbMG1gO1xufVxuZnVuY3Rpb24gcmVkKHRleHQpIHtcbiAgcmV0dXJuIGBcXHgxQlszMW0ke3RleHR9XFx4MUJbMG1gO1xufVxuZnVuY3Rpb24gZ3JlZW4odGV4dCkge1xuICByZXR1cm4gYFxceDFCWzMybSR7dGV4dH1cXHgxQlswbWA7XG59XG52YXIgSVNfTk9ERSA9IGlzTm9kZVByb2Nlc3MoKTtcbnZhciBMb2dnZXIgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKG5hbWUpIHtcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgIHRoaXMucHJlZml4ID0gYFske3RoaXMubmFtZX1dYDtcbiAgICBjb25zdCBMT0dHRVJfTkFNRSA9IGdldFZhcmlhYmxlKFwiREVCVUdcIik7XG4gICAgY29uc3QgTE9HR0VSX0xFVkVMID0gZ2V0VmFyaWFibGUoXCJMT0dfTEVWRUxcIik7XG4gICAgY29uc3QgaXNMb2dnaW5nRW5hYmxlZCA9IExPR0dFUl9OQU1FID09PSBcIjFcIiB8fCBMT0dHRVJfTkFNRSA9PT0gXCJ0cnVlXCIgfHwgdHlwZW9mIExPR0dFUl9OQU1FICE9PSBcInVuZGVmaW5lZFwiICYmIHRoaXMubmFtZS5zdGFydHNXaXRoKExPR0dFUl9OQU1FKTtcbiAgICBpZiAoaXNMb2dnaW5nRW5hYmxlZCkge1xuICAgICAgdGhpcy5kZWJ1ZyA9IGlzRGVmaW5lZEFuZE5vdEVxdWFscyhMT0dHRVJfTEVWRUwsIFwiZGVidWdcIikgPyBub29wIDogdGhpcy5kZWJ1ZztcbiAgICAgIHRoaXMuaW5mbyA9IGlzRGVmaW5lZEFuZE5vdEVxdWFscyhMT0dHRVJfTEVWRUwsIFwiaW5mb1wiKSA/IG5vb3AgOiB0aGlzLmluZm87XG4gICAgICB0aGlzLnN1Y2Nlc3MgPSBpc0RlZmluZWRBbmROb3RFcXVhbHMoTE9HR0VSX0xFVkVMLCBcInN1Y2Nlc3NcIikgPyBub29wIDogdGhpcy5zdWNjZXNzO1xuICAgICAgdGhpcy53YXJuaW5nID0gaXNEZWZpbmVkQW5kTm90RXF1YWxzKExPR0dFUl9MRVZFTCwgXCJ3YXJuaW5nXCIpID8gbm9vcCA6IHRoaXMud2FybmluZztcbiAgICAgIHRoaXMuZXJyb3IgPSBpc0RlZmluZWRBbmROb3RFcXVhbHMoTE9HR0VSX0xFVkVMLCBcImVycm9yXCIpID8gbm9vcCA6IHRoaXMuZXJyb3I7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuaW5mbyA9IG5vb3A7XG4gICAgICB0aGlzLnN1Y2Nlc3MgPSBub29wO1xuICAgICAgdGhpcy53YXJuaW5nID0gbm9vcDtcbiAgICAgIHRoaXMuZXJyb3IgPSBub29wO1xuICAgICAgdGhpcy5vbmx5ID0gbm9vcDtcbiAgICB9XG4gIH1cbiAgcHJlZml4O1xuICBleHRlbmQoZG9tYWluKSB7XG4gICAgcmV0dXJuIG5ldyBMb2dnZXIoYCR7dGhpcy5uYW1lfToke2RvbWFpbn1gKTtcbiAgfVxuICAvKipcbiAgICogUHJpbnQgYSBkZWJ1ZyBtZXNzYWdlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBsb2dnZXIuZGVidWcoJ25vIGR1cGxpY2F0ZXMgZm91bmQsIGNyZWF0aW5nIGEgZG9jdW1lbnQuLi4nKVxuICAgKi9cbiAgZGVidWcobWVzc2FnZSwgLi4ucG9zaXRpb25hbHMpIHtcbiAgICB0aGlzLmxvZ0VudHJ5KHtcbiAgICAgIGxldmVsOiBcImRlYnVnXCIsXG4gICAgICBtZXNzYWdlOiBncmF5KG1lc3NhZ2UpLFxuICAgICAgcG9zaXRpb25hbHMsXG4gICAgICBwcmVmaXg6IHRoaXMucHJlZml4LFxuICAgICAgY29sb3JzOiB7XG4gICAgICAgIHByZWZpeDogXCJncmF5XCJcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogUHJpbnQgYW4gaW5mbyBtZXNzYWdlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBsb2dnZXIuaW5mbygnc3RhcnQgcGFyc2luZy4uLicpXG4gICAqL1xuICBpbmZvKG1lc3NhZ2UsIC4uLnBvc2l0aW9uYWxzKSB7XG4gICAgdGhpcy5sb2dFbnRyeSh7XG4gICAgICBsZXZlbDogXCJpbmZvXCIsXG4gICAgICBtZXNzYWdlLFxuICAgICAgcG9zaXRpb25hbHMsXG4gICAgICBwcmVmaXg6IHRoaXMucHJlZml4LFxuICAgICAgY29sb3JzOiB7XG4gICAgICAgIHByZWZpeDogXCJibHVlXCJcbiAgICAgIH1cbiAgICB9KTtcbiAgICBjb25zdCBwZXJmb3JtYW5jZTIgPSBuZXcgUGVyZm9ybWFuY2VFbnRyeSgpO1xuICAgIHJldHVybiAobWVzc2FnZTIsIC4uLnBvc2l0aW9uYWxzMikgPT4ge1xuICAgICAgcGVyZm9ybWFuY2UyLm1lYXN1cmUoKTtcbiAgICAgIHRoaXMubG9nRW50cnkoe1xuICAgICAgICBsZXZlbDogXCJpbmZvXCIsXG4gICAgICAgIG1lc3NhZ2U6IGAke21lc3NhZ2UyfSAke2dyYXkoYCR7cGVyZm9ybWFuY2UyLmRlbHRhVGltZX1tc2ApfWAsXG4gICAgICAgIHBvc2l0aW9uYWxzOiBwb3NpdGlvbmFsczIsXG4gICAgICAgIHByZWZpeDogdGhpcy5wcmVmaXgsXG4gICAgICAgIGNvbG9yczoge1xuICAgICAgICAgIHByZWZpeDogXCJibHVlXCJcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcbiAgfVxuICAvKipcbiAgICogUHJpbnQgYSBzdWNjZXNzIG1lc3NhZ2UuXG4gICAqIEBleGFtcGxlXG4gICAqIGxvZ2dlci5zdWNjZXNzKCdzdWNjZXNzZnVsbHkgY3JlYXRlZCBkb2N1bWVudCcpXG4gICAqL1xuICBzdWNjZXNzKG1lc3NhZ2UsIC4uLnBvc2l0aW9uYWxzKSB7XG4gICAgdGhpcy5sb2dFbnRyeSh7XG4gICAgICBsZXZlbDogXCJpbmZvXCIsXG4gICAgICBtZXNzYWdlLFxuICAgICAgcG9zaXRpb25hbHMsXG4gICAgICBwcmVmaXg6IGBcXHUyNzE0ICR7dGhpcy5wcmVmaXh9YCxcbiAgICAgIGNvbG9yczoge1xuICAgICAgICB0aW1lc3RhbXA6IFwiZ3JlZW5cIixcbiAgICAgICAgcHJlZml4OiBcImdyZWVuXCJcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogUHJpbnQgYSB3YXJuaW5nLlxuICAgKiBAZXhhbXBsZVxuICAgKiBsb2dnZXIud2FybmluZygnZm91bmQgbGVnYWN5IGRvY3VtZW50IGZvcm1hdCcpXG4gICAqL1xuICB3YXJuaW5nKG1lc3NhZ2UsIC4uLnBvc2l0aW9uYWxzKSB7XG4gICAgdGhpcy5sb2dFbnRyeSh7XG4gICAgICBsZXZlbDogXCJ3YXJuaW5nXCIsXG4gICAgICBtZXNzYWdlLFxuICAgICAgcG9zaXRpb25hbHMsXG4gICAgICBwcmVmaXg6IGBcXHUyNkEwICR7dGhpcy5wcmVmaXh9YCxcbiAgICAgIGNvbG9yczoge1xuICAgICAgICB0aW1lc3RhbXA6IFwieWVsbG93XCIsXG4gICAgICAgIHByZWZpeDogXCJ5ZWxsb3dcIlxuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBQcmludCBhbiBlcnJvciBtZXNzYWdlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBsb2dnZXIuZXJyb3IoJ3NvbWV0aGluZyB3ZW50IHdyb25nJylcbiAgICovXG4gIGVycm9yKG1lc3NhZ2UsIC4uLnBvc2l0aW9uYWxzKSB7XG4gICAgdGhpcy5sb2dFbnRyeSh7XG4gICAgICBsZXZlbDogXCJlcnJvclwiLFxuICAgICAgbWVzc2FnZSxcbiAgICAgIHBvc2l0aW9uYWxzLFxuICAgICAgcHJlZml4OiBgXFx1MjcxNiAke3RoaXMucHJlZml4fWAsXG4gICAgICBjb2xvcnM6IHtcbiAgICAgICAgdGltZXN0YW1wOiBcInJlZFwiLFxuICAgICAgICBwcmVmaXg6IFwicmVkXCJcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogRXhlY3V0ZSB0aGUgZ2l2ZW4gY2FsbGJhY2sgb25seSB3aGVuIHRoZSBsb2dnaW5nIGlzIGVuYWJsZWQuXG4gICAqIFRoaXMgaXMgc2tpcHBlZCBpbiBpdHMgZW50aXJldHkgYW5kIGhhcyBubyBydW50aW1lIGNvc3Qgb3RoZXJ3aXNlLlxuICAgKiBUaGlzIGV4ZWN1dGVzIHJlZ2FyZGxlc3Mgb2YgdGhlIGxvZyBsZXZlbC5cbiAgICogQGV4YW1wbGVcbiAgICogbG9nZ2VyLm9ubHkoKCkgPT4ge1xuICAgKiAgIGxvZ2dlci5pbmZvKCdhZGRpdGlvbmFsIGluZm8nKVxuICAgKiB9KVxuICAgKi9cbiAgb25seShjYWxsYmFjaykge1xuICAgIGNhbGxiYWNrKCk7XG4gIH1cbiAgY3JlYXRlRW50cnkobGV2ZWwsIG1lc3NhZ2UpIHtcbiAgICByZXR1cm4ge1xuICAgICAgdGltZXN0YW1wOiAvKiBAX19QVVJFX18gKi8gbmV3IERhdGUoKSxcbiAgICAgIGxldmVsLFxuICAgICAgbWVzc2FnZVxuICAgIH07XG4gIH1cbiAgbG9nRW50cnkoYXJncykge1xuICAgIGNvbnN0IHtcbiAgICAgIGxldmVsLFxuICAgICAgbWVzc2FnZSxcbiAgICAgIHByZWZpeCxcbiAgICAgIGNvbG9yczogY3VzdG9tQ29sb3JzLFxuICAgICAgcG9zaXRpb25hbHMgPSBbXVxuICAgIH0gPSBhcmdzO1xuICAgIGNvbnN0IGVudHJ5ID0gdGhpcy5jcmVhdGVFbnRyeShsZXZlbCwgbWVzc2FnZSk7XG4gICAgY29uc3QgdGltZXN0YW1wQ29sb3IgPSBjdXN0b21Db2xvcnM/LnRpbWVzdGFtcCB8fCBcImdyYXlcIjtcbiAgICBjb25zdCBwcmVmaXhDb2xvciA9IGN1c3RvbUNvbG9ycz8ucHJlZml4IHx8IFwiZ3JheVwiO1xuICAgIGNvbnN0IGNvbG9yaXplID0ge1xuICAgICAgdGltZXN0YW1wOiBjb2xvcnNfZXhwb3J0c1t0aW1lc3RhbXBDb2xvcl0sXG4gICAgICBwcmVmaXg6IGNvbG9yc19leHBvcnRzW3ByZWZpeENvbG9yXVxuICAgIH07XG4gICAgY29uc3Qgd3JpdGUgPSB0aGlzLmdldFdyaXRlcihsZXZlbCk7XG4gICAgd3JpdGUoXG4gICAgICBbY29sb3JpemUudGltZXN0YW1wKHRoaXMuZm9ybWF0VGltZXN0YW1wKGVudHJ5LnRpbWVzdGFtcCkpXS5jb25jYXQocHJlZml4ICE9IG51bGwgPyBjb2xvcml6ZS5wcmVmaXgocHJlZml4KSA6IFtdKS5jb25jYXQoc2VyaWFsaXplSW5wdXQobWVzc2FnZSkpLmpvaW4oXCIgXCIpLFxuICAgICAgLi4ucG9zaXRpb25hbHMubWFwKHNlcmlhbGl6ZUlucHV0KVxuICAgICk7XG4gIH1cbiAgZm9ybWF0VGltZXN0YW1wKHRpbWVzdGFtcCkge1xuICAgIHJldHVybiBgJHt0aW1lc3RhbXAudG9Mb2NhbGVUaW1lU3RyaW5nKFxuICAgICAgXCJlbi1HQlwiXG4gICAgKX06JHt0aW1lc3RhbXAuZ2V0TWlsbGlzZWNvbmRzKCl9YDtcbiAgfVxuICBnZXRXcml0ZXIobGV2ZWwpIHtcbiAgICBzd2l0Y2ggKGxldmVsKSB7XG4gICAgICBjYXNlIFwiZGVidWdcIjpcbiAgICAgIGNhc2UgXCJzdWNjZXNzXCI6XG4gICAgICBjYXNlIFwiaW5mb1wiOiB7XG4gICAgICAgIHJldHVybiBsb2c7XG4gICAgICB9XG4gICAgICBjYXNlIFwid2FybmluZ1wiOiB7XG4gICAgICAgIHJldHVybiB3YXJuO1xuICAgICAgfVxuICAgICAgY2FzZSBcImVycm9yXCI6IHtcbiAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgfVxuICAgIH1cbiAgfVxufTtcbnZhciBQZXJmb3JtYW5jZUVudHJ5ID0gY2xhc3Mge1xuICBzdGFydFRpbWU7XG4gIGVuZFRpbWU7XG4gIGRlbHRhVGltZTtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5zdGFydFRpbWUgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgfVxuICBtZWFzdXJlKCkge1xuICAgIHRoaXMuZW5kVGltZSA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgIGNvbnN0IGRlbHRhVGltZSA9IHRoaXMuZW5kVGltZSAtIHRoaXMuc3RhcnRUaW1lO1xuICAgIHRoaXMuZGVsdGFUaW1lID0gZGVsdGFUaW1lLnRvRml4ZWQoMik7XG4gIH1cbn07XG52YXIgbm9vcCA9ICgpID0+IHZvaWQgMDtcbmZ1bmN0aW9uIGxvZyhtZXNzYWdlLCAuLi5wb3NpdGlvbmFscykge1xuICBpZiAoSVNfTk9ERSkge1xuICAgIHByb2Nlc3Muc3Rkb3V0LndyaXRlKGZvcm1hdChtZXNzYWdlLCAuLi5wb3NpdGlvbmFscykgKyBcIlxcblwiKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc29sZS5sb2cobWVzc2FnZSwgLi4ucG9zaXRpb25hbHMpO1xufVxuZnVuY3Rpb24gd2FybihtZXNzYWdlLCAuLi5wb3NpdGlvbmFscykge1xuICBpZiAoSVNfTk9ERSkge1xuICAgIHByb2Nlc3Muc3RkZXJyLndyaXRlKGZvcm1hdChtZXNzYWdlLCAuLi5wb3NpdGlvbmFscykgKyBcIlxcblwiKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc29sZS53YXJuKG1lc3NhZ2UsIC4uLnBvc2l0aW9uYWxzKTtcbn1cbmZ1bmN0aW9uIGVycm9yKG1lc3NhZ2UsIC4uLnBvc2l0aW9uYWxzKSB7XG4gIGlmIChJU19OT0RFKSB7XG4gICAgcHJvY2Vzcy5zdGRlcnIud3JpdGUoZm9ybWF0KG1lc3NhZ2UsIC4uLnBvc2l0aW9uYWxzKSArIFwiXFxuXCIpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zb2xlLmVycm9yKG1lc3NhZ2UsIC4uLnBvc2l0aW9uYWxzKTtcbn1cbmZ1bmN0aW9uIGdldFZhcmlhYmxlKHZhcmlhYmxlTmFtZSkge1xuICBpZiAoSVNfTk9ERSkge1xuICAgIHJldHVybiBwcm9jZXNzLmVudlt2YXJpYWJsZU5hbWVdO1xuICB9XG4gIHJldHVybiBnbG9iYWxUaGlzW3ZhcmlhYmxlTmFtZV0/LnRvU3RyaW5nKCk7XG59XG5mdW5jdGlvbiBpc0RlZmluZWRBbmROb3RFcXVhbHModmFsdWUsIGV4cGVjdGVkKSB7XG4gIHJldHVybiB2YWx1ZSAhPT0gdm9pZCAwICYmIHZhbHVlICE9PSBleHBlY3RlZDtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZUlucHV0KG1lc3NhZ2UpIHtcbiAgaWYgKHR5cGVvZiBtZXNzYWdlID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgcmV0dXJuIFwidW5kZWZpbmVkXCI7XG4gIH1cbiAgaWYgKG1lc3NhZ2UgPT09IG51bGwpIHtcbiAgICByZXR1cm4gXCJudWxsXCI7XG4gIH1cbiAgaWYgKHR5cGVvZiBtZXNzYWdlID09PSBcInN0cmluZ1wiKSB7XG4gICAgcmV0dXJuIG1lc3NhZ2U7XG4gIH1cbiAgaWYgKHR5cGVvZiBtZXNzYWdlID09PSBcIm9iamVjdFwiKSB7XG4gICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KG1lc3NhZ2UpO1xuICB9XG4gIHJldHVybiBtZXNzYWdlLnRvU3RyaW5nKCk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9zdHJpY3QtZXZlbnQtZW1pdHRlckAwLjUuMS9ub2RlX21vZHVsZXMvc3RyaWN0LWV2ZW50LWVtaXR0ZXIvbGliL2luZGV4Lm1qc1xudmFyIE1lbW9yeUxlYWtFcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihlbWl0dGVyLCB0eXBlLCBjb3VudCkge1xuICAgIHN1cGVyKFxuICAgICAgYFBvc3NpYmxlIEV2ZW50RW1pdHRlciBtZW1vcnkgbGVhayBkZXRlY3RlZC4gJHtjb3VudH0gJHt0eXBlLnRvU3RyaW5nKCl9IGxpc3RlbmVycyBhZGRlZC4gVXNlIGVtaXR0ZXIuc2V0TWF4TGlzdGVuZXJzKCkgdG8gaW5jcmVhc2UgbGltaXRgXG4gICAgKTtcbiAgICB0aGlzLmVtaXR0ZXIgPSBlbWl0dGVyO1xuICAgIHRoaXMudHlwZSA9IHR5cGU7XG4gICAgdGhpcy5jb3VudCA9IGNvdW50O1xuICAgIHRoaXMubmFtZSA9IFwiTWF4TGlzdGVuZXJzRXhjZWVkZWRXYXJuaW5nXCI7XG4gIH1cbn07XG52YXIgX0VtaXR0ZXIgPSBjbGFzcyB7XG4gIHN0YXRpYyBsaXN0ZW5lckNvdW50KGVtaXR0ZXIsIGV2ZW50TmFtZSkge1xuICAgIHJldHVybiBlbWl0dGVyLmxpc3RlbmVyQ291bnQoZXZlbnROYW1lKTtcbiAgfVxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmV2ZW50cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgdGhpcy5tYXhMaXN0ZW5lcnMgPSBfRW1pdHRlci5kZWZhdWx0TWF4TGlzdGVuZXJzO1xuICAgIHRoaXMuaGFzV2FybmVkQWJvdXRQb3RlbnRpYWxNZW1vcnlMZWFrID0gZmFsc2U7XG4gIH1cbiAgX2VtaXRJbnRlcm5hbEV2ZW50KGludGVybmFsRXZlbnROYW1lLCBldmVudE5hbWUsIGxpc3RlbmVyKSB7XG4gICAgdGhpcy5lbWl0KFxuICAgICAgaW50ZXJuYWxFdmVudE5hbWUsXG4gICAgICAuLi5bZXZlbnROYW1lLCBsaXN0ZW5lcl1cbiAgICApO1xuICB9XG4gIF9nZXRMaXN0ZW5lcnMoZXZlbnROYW1lKSB7XG4gICAgcmV0dXJuIEFycmF5LnByb3RvdHlwZS5jb25jYXQuYXBwbHkoW10sIHRoaXMuZXZlbnRzLmdldChldmVudE5hbWUpKSB8fCBbXTtcbiAgfVxuICBfcmVtb3ZlTGlzdGVuZXIobGlzdGVuZXJzLCBsaXN0ZW5lcikge1xuICAgIGNvbnN0IGluZGV4ID0gbGlzdGVuZXJzLmluZGV4T2YobGlzdGVuZXIpO1xuICAgIGlmIChpbmRleCA+IC0xKSB7XG4gICAgICBsaXN0ZW5lcnMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICB9XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIF93cmFwT25jZUxpc3RlbmVyKGV2ZW50TmFtZSwgbGlzdGVuZXIpIHtcbiAgICBjb25zdCBvbmNlTGlzdGVuZXIgPSAoLi4uZGF0YSkgPT4ge1xuICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcihldmVudE5hbWUsIG9uY2VMaXN0ZW5lcik7XG4gICAgICByZXR1cm4gbGlzdGVuZXIuYXBwbHkodGhpcywgZGF0YSk7XG4gICAgfTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkob25jZUxpc3RlbmVyLCBcIm5hbWVcIiwgeyB2YWx1ZTogbGlzdGVuZXIubmFtZSB9KTtcbiAgICByZXR1cm4gb25jZUxpc3RlbmVyO1xuICB9XG4gIHNldE1heExpc3RlbmVycyhtYXhMaXN0ZW5lcnMpIHtcbiAgICB0aGlzLm1heExpc3RlbmVycyA9IG1heExpc3RlbmVycztcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgY3VycmVudCBtYXggbGlzdGVuZXIgdmFsdWUgZm9yIHRoZSBgRW1pdHRlcmAgd2hpY2ggaXNcbiAgICogZWl0aGVyIHNldCBieSBgZW1pdHRlci5zZXRNYXhMaXN0ZW5lcnMobilgIG9yIGRlZmF1bHRzIHRvXG4gICAqIGBFbWl0dGVyLmRlZmF1bHRNYXhMaXN0ZW5lcnNgLlxuICAgKi9cbiAgZ2V0TWF4TGlzdGVuZXJzKCkge1xuICAgIHJldHVybiB0aGlzLm1heExpc3RlbmVycztcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhbiBhcnJheSBsaXN0aW5nIHRoZSBldmVudHMgZm9yIHdoaWNoIHRoZSBlbWl0dGVyIGhhcyByZWdpc3RlcmVkIGxpc3RlbmVycy5cbiAgICogVGhlIHZhbHVlcyBpbiB0aGUgYXJyYXkgd2lsbCBiZSBzdHJpbmdzIG9yIFN5bWJvbHMuXG4gICAqL1xuICBldmVudE5hbWVzKCkge1xuICAgIHJldHVybiBBcnJheS5mcm9tKHRoaXMuZXZlbnRzLmtleXMoKSk7XG4gIH1cbiAgLyoqXG4gICAqIFN5bmNocm9ub3VzbHkgY2FsbHMgZWFjaCBvZiB0aGUgbGlzdGVuZXJzIHJlZ2lzdGVyZWQgZm9yIHRoZSBldmVudCBuYW1lZCBgZXZlbnROYW1lYCxcbiAgICogaW4gdGhlIG9yZGVyIHRoZXkgd2VyZSByZWdpc3RlcmVkLCBwYXNzaW5nIHRoZSBzdXBwbGllZCBhcmd1bWVudHMgdG8gZWFjaC5cbiAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGV2ZW50IGhhcyBsaXN0ZW5lcnMsIGBmYWxzZWAgb3RoZXJ3aXNlLlxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBjb25zdCBlbWl0dGVyID0gbmV3IEVtaXR0ZXI8eyBoZWxsbzogW3N0cmluZ10gfT4oKVxuICAgKiBlbWl0dGVyLmVtaXQoJ2hlbGxvJywgJ0pvaG4nKVxuICAgKi9cbiAgZW1pdChldmVudE5hbWUsIC4uLmRhdGEpIHtcbiAgICBjb25zdCBsaXN0ZW5lcnMgPSB0aGlzLl9nZXRMaXN0ZW5lcnMoZXZlbnROYW1lKTtcbiAgICBsaXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcbiAgICAgIGxpc3RlbmVyLmFwcGx5KHRoaXMsIGRhdGEpO1xuICAgIH0pO1xuICAgIHJldHVybiBsaXN0ZW5lcnMubGVuZ3RoID4gMDtcbiAgfVxuICBhZGRMaXN0ZW5lcihldmVudE5hbWUsIGxpc3RlbmVyKSB7XG4gICAgdGhpcy5fZW1pdEludGVybmFsRXZlbnQoXCJuZXdMaXN0ZW5lclwiLCBldmVudE5hbWUsIGxpc3RlbmVyKTtcbiAgICBjb25zdCBuZXh0TGlzdGVuZXJzID0gdGhpcy5fZ2V0TGlzdGVuZXJzKGV2ZW50TmFtZSkuY29uY2F0KGxpc3RlbmVyKTtcbiAgICB0aGlzLmV2ZW50cy5zZXQoZXZlbnROYW1lLCBuZXh0TGlzdGVuZXJzKTtcbiAgICBpZiAodGhpcy5tYXhMaXN0ZW5lcnMgPiAwICYmIHRoaXMubGlzdGVuZXJDb3VudChldmVudE5hbWUpID4gdGhpcy5tYXhMaXN0ZW5lcnMgJiYgIXRoaXMuaGFzV2FybmVkQWJvdXRQb3RlbnRpYWxNZW1vcnlMZWFrKSB7XG4gICAgICB0aGlzLmhhc1dhcm5lZEFib3V0UG90ZW50aWFsTWVtb3J5TGVhayA9IHRydWU7XG4gICAgICBjb25zdCBtZW1vcnlMZWFrV2FybmluZyA9IG5ldyBNZW1vcnlMZWFrRXJyb3IoXG4gICAgICAgIHRoaXMsXG4gICAgICAgIGV2ZW50TmFtZSxcbiAgICAgICAgdGhpcy5saXN0ZW5lckNvdW50KGV2ZW50TmFtZSlcbiAgICAgICk7XG4gICAgICBjb25zb2xlLndhcm4obWVtb3J5TGVha1dhcm5pbmcpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBvbihldmVudE5hbWUsIGxpc3RlbmVyKSB7XG4gICAgcmV0dXJuIHRoaXMuYWRkTGlzdGVuZXIoZXZlbnROYW1lLCBsaXN0ZW5lcik7XG4gIH1cbiAgb25jZShldmVudE5hbWUsIGxpc3RlbmVyKSB7XG4gICAgcmV0dXJuIHRoaXMuYWRkTGlzdGVuZXIoXG4gICAgICBldmVudE5hbWUsXG4gICAgICB0aGlzLl93cmFwT25jZUxpc3RlbmVyKGV2ZW50TmFtZSwgbGlzdGVuZXIpXG4gICAgKTtcbiAgfVxuICBwcmVwZW5kTGlzdGVuZXIoZXZlbnROYW1lLCBsaXN0ZW5lcikge1xuICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuX2dldExpc3RlbmVycyhldmVudE5hbWUpO1xuICAgIGlmIChsaXN0ZW5lcnMubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgbmV4dExpc3RlbmVycyA9IFtsaXN0ZW5lcl0uY29uY2F0KGxpc3RlbmVycyk7XG4gICAgICB0aGlzLmV2ZW50cy5zZXQoZXZlbnROYW1lLCBuZXh0TGlzdGVuZXJzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5ldmVudHMuc2V0KGV2ZW50TmFtZSwgbGlzdGVuZXJzLmNvbmNhdChsaXN0ZW5lcikpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBwcmVwZW5kT25jZUxpc3RlbmVyKGV2ZW50TmFtZSwgbGlzdGVuZXIpIHtcbiAgICByZXR1cm4gdGhpcy5wcmVwZW5kTGlzdGVuZXIoXG4gICAgICBldmVudE5hbWUsXG4gICAgICB0aGlzLl93cmFwT25jZUxpc3RlbmVyKGV2ZW50TmFtZSwgbGlzdGVuZXIpXG4gICAgKTtcbiAgfVxuICByZW1vdmVMaXN0ZW5lcihldmVudE5hbWUsIGxpc3RlbmVyKSB7XG4gICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5fZ2V0TGlzdGVuZXJzKGV2ZW50TmFtZSk7XG4gICAgaWYgKGxpc3RlbmVycy5sZW5ndGggPiAwKSB7XG4gICAgICB0aGlzLl9yZW1vdmVMaXN0ZW5lcihsaXN0ZW5lcnMsIGxpc3RlbmVyKTtcbiAgICAgIHRoaXMuZXZlbnRzLnNldChldmVudE5hbWUsIGxpc3RlbmVycyk7XG4gICAgICB0aGlzLl9lbWl0SW50ZXJuYWxFdmVudChcInJlbW92ZUxpc3RlbmVyXCIsIGV2ZW50TmFtZSwgbGlzdGVuZXIpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQWxpYXMgZm9yIGBlbWl0dGVyLnJlbW92ZUxpc3RlbmVyKClgLlxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBlbWl0dGVyLm9mZignaGVsbG8nLCBsaXN0ZW5lcilcbiAgICovXG4gIG9mZihldmVudE5hbWUsIGxpc3RlbmVyKSB7XG4gICAgcmV0dXJuIHRoaXMucmVtb3ZlTGlzdGVuZXIoZXZlbnROYW1lLCBsaXN0ZW5lcik7XG4gIH1cbiAgcmVtb3ZlQWxsTGlzdGVuZXJzKGV2ZW50TmFtZSkge1xuICAgIGlmIChldmVudE5hbWUpIHtcbiAgICAgIHRoaXMuZXZlbnRzLmRlbGV0ZShldmVudE5hbWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmV2ZW50cy5jbGVhcigpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhIGNvcHkgb2YgdGhlIGFycmF5IG9mIGxpc3RlbmVycyBmb3IgdGhlIGV2ZW50IG5hbWVkIGBldmVudE5hbWVgLlxuICAgKi9cbiAgbGlzdGVuZXJzKGV2ZW50TmFtZSkge1xuICAgIHJldHVybiBBcnJheS5mcm9tKHRoaXMuX2dldExpc3RlbmVycyhldmVudE5hbWUpKTtcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgbnVtYmVyIG9mIGxpc3RlbmVycyBsaXN0ZW5pbmcgdG8gdGhlIGV2ZW50IG5hbWVkIGBldmVudE5hbWVgLlxuICAgKi9cbiAgbGlzdGVuZXJDb3VudChldmVudE5hbWUpIHtcbiAgICByZXR1cm4gdGhpcy5fZ2V0TGlzdGVuZXJzKGV2ZW50TmFtZSkubGVuZ3RoO1xuICB9XG4gIHJhd0xpc3RlbmVycyhldmVudE5hbWUpIHtcbiAgICByZXR1cm4gdGhpcy5saXN0ZW5lcnMoZXZlbnROYW1lKTtcbiAgfVxufTtcbnZhciBFbWl0dGVyID0gX0VtaXR0ZXI7XG5FbWl0dGVyLmRlZmF1bHRNYXhMaXN0ZW5lcnMgPSAxMDtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0Btc3dqcytpbnRlcmNlcHRvcnNAMC40MS45L25vZGVfbW9kdWxlcy9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL2NyZWF0ZVJlcXVlc3RJZC1EWUNzRkhPaS5tanNcbnZhciBJTlRFUk5BTF9SRVFVRVNUX0lEX0hFQURFUl9OQU1FID0gXCJ4LWludGVyY2VwdG9ycy1pbnRlcm5hbC1yZXF1ZXN0LWlkXCI7XG5mdW5jdGlvbiBnZXRHbG9iYWxTeW1ib2woc3ltYm9sKSB7XG4gIHJldHVybiBnbG9iYWxUaGlzW3N5bWJvbF0gfHwgdm9pZCAwO1xufVxuZnVuY3Rpb24gc2V0R2xvYmFsU3ltYm9sKHN5bWJvbCwgdmFsdWUpIHtcbiAgZ2xvYmFsVGhpc1tzeW1ib2xdID0gdmFsdWU7XG59XG5mdW5jdGlvbiBkZWxldGVHbG9iYWxTeW1ib2woc3ltYm9sKSB7XG4gIGRlbGV0ZSBnbG9iYWxUaGlzW3N5bWJvbF07XG59XG52YXIgSW50ZXJjZXB0b3JSZWFkeVN0YXRlID0gLyogQF9fUFVSRV9fICovIChmdW5jdGlvbihJbnRlcmNlcHRvclJlYWR5U3RhdGUkMSkge1xuICBJbnRlcmNlcHRvclJlYWR5U3RhdGUkMVtcIklOQUNUSVZFXCJdID0gXCJJTkFDVElWRVwiO1xuICBJbnRlcmNlcHRvclJlYWR5U3RhdGUkMVtcIkFQUExZSU5HXCJdID0gXCJBUFBMWUlOR1wiO1xuICBJbnRlcmNlcHRvclJlYWR5U3RhdGUkMVtcIkFQUExJRURcIl0gPSBcIkFQUExJRURcIjtcbiAgSW50ZXJjZXB0b3JSZWFkeVN0YXRlJDFbXCJESVNQT1NJTkdcIl0gPSBcIkRJU1BPU0lOR1wiO1xuICBJbnRlcmNlcHRvclJlYWR5U3RhdGUkMVtcIkRJU1BPU0VEXCJdID0gXCJESVNQT1NFRFwiO1xuICByZXR1cm4gSW50ZXJjZXB0b3JSZWFkeVN0YXRlJDE7XG59KSh7fSk7XG52YXIgSW50ZXJjZXB0b3IgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKHN5bWJvbCkge1xuICAgIHRoaXMuc3ltYm9sID0gc3ltYm9sO1xuICAgIHRoaXMucmVhZHlTdGF0ZSA9IEludGVyY2VwdG9yUmVhZHlTdGF0ZS5JTkFDVElWRTtcbiAgICB0aGlzLmVtaXR0ZXIgPSBuZXcgRW1pdHRlcigpO1xuICAgIHRoaXMuc3Vic2NyaXB0aW9ucyA9IFtdO1xuICAgIHRoaXMubG9nZ2VyID0gbmV3IExvZ2dlcihzeW1ib2wuZGVzY3JpcHRpb24pO1xuICAgIHRoaXMuZW1pdHRlci5zZXRNYXhMaXN0ZW5lcnMoMCk7XG4gICAgdGhpcy5sb2dnZXIuaW5mbyhcImNvbnN0cnVjdGluZyB0aGUgaW50ZXJjZXB0b3IuLi5cIik7XG4gIH1cbiAgLyoqXG4gICogRGV0ZXJtaW5lIGlmIHRoaXMgaW50ZXJjZXB0b3IgY2FuIGJlIGFwcGxpZWRcbiAgKiBpbiB0aGUgY3VycmVudCBlbnZpcm9ubWVudC5cbiAgKi9cbiAgY2hlY2tFbnZpcm9ubWVudCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICAvKipcbiAgKiBBcHBseSB0aGlzIGludGVyY2VwdG9yIHRvIHRoZSBjdXJyZW50IHByb2Nlc3MuXG4gICogUmV0dXJucyBhbiBhbHJlYWR5IHJ1bm5pbmcgaW50ZXJjZXB0b3IgaW5zdGFuY2UgaWYgaXQncyBwcmVzZW50LlxuICAqL1xuICBhcHBseSgpIHtcbiAgICBjb25zdCBsb2dnZXIgPSB0aGlzLmxvZ2dlci5leHRlbmQoXCJhcHBseVwiKTtcbiAgICBsb2dnZXIuaW5mbyhcImFwcGx5aW5nIHRoZSBpbnRlcmNlcHRvci4uLlwiKTtcbiAgICBpZiAodGhpcy5yZWFkeVN0YXRlID09PSBJbnRlcmNlcHRvclJlYWR5U3RhdGUuQVBQTElFRCkge1xuICAgICAgbG9nZ2VyLmluZm8oXCJpbnRlcmNlcHRlZCBhbHJlYWR5IGFwcGxpZWQhXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuY2hlY2tFbnZpcm9ubWVudCgpKSB7XG4gICAgICBsb2dnZXIuaW5mbyhcInRoZSBpbnRlcmNlcHRvciBjYW5ub3QgYmUgYXBwbGllZCBpbiB0aGlzIGVudmlyb25tZW50IVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5yZWFkeVN0YXRlID0gSW50ZXJjZXB0b3JSZWFkeVN0YXRlLkFQUExZSU5HO1xuICAgIGNvbnN0IHJ1bm5pbmdJbnN0YW5jZSA9IHRoaXMuZ2V0SW5zdGFuY2UoKTtcbiAgICBpZiAocnVubmluZ0luc3RhbmNlKSB7XG4gICAgICBsb2dnZXIuaW5mbyhcImZvdW5kIGEgcnVubmluZyBpbnN0YW5jZSwgcmV1c2luZy4uLlwiKTtcbiAgICAgIHRoaXMub24gPSAoZXZlbnQsIGxpc3RlbmVyKSA9PiB7XG4gICAgICAgIGxvZ2dlci5pbmZvKCdwcm94eWluZyB0aGUgXCIlc1wiIGxpc3RlbmVyJywgZXZlbnQpO1xuICAgICAgICBydW5uaW5nSW5zdGFuY2UuZW1pdHRlci5hZGRMaXN0ZW5lcihldmVudCwgbGlzdGVuZXIpO1xuICAgICAgICB0aGlzLnN1YnNjcmlwdGlvbnMucHVzaCgoKSA9PiB7XG4gICAgICAgICAgcnVubmluZ0luc3RhbmNlLmVtaXR0ZXIucmVtb3ZlTGlzdGVuZXIoZXZlbnQsIGxpc3RlbmVyKTtcbiAgICAgICAgICBsb2dnZXIuaW5mbygncmVtb3ZlZCBwcm94aWVkIFwiJXNcIiBsaXN0ZW5lciEnLCBldmVudCk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH07XG4gICAgICB0aGlzLnJlYWR5U3RhdGUgPSBJbnRlcmNlcHRvclJlYWR5U3RhdGUuQVBQTElFRDtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgbG9nZ2VyLmluZm8oXCJubyBydW5uaW5nIGluc3RhbmNlIGZvdW5kLCBzZXR0aW5nIHVwIGEgbmV3IGluc3RhbmNlLi4uXCIpO1xuICAgIHRoaXMuc2V0dXAoKTtcbiAgICB0aGlzLnNldEluc3RhbmNlKCk7XG4gICAgdGhpcy5yZWFkeVN0YXRlID0gSW50ZXJjZXB0b3JSZWFkeVN0YXRlLkFQUExJRUQ7XG4gIH1cbiAgLyoqXG4gICogU2V0dXAgdGhlIG1vZHVsZSBhdWdtZW50cyBhbmQgc3R1YnMgbmVjZXNzYXJ5IGZvciB0aGlzIGludGVyY2VwdG9yLlxuICAqIFRoaXMgbWV0aG9kIGlzIG5vdCBydW4gaWYgdGhlcmUncyBhIHJ1bm5pbmcgaW50ZXJjZXB0b3IgaW5zdGFuY2VcbiAgKiB0byBwcmV2ZW50IGluc3RhbnRpYXRpbmcgYW4gaW50ZXJjZXB0b3IgbXVsdGlwbGUgdGltZXMuXG4gICovXG4gIHNldHVwKCkge1xuICB9XG4gIC8qKlxuICAqIExpc3RlbiB0byB0aGUgaW50ZXJjZXB0b3IncyBwdWJsaWMgZXZlbnRzLlxuICAqL1xuICBvbihldmVudCwgbGlzdGVuZXIpIHtcbiAgICBjb25zdCBsb2dnZXIgPSB0aGlzLmxvZ2dlci5leHRlbmQoXCJvblwiKTtcbiAgICBpZiAodGhpcy5yZWFkeVN0YXRlID09PSBJbnRlcmNlcHRvclJlYWR5U3RhdGUuRElTUE9TSU5HIHx8IHRoaXMucmVhZHlTdGF0ZSA9PT0gSW50ZXJjZXB0b3JSZWFkeVN0YXRlLkRJU1BPU0VEKSB7XG4gICAgICBsb2dnZXIuaW5mbyhcImNhbm5vdCBsaXN0ZW4gdG8gZXZlbnRzLCBhbHJlYWR5IGRpc3Bvc2VkIVwiKTtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBsb2dnZXIuaW5mbygnYWRkaW5nIFwiJXNcIiBldmVudCBsaXN0ZW5lcjonLCBldmVudCwgbGlzdGVuZXIpO1xuICAgIHRoaXMuZW1pdHRlci5vbihldmVudCwgbGlzdGVuZXIpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIG9uY2UoZXZlbnQsIGxpc3RlbmVyKSB7XG4gICAgdGhpcy5lbWl0dGVyLm9uY2UoZXZlbnQsIGxpc3RlbmVyKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBvZmYoZXZlbnQsIGxpc3RlbmVyKSB7XG4gICAgdGhpcy5lbWl0dGVyLm9mZihldmVudCwgbGlzdGVuZXIpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIHJlbW92ZUFsbExpc3RlbmVycyhldmVudCkge1xuICAgIHRoaXMuZW1pdHRlci5yZW1vdmVBbGxMaXN0ZW5lcnMoZXZlbnQpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAqIERpc3Bvc2VzIG9mIGFueSBzaWRlLWVmZmVjdHMgdGhpcyBpbnRlcmNlcHRvciBoYXMgaW50cm9kdWNlZC5cbiAgKi9cbiAgZGlzcG9zZSgpIHtcbiAgICBjb25zdCBsb2dnZXIgPSB0aGlzLmxvZ2dlci5leHRlbmQoXCJkaXNwb3NlXCIpO1xuICAgIGlmICh0aGlzLnJlYWR5U3RhdGUgPT09IEludGVyY2VwdG9yUmVhZHlTdGF0ZS5ESVNQT1NFRCkge1xuICAgICAgbG9nZ2VyLmluZm8oXCJjYW5ub3QgZGlzcG9zZSwgYWxyZWFkeSBkaXNwb3NlZCFcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxvZ2dlci5pbmZvKFwiZGlzcG9zaW5nIHRoZSBpbnRlcmNlcHRvci4uLlwiKTtcbiAgICB0aGlzLnJlYWR5U3RhdGUgPSBJbnRlcmNlcHRvclJlYWR5U3RhdGUuRElTUE9TSU5HO1xuICAgIGlmICghdGhpcy5nZXRJbnN0YW5jZSgpKSB7XG4gICAgICBsb2dnZXIuaW5mbyhcIm5vIGludGVyY2VwdG9ycyBydW5uaW5nLCBza2lwcGluZyBkaXNwb3NlLi4uXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLmNsZWFySW5zdGFuY2UoKTtcbiAgICBsb2dnZXIuaW5mbyhcImdsb2JhbCBzeW1ib2wgZGVsZXRlZDpcIiwgZ2V0R2xvYmFsU3ltYm9sKHRoaXMuc3ltYm9sKSk7XG4gICAgaWYgKHRoaXMuc3Vic2NyaXB0aW9ucy5sZW5ndGggPiAwKSB7XG4gICAgICBsb2dnZXIuaW5mbyhcImRpc3Bvc2luZyBvZiAlZCBzdWJzY3JpcHRpb25zLi4uXCIsIHRoaXMuc3Vic2NyaXB0aW9ucy5sZW5ndGgpO1xuICAgICAgZm9yIChjb25zdCBkaXNwb3NlIG9mIHRoaXMuc3Vic2NyaXB0aW9ucykgZGlzcG9zZSgpO1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb25zID0gW107XG4gICAgICBsb2dnZXIuaW5mbyhcImRpc3Bvc2VkIG9mIGFsbCBzdWJzY3JpcHRpb25zIVwiLCB0aGlzLnN1YnNjcmlwdGlvbnMubGVuZ3RoKTtcbiAgICB9XG4gICAgdGhpcy5lbWl0dGVyLnJlbW92ZUFsbExpc3RlbmVycygpO1xuICAgIGxvZ2dlci5pbmZvKFwiZGVzdHJveWVkIHRoZSBsaXN0ZW5lciFcIik7XG4gICAgdGhpcy5yZWFkeVN0YXRlID0gSW50ZXJjZXB0b3JSZWFkeVN0YXRlLkRJU1BPU0VEO1xuICB9XG4gIGdldEluc3RhbmNlKCkge1xuICAgIGNvbnN0IGluc3RhbmNlID0gZ2V0R2xvYmFsU3ltYm9sKHRoaXMuc3ltYm9sKTtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKFwicmV0cmlldmVkIGdsb2JhbCBpbnN0YW5jZTpcIiwgaW5zdGFuY2U/LmNvbnN0cnVjdG9yPy5uYW1lKTtcbiAgICByZXR1cm4gaW5zdGFuY2U7XG4gIH1cbiAgc2V0SW5zdGFuY2UoKSB7XG4gICAgc2V0R2xvYmFsU3ltYm9sKHRoaXMuc3ltYm9sLCB0aGlzKTtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKFwic2V0IGdsb2JhbCBpbnN0YW5jZSFcIiwgdGhpcy5zeW1ib2wuZGVzY3JpcHRpb24pO1xuICB9XG4gIGNsZWFySW5zdGFuY2UoKSB7XG4gICAgZGVsZXRlR2xvYmFsU3ltYm9sKHRoaXMuc3ltYm9sKTtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKFwiY2xlYXJlZCBnbG9iYWwgaW5zdGFuY2UhXCIsIHRoaXMuc3ltYm9sLmRlc2NyaXB0aW9uKTtcbiAgfVxufTtcbmZ1bmN0aW9uIGNyZWF0ZVJlcXVlc3RJZCgpIHtcbiAgcmV0dXJuIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMTYpLnNsaWNlKDIpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vQG1zd2pzK2ludGVyY2VwdG9yc0AwLjQxLjkvbm9kZV9tb2R1bGVzL0Btc3dqcy9pbnRlcmNlcHRvcnMvbGliL2Jyb3dzZXIvcmVzb2x2ZVdlYlNvY2tldFVybC1DODMteDlpRS5tanNcbmZ1bmN0aW9uIHJlc29sdmVXZWJTb2NrZXRVcmwodXJsKSB7XG4gIGlmICh0eXBlb2YgdXJsID09PSBcInN0cmluZ1wiKSByZXR1cm4gcmVzb2x2ZVdlYlNvY2tldFVybChuZXcgVVJMKHVybCwgdHlwZW9mIGxvY2F0aW9uICE9PSBcInVuZGVmaW5lZFwiID8gbG9jYXRpb24uaHJlZiA6IHZvaWQgMCkpO1xuICBpZiAodXJsLnByb3RvY29sID09PSBcImh0dHA6XCIpIHVybC5wcm90b2NvbCA9IFwid3M6XCI7XG4gIGVsc2UgaWYgKHVybC5wcm90b2NvbCA9PT0gXCJodHRwczpcIikgdXJsLnByb3RvY29sID0gXCJ3c3M6XCI7XG4gIGlmICh1cmwucHJvdG9jb2wgIT09IFwid3M6XCIgJiYgdXJsLnByb3RvY29sICE9PSBcIndzczpcIilcbiAgICB0aHJvdyBuZXcgU3ludGF4RXJyb3IoYEZhaWxlZCB0byBjb25zdHJ1Y3QgJ1dlYlNvY2tldCc6IFRoZSBVUkwncyBzY2hlbWUgbXVzdCBiZSBlaXRoZXIgJ2h0dHAnLCAnaHR0cHMnLCAnd3MnLCBvciAnd3NzJy4gJyR7dXJsLnByb3RvY29sfScgaXMgbm90IGFsbG93ZWQuYCk7XG4gIGlmICh1cmwuaGFzaCAhPT0gXCJcIikgdGhyb3cgbmV3IFN5bnRheEVycm9yKGBGYWlsZWQgdG8gY29uc3RydWN0ICdXZWJTb2NrZXQnOiBUaGUgVVJMIGNvbnRhaW5zIGEgZnJhZ21lbnQgaWRlbnRpZmllciAoJyR7dXJsLmhhc2h9JykuIEZyYWdtZW50IGlkZW50aWZpZXJzIGFyZSBub3QgYWxsb3dlZCBpbiBXZWJTb2NrZXQgVVJMcy5gKTtcbiAgcmV0dXJuIHVybC5ocmVmO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vQG1zd2pzK2ludGVyY2VwdG9yc0AwLjQxLjkvbm9kZV9tb2R1bGVzL0Btc3dqcy9pbnRlcmNlcHRvcnMvbGliL2Jyb3dzZXIvaGFzQ29uZmlndXJhYmxlR2xvYmFsLUM4enExTUNnLm1qc1xuYXN5bmMgZnVuY3Rpb24gZW1pdEFzeW5jKGVtaXR0ZXIsIGV2ZW50TmFtZSwgLi4uZGF0YSkge1xuICBjb25zdCBsaXN0ZW5lcnMgPSBlbWl0dGVyLmxpc3RlbmVycyhldmVudE5hbWUpO1xuICBpZiAobGlzdGVuZXJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIGxpc3RlbmVycykgYXdhaXQgbGlzdGVuZXIuYXBwbHkoZW1pdHRlciwgZGF0YSk7XG59XG52YXIgUGF0Y2hlc1JlZ2lzdHJ5ID0gY2xhc3Mge1xuICAjcmVwbGFjZW1lbnRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgYXBwbHlQYXRjaChvd25lciwga2V5LCBnZXROZXh0VmFsdWUpIHtcbiAgICBjb25zdCBvd25lclJlcGxhY2VtZW50cyA9IHRoaXMuI3JlcGxhY2VtZW50cy5nZXQob3duZXIpO1xuICAgIGludmFyaWFudCghb3duZXJSZXBsYWNlbWVudHM/LmhhcyhrZXkpLCBgRmFpbGVkIHRvIHJlcGxhY2UgYSBnbG9iYWwgdmFsdWUgYXQgXCIke1N0cmluZyhrZXkpfVwiOiBhbHJlYWR5IHJlcGxhY2VkLmApO1xuICAgIGNvbnN0IG1hdGNoID0gZ2V0RGVlcFByb3BlcnR5RGVzY3JpcHRvcihvd25lciwga2V5KTtcbiAgICBpZiAodHlwZW9mIG1hdGNoID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBjb25zb2xlLndhcm4oYEZhaWxlZCB0byByZXBsYWNlIGEgZ2xvYmFsIHZhbHVlIGF0IFwiJHtTdHJpbmcoa2V5KX1cIjogbm90IGEgZ2xvYmFsIHZhbHVlLmApO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgIH07XG4gICAgfVxuICAgIGlmIChtYXRjaC5kZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSkgT2JqZWN0LmRlZmluZVByb3BlcnR5KG93bmVyLCBrZXksIHtcbiAgICAgIHZhbHVlOiBnZXROZXh0VmFsdWUob3duZXJba2V5XSksXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgZWxzZSBpZiAobWF0Y2guZGVzY3JpcHRvci53cml0YWJsZSkgb3duZXJba2V5XSA9IGdldE5leHRWYWx1ZShvd25lcltrZXldKTtcbiAgICBlbHNlIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIHBhdGNoIGEgbm9uLWNvbmZpZ3VyYWJsZSBub24td3JpdGFibGUgcHJvcGVydHkgXCIke2tleS50b1N0cmluZygpfVwiYCk7XG4gICAgY29uc3QgcmVzdG9yZVBhdGNoID0gKCkgPT4ge1xuICAgICAgY29uc3QgY3VycmVudFJlcGxhY2VtZW50cyA9IHRoaXMuI3JlcGxhY2VtZW50cy5nZXQob3duZXIpO1xuICAgICAgaWYgKCFjdXJyZW50UmVwbGFjZW1lbnRzPy5oYXMoa2V5KSkgcmV0dXJuO1xuICAgICAgaWYgKG1hdGNoLm93bmVyID09PSBvd25lcilcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG1hdGNoLm93bmVyLCBrZXksIG1hdGNoLmRlc2NyaXB0b3IpO1xuICAgICAgZWxzZVxuICAgICAgICBSZWZsZWN0LmRlbGV0ZVByb3BlcnR5KG93bmVyLCBrZXkpO1xuICAgICAgY3VycmVudFJlcGxhY2VtZW50cy5kZWxldGUoa2V5KTtcbiAgICAgIGlmIChjdXJyZW50UmVwbGFjZW1lbnRzLnNpemUgPT09IDApIHRoaXMuI3JlcGxhY2VtZW50cy5kZWxldGUob3duZXIpO1xuICAgIH07XG4gICAgaWYgKG93bmVyUmVwbGFjZW1lbnRzKSBvd25lclJlcGxhY2VtZW50cy5zZXQoa2V5LCByZXN0b3JlUGF0Y2gpO1xuICAgIGVsc2UgdGhpcy4jcmVwbGFjZW1lbnRzLnNldChvd25lciwgLyogQF9fUFVSRV9fICovIG5ldyBNYXAoW1trZXksIHJlc3RvcmVQYXRjaF1dKSk7XG4gICAgcmV0dXJuIHJlc3RvcmVQYXRjaDtcbiAgfVxuICByZXN0b3JlQWxsUGF0Y2hlcygpIHtcbiAgICBjb25zdCBlcnJvcnMgPSBbXTtcbiAgICBmb3IgKGNvbnN0IFssIG93bmVyUmVwbGFjZW1lbnRzXSBvZiB0aGlzLiNyZXBsYWNlbWVudHMpIGZvciAoY29uc3QgWywgcmVzdG9yZVBhdGNoXSBvZiBvd25lclJlcGxhY2VtZW50cykgdHJ5IHtcbiAgICAgIHJlc3RvcmVQYXRjaCgpO1xuICAgIH0gY2F0Y2ggKGVycm9yMikge1xuICAgICAgaWYgKGVycm9yMiBpbnN0YW5jZW9mIEVycm9yKSBlcnJvcnMucHVzaChlcnJvcjIpO1xuICAgICAgZWxzZSB0aHJvdyBlcnJvcjI7XG4gICAgfVxuICAgIGlmIChlcnJvcnMubGVuZ3RoID4gMCkgdGhyb3cgbmV3IEFnZ3JlZ2F0ZUVycm9yKGVycm9ycywgXCJGT08hXCIpO1xuICB9XG59O1xudmFyIHBhdGNoZXNSZWdpc3RyeSA9IG5ldyBQYXRjaGVzUmVnaXN0cnkoKTtcbmZ1bmN0aW9uIGdldERlZXBQcm9wZXJ0eURlc2NyaXB0b3Iob3duZXIsIGtleSkge1xuICBsZXQgY3VycmVudE93bmVyID0gb3duZXI7XG4gIGxldCBkZXNjcmlwdG9yO1xuICB3aGlsZSAoY3VycmVudE93bmVyKSB7XG4gICAgZGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoY3VycmVudE93bmVyLCBrZXkpO1xuICAgIGlmIChkZXNjcmlwdG9yKSByZXR1cm4ge1xuICAgICAgb3duZXI6IGN1cnJlbnRPd25lcixcbiAgICAgIGRlc2NyaXB0b3JcbiAgICB9O1xuICAgIGN1cnJlbnRPd25lciA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihjdXJyZW50T3duZXIpO1xuICB9XG59XG5mdW5jdGlvbiBoYXNDb25maWd1cmFibGVHbG9iYWwocHJvcGVydHlOYW1lKSB7XG4gIGNvbnN0IG1hdGNoID0gZ2V0RGVlcFByb3BlcnR5RGVzY3JpcHRvcihnbG9iYWxUaGlzLCBwcm9wZXJ0eU5hbWUpO1xuICBpZiAodHlwZW9mIG1hdGNoID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHsgZGVzY3JpcHRvciB9ID0gbWF0Y2g7XG4gIGlmICh0eXBlb2YgZGVzY3JpcHRvci5nZXQgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgZGVzY3JpcHRvci5nZXQoKSA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIGZhbHNlO1xuICBpZiAodHlwZW9mIGRlc2NyaXB0b3IuZ2V0ID09PSBcInVuZGVmaW5lZFwiICYmIGRlc2NyaXB0b3IudmFsdWUgPT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICBpZiAodHlwZW9mIGRlc2NyaXB0b3Iuc2V0ID09PSBcInVuZGVmaW5lZFwiICYmICFkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSkge1xuICAgIGNvbnNvbGUuZXJyb3IoYFtNU1ddIEZhaWxlZCB0byBhcHBseSBpbnRlcmNlcHRvcjogdGhlIGdsb2JhbCBcXGAke3Byb3BlcnR5TmFtZX1cXGAgcHJvcGVydHkgaXMgbm9uLWNvbmZpZ3VyYWJsZS4gVGhpcyBpcyBsaWtlbHkgYW4gaXNzdWUgd2l0aCB5b3VyIGVudmlyb25tZW50LiBJZiB5b3UgYXJlIHVzaW5nIGEgZnJhbWV3b3JrLCBwbGVhc2Ugb3BlbiBhbiBpc3N1ZSBhYm91dCB0aGlzIGluIHRoZWlyIHJlcG9zaXRvcnkuYCk7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vQG9wZW4tZHJhZnQrZGVmZXJyZWQtcHJvbWlzZUAyLjIuMC9ub2RlX21vZHVsZXMvQG9wZW4tZHJhZnQvZGVmZXJyZWQtcHJvbWlzZS9idWlsZC9pbmRleC5tanNcbmZ1bmN0aW9uIGNyZWF0ZURlZmVycmVkRXhlY3V0b3IoKSB7XG4gIGNvbnN0IGV4ZWN1dG9yID0gKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGV4ZWN1dG9yLnN0YXRlID0gXCJwZW5kaW5nXCI7XG4gICAgZXhlY3V0b3IucmVzb2x2ZSA9IChkYXRhKSA9PiB7XG4gICAgICBpZiAoZXhlY3V0b3Iuc3RhdGUgIT09IFwicGVuZGluZ1wiKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGV4ZWN1dG9yLnJlc3VsdCA9IGRhdGE7XG4gICAgICBjb25zdCBvbkZ1bGZpbGxlZCA9ICh2YWx1ZSkgPT4ge1xuICAgICAgICBleGVjdXRvci5zdGF0ZSA9IFwiZnVsZmlsbGVkXCI7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIH07XG4gICAgICByZXR1cm4gcmVzb2x2ZShcbiAgICAgICAgZGF0YSBpbnN0YW5jZW9mIFByb21pc2UgPyBkYXRhIDogUHJvbWlzZS5yZXNvbHZlKGRhdGEpLnRoZW4ob25GdWxmaWxsZWQpXG4gICAgICApO1xuICAgIH07XG4gICAgZXhlY3V0b3IucmVqZWN0ID0gKHJlYXNvbikgPT4ge1xuICAgICAgaWYgKGV4ZWN1dG9yLnN0YXRlICE9PSBcInBlbmRpbmdcIikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICAgIGV4ZWN1dG9yLnN0YXRlID0gXCJyZWplY3RlZFwiO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gcmVqZWN0KGV4ZWN1dG9yLnJlamVjdGlvblJlYXNvbiA9IHJlYXNvbik7XG4gICAgfTtcbiAgfTtcbiAgcmV0dXJuIGV4ZWN1dG9yO1xufVxudmFyIERlZmVycmVkUHJvbWlzZSA9IGNsYXNzIGV4dGVuZHMgUHJvbWlzZSB7XG4gICNleGVjdXRvcjtcbiAgcmVzb2x2ZTtcbiAgcmVqZWN0O1xuICBjb25zdHJ1Y3RvcihleGVjdXRvciA9IG51bGwpIHtcbiAgICBjb25zdCBkZWZlcnJlZEV4ZWN1dG9yID0gY3JlYXRlRGVmZXJyZWRFeGVjdXRvcigpO1xuICAgIHN1cGVyKChvcmlnaW5hbFJlc29sdmUsIG9yaWdpbmFsUmVqZWN0KSA9PiB7XG4gICAgICBkZWZlcnJlZEV4ZWN1dG9yKG9yaWdpbmFsUmVzb2x2ZSwgb3JpZ2luYWxSZWplY3QpO1xuICAgICAgZXhlY3V0b3I/LihkZWZlcnJlZEV4ZWN1dG9yLnJlc29sdmUsIGRlZmVycmVkRXhlY3V0b3IucmVqZWN0KTtcbiAgICB9KTtcbiAgICB0aGlzLiNleGVjdXRvciA9IGRlZmVycmVkRXhlY3V0b3I7XG4gICAgdGhpcy5yZXNvbHZlID0gdGhpcy4jZXhlY3V0b3IucmVzb2x2ZTtcbiAgICB0aGlzLnJlamVjdCA9IHRoaXMuI2V4ZWN1dG9yLnJlamVjdDtcbiAgfVxuICBnZXQgc3RhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuI2V4ZWN1dG9yLnN0YXRlO1xuICB9XG4gIGdldCByZWplY3Rpb25SZWFzb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuI2V4ZWN1dG9yLnJlamVjdGlvblJlYXNvbjtcbiAgfVxuICB0aGVuKG9uRnVsZmlsbGVkLCBvblJlamVjdGVkKSB7XG4gICAgcmV0dXJuIHRoaXMuI2RlY29yYXRlKHN1cGVyLnRoZW4ob25GdWxmaWxsZWQsIG9uUmVqZWN0ZWQpKTtcbiAgfVxuICBjYXRjaChvblJlamVjdGVkKSB7XG4gICAgcmV0dXJuIHRoaXMuI2RlY29yYXRlKHN1cGVyLmNhdGNoKG9uUmVqZWN0ZWQpKTtcbiAgfVxuICBmaW5hbGx5KG9uZmluYWxseSkge1xuICAgIHJldHVybiB0aGlzLiNkZWNvcmF0ZShzdXBlci5maW5hbGx5KG9uZmluYWxseSkpO1xuICB9XG4gICNkZWNvcmF0ZShwcm9taXNlKSB7XG4gICAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHByb21pc2UsIHtcbiAgICAgIHJlc29sdmU6IHsgY29uZmlndXJhYmxlOiB0cnVlLCB2YWx1ZTogdGhpcy5yZXNvbHZlIH0sXG4gICAgICByZWplY3Q6IHsgY29uZmlndXJhYmxlOiB0cnVlLCB2YWx1ZTogdGhpcy5yZWplY3QgfVxuICAgIH0pO1xuICB9XG59O1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vQG1zd2pzK2ludGVyY2VwdG9yc0AwLjQxLjkvbm9kZV9tb2R1bGVzL0Btc3dqcy9pbnRlcmNlcHRvcnMvbGliL2Jyb3dzZXIvaW50ZXJjZXB0b3JzL1dlYlNvY2tldC9pbmRleC5tanNcbmZ1bmN0aW9uIGJpbmRFdmVudCh0YXJnZXQsIGV2ZW50KSB7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGV2ZW50LCB7XG4gICAgdGFyZ2V0OiB7XG4gICAgICB2YWx1ZTogdGFyZ2V0LFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlXG4gICAgfSxcbiAgICBjdXJyZW50VGFyZ2V0OiB7XG4gICAgICB2YWx1ZTogdGFyZ2V0LFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlXG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGV2ZW50O1xufVxudmFyIGtDYW5jZWxhYmxlID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImtDYW5jZWxhYmxlXCIpO1xudmFyIGtEZWZhdWx0UHJldmVudGVkID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImtEZWZhdWx0UHJldmVudGVkXCIpO1xudmFyIENhbmNlbGFibGVNZXNzYWdlRXZlbnQgPSBjbGFzcyBleHRlbmRzIE1lc3NhZ2VFdmVudCB7XG4gIGNvbnN0cnVjdG9yKHR5cGUsIGluaXQpIHtcbiAgICBzdXBlcih0eXBlLCBpbml0KTtcbiAgICB0aGlzW2tDYW5jZWxhYmxlXSA9ICEhaW5pdC5jYW5jZWxhYmxlO1xuICAgIHRoaXNba0RlZmF1bHRQcmV2ZW50ZWRdID0gZmFsc2U7XG4gIH1cbiAgZ2V0IGNhbmNlbGFibGUoKSB7XG4gICAgcmV0dXJuIHRoaXNba0NhbmNlbGFibGVdO1xuICB9XG4gIHNldCBjYW5jZWxhYmxlKG5leHRDYW5jZWxhYmxlKSB7XG4gICAgdGhpc1trQ2FuY2VsYWJsZV0gPSBuZXh0Q2FuY2VsYWJsZTtcbiAgfVxuICBnZXQgZGVmYXVsdFByZXZlbnRlZCgpIHtcbiAgICByZXR1cm4gdGhpc1trRGVmYXVsdFByZXZlbnRlZF07XG4gIH1cbiAgc2V0IGRlZmF1bHRQcmV2ZW50ZWQobmV4dERlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICB0aGlzW2tEZWZhdWx0UHJldmVudGVkXSA9IG5leHREZWZhdWx0UHJldmVudGVkO1xuICB9XG4gIHByZXZlbnREZWZhdWx0KCkge1xuICAgIGlmICh0aGlzLmNhbmNlbGFibGUgJiYgIXRoaXNba0RlZmF1bHRQcmV2ZW50ZWRdKSB0aGlzW2tEZWZhdWx0UHJldmVudGVkXSA9IHRydWU7XG4gIH1cbn07XG52YXIgQ2xvc2VFdmVudCA9IGNsYXNzIGV4dGVuZHMgRXZlbnQge1xuICBjb25zdHJ1Y3Rvcih0eXBlLCBpbml0ID0ge30pIHtcbiAgICBzdXBlcih0eXBlLCBpbml0KTtcbiAgICB0aGlzLmNvZGUgPSBpbml0LmNvZGUgPT09IHZvaWQgMCA/IDAgOiBpbml0LmNvZGU7XG4gICAgdGhpcy5yZWFzb24gPSBpbml0LnJlYXNvbiA9PT0gdm9pZCAwID8gXCJcIiA6IGluaXQucmVhc29uO1xuICAgIHRoaXMud2FzQ2xlYW4gPSBpbml0Lndhc0NsZWFuID09PSB2b2lkIDAgPyBmYWxzZSA6IGluaXQud2FzQ2xlYW47XG4gIH1cbn07XG52YXIgQ2FuY2VsYWJsZUNsb3NlRXZlbnQgPSBjbGFzcyBleHRlbmRzIENsb3NlRXZlbnQge1xuICBjb25zdHJ1Y3Rvcih0eXBlLCBpbml0ID0ge30pIHtcbiAgICBzdXBlcih0eXBlLCBpbml0KTtcbiAgICB0aGlzW2tDYW5jZWxhYmxlXSA9ICEhaW5pdC5jYW5jZWxhYmxlO1xuICAgIHRoaXNba0RlZmF1bHRQcmV2ZW50ZWRdID0gZmFsc2U7XG4gIH1cbiAgZ2V0IGNhbmNlbGFibGUoKSB7XG4gICAgcmV0dXJuIHRoaXNba0NhbmNlbGFibGVdO1xuICB9XG4gIHNldCBjYW5jZWxhYmxlKG5leHRDYW5jZWxhYmxlKSB7XG4gICAgdGhpc1trQ2FuY2VsYWJsZV0gPSBuZXh0Q2FuY2VsYWJsZTtcbiAgfVxuICBnZXQgZGVmYXVsdFByZXZlbnRlZCgpIHtcbiAgICByZXR1cm4gdGhpc1trRGVmYXVsdFByZXZlbnRlZF07XG4gIH1cbiAgc2V0IGRlZmF1bHRQcmV2ZW50ZWQobmV4dERlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICB0aGlzW2tEZWZhdWx0UHJldmVudGVkXSA9IG5leHREZWZhdWx0UHJldmVudGVkO1xuICB9XG4gIHByZXZlbnREZWZhdWx0KCkge1xuICAgIGlmICh0aGlzLmNhbmNlbGFibGUgJiYgIXRoaXNba0RlZmF1bHRQcmV2ZW50ZWRdKSB0aGlzW2tEZWZhdWx0UHJldmVudGVkXSA9IHRydWU7XG4gIH1cbn07XG52YXIga0VtaXR0ZXIkMSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJrRW1pdHRlclwiKTtcbnZhciBrQm91bmRMaXN0ZW5lciQxID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImtCb3VuZExpc3RlbmVyXCIpO1xudmFyIFdlYlNvY2tldENsaWVudENvbm5lY3Rpb24gPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKHNvY2tldCwgdHJhbnNwb3J0KSB7XG4gICAgdGhpcy5zb2NrZXQgPSBzb2NrZXQ7XG4gICAgdGhpcy50cmFuc3BvcnQgPSB0cmFuc3BvcnQ7XG4gICAgdGhpcy5pZCA9IGNyZWF0ZVJlcXVlc3RJZCgpO1xuICAgIHRoaXMudXJsID0gbmV3IFVSTChzb2NrZXQudXJsKTtcbiAgICB0aGlzW2tFbWl0dGVyJDFdID0gbmV3IEV2ZW50VGFyZ2V0KCk7XG4gICAgdGhpcy50cmFuc3BvcnQuYWRkRXZlbnRMaXN0ZW5lcihcIm91dGdvaW5nXCIsIChldmVudCkgPT4ge1xuICAgICAgY29uc3QgbWVzc2FnZSA9IGJpbmRFdmVudCh0aGlzLnNvY2tldCwgbmV3IENhbmNlbGFibGVNZXNzYWdlRXZlbnQoXCJtZXNzYWdlXCIsIHtcbiAgICAgICAgZGF0YTogZXZlbnQuZGF0YSxcbiAgICAgICAgb3JpZ2luOiBldmVudC5vcmlnaW4sXG4gICAgICAgIGNhbmNlbGFibGU6IHRydWVcbiAgICAgIH0pKTtcbiAgICAgIHRoaXNba0VtaXR0ZXIkMV0uZGlzcGF0Y2hFdmVudChtZXNzYWdlKTtcbiAgICAgIGlmIChtZXNzYWdlLmRlZmF1bHRQcmV2ZW50ZWQpIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgfSk7XG4gICAgdGhpcy50cmFuc3BvcnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsb3NlXCIsIChldmVudCkgPT4ge1xuICAgICAgdGhpc1trRW1pdHRlciQxXS5kaXNwYXRjaEV2ZW50KGJpbmRFdmVudCh0aGlzLnNvY2tldCwgbmV3IENsb3NlRXZlbnQoXCJjbG9zZVwiLCBldmVudCkpKTtcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgKiBMaXN0ZW4gZm9yIHRoZSBvdXRnb2luZyBldmVudHMgZnJvbSB0aGUgY29ubmVjdGVkIFdlYlNvY2tldCBjbGllbnQuXG4gICovXG4gIGFkZEV2ZW50TGlzdGVuZXIodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcbiAgICBpZiAoIVJlZmxlY3QuaGFzKGxpc3RlbmVyLCBrQm91bmRMaXN0ZW5lciQxKSkge1xuICAgICAgY29uc3QgYm91bmRMaXN0ZW5lciA9IGxpc3RlbmVyLmJpbmQodGhpcy5zb2NrZXQpO1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGxpc3RlbmVyLCBrQm91bmRMaXN0ZW5lciQxLCB7XG4gICAgICAgIHZhbHVlOiBib3VuZExpc3RlbmVyLFxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiBmYWxzZVxuICAgICAgfSk7XG4gICAgfVxuICAgIHRoaXNba0VtaXR0ZXIkMV0uYWRkRXZlbnRMaXN0ZW5lcih0eXBlLCBSZWZsZWN0LmdldChsaXN0ZW5lciwga0JvdW5kTGlzdGVuZXIkMSksIG9wdGlvbnMpO1xuICB9XG4gIC8qKlxuICAqIFJlbW92ZXMgdGhlIGxpc3RlbmVyIGZvciB0aGUgZ2l2ZW4gZXZlbnQuXG4gICovXG4gIHJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnQsIGxpc3RlbmVyLCBvcHRpb25zKSB7XG4gICAgdGhpc1trRW1pdHRlciQxXS5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50LCBSZWZsZWN0LmdldChsaXN0ZW5lciwga0JvdW5kTGlzdGVuZXIkMSksIG9wdGlvbnMpO1xuICB9XG4gIC8qKlxuICAqIFNlbmQgZGF0YSB0byB0aGUgY29ubmVjdGVkIGNsaWVudC5cbiAgKi9cbiAgc2VuZChkYXRhKSB7XG4gICAgdGhpcy50cmFuc3BvcnQuc2VuZChkYXRhKTtcbiAgfVxuICAvKipcbiAgKiBDbG9zZSB0aGUgV2ViU29ja2V0IGNvbm5lY3Rpb24uXG4gICogQHBhcmFtIHtudW1iZXJ9IGNvZGUgQSBzdGF0dXMgY29kZSAoc2VlIGh0dHBzOi8vd3d3LnJmYy1lZGl0b3Iub3JnL3JmYy9yZmM2NDU1I3NlY3Rpb24tNy40LjEpLlxuICAqIEBwYXJhbSB7c3RyaW5nfSByZWFzb24gQSBjdXN0b20gY29ubmVjdGlvbiBjbG9zZSByZWFzb24uXG4gICovXG4gIGNsb3NlKGNvZGUsIHJlYXNvbikge1xuICAgIHRoaXMudHJhbnNwb3J0LmNsb3NlKGNvZGUsIHJlYXNvbik7XG4gIH1cbn07XG52YXIgV0VCU09DS0VUX0NMT1NFX0NPREVfUkFOR0VfRVJST1IgPSBcIkludmFsaWRBY2Nlc3NFcnJvcjogY2xvc2UgY29kZSBvdXQgb2YgdXNlciBjb25maWd1cmFibGUgcmFuZ2VcIjtcbnZhciBrUGFzc3Rocm91Z2hQcm9taXNlID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImtQYXNzdGhyb3VnaFByb21pc2VcIik7XG52YXIga09uU2VuZCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJrT25TZW5kXCIpO1xudmFyIGtDbG9zZSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJrQ2xvc2VcIik7XG52YXIgV2ViU29ja2V0T3ZlcnJpZGUgPSBjbGFzcyBleHRlbmRzIEV2ZW50VGFyZ2V0IHtcbiAgc3RhdGljIHtcbiAgICB0aGlzLkNPTk5FQ1RJTkcgPSAwO1xuICB9XG4gIHN0YXRpYyB7XG4gICAgdGhpcy5PUEVOID0gMTtcbiAgfVxuICBzdGF0aWMge1xuICAgIHRoaXMuQ0xPU0lORyA9IDI7XG4gIH1cbiAgc3RhdGljIHtcbiAgICB0aGlzLkNMT1NFRCA9IDM7XG4gIH1cbiAgY29uc3RydWN0b3IodXJsLCBwcm90b2NvbHMpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuQ09OTkVDVElORyA9IDA7XG4gICAgdGhpcy5PUEVOID0gMTtcbiAgICB0aGlzLkNMT1NJTkcgPSAyO1xuICAgIHRoaXMuQ0xPU0VEID0gMztcbiAgICB0aGlzLl9vbm9wZW4gPSBudWxsO1xuICAgIHRoaXMuX29ubWVzc2FnZSA9IG51bGw7XG4gICAgdGhpcy5fb25lcnJvciA9IG51bGw7XG4gICAgdGhpcy5fb25jbG9zZSA9IG51bGw7XG4gICAgdGhpcy51cmwgPSByZXNvbHZlV2ViU29ja2V0VXJsKHVybCk7XG4gICAgdGhpcy5wcm90b2NvbCA9IFwiXCI7XG4gICAgdGhpcy5leHRlbnNpb25zID0gXCJcIjtcbiAgICB0aGlzLmJpbmFyeVR5cGUgPSBcImJsb2JcIjtcbiAgICB0aGlzLnJlYWR5U3RhdGUgPSB0aGlzLkNPTk5FQ1RJTkc7XG4gICAgdGhpcy5idWZmZXJlZEFtb3VudCA9IDA7XG4gICAgdGhpc1trUGFzc3Rocm91Z2hQcm9taXNlXSA9IG5ldyBEZWZlcnJlZFByb21pc2UoKTtcbiAgICBxdWV1ZU1pY3JvdGFzayhhc3luYyAoKSA9PiB7XG4gICAgICBpZiAoYXdhaXQgdGhpc1trUGFzc3Rocm91Z2hQcm9taXNlXSkgcmV0dXJuO1xuICAgICAgdGhpcy5wcm90b2NvbCA9IHR5cGVvZiBwcm90b2NvbHMgPT09IFwic3RyaW5nXCIgPyBwcm90b2NvbHMgOiBBcnJheS5pc0FycmF5KHByb3RvY29scykgJiYgcHJvdG9jb2xzLmxlbmd0aCA+IDAgPyBwcm90b2NvbHNbMF0gOiBcIlwiO1xuICAgICAgaWYgKHRoaXMucmVhZHlTdGF0ZSA9PT0gdGhpcy5DT05ORUNUSU5HKSB7XG4gICAgICAgIHRoaXMucmVhZHlTdGF0ZSA9IHRoaXMuT1BFTjtcbiAgICAgICAgdGhpcy5kaXNwYXRjaEV2ZW50KGJpbmRFdmVudCh0aGlzLCBuZXcgRXZlbnQoXCJvcGVuXCIpKSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgc2V0IG9ub3BlbihsaXN0ZW5lcikge1xuICAgIHRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm9wZW5cIiwgdGhpcy5fb25vcGVuKTtcbiAgICB0aGlzLl9vbm9wZW4gPSBsaXN0ZW5lcjtcbiAgICBpZiAobGlzdGVuZXIgIT09IG51bGwpIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcihcIm9wZW5cIiwgbGlzdGVuZXIpO1xuICB9XG4gIGdldCBvbm9wZW4oKSB7XG4gICAgcmV0dXJuIHRoaXMuX29ub3BlbjtcbiAgfVxuICBzZXQgb25tZXNzYWdlKGxpc3RlbmVyKSB7XG4gICAgdGhpcy5yZW1vdmVFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCB0aGlzLl9vbm1lc3NhZ2UpO1xuICAgIHRoaXMuX29ubWVzc2FnZSA9IGxpc3RlbmVyO1xuICAgIGlmIChsaXN0ZW5lciAhPT0gbnVsbCkgdGhpcy5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBsaXN0ZW5lcik7XG4gIH1cbiAgZ2V0IG9ubWVzc2FnZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fb25tZXNzYWdlO1xuICB9XG4gIHNldCBvbmVycm9yKGxpc3RlbmVyKSB7XG4gICAgdGhpcy5yZW1vdmVFdmVudExpc3RlbmVyKFwiZXJyb3JcIiwgdGhpcy5fb25lcnJvcik7XG4gICAgdGhpcy5fb25lcnJvciA9IGxpc3RlbmVyO1xuICAgIGlmIChsaXN0ZW5lciAhPT0gbnVsbCkgdGhpcy5hZGRFdmVudExpc3RlbmVyKFwiZXJyb3JcIiwgbGlzdGVuZXIpO1xuICB9XG4gIGdldCBvbmVycm9yKCkge1xuICAgIHJldHVybiB0aGlzLl9vbmVycm9yO1xuICB9XG4gIHNldCBvbmNsb3NlKGxpc3RlbmVyKSB7XG4gICAgdGhpcy5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2xvc2VcIiwgdGhpcy5fb25jbG9zZSk7XG4gICAgdGhpcy5fb25jbG9zZSA9IGxpc3RlbmVyO1xuICAgIGlmIChsaXN0ZW5lciAhPT0gbnVsbCkgdGhpcy5hZGRFdmVudExpc3RlbmVyKFwiY2xvc2VcIiwgbGlzdGVuZXIpO1xuICB9XG4gIGdldCBvbmNsb3NlKCkge1xuICAgIHJldHVybiB0aGlzLl9vbmNsb3NlO1xuICB9XG4gIC8qKlxuICAqIEBzZWUgaHR0cHM6Ly93ZWJzb2NrZXRzLnNwZWMud2hhdHdnLm9yZy8jcmVmLWZvci1kb20td2Vic29ja2V0LXNlbmQlRTIlOTElQTBcbiAgKi9cbiAgc2VuZChkYXRhKSB7XG4gICAgaWYgKHRoaXMucmVhZHlTdGF0ZSA9PT0gdGhpcy5DT05ORUNUSU5HKSB7XG4gICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICB0aHJvdyBuZXcgRE9NRXhjZXB0aW9uKFwiSW52YWxpZFN0YXRlRXJyb3JcIik7XG4gICAgfVxuICAgIGlmICh0aGlzLnJlYWR5U3RhdGUgPT09IHRoaXMuQ0xPU0lORyB8fCB0aGlzLnJlYWR5U3RhdGUgPT09IHRoaXMuQ0xPU0VEKSByZXR1cm47XG4gICAgdGhpcy5idWZmZXJlZEFtb3VudCArPSBnZXREYXRhU2l6ZShkYXRhKTtcbiAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICB0aGlzLmJ1ZmZlcmVkQW1vdW50ID0gMDtcbiAgICAgIHRoaXNba09uU2VuZF0/LihkYXRhKTtcbiAgICB9KTtcbiAgfVxuICBjbG9zZShjb2RlID0gMWUzLCByZWFzb24pIHtcbiAgICBpbnZhcmlhbnQoY29kZSwgV0VCU09DS0VUX0NMT1NFX0NPREVfUkFOR0VfRVJST1IpO1xuICAgIGludmFyaWFudChjb2RlID09PSAxZTMgfHwgY29kZSA+PSAzZTMgJiYgY29kZSA8PSA0OTk5LCBXRUJTT0NLRVRfQ0xPU0VfQ09ERV9SQU5HRV9FUlJPUik7XG4gICAgdGhpc1trQ2xvc2VdKGNvZGUsIHJlYXNvbik7XG4gIH1cbiAgW2tDbG9zZV0oY29kZSA9IDFlMywgcmVhc29uLCB3YXNDbGVhbiA9IHRydWUpIHtcbiAgICBpZiAodGhpcy5yZWFkeVN0YXRlID09PSB0aGlzLkNMT1NJTkcgfHwgdGhpcy5yZWFkeVN0YXRlID09PSB0aGlzLkNMT1NFRCkgcmV0dXJuO1xuICAgIHRoaXMucmVhZHlTdGF0ZSA9IHRoaXMuQ0xPU0lORztcbiAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICB0aGlzLnJlYWR5U3RhdGUgPSB0aGlzLkNMT1NFRDtcbiAgICAgIHRoaXMuZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcywgbmV3IENsb3NlRXZlbnQoXCJjbG9zZVwiLCB7XG4gICAgICAgIGNvZGUsXG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgd2FzQ2xlYW5cbiAgICAgIH0pKSk7XG4gICAgICB0aGlzLl9vbm9wZW4gPSBudWxsO1xuICAgICAgdGhpcy5fb25tZXNzYWdlID0gbnVsbDtcbiAgICAgIHRoaXMuX29uZXJyb3IgPSBudWxsO1xuICAgICAgdGhpcy5fb25jbG9zZSA9IG51bGw7XG4gICAgfSk7XG4gIH1cbiAgYWRkRXZlbnRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucykge1xuICAgIHJldHVybiBzdXBlci5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKTtcbiAgfVxuICByZW1vdmVFdmVudExpc3RlbmVyKHR5cGUsIGNhbGxiYWNrLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHN1cGVyLnJlbW92ZUV2ZW50TGlzdGVuZXIodHlwZSwgY2FsbGJhY2ssIG9wdGlvbnMpO1xuICB9XG59O1xuZnVuY3Rpb24gZ2V0RGF0YVNpemUoZGF0YSkge1xuICBpZiAodHlwZW9mIGRhdGEgPT09IFwic3RyaW5nXCIpIHJldHVybiBkYXRhLmxlbmd0aDtcbiAgaWYgKGRhdGEgaW5zdGFuY2VvZiBCbG9iKSByZXR1cm4gZGF0YS5zaXplO1xuICByZXR1cm4gZGF0YS5ieXRlTGVuZ3RoO1xufVxudmFyIGtFbWl0dGVyID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImtFbWl0dGVyXCIpO1xudmFyIGtCb3VuZExpc3RlbmVyID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImtCb3VuZExpc3RlbmVyXCIpO1xudmFyIGtTZW5kID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImtTZW5kXCIpO1xudmFyIFdlYlNvY2tldFNlcnZlckNvbm5lY3Rpb24gPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGNsaWVudCwgdHJhbnNwb3J0LCBjcmVhdGVDb25uZWN0aW9uKSB7XG4gICAgdGhpcy5jbGllbnQgPSBjbGllbnQ7XG4gICAgdGhpcy50cmFuc3BvcnQgPSB0cmFuc3BvcnQ7XG4gICAgdGhpcy5jcmVhdGVDb25uZWN0aW9uID0gY3JlYXRlQ29ubmVjdGlvbjtcbiAgICB0aGlzW2tFbWl0dGVyXSA9IG5ldyBFdmVudFRhcmdldCgpO1xuICAgIHRoaXMubW9ja0Nsb3NlQ29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICB0aGlzLnJlYWxDbG9zZUNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgdGhpcy50cmFuc3BvcnQuYWRkRXZlbnRMaXN0ZW5lcihcIm91dGdvaW5nXCIsIChldmVudCkgPT4ge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnJlYWxXZWJTb2NrZXQgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcbiAgICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICAgICAgaWYgKCFldmVudC5kZWZhdWx0UHJldmVudGVkKVxuICAgICAgICAgIHRoaXNba1NlbmRdKGV2ZW50LmRhdGEpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gICAgdGhpcy50cmFuc3BvcnQuYWRkRXZlbnRMaXN0ZW5lcihcImluY29taW5nXCIsIHRoaXMuaGFuZGxlSW5jb21pbmdNZXNzYWdlLmJpbmQodGhpcykpO1xuICB9XG4gIC8qKlxuICAqIFRoZSBgV2ViU29ja2V0YCBpbnN0YW5jZSBjb25uZWN0ZWQgdG8gdGhlIG9yaWdpbmFsIHNlcnZlci5cbiAgKiBBY2Nlc3NpbmcgdGhpcyBiZWZvcmUgY2FsbGluZyBgc2VydmVyLmNvbm5lY3QoKWAgd2lsbCB0aHJvdy5cbiAgKi9cbiAgZ2V0IHNvY2tldCgpIHtcbiAgICBpbnZhcmlhbnQodGhpcy5yZWFsV2ViU29ja2V0LCAnQ2Fubm90IGFjY2VzcyBcInNvY2tldFwiIG9uIHRoZSBvcmlnaW5hbCBXZWJTb2NrZXQgc2VydmVyIG9iamVjdDogdGhlIGNvbm5lY3Rpb24gaXMgbm90IG9wZW4uIERpZCB5b3UgZm9yZ2V0IHRvIGNhbGwgYHNlcnZlci5jb25uZWN0KClgPycpO1xuICAgIHJldHVybiB0aGlzLnJlYWxXZWJTb2NrZXQ7XG4gIH1cbiAgLyoqXG4gICogT3BlbiBjb25uZWN0aW9uIHRvIHRoZSBvcmlnaW5hbCBXZWJTb2NrZXQgc2VydmVyLlxuICAqL1xuICBjb25uZWN0KCkge1xuICAgIGludmFyaWFudCghdGhpcy5yZWFsV2ViU29ja2V0IHx8IHRoaXMucmVhbFdlYlNvY2tldC5yZWFkeVN0YXRlICE9PSBXZWJTb2NrZXQuT1BFTiwgJ0ZhaWxlZCB0byBjYWxsIFwiY29ubmVjdCgpXCIgb24gdGhlIG9yaWdpbmFsIFdlYlNvY2tldCBpbnN0YW5jZTogdGhlIGNvbm5lY3Rpb24gYWxyZWFkeSBvcGVuJyk7XG4gICAgY29uc3QgcmVhbFdlYlNvY2tldCA9IHRoaXMuY3JlYXRlQ29ubmVjdGlvbigpO1xuICAgIHJlYWxXZWJTb2NrZXQuYmluYXJ5VHlwZSA9IHRoaXMuY2xpZW50LmJpbmFyeVR5cGU7XG4gICAgcmVhbFdlYlNvY2tldC5hZGRFdmVudExpc3RlbmVyKFwib3BlblwiLCAoZXZlbnQpID0+IHtcbiAgICAgIHRoaXNba0VtaXR0ZXJdLmRpc3BhdGNoRXZlbnQoYmluZEV2ZW50KHRoaXMucmVhbFdlYlNvY2tldCwgbmV3IEV2ZW50KFwib3BlblwiLCBldmVudCkpKTtcbiAgICB9LCB7IG9uY2U6IHRydWUgfSk7XG4gICAgcmVhbFdlYlNvY2tldC5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCAoZXZlbnQpID0+IHtcbiAgICAgIHRoaXMudHJhbnNwb3J0LmRpc3BhdGNoRXZlbnQoYmluZEV2ZW50KHRoaXMucmVhbFdlYlNvY2tldCwgbmV3IE1lc3NhZ2VFdmVudChcImluY29taW5nXCIsIHtcbiAgICAgICAgZGF0YTogZXZlbnQuZGF0YSxcbiAgICAgICAgb3JpZ2luOiBldmVudC5vcmlnaW5cbiAgICAgIH0pKSk7XG4gICAgfSk7XG4gICAgdGhpcy5jbGllbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsb3NlXCIsIChldmVudCkgPT4ge1xuICAgICAgdGhpcy5oYW5kbGVNb2NrQ2xvc2UoZXZlbnQpO1xuICAgIH0sIHsgc2lnbmFsOiB0aGlzLm1vY2tDbG9zZUNvbnRyb2xsZXIuc2lnbmFsIH0pO1xuICAgIHJlYWxXZWJTb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcihcImNsb3NlXCIsIChldmVudCkgPT4ge1xuICAgICAgdGhpcy5oYW5kbGVSZWFsQ2xvc2UoZXZlbnQpO1xuICAgIH0sIHsgc2lnbmFsOiB0aGlzLnJlYWxDbG9zZUNvbnRyb2xsZXIuc2lnbmFsIH0pO1xuICAgIHJlYWxXZWJTb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsICgpID0+IHtcbiAgICAgIGNvbnN0IGVycm9yRXZlbnQgPSBiaW5kRXZlbnQocmVhbFdlYlNvY2tldCwgbmV3IEV2ZW50KFwiZXJyb3JcIiwgeyBjYW5jZWxhYmxlOiB0cnVlIH0pKTtcbiAgICAgIHRoaXNba0VtaXR0ZXJdLmRpc3BhdGNoRXZlbnQoZXJyb3JFdmVudCk7XG4gICAgICBpZiAoIWVycm9yRXZlbnQuZGVmYXVsdFByZXZlbnRlZCkgdGhpcy5jbGllbnQuZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcy5jbGllbnQsIG5ldyBFdmVudChcImVycm9yXCIpKSk7XG4gICAgfSk7XG4gICAgdGhpcy5yZWFsV2ViU29ja2V0ID0gcmVhbFdlYlNvY2tldDtcbiAgfVxuICAvKipcbiAgKiBMaXN0ZW4gZm9yIHRoZSBpbmNvbWluZyBldmVudHMgZnJvbSB0aGUgb3JpZ2luYWwgV2ViU29ja2V0IHNlcnZlci5cbiAgKi9cbiAgYWRkRXZlbnRMaXN0ZW5lcihldmVudCwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcbiAgICBpZiAoIVJlZmxlY3QuaGFzKGxpc3RlbmVyLCBrQm91bmRMaXN0ZW5lcikpIHtcbiAgICAgIGNvbnN0IGJvdW5kTGlzdGVuZXIgPSBsaXN0ZW5lci5iaW5kKHRoaXMuY2xpZW50KTtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShsaXN0ZW5lciwga0JvdW5kTGlzdGVuZXIsIHtcbiAgICAgICAgdmFsdWU6IGJvdW5kTGlzdGVuZXIsXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlXG4gICAgICB9KTtcbiAgICB9XG4gICAgdGhpc1trRW1pdHRlcl0uYWRkRXZlbnRMaXN0ZW5lcihldmVudCwgUmVmbGVjdC5nZXQobGlzdGVuZXIsIGtCb3VuZExpc3RlbmVyKSwgb3B0aW9ucyk7XG4gIH1cbiAgLyoqXG4gICogUmVtb3ZlIHRoZSBsaXN0ZW5lciBmb3IgdGhlIGdpdmVuIGV2ZW50LlxuICAqL1xuICByZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50LCBsaXN0ZW5lciwgb3B0aW9ucykge1xuICAgIHRoaXNba0VtaXR0ZXJdLnJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnQsIFJlZmxlY3QuZ2V0KGxpc3RlbmVyLCBrQm91bmRMaXN0ZW5lciksIG9wdGlvbnMpO1xuICB9XG4gIC8qKlxuICAqIFNlbmQgZGF0YSB0byB0aGUgb3JpZ2luYWwgV2ViU29ja2V0IHNlcnZlci5cbiAgKiBAZXhhbXBsZVxuICAqIHNlcnZlci5zZW5kKCdoZWxsbycpXG4gICogc2VydmVyLnNlbmQobmV3IEJsb2IoWydoZWxsbyddKSlcbiAgKiBzZXJ2ZXIuc2VuZChuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoJ2hlbGxvJykpXG4gICovXG4gIHNlbmQoZGF0YSkge1xuICAgIHRoaXNba1NlbmRdKGRhdGEpO1xuICB9XG4gIFtrU2VuZF0oZGF0YSkge1xuICAgIGNvbnN0IHsgcmVhbFdlYlNvY2tldCB9ID0gdGhpcztcbiAgICBpbnZhcmlhbnQocmVhbFdlYlNvY2tldCwgJ0ZhaWxlZCB0byBjYWxsIFwic2VydmVyLnNlbmQoKVwiIGZvciBcIiVzXCI6IHRoZSBjb25uZWN0aW9uIGlzIG5vdCBvcGVuLiBEaWQgeW91IGZvcmdldCB0byBjYWxsIFwic2VydmVyLmNvbm5lY3QoKVwiPycsIHRoaXMuY2xpZW50LnVybCk7XG4gICAgaWYgKHJlYWxXZWJTb2NrZXQucmVhZHlTdGF0ZSA9PT0gV2ViU29ja2V0LkNMT1NJTkcgfHwgcmVhbFdlYlNvY2tldC5yZWFkeVN0YXRlID09PSBXZWJTb2NrZXQuQ0xPU0VEKSByZXR1cm47XG4gICAgaWYgKHJlYWxXZWJTb2NrZXQucmVhZHlTdGF0ZSA9PT0gV2ViU29ja2V0LkNPTk5FQ1RJTkcpIHtcbiAgICAgIHJlYWxXZWJTb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcihcIm9wZW5cIiwgKCkgPT4ge1xuICAgICAgICByZWFsV2ViU29ja2V0LnNlbmQoZGF0YSk7XG4gICAgICB9LCB7IG9uY2U6IHRydWUgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJlYWxXZWJTb2NrZXQuc2VuZChkYXRhKTtcbiAgfVxuICAvKipcbiAgKiBDbG9zZSB0aGUgYWN0dWFsIHNlcnZlciBjb25uZWN0aW9uLlxuICAqL1xuICBjbG9zZSgpIHtcbiAgICBjb25zdCB7IHJlYWxXZWJTb2NrZXQgfSA9IHRoaXM7XG4gICAgaW52YXJpYW50KHJlYWxXZWJTb2NrZXQsICdGYWlsZWQgdG8gY2xvc2Ugc2VydmVyIGNvbm5lY3Rpb24gZm9yIFwiJXNcIjogdGhlIGNvbm5lY3Rpb24gaXMgbm90IG9wZW4uIERpZCB5b3UgZm9yZ2V0IHRvIGNhbGwgXCJzZXJ2ZXIuY29ubmVjdCgpXCI/JywgdGhpcy5jbGllbnQudXJsKTtcbiAgICB0aGlzLnJlYWxDbG9zZUNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICBpZiAocmVhbFdlYlNvY2tldC5yZWFkeVN0YXRlID09PSBXZWJTb2NrZXQuQ0xPU0lORyB8fCByZWFsV2ViU29ja2V0LnJlYWR5U3RhdGUgPT09IFdlYlNvY2tldC5DTE9TRUQpIHJldHVybjtcbiAgICByZWFsV2ViU29ja2V0LmNsb3NlKCk7XG4gICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgdGhpc1trRW1pdHRlcl0uZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcy5yZWFsV2ViU29ja2V0LCBuZXcgQ2FuY2VsYWJsZUNsb3NlRXZlbnQoXCJjbG9zZVwiLCB7XG4gICAgICAgIGNvZGU6IDFlMyxcbiAgICAgICAgY2FuY2VsYWJsZTogdHJ1ZVxuICAgICAgfSkpKTtcbiAgICB9KTtcbiAgfVxuICBoYW5kbGVJbmNvbWluZ01lc3NhZ2UoZXZlbnQpIHtcbiAgICBjb25zdCBtZXNzYWdlRXZlbnQgPSBiaW5kRXZlbnQoZXZlbnQudGFyZ2V0LCBuZXcgQ2FuY2VsYWJsZU1lc3NhZ2VFdmVudChcIm1lc3NhZ2VcIiwge1xuICAgICAgZGF0YTogZXZlbnQuZGF0YSxcbiAgICAgIG9yaWdpbjogZXZlbnQub3JpZ2luLFxuICAgICAgY2FuY2VsYWJsZTogdHJ1ZVxuICAgIH0pKTtcbiAgICB0aGlzW2tFbWl0dGVyXS5kaXNwYXRjaEV2ZW50KG1lc3NhZ2VFdmVudCk7XG4gICAgaWYgKCFtZXNzYWdlRXZlbnQuZGVmYXVsdFByZXZlbnRlZCkgdGhpcy5jbGllbnQuZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQoXG4gICAgICAvKipcbiAgICAgICogQG5vdGUgQmluZCB0aGUgZm9yd2FyZGVkIG9yaWdpbmFsIHNlcnZlciBldmVudHNcbiAgICAgICogdG8gdGhlIG1vY2sgV2ViU29ja2V0IGluc3RhbmNlIHNvIGl0IHdvdWxkXG4gICAgICAqIGRpc3BhdGNoIHRoZW0gc3RyYWlnaHQgYXdheS5cbiAgICAgICovXG4gICAgICB0aGlzLmNsaWVudCxcbiAgICAgIG5ldyBNZXNzYWdlRXZlbnQoXCJtZXNzYWdlXCIsIHtcbiAgICAgICAgZGF0YTogZXZlbnQuZGF0YSxcbiAgICAgICAgb3JpZ2luOiBldmVudC5vcmlnaW5cbiAgICAgIH0pXG4gICAgKSk7XG4gIH1cbiAgaGFuZGxlTW9ja0Nsb3NlKF9ldmVudCkge1xuICAgIGlmICh0aGlzLnJlYWxXZWJTb2NrZXQpIHRoaXMucmVhbFdlYlNvY2tldC5jbG9zZSgpO1xuICB9XG4gIGhhbmRsZVJlYWxDbG9zZShldmVudCkge1xuICAgIHRoaXMubW9ja0Nsb3NlQ29udHJvbGxlci5hYm9ydCgpO1xuICAgIGNvbnN0IGNsb3NlRXZlbnQgPSBiaW5kRXZlbnQodGhpcy5yZWFsV2ViU29ja2V0LCBuZXcgQ2FuY2VsYWJsZUNsb3NlRXZlbnQoXCJjbG9zZVwiLCB7XG4gICAgICBjb2RlOiBldmVudC5jb2RlLFxuICAgICAgcmVhc29uOiBldmVudC5yZWFzb24sXG4gICAgICB3YXNDbGVhbjogZXZlbnQud2FzQ2xlYW4sXG4gICAgICBjYW5jZWxhYmxlOiB0cnVlXG4gICAgfSkpO1xuICAgIHRoaXNba0VtaXR0ZXJdLmRpc3BhdGNoRXZlbnQoY2xvc2VFdmVudCk7XG4gICAgaWYgKCFjbG9zZUV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHRoaXMuY2xpZW50W2tDbG9zZV0oZXZlbnQuY29kZSwgZXZlbnQucmVhc29uKTtcbiAgfVxufTtcbnZhciBXZWJTb2NrZXRDbGFzc1RyYW5zcG9ydCA9IGNsYXNzIGV4dGVuZHMgRXZlbnRUYXJnZXQge1xuICBjb25zdHJ1Y3Rvcihzb2NrZXQpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuc29ja2V0ID0gc29ja2V0O1xuICAgIHRoaXMuc29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoXCJjbG9zZVwiLCAoZXZlbnQpID0+IHtcbiAgICAgIHRoaXMuZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQodGhpcy5zb2NrZXQsIG5ldyBDbG9zZUV2ZW50KFwiY2xvc2VcIiwgZXZlbnQpKSk7XG4gICAgfSk7XG4gICAgdGhpcy5zb2NrZXRba09uU2VuZF0gPSAoZGF0YSkgPT4ge1xuICAgICAgdGhpcy5kaXNwYXRjaEV2ZW50KGJpbmRFdmVudCh0aGlzLnNvY2tldCwgbmV3IENhbmNlbGFibGVNZXNzYWdlRXZlbnQoXCJvdXRnb2luZ1wiLCB7XG4gICAgICAgIGRhdGEsXG4gICAgICAgIG9yaWdpbjogdGhpcy5zb2NrZXQudXJsLFxuICAgICAgICBjYW5jZWxhYmxlOiB0cnVlXG4gICAgICB9KSkpO1xuICAgIH07XG4gIH1cbiAgYWRkRXZlbnRMaXN0ZW5lcih0eXBlLCBjYWxsYmFjaywgb3B0aW9ucykge1xuICAgIHJldHVybiBzdXBlci5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGNhbGxiYWNrLCBvcHRpb25zKTtcbiAgfVxuICBkaXNwYXRjaEV2ZW50KGV2ZW50KSB7XG4gICAgcmV0dXJuIHN1cGVyLmRpc3BhdGNoRXZlbnQoZXZlbnQpO1xuICB9XG4gIHNlbmQoZGF0YSkge1xuICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICAgIGlmICh0aGlzLnNvY2tldC5yZWFkeVN0YXRlID09PSB0aGlzLnNvY2tldC5DTE9TSU5HIHx8IHRoaXMuc29ja2V0LnJlYWR5U3RhdGUgPT09IHRoaXMuc29ja2V0LkNMT1NFRCkgcmV0dXJuO1xuICAgICAgY29uc3QgZGlzcGF0Y2hFdmVudCA9ICgpID0+IHtcbiAgICAgICAgdGhpcy5zb2NrZXQuZGlzcGF0Y2hFdmVudChiaW5kRXZlbnQoXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgKiBAbm90ZSBTZXR0aW5nIHRoaXMgZXZlbnQncyBcInRhcmdldFwiIHRvIHRoZVxuICAgICAgICAgICogV2ViU29ja2V0IG92ZXJyaWRlIGluc3RhbmNlIGlzIGltcG9ydGFudC5cbiAgICAgICAgICAqIFRoaXMgd2F5IGl0IGNhbiB0ZWxsIGFwYXJ0IG9yaWdpbmFsIGluY29taW5nIGV2ZW50c1xuICAgICAgICAgICogKG11c3QgYmUgZm9yd2FyZGVkIHRvIHRoZSB0cmFuc3BvcnQpIGZyb20gdGhlXG4gICAgICAgICAgKiBtb2NrZWQgbWVzc2FnZSBldmVudHMgbGlrZSB0aGUgb25lIGJlbG93XG4gICAgICAgICAgKiAobXVzdCBiZSBkaXNwYXRjaGVkIG9uIHRoZSBjbGllbnQgaW5zdGFuY2UpLlxuICAgICAgICAgICovXG4gICAgICAgICAgdGhpcy5zb2NrZXQsXG4gICAgICAgICAgbmV3IE1lc3NhZ2VFdmVudChcIm1lc3NhZ2VcIiwge1xuICAgICAgICAgICAgZGF0YSxcbiAgICAgICAgICAgIG9yaWdpbjogdGhpcy5zb2NrZXQudXJsXG4gICAgICAgICAgfSlcbiAgICAgICAgKSk7XG4gICAgICB9O1xuICAgICAgaWYgKHRoaXMuc29ja2V0LnJlYWR5U3RhdGUgPT09IHRoaXMuc29ja2V0LkNPTk5FQ1RJTkcpIHRoaXMuc29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoXCJvcGVuXCIsICgpID0+IHtcbiAgICAgICAgZGlzcGF0Y2hFdmVudCgpO1xuICAgICAgfSwgeyBvbmNlOiB0cnVlIH0pO1xuICAgICAgZWxzZSBkaXNwYXRjaEV2ZW50KCk7XG4gICAgfSk7XG4gIH1cbiAgY2xvc2UoY29kZSwgcmVhc29uKSB7XG4gICAgdGhpcy5zb2NrZXRba0Nsb3NlXShjb2RlLCByZWFzb24pO1xuICB9XG59O1xudmFyIFdlYlNvY2tldEludGVyY2VwdG9yID0gY2xhc3MgV2ViU29ja2V0SW50ZXJjZXB0b3IyIGV4dGVuZHMgSW50ZXJjZXB0b3Ige1xuICBzdGF0aWMge1xuICAgIHRoaXMuc3ltYm9sID0gLyogQF9fUFVSRV9fICovIFN5bWJvbC5mb3IoXCJ3ZWJzb2NrZXQtaW50ZXJjZXB0b3JcIik7XG4gIH1cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoV2ViU29ja2V0SW50ZXJjZXB0b3IyLnN5bWJvbCk7XG4gIH1cbiAgY2hlY2tFbnZpcm9ubWVudCgpIHtcbiAgICByZXR1cm4gaGFzQ29uZmlndXJhYmxlR2xvYmFsKFwiV2ViU29ja2V0XCIpO1xuICB9XG4gIHNldHVwKCkge1xuICAgIGNvbnN0IGxvZ2dlciA9IHRoaXMubG9nZ2VyLmV4dGVuZChcInNldHVwXCIpO1xuICAgIGNvbnN0IFdlYlNvY2tldFByb3h5ID0gbmV3IFByb3h5KGdsb2JhbFRoaXMuV2ViU29ja2V0LCB7IGNvbnN0cnVjdDogKHRhcmdldCwgYXJncywgbmV3VGFyZ2V0KSA9PiB7XG4gICAgICBjb25zdCBbdXJsLCBwcm90b2NvbHNdID0gYXJncztcbiAgICAgIGNvbnN0IGNyZWF0ZUNvbm5lY3Rpb24gPSAoKSA9PiB7XG4gICAgICAgIHJldHVybiBSZWZsZWN0LmNvbnN0cnVjdCh0YXJnZXQsIGFyZ3MsIG5ld1RhcmdldCk7XG4gICAgICB9O1xuICAgICAgY29uc3Qgc29ja2V0ID0gbmV3IFdlYlNvY2tldE92ZXJyaWRlKHVybCwgcHJvdG9jb2xzKTtcbiAgICAgIGNvbnN0IHRyYW5zcG9ydCA9IG5ldyBXZWJTb2NrZXRDbGFzc1RyYW5zcG9ydChzb2NrZXQpO1xuICAgICAgcXVldWVNaWNyb3Rhc2soYXN5bmMgKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHNlcnZlciA9IG5ldyBXZWJTb2NrZXRTZXJ2ZXJDb25uZWN0aW9uKHNvY2tldCwgdHJhbnNwb3J0LCBjcmVhdGVDb25uZWN0aW9uKTtcbiAgICAgICAgICBjb25zdCBoYXNDb25uZWN0aW9uTGlzdGVuZXJzID0gdGhpcy5lbWl0dGVyLmxpc3RlbmVyQ291bnQoXCJjb25uZWN0aW9uXCIpID4gMDtcbiAgICAgICAgICBhd2FpdCBlbWl0QXN5bmModGhpcy5lbWl0dGVyLCBcImNvbm5lY3Rpb25cIiwge1xuICAgICAgICAgICAgY2xpZW50OiBuZXcgV2ViU29ja2V0Q2xpZW50Q29ubmVjdGlvbihzb2NrZXQsIHRyYW5zcG9ydCksXG4gICAgICAgICAgICBzZXJ2ZXIsXG4gICAgICAgICAgICBpbmZvOiB7IHByb3RvY29scyB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWYgKGhhc0Nvbm5lY3Rpb25MaXN0ZW5lcnMpIHNvY2tldFtrUGFzc3Rocm91Z2hQcm9taXNlXS5yZXNvbHZlKGZhbHNlKTtcbiAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHNvY2tldFtrUGFzc3Rocm91Z2hQcm9taXNlXS5yZXNvbHZlKHRydWUpO1xuICAgICAgICAgICAgc2VydmVyLmNvbm5lY3QoKTtcbiAgICAgICAgICAgIHNlcnZlci5hZGRFdmVudExpc3RlbmVyKFwib3BlblwiLCAoKSA9PiB7XG4gICAgICAgICAgICAgIHNvY2tldC5kaXNwYXRjaEV2ZW50KGJpbmRFdmVudChzb2NrZXQsIG5ldyBFdmVudChcIm9wZW5cIikpKTtcbiAgICAgICAgICAgICAgaWYgKHNlcnZlcltcInJlYWxXZWJTb2NrZXRcIl0pIHNvY2tldC5wcm90b2NvbCA9IHNlcnZlcltcInJlYWxXZWJTb2NrZXRcIl0ucHJvdG9jb2w7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yMikge1xuICAgICAgICAgIGlmIChlcnJvcjIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgc29ja2V0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiZXJyb3JcIikpO1xuICAgICAgICAgICAgaWYgKHNvY2tldC5yZWFkeVN0YXRlICE9PSBXZWJTb2NrZXQuQ0xPU0lORyAmJiBzb2NrZXQucmVhZHlTdGF0ZSAhPT0gV2ViU29ja2V0LkNMT1NFRCkgc29ja2V0W2tDbG9zZV0oMTAxMSwgZXJyb3IyLm1lc3NhZ2UsIGZhbHNlKTtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IyKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHNvY2tldDtcbiAgICB9IH0pO1xuICAgIGxvZ2dlci5pbmZvKFwicGF0Y2hpbmcgZ2xvYmFsIFdlYlNvY2tldC4uLlwiKTtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMucHVzaChwYXRjaGVzUmVnaXN0cnkuYXBwbHlQYXRjaChnbG9iYWxUaGlzLCBcIldlYlNvY2tldFwiLCAoKSA9PiBXZWJTb2NrZXRQcm94eSkpO1xuICAgIGxvZ2dlci5pbmZvKFwiZ2xvYmFsIFdlYlNvY2tldCBwYXRjaGVkIVwiLCBnbG9iYWxUaGlzLldlYlNvY2tldC5uYW1lKTtcbiAgfVxufTtcblxuLy8gc3JjL2Jyb3dzZXIvc2V0dXAtd29ya2VyLnRzXG5pbXBvcnQge1xuICBkZWZpbmVOZXR3b3JrLFxuICBOZXR3b3JrUmVhZHlTdGF0ZVxufSBmcm9tICcuLi9jb3JlL2V4cGVyaW1lbnRhbC9kZWZpbmUtbmV0d29yay5tanMnO1xuaW1wb3J0IHsgSW50ZXJjZXB0b3JTb3VyY2UgYXMgSW50ZXJjZXB0b3JTb3VyY2UyIH0gZnJvbSAnLi4vY29yZS9leHBlcmltZW50YWwvc291cmNlcy9pbnRlcmNlcHRvci1zb3VyY2UubWpzJztcbmltcG9ydCB7IGZyb21MZWdhY3lPblVuaGFuZGxlZFJlcXVlc3QgfSBmcm9tICcuLi9jb3JlL2V4cGVyaW1lbnRhbC9jb21wYXQubWpzJztcbmltcG9ydCB7IGRldlV0aWxzIGFzIGRldlV0aWxzNSB9IGZyb20gJy4uL2NvcmUvdXRpbHMvaW50ZXJuYWwvZGV2VXRpbHMubWpzJztcblxuLy8gc3JjL2Jyb3dzZXIvdXRpbHMvc3VwcG9ydHMudHNcbmZ1bmN0aW9uIHN1cHBvcnRzU2VydmljZVdvcmtlcigpIHtcbiAgcmV0dXJuIHR5cGVvZiBuYXZpZ2F0b3IgIT09IFwidW5kZWZpbmVkXCIgJiYgXCJzZXJ2aWNlV29ya2VyXCIgaW4gbmF2aWdhdG9yICYmIHR5cGVvZiBsb2NhdGlvbiAhPT0gXCJ1bmRlZmluZWRcIiAmJiBsb2NhdGlvbi5wcm90b2NvbCAhPT0gXCJmaWxlOlwiO1xufVxuZnVuY3Rpb24gc3VwcG9ydHNSZWFkYWJsZVN0cmVhbVRyYW5zZmVyKCkge1xuICB0cnkge1xuICAgIGNvbnN0IHN0cmVhbSA9IG5ldyBSZWFkYWJsZVN0cmVhbSh7XG4gICAgICBzdGFydDogKGNvbnRyb2xsZXIpID0+IGNvbnRyb2xsZXIuY2xvc2UoKVxuICAgIH0pO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBuZXcgTWVzc2FnZUNoYW5uZWwoKTtcbiAgICBtZXNzYWdlLnBvcnQxLnBvc3RNZXNzYWdlKHN0cmVhbSwgW3N0cmVhbV0pO1xuICAgIHJldHVybiB0cnVlO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0BvcGVuLWRyYWZ0K2RlZmVycmVkLXByb21pc2VAMy4wLjAvbm9kZV9tb2R1bGVzL0BvcGVuLWRyYWZ0L2RlZmVycmVkLXByb21pc2UvYnVpbGQvaW5kZXgubWpzXG5mdW5jdGlvbiBjcmVhdGVEZWZlcnJlZEV4ZWN1dG9yMigpIHtcbiAgY29uc3QgZXhlY3V0b3IgPSAoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGV4ZWN1dG9yLnN0YXRlID0gXCJwZW5kaW5nXCI7XG4gICAgZXhlY3V0b3IucmVzb2x2ZSA9IChkYXRhKSA9PiB7XG4gICAgICBpZiAoZXhlY3V0b3Iuc3RhdGUgIT09IFwicGVuZGluZ1wiKSByZXR1cm47XG4gICAgICBleGVjdXRvci5yZXN1bHQgPSBkYXRhO1xuICAgICAgY29uc3Qgb25GdWxmaWxsZWQgPSAodmFsdWUpID0+IHtcbiAgICAgICAgZXhlY3V0b3Iuc3RhdGUgPSBcImZ1bGZpbGxlZFwiO1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICB9O1xuICAgICAgcmV0dXJuIHJlc29sdmUoZGF0YSBpbnN0YW5jZW9mIFByb21pc2UgPyBkYXRhIDogUHJvbWlzZS5yZXNvbHZlKGRhdGEpLnRoZW4ob25GdWxmaWxsZWQpKTtcbiAgICB9O1xuICAgIGV4ZWN1dG9yLnJlamVjdCA9IChyZWFzb24pID0+IHtcbiAgICAgIGlmIChleGVjdXRvci5zdGF0ZSAhPT0gXCJwZW5kaW5nXCIpIHJldHVybjtcbiAgICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICAgICAgZXhlY3V0b3Iuc3RhdGUgPSBcInJlamVjdGVkXCI7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZWplY3QoZXhlY3V0b3IucmVqZWN0aW9uUmVhc29uID0gcmVhc29uKTtcbiAgICB9O1xuICB9KTtcbiAgcmV0dXJuIGV4ZWN1dG9yO1xufVxudmFyIERlZmVycmVkUHJvbWlzZTIgPSBjbGFzcyBleHRlbmRzIFByb21pc2Uge1xuICAjZXhlY3V0b3I7XG4gIHJlc29sdmU7XG4gIHJlamVjdDtcbiAgY29uc3RydWN0b3IoZXhlY3V0b3IgPSBudWxsKSB7XG4gICAgY29uc3QgZGVmZXJyZWRFeGVjdXRvciA9IGNyZWF0ZURlZmVycmVkRXhlY3V0b3IyKCk7XG4gICAgc3VwZXIoKG9yaWdpbmFsUmVzb2x2ZSwgb3JpZ2luYWxSZWplY3QpID0+IHtcbiAgICAgIGRlZmVycmVkRXhlY3V0b3Iob3JpZ2luYWxSZXNvbHZlLCBvcmlnaW5hbFJlamVjdCk7XG4gICAgICBleGVjdXRvcj8uKGRlZmVycmVkRXhlY3V0b3IucmVzb2x2ZSwgZGVmZXJyZWRFeGVjdXRvci5yZWplY3QpO1xuICAgIH0pO1xuICAgIHRoaXMuI2V4ZWN1dG9yID0gZGVmZXJyZWRFeGVjdXRvcjtcbiAgICB0aGlzLnJlc29sdmUgPSB0aGlzLiNleGVjdXRvci5yZXNvbHZlO1xuICAgIHRoaXMucmVqZWN0ID0gdGhpcy4jZXhlY3V0b3IucmVqZWN0O1xuICB9XG4gIGdldCBzdGF0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy4jZXhlY3V0b3Iuc3RhdGU7XG4gIH1cbiAgZ2V0IHJlamVjdGlvblJlYXNvbigpIHtcbiAgICByZXR1cm4gdGhpcy4jZXhlY3V0b3IucmVqZWN0aW9uUmVhc29uO1xuICB9XG4gIHRoZW4ob25GdWxmaWxsZWQsIG9uUmVqZWN0ZWQpIHtcbiAgICByZXR1cm4gdGhpcy4jZGVjb3JhdGUoc3VwZXIudGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkpO1xuICB9XG4gIGNhdGNoKG9uUmVqZWN0ZWQpIHtcbiAgICByZXR1cm4gdGhpcy4jZGVjb3JhdGUoc3VwZXIuY2F0Y2gob25SZWplY3RlZCkpO1xuICB9XG4gIGZpbmFsbHkob25maW5hbGx5KSB7XG4gICAgcmV0dXJuIHRoaXMuI2RlY29yYXRlKHN1cGVyLmZpbmFsbHkob25maW5hbGx5KSk7XG4gIH1cbiAgI2RlY29yYXRlKHByb21pc2UpIHtcbiAgICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMocHJvbWlzZSwge1xuICAgICAgcmVzb2x2ZToge1xuICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgIHZhbHVlOiB0aGlzLnJlc29sdmVcbiAgICAgIH0sXG4gICAgICByZWplY3Q6IHtcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICB2YWx1ZTogdGhpcy5yZWplY3RcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0Btc3dqcytpbnRlcmNlcHRvcnNAMC40MS45L25vZGVfbW9kdWxlcy9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL2dldFJhd1JlcXVlc3QtQjFCcWdXRzYubWpzXG52YXIgSW50ZXJjZXB0b3JFcnJvciA9IGNsYXNzIEludGVyY2VwdG9yRXJyb3IyIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gXCJJbnRlcmNlcHRvckVycm9yXCI7XG4gICAgT2JqZWN0LnNldFByb3RvdHlwZU9mKHRoaXMsIEludGVyY2VwdG9yRXJyb3IyLnByb3RvdHlwZSk7XG4gIH1cbn07XG52YXIgUmVxdWVzdENvbnRyb2xsZXIgPSBjbGFzcyBSZXF1ZXN0Q29udHJvbGxlcjIge1xuICBzdGF0aWMge1xuICAgIHRoaXMuUEVORElORyA9IDA7XG4gIH1cbiAgc3RhdGljIHtcbiAgICB0aGlzLlBBU1NUSFJPVUdIID0gMTtcbiAgfVxuICBzdGF0aWMge1xuICAgIHRoaXMuUkVTUE9OU0UgPSAyO1xuICB9XG4gIHN0YXRpYyB7XG4gICAgdGhpcy5FUlJPUiA9IDM7XG4gIH1cbiAgY29uc3RydWN0b3IocmVxdWVzdCwgc291cmNlKSB7XG4gICAgdGhpcy5yZXF1ZXN0ID0gcmVxdWVzdDtcbiAgICB0aGlzLnNvdXJjZSA9IHNvdXJjZTtcbiAgICB0aGlzLnJlYWR5U3RhdGUgPSBSZXF1ZXN0Q29udHJvbGxlcjIuUEVORElORztcbiAgICB0aGlzLmhhbmRsZWQgPSBuZXcgRGVmZXJyZWRQcm9taXNlKCk7XG4gIH1cbiAgZ2V0ICNoYW5kbGVkKCkge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZWQ7XG4gIH1cbiAgLyoqXG4gICogUGVyZm9ybSB0aGlzIHJlcXVlc3QgYXMtaXMuXG4gICovXG4gIGFzeW5jIHBhc3N0aHJvdWdoKCkge1xuICAgIGludmFyaWFudC5hcyhJbnRlcmNlcHRvckVycm9yLCB0aGlzLnJlYWR5U3RhdGUgPT09IFJlcXVlc3RDb250cm9sbGVyMi5QRU5ESU5HLCAnRmFpbGVkIHRvIHBhc3N0aHJvdWdoIHRoZSBcIiVzICVzXCIgcmVxdWVzdDogdGhlIHJlcXVlc3QgaGFzIGFscmVhZHkgYmVlbiBoYW5kbGVkJywgdGhpcy5yZXF1ZXN0Lm1ldGhvZCwgdGhpcy5yZXF1ZXN0LnVybCk7XG4gICAgdGhpcy5yZWFkeVN0YXRlID0gUmVxdWVzdENvbnRyb2xsZXIyLlBBU1NUSFJPVUdIO1xuICAgIGF3YWl0IHRoaXMuc291cmNlLnBhc3N0aHJvdWdoKCk7XG4gICAgdGhpcy4jaGFuZGxlZC5yZXNvbHZlKCk7XG4gIH1cbiAgLyoqXG4gICogUmVzcG9uZCB0byB0aGlzIHJlcXVlc3Qgd2l0aCB0aGUgZ2l2ZW4gYFJlc3BvbnNlYCBpbnN0YW5jZS5cbiAgKlxuICAqIEBleGFtcGxlXG4gICogY29udHJvbGxlci5yZXNwb25kV2l0aChuZXcgUmVzcG9uc2UoKSlcbiAgKiBjb250cm9sbGVyLnJlc3BvbmRXaXRoKFJlc3BvbnNlLmpzb24oeyBpZCB9KSlcbiAgKiBjb250cm9sbGVyLnJlc3BvbmRXaXRoKFJlc3BvbnNlLmVycm9yKCkpXG4gICovXG4gIHJlc3BvbmRXaXRoKHJlc3BvbnNlKSB7XG4gICAgaW52YXJpYW50LmFzKEludGVyY2VwdG9yRXJyb3IsIHRoaXMucmVhZHlTdGF0ZSA9PT0gUmVxdWVzdENvbnRyb2xsZXIyLlBFTkRJTkcsICdGYWlsZWQgdG8gcmVzcG9uZCB0byB0aGUgXCIlcyAlc1wiIHJlcXVlc3Qgd2l0aCBcIiVkICVzXCI6IHRoZSByZXF1ZXN0IGhhcyBhbHJlYWR5IGJlZW4gaGFuZGxlZCAoJWQpJywgdGhpcy5yZXF1ZXN0Lm1ldGhvZCwgdGhpcy5yZXF1ZXN0LnVybCwgcmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS5zdGF0dXNUZXh0IHx8IFwiT0tcIiwgdGhpcy5yZWFkeVN0YXRlKTtcbiAgICB0aGlzLnJlYWR5U3RhdGUgPSBSZXF1ZXN0Q29udHJvbGxlcjIuUkVTUE9OU0U7XG4gICAgdGhpcy4jaGFuZGxlZC5yZXNvbHZlKCk7XG4gICAgdGhpcy5zb3VyY2UucmVzcG9uZFdpdGgocmVzcG9uc2UpO1xuICB9XG4gIC8qKlxuICAqIEVycm9yIHRoaXMgcmVxdWVzdCB3aXRoIHRoZSBnaXZlbiByZWFzb24uXG4gICpcbiAgKiBAZXhhbXBsZVxuICAqIGNvbnRyb2xsZXIuZXJyb3JXaXRoKClcbiAgKiBjb250cm9sbGVyLmVycm9yV2l0aChuZXcgRXJyb3IoJ09vcHMhJykpXG4gICogY29udHJvbGxlci5lcnJvcldpdGgoeyBtZXNzYWdlOiAnT29wcyEnfSlcbiAgKi9cbiAgZXJyb3JXaXRoKHJlYXNvbikge1xuICAgIGludmFyaWFudC5hcyhJbnRlcmNlcHRvckVycm9yLCB0aGlzLnJlYWR5U3RhdGUgPT09IFJlcXVlc3RDb250cm9sbGVyMi5QRU5ESU5HLCAnRmFpbGVkIHRvIGVycm9yIHRoZSBcIiVzICVzXCIgcmVxdWVzdCB3aXRoIFwiJXNcIjogdGhlIHJlcXVlc3QgaGFzIGFscmVhZHkgYmVlbiBoYW5kbGVkICglZCknLCB0aGlzLnJlcXVlc3QubWV0aG9kLCB0aGlzLnJlcXVlc3QudXJsLCByZWFzb24/LnRvU3RyaW5nKCksIHRoaXMucmVhZHlTdGF0ZSk7XG4gICAgdGhpcy5yZWFkeVN0YXRlID0gUmVxdWVzdENvbnRyb2xsZXIyLkVSUk9SO1xuICAgIHRoaXMuc291cmNlLmVycm9yV2l0aChyZWFzb24pO1xuICAgIHRoaXMuI2hhbmRsZWQucmVzb2x2ZSgpO1xuICB9XG59O1xuZnVuY3Rpb24gY2FuUGFyc2VVcmwodXJsKSB7XG4gIHRyeSB7XG4gICAgbmV3IFVSTCh1cmwpO1xuICAgIHJldHVybiB0cnVlO1xuICB9IGNhdGNoIChfZXJyb3IpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldFZhbHVlQnlTeW1ib2woc3ltYm9sTmFtZSwgc291cmNlKSB7XG4gIGNvbnN0IHN5bWJvbCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoc291cmNlKS5maW5kKChzeW1ib2wkMSkgPT4ge1xuICAgIHJldHVybiBzeW1ib2wkMS5kZXNjcmlwdGlvbiA9PT0gc3ltYm9sTmFtZTtcbiAgfSk7XG4gIGlmIChzeW1ib2wpIHJldHVybiBSZWZsZWN0LmdldChzb3VyY2UsIHN5bWJvbCk7XG59XG52YXIgRmV0Y2hSZXF1ZXN0ID0gY2xhc3MgRmV0Y2hSZXF1ZXN0MiBleHRlbmRzIFJlcXVlc3Qge1xuICBzdGF0aWMgI3Jlc29sdmVQcm9wZXJ0eShpbnB1dCwgaW5pdCA9IHt9LCBrZXkpIHtcbiAgICByZXR1cm4gaW5pdFtrZXldID8/IChpbnB1dCBpbnN0YW5jZW9mIFJlcXVlc3QgPyBpbnB1dFtrZXldIDogdm9pZCAwKTtcbiAgfVxuICAvKipcbiAgKiBDaGVjayBpZiB0aGUgZ2l2ZW4gcmVxdWVzdCBtZXRob2QgaXMgY29uZmlndXJhYmxlLlxuICAqIEBzZWUgaHR0cHM6Ly9mZXRjaC5zcGVjLndoYXR3Zy5vcmcvI21ldGhvZHNcbiAgKi9cbiAgc3RhdGljIGlzQ29uZmlndXJhYmxlTWV0aG9kKG1ldGhvZCkge1xuICAgIHJldHVybiBtZXRob2QgIT09IFwiQ09OTkVDVFwiICYmIG1ldGhvZCAhPT0gXCJUUkFDRVwiICYmIG1ldGhvZCAhPT0gXCJUUkFDS1wiO1xuICB9XG4gIHN0YXRpYyBpc01ldGhvZFdpdGhCb2R5KG1ldGhvZCkge1xuICAgIHJldHVybiBtZXRob2QgIT09IFwiSEVBRFwiICYmIG1ldGhvZCAhPT0gXCJHRVRcIiAmJiBGZXRjaFJlcXVlc3QyLmlzQ29uZmlndXJhYmxlTWV0aG9kKG1ldGhvZCk7XG4gIH1cbiAgLyoqXG4gICogQ2hlY2sgaWYgdGhlIGdpdmVuIHJlcXVlc3QgYG1vZGVgIGlzIGNvbmZpZ3VyYWJsZS5cbiAgKiBAc2VlIGh0dHBzOi8vZmV0Y2guc3BlYy53aGF0d2cub3JnLyNjb25jZXB0LXJlcXVlc3QtbW9kZVxuICAqL1xuICBzdGF0aWMgaXNDb25maWd1cmFibGVNb2RlKG1vZGUpIHtcbiAgICByZXR1cm4gbW9kZSAhPT0gXCJuYXZpZ2F0ZVwiICYmIG1vZGUgIT09IFwid2Vic29ja2V0XCIgJiYgbW9kZSAhPT0gXCJ3ZWJ0cmFuc3BvcnRcIjtcbiAgfVxuICBjb25zdHJ1Y3RvcihpbnB1dCwgaW5pdCkge1xuICAgIGNvbnN0IG1ldGhvZCA9IEZldGNoUmVxdWVzdDIuI3Jlc29sdmVQcm9wZXJ0eShpbnB1dCwgaW5pdCwgXCJtZXRob2RcIikgfHwgXCJHRVRcIjtcbiAgICBjb25zdCBzYWZlTWV0aG9kID0gRmV0Y2hSZXF1ZXN0Mi5pc0NvbmZpZ3VyYWJsZU1ldGhvZChtZXRob2QpID8gbWV0aG9kIDogXCJHRVRcIjtcbiAgICBjb25zdCBoYXNFeHBsaWNpdEJvZHkgPSBpbml0ICE9IG51bGwgJiYgXCJib2R5XCIgaW4gaW5pdDtcbiAgICBjb25zdCBib2R5SW5pdCA9ICFGZXRjaFJlcXVlc3QyLmlzTWV0aG9kV2l0aEJvZHkobWV0aG9kKSA/IHsgYm9keTogdm9pZCAwIH0gOiBoYXNFeHBsaWNpdEJvZHkgPyB7IGJvZHk6IGluaXQuYm9keSB9IDoge307XG4gICAgY29uc3QgbW9kZSA9IEZldGNoUmVxdWVzdDIuI3Jlc29sdmVQcm9wZXJ0eShpbnB1dCwgaW5pdCwgXCJtb2RlXCIpID8/IHZvaWQgMDtcbiAgICBjb25zdCBzYWZlTW9kZSA9IEZldGNoUmVxdWVzdDIuaXNDb25maWd1cmFibGVNb2RlKG1vZGUpID8gbW9kZSA6IHZvaWQgMDtcbiAgICBzdXBlcihpbnB1dCwge1xuICAgICAgLi4uaW5pdCB8fCB7fSxcbiAgICAgIG1ldGhvZDogc2FmZU1ldGhvZCxcbiAgICAgIG1vZGU6IHNhZmVNb2RlLFxuICAgICAgZHVwbGV4OiBpbml0Py5kdXBsZXggPz8gKEZldGNoUmVxdWVzdDIuaXNNZXRob2RXaXRoQm9keShtZXRob2QpID8gXCJoYWxmXCIgOiB2b2lkIDApLFxuICAgICAgLi4uYm9keUluaXRcbiAgICB9KTtcbiAgICBpZiAobWV0aG9kICE9PSBzYWZlTWV0aG9kKSB0aGlzLiNzZXRJbnRlcm5hbFByb3BlcnR5KFwibWV0aG9kXCIsIG1ldGhvZCk7XG4gICAgaWYgKG1ldGhvZCA9PT0gXCJDT05ORUNUXCIpIHtcbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwoaW5wdXQgaW5zdGFuY2VvZiBSZXF1ZXN0ID8gaW5wdXQudXJsIDogaW5wdXQpO1xuICAgICAgbGV0IGF1dGhvcml0eTtcbiAgICAgIGlmICh1cmwucHJvdG9jb2wgPT09IFwibG9jYWxob3N0OlwiKSBhdXRob3JpdHkgPSB1cmwuaHJlZjtcbiAgICAgIGVsc2UgYXV0aG9yaXR5ID0gdXJsLnBhdGhuYW1lLnJlcGxhY2UoL15cXC8rLywgXCJcIik7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJ1cmxcIiwge1xuICAgICAgICBnZXQ6ICgpID0+IGF1dGhvcml0eSxcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG1vZGUgIT0gbnVsbCAmJiBtb2RlICE9PSBzYWZlTW9kZSkgdGhpcy4jc2V0SW50ZXJuYWxQcm9wZXJ0eShcIm1vZGVcIiwgbW9kZSk7XG4gIH1cbiAgI3NldEludGVybmFsUHJvcGVydHkoa2V5LCB2YWx1ZSkge1xuICAgIGNvbnN0IGludGVybmFsU3RhdGUgPSBnZXRWYWx1ZUJ5U3ltYm9sKFwic3RhdGVcIiwgdGhpcyk7XG4gICAgaWYgKGludGVybmFsU3RhdGUpIFJlZmxlY3Quc2V0KGludGVybmFsU3RhdGUsIGtleSwgdmFsdWUpO1xuICAgIGVsc2UgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIGtleSwge1xuICAgICAgdmFsdWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgd3JpdGFibGU6IGZhbHNlXG4gICAgfSk7XG4gIH1cbn07XG52YXIga1N0YXR1cyA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJrU3RhdHVzXCIpO1xudmFyIGtVcmwgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwia1VybFwiKTtcbnZhciBGZXRjaFJlc3BvbnNlID0gY2xhc3MgRmV0Y2hSZXNwb25zZTIgZXh0ZW5kcyBSZXNwb25zZSB7XG4gIHN0YXRpYyB7XG4gICAgdGhpcy5TVEFUVVNfQ09ERVNfV0lUSE9VVF9CT0RZID0gW1xuICAgICAgMTAxLFxuICAgICAgMTAzLFxuICAgICAgMjA0LFxuICAgICAgMjA1LFxuICAgICAgMzA0XG4gICAgXTtcbiAgfVxuICBzdGF0aWMge1xuICAgIHRoaXMuU1RBVFVTX0NPREVTX1dJVEhfUkVESVJFQ1QgPSBbXG4gICAgICAzMDEsXG4gICAgICAzMDIsXG4gICAgICAzMDMsXG4gICAgICAzMDcsXG4gICAgICAzMDhcbiAgICBdO1xuICB9XG4gIHN0YXRpYyBpc0NvbmZpZ3VyYWJsZVN0YXR1c0NvZGUoc3RhdHVzKSB7XG4gICAgcmV0dXJuIHN0YXR1cyA+PSAyMDAgJiYgc3RhdHVzIDw9IDU5OTtcbiAgfVxuICBzdGF0aWMgaXNSZWRpcmVjdFJlc3BvbnNlKHN0YXR1cykge1xuICAgIHJldHVybiBGZXRjaFJlc3BvbnNlMi5TVEFUVVNfQ09ERVNfV0lUSF9SRURJUkVDVC5pbmNsdWRlcyhzdGF0dXMpO1xuICB9XG4gIC8qKlxuICAqIFJldHVybnMgYSBib29sZWFuIGluZGljYXRpbmcgd2hldGhlciB0aGUgZ2l2ZW4gcmVzcG9uc2Ugc3RhdHVzXG4gICogY29kZSByZXByZXNlbnRzIGEgcmVzcG9uc2UgdGhhdCBjYW4gaGF2ZSBhIGJvZHkuXG4gICovXG4gIHN0YXRpYyBpc1Jlc3BvbnNlV2l0aEJvZHkoc3RhdHVzKSB7XG4gICAgcmV0dXJuICFGZXRjaFJlc3BvbnNlMi5TVEFUVVNfQ09ERVNfV0lUSE9VVF9CT0RZLmluY2x1ZGVzKHN0YXR1cyk7XG4gIH1cbiAgc3RhdGljIHNldFN0YXR1cyhzdGF0dXMsIHJlc3BvbnNlKSB7XG4gICAgY29uc3QgaW50ZXJuYWxTdGF0ZSA9IGdldFZhbHVlQnlTeW1ib2woXCJzdGF0ZVwiLCByZXNwb25zZSk7XG4gICAgaWYgKGludGVybmFsU3RhdGUpIGludGVybmFsU3RhdGUuc3RhdHVzID0gc3RhdHVzO1xuICAgIGVsc2UgT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlc3BvbnNlLCBcInN0YXR1c1wiLCB7XG4gICAgICB2YWx1ZTogc3RhdHVzLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlOiBmYWxzZVxuICAgIH0pO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZXNwb25zZSwga1N0YXR1cywge1xuICAgICAgdmFsdWU6IHN0YXR1cyxcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlXG4gICAgfSk7XG4gIH1cbiAgc3RhdGljIHNldFVybCh1cmwsIHJlc3BvbnNlKSB7XG4gICAgaWYgKCF1cmwgfHwgdXJsID09PSBcImFib3V0OlwiIHx8ICFjYW5QYXJzZVVybCh1cmwpKSByZXR1cm47XG4gICAgY29uc3Qgc3RhdGUgPSBnZXRWYWx1ZUJ5U3ltYm9sKFwic3RhdGVcIiwgcmVzcG9uc2UpO1xuICAgIGlmIChzdGF0ZSkgc3RhdGUudXJsTGlzdC5wdXNoKG5ldyBVUkwodXJsKSk7XG4gICAgZWxzZSBPYmplY3QuZGVmaW5lUHJvcGVydHkocmVzcG9uc2UsIFwidXJsXCIsIHtcbiAgICAgIHZhbHVlOiB1cmwsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgd3JpdGFibGU6IGZhbHNlXG4gICAgfSk7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlc3BvbnNlLCBrVXJsLCB7XG4gICAgICB2YWx1ZTogdXJsLFxuICAgICAgZW51bWVyYWJsZTogZmFsc2VcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgKiBQYXJzZXMgdGhlIGdpdmVuIHJhdyBIVFRQIGhlYWRlcnMgaW50byBhIEZldGNoIEFQSSBgSGVhZGVyc2AgaW5zdGFuY2UuXG4gICovXG4gIHN0YXRpYyBwYXJzZVJhd0hlYWRlcnMocmF3SGVhZGVycykge1xuICAgIGNvbnN0IGhlYWRlcnMgPSBuZXcgSGVhZGVycygpO1xuICAgIGZvciAobGV0IGxpbmUgPSAwOyBsaW5lIDwgcmF3SGVhZGVycy5sZW5ndGg7IGxpbmUgKz0gMikgaGVhZGVycy5hcHBlbmQocmF3SGVhZGVyc1tsaW5lXSwgcmF3SGVhZGVyc1tsaW5lICsgMV0pO1xuICAgIHJldHVybiBoZWFkZXJzO1xuICB9XG4gIC8qKlxuICAqIFNhZmVseSBjbG9uZXMgdGhlIGdpdmVuIGBSZXNwb25zZWAuXG4gICogQ29lcmNlcyByZXNwb25zZSBjbG9uZSBleGNlcHRpb25zIGludG8gNTAwIG1vY2tlZCByZXNwb25zZXMuXG4gICogSGFuZHkgaW4gdGhlIGVudmlyb25tZW50cyB0aGF0IGludHJvZHVjZSBhcmJpdHJhcnkgcmVzcG9uc2VcbiAgKiBjbG9uaW5nIHJlc3RyaWN0aW9ucywgbGlrZSBcIjEwMSBTd2l0Y2hpbmcgUHJvdG9jb2xzXCIgY2xvbmluZ1xuICAqIGluIFwibWluaWZsYXJlXCIuXG4gICovXG4gIHN0YXRpYyBjbG9uZShyZXNwb25zZSkge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gcmVzcG9uc2UuY2xvbmUoKTtcbiAgICB9IGNhdGNoIChlcnJvcjIpIHtcbiAgICAgIHJldHVybiBSZXNwb25zZS5qc29uKGVycm9yMiBpbnN0YW5jZW9mIEVycm9yID8ge1xuICAgICAgICBuYW1lOiBlcnJvcjIubmFtZSxcbiAgICAgICAgbWVzc2FnZTogZXJyb3IyLm1lc3NhZ2UsXG4gICAgICAgIHN0YWNrOiBlcnJvcjIuc3RhY2tcbiAgICAgIH0gOiB7fSwge1xuICAgICAgICBzdGF0dXM6IDUwMCxcbiAgICAgICAgc3RhdHVzVGV4dDogXCJVbmNsb25hYmxlIFJlc3BvbnNlXCJcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBjb25zdHJ1Y3Rvcihib2R5LCBpbml0ID0ge30pIHtcbiAgICBjb25zdCBzdGF0dXMgPSBpbml0LnN0YXR1cyA/PyAyMDA7XG4gICAgY29uc3Qgc2FmZVN0YXR1cyA9IEZldGNoUmVzcG9uc2UyLmlzQ29uZmlndXJhYmxlU3RhdHVzQ29kZShzdGF0dXMpID8gc3RhdHVzIDogMjAwO1xuICAgIGNvbnN0IGZpbmFsQm9keSA9IEZldGNoUmVzcG9uc2UyLmlzUmVzcG9uc2VXaXRoQm9keShzdGF0dXMpID8gYm9keSA6IG51bGw7XG4gICAgc3VwZXIoZmluYWxCb2R5LCB7XG4gICAgICBzdGF0dXM6IHNhZmVTdGF0dXMsXG4gICAgICBzdGF0dXNUZXh0OiBpbml0LnN0YXR1c1RleHQsXG4gICAgICBoZWFkZXJzOiBpbml0LmhlYWRlcnNcbiAgICB9KTtcbiAgICBpZiAoc3RhdHVzICE9PSBzYWZlU3RhdHVzKSBGZXRjaFJlc3BvbnNlMi5zZXRTdGF0dXMoc3RhdHVzLCB0aGlzKTtcbiAgICBGZXRjaFJlc3BvbnNlMi5zZXRVcmwoaW5pdC51cmwsIHRoaXMpO1xuICB9XG4gIGNsb25lKCkge1xuICAgIGNvbnN0IGNsb25lZFJlc3BvbnNlID0gc3VwZXIuY2xvbmUoKTtcbiAgICBjb25zdCBjdXN0b21TdGF0dXMgPSBSZWZsZWN0LmdldCh0aGlzLCBrU3RhdHVzKTtcbiAgICBpZiAoY3VzdG9tU3RhdHVzKSBGZXRjaFJlc3BvbnNlMi5zZXRTdGF0dXMoY3VzdG9tU3RhdHVzLCBjbG9uZWRSZXNwb25zZSk7XG4gICAgY29uc3QgY3VzdG9tVXJsID0gUmVmbGVjdC5nZXQodGhpcywga1VybCk7XG4gICAgaWYgKGN1c3RvbVVybCkgRmV0Y2hSZXNwb25zZTIuc2V0VXJsKGN1c3RvbVVybCwgY2xvbmVkUmVzcG9uc2UpO1xuICAgIHJldHVybiBjbG9uZWRSZXNwb25zZTtcbiAgfVxufTtcbnZhciBrUmF3UmVxdWVzdCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJrUmF3UmVxdWVzdFwiKTtcbmZ1bmN0aW9uIHNldFJhd1JlcXVlc3QocmVxdWVzdCwgcmF3UmVxdWVzdCkge1xuICBSZWZsZWN0LnNldChyZXF1ZXN0LCBrUmF3UmVxdWVzdCwgcmF3UmVxdWVzdCk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9AbXN3anMraW50ZXJjZXB0b3JzQDAuNDEuOS9ub2RlX21vZHVsZXMvQG1zd2pzL2ludGVyY2VwdG9ycy9saWIvYnJvd3Nlci9idWZmZXJVdGlscy1CaWlPNkhadi5tanNcbnZhciBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG5mdW5jdGlvbiBlbmNvZGVCdWZmZXIodGV4dCkge1xuICByZXR1cm4gZW5jb2Rlci5lbmNvZGUodGV4dCk7XG59XG5mdW5jdGlvbiBkZWNvZGVCdWZmZXIoYnVmZmVyLCBlbmNvZGluZykge1xuICByZXR1cm4gbmV3IFRleHREZWNvZGVyKGVuY29kaW5nKS5kZWNvZGUoYnVmZmVyKTtcbn1cbmZ1bmN0aW9uIHRvQXJyYXlCdWZmZXIoYXJyYXkpIHtcbiAgcmV0dXJuIGFycmF5LmJ1ZmZlci5zbGljZShhcnJheS5ieXRlT2Zmc2V0LCBhcnJheS5ieXRlT2Zmc2V0ICsgYXJyYXkuYnl0ZUxlbmd0aCk7XG59XG5cbi8vIHNyYy9icm93c2VyL3NvdXJjZXMvc2VydmljZS13b3JrZXItc291cmNlLnRzXG5pbXBvcnQgeyBOZXR3b3JrU291cmNlIH0gZnJvbSAnLi4vY29yZS9leHBlcmltZW50YWwvc291cmNlcy9uZXR3b3JrLXNvdXJjZS5tanMnO1xuaW1wb3J0IHsgUmVxdWVzdEhhbmRsZXIgfSBmcm9tICcuLi9jb3JlL2hhbmRsZXJzL1JlcXVlc3RIYW5kbGVyLm1qcyc7XG5pbXBvcnQge1xuICBIdHRwTmV0d29ya0ZyYW1lLFxuICBSZXNwb25zZUV2ZW50XG59IGZyb20gJy4uL2NvcmUvZXhwZXJpbWVudGFsL2ZyYW1lcy9odHRwLWZyYW1lLm1qcyc7XG5pbXBvcnQgeyBIdHRwUmVzcG9uc2UgfSBmcm9tICcuLi9jb3JlL0h0dHBSZXNwb25zZS5tanMnO1xuaW1wb3J0IHsgdG9SZXNwb25zZUluaXQgfSBmcm9tICcuLi9jb3JlL3V0aWxzL3RvUmVzcG9uc2VJbml0Lm1qcyc7XG5pbXBvcnQgeyBkZXZVdGlscyBhcyBkZXZVdGlsczMgfSBmcm9tICcuLi9jb3JlL3V0aWxzL2ludGVybmFsL2RldlV0aWxzLm1qcyc7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS91bnRpbC1hc3luY0AzLjAuMi9ub2RlX21vZHVsZXMvdW50aWwtYXN5bmMvbGliL2luZGV4LmpzXG5hc3luYyBmdW5jdGlvbiB1bnRpbChjYWxsYmFjaykge1xuICB0cnkge1xuICAgIHJldHVybiBbbnVsbCwgYXdhaXQgY2FsbGJhY2soKS5jYXRjaCgoZXJyb3IyKSA9PiB7XG4gICAgICB0aHJvdyBlcnJvcjI7XG4gICAgfSldO1xuICB9IGNhdGNoIChlcnJvcjIpIHtcbiAgICByZXR1cm4gW2Vycm9yMiwgbnVsbF07XG4gIH1cbn1cblxuLy8gc3JjL2Jyb3dzZXIvdXRpbHMvZ2V0LXdvcmtlci1pbnN0YW5jZS50c1xuaW1wb3J0IHsgZGV2VXRpbHMgfSBmcm9tICcuLi9jb3JlL3V0aWxzL2ludGVybmFsL2RldlV0aWxzLm1qcyc7XG5cbi8vIHNyYy9icm93c2VyL3V0aWxzL2dldEFic29sdXRlV29ya2VyVXJsLnRzXG5mdW5jdGlvbiBnZXRBYnNvbHV0ZVdvcmtlclVybCh3b3JrZXJVcmwpIHtcbiAgcmV0dXJuIG5ldyBVUkwod29ya2VyVXJsLCBsb2NhdGlvbi5ocmVmKS5ocmVmO1xufVxuXG4vLyBzcmMvYnJvd3Nlci91dGlscy9nZXQtd29ya2VyLWJ5LXJlZ2lzdHJhdGlvbi50c1xuZnVuY3Rpb24gZ2V0V29ya2VyQnlSZWdpc3RyYXRpb24ocmVnaXN0cmF0aW9uLCBhYnNvbHV0ZVdvcmtlclVybCwgZmluZFdvcmtlcikge1xuICBjb25zdCBhbGxTdGF0ZXMgPSBbXG4gICAgcmVnaXN0cmF0aW9uLmFjdGl2ZSxcbiAgICByZWdpc3RyYXRpb24uaW5zdGFsbGluZyxcbiAgICByZWdpc3RyYXRpb24ud2FpdGluZ1xuICBdO1xuICBjb25zdCByZWxldmFudFN0YXRlcyA9IGFsbFN0YXRlcy5maWx0ZXIoKHN0YXRlKSA9PiB7XG4gICAgcmV0dXJuIHN0YXRlICE9IG51bGw7XG4gIH0pO1xuICBjb25zdCB3b3JrZXIgPSByZWxldmFudFN0YXRlcy5maW5kKCh3b3JrZXIyKSA9PiB7XG4gICAgcmV0dXJuIGZpbmRXb3JrZXIod29ya2VyMi5zY3JpcHRVUkwsIGFic29sdXRlV29ya2VyVXJsKTtcbiAgfSk7XG4gIHJldHVybiB3b3JrZXIgfHwgbnVsbDtcbn1cblxuLy8gc3JjL2Jyb3dzZXIvdXRpbHMvZ2V0LXdvcmtlci1pbnN0YW5jZS50c1xudmFyIGdldFdvcmtlckluc3RhbmNlID0gYXN5bmMgKHVybCwgb3B0aW9ucyA9IHt9LCBmaW5kV29ya2VyKSA9PiB7XG4gIGNvbnN0IGFic29sdXRlV29ya2VyVXJsID0gZ2V0QWJzb2x1dGVXb3JrZXJVcmwodXJsKTtcbiAgY29uc3QgbW9ja1JlZ2lzdHJhdGlvbnMgPSBhd2FpdCBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5nZXRSZWdpc3RyYXRpb25zKCkudGhlbihcbiAgICAocmVnaXN0cmF0aW9ucykgPT4gcmVnaXN0cmF0aW9ucy5maWx0ZXIoXG4gICAgICAocmVnaXN0cmF0aW9uKSA9PiBnZXRXb3JrZXJCeVJlZ2lzdHJhdGlvbihyZWdpc3RyYXRpb24sIGFic29sdXRlV29ya2VyVXJsLCBmaW5kV29ya2VyKVxuICAgIClcbiAgKTtcbiAgaWYgKCFuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5jb250cm9sbGVyICYmIG1vY2tSZWdpc3RyYXRpb25zLmxlbmd0aCA+IDApIHtcbiAgICBsb2NhdGlvbi5yZWxvYWQoKTtcbiAgfVxuICBjb25zdCBbZXhpc3RpbmdSZWdpc3RyYXRpb25dID0gbW9ja1JlZ2lzdHJhdGlvbnM7XG4gIGlmIChleGlzdGluZ1JlZ2lzdHJhdGlvbikge1xuICAgIGV4aXN0aW5nUmVnaXN0cmF0aW9uLnVwZGF0ZSgpO1xuICAgIHJldHVybiBbXG4gICAgICBnZXRXb3JrZXJCeVJlZ2lzdHJhdGlvbihcbiAgICAgICAgZXhpc3RpbmdSZWdpc3RyYXRpb24sXG4gICAgICAgIGFic29sdXRlV29ya2VyVXJsLFxuICAgICAgICBmaW5kV29ya2VyXG4gICAgICApLFxuICAgICAgZXhpc3RpbmdSZWdpc3RyYXRpb25cbiAgICBdO1xuICB9XG4gIGNvbnN0IFtyZWdpc3RyYXRpb25FcnJvciwgcmVnaXN0cmF0aW9uUmVzdWx0XSA9IGF3YWl0IHVudGlsKGFzeW5jICgpID0+IHtcbiAgICBjb25zdCByZWdpc3RyYXRpb24gPSBhd2FpdCBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5yZWdpc3Rlcih1cmwsIG9wdGlvbnMpO1xuICAgIHJldHVybiBbXG4gICAgICAvLyBDb21wYXJlIGV4aXN0aW5nIHdvcmtlciByZWdpc3RyYXRpb24gYnkgaXRzIHdvcmtlciBVUkwsXG4gICAgICAvLyB0byBwcmV2ZW50IGlycmVsZXZhbnQgd29ya2VycyB0byByZXNvbHZlIGhlcmUgKHN1Y2ggYXMgQ29kZXNhbmRib3ggd29ya2VyKS5cbiAgICAgIGdldFdvcmtlckJ5UmVnaXN0cmF0aW9uKHJlZ2lzdHJhdGlvbiwgYWJzb2x1dGVXb3JrZXJVcmwsIGZpbmRXb3JrZXIpLFxuICAgICAgcmVnaXN0cmF0aW9uXG4gICAgXTtcbiAgfSk7XG4gIGlmIChyZWdpc3RyYXRpb25FcnJvcikge1xuICAgIGNvbnN0IGlzV29ya2VyTWlzc2luZyA9IHJlZ2lzdHJhdGlvbkVycm9yLm1lc3NhZ2UuaW5jbHVkZXMoXCIoNDA0KVwiKTtcbiAgICBpZiAoaXNXb3JrZXJNaXNzaW5nKSB7XG4gICAgICBjb25zdCBzY29wZVVybCA9IG5ldyBVUkwob3B0aW9ucz8uc2NvcGUgfHwgXCIvXCIsIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKGBGYWlsZWQgdG8gcmVnaXN0ZXIgYSBTZXJ2aWNlIFdvcmtlciBmb3Igc2NvcGUgKCcke3Njb3BlVXJsLmhyZWZ9Jykgd2l0aCBzY3JpcHQgKCcke2Fic29sdXRlV29ya2VyVXJsfScpOiBTZXJ2aWNlIFdvcmtlciBzY3JpcHQgZG9lcyBub3QgZXhpc3QgYXQgdGhlIGdpdmVuIHBhdGguXG5cbkRpZCB5b3UgZm9yZ2V0IHRvIHJ1biBcIm5weCBtc3cgaW5pdCA8UFVCTElDX0RJUj5cIj9cblxuTGVhcm4gbW9yZSBhYm91dCBjcmVhdGluZyB0aGUgU2VydmljZSBXb3JrZXIgc2NyaXB0OiBodHRwczovL21zd2pzLmlvL2RvY3MvY2xpL2luaXRgKVxuICAgICAgKTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcbiAgICAgICAgXCJGYWlsZWQgdG8gcmVnaXN0ZXIgdGhlIFNlcnZpY2UgV29ya2VyOlxcblxcbiVzXCIsXG4gICAgICAgIHJlZ2lzdHJhdGlvbkVycm9yLm1lc3NhZ2VcbiAgICAgIClcbiAgICApO1xuICB9XG4gIHJldHVybiByZWdpc3RyYXRpb25SZXN1bHQ7XG59O1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vcmV0dGltZUAwLjExLjExL25vZGVfbW9kdWxlcy9yZXR0aW1lL2J1aWxkL2xlbnMtbGlzdC5tanNcbnZhciBMZW5zTGlzdCA9IGNsYXNzIHtcbiAgI2xpc3Q7XG4gICNsZW5zO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLiNsaXN0ID0gW107XG4gICAgdGhpcy4jbGVucyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIH1cbiAgZ2V0IFtTeW1ib2wuaXRlcmF0b3JdKCkge1xuICAgIHJldHVybiB0aGlzLiNsaXN0W1N5bWJvbC5pdGVyYXRvcl0uYmluZCh0aGlzLiNsaXN0KTtcbiAgfVxuICBlbnRyaWVzKCkge1xuICAgIHJldHVybiB0aGlzLiNsZW5zLmVudHJpZXMoKTtcbiAgfVxuICAvKipcbiAgKiBSZXR1cm4gYW4gb3JkZXItc2Vuc2l0aXZlIGxpc3Qgb2YgdmFsdWVzIGJ5IHRoZSBnaXZlbiBrZXkuXG4gICovXG4gIGdldChrZXkpIHtcbiAgICByZXR1cm4gdGhpcy4jbGVucy5nZXQoa2V5KSB8fCBbXTtcbiAgfVxuICAvKipcbiAgKiBSZXR1cm4gYW4gb3JkZXItc2Vuc2l0aXZlIGxpc3Qgb2YgYWxsIHZhbHVlcy5cbiAgKi9cbiAgZ2V0QWxsKCkge1xuICAgIHJldHVybiB0aGlzLiNsaXN0Lm1hcCgoWywgdmFsdWVdKSA9PiB2YWx1ZSk7XG4gIH1cbiAgLyoqXG4gICogQXBwZW5kIGEgbmV3IHZhbHVlIHRvIHRoZSBnaXZlbiBrZXkuXG4gICovXG4gIGFwcGVuZChrZXksIHZhbHVlKSB7XG4gICAgdGhpcy4jbGlzdC5wdXNoKFtrZXksIHZhbHVlXSk7XG4gICAgdGhpcy4jb3BlbkxlbnMoa2V5LCAobGlzdCkgPT4gbGlzdC5wdXNoKHZhbHVlKSk7XG4gIH1cbiAgLyoqXG4gICogUHJlcGVuZCBhIG5ldyB2YWx1ZSB0byB0aGUgZ2l2ZW4ga2V5LlxuICAqL1xuICBwcmVwZW5kKGtleSwgdmFsdWUpIHtcbiAgICB0aGlzLiNsaXN0LnVuc2hpZnQoW2tleSwgdmFsdWVdKTtcbiAgICB0aGlzLiNvcGVuTGVucyhrZXksIChsaXN0KSA9PiBsaXN0LnVuc2hpZnQodmFsdWUpKTtcbiAgfVxuICAvKipcbiAgKiBEZWxldGUgdGhlIHZhbHVlIGJlbG9uZ2luZyB0byB0aGUgZ2l2ZW4ga2V5LlxuICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSB2YWx1ZSB3YXMgcHJlc2VudCBhbmQgcmVtb3ZlZCwgYGZhbHNlYCBvdGhlcndpc2UuXG4gICovXG4gIGRlbGV0ZShrZXksIHZhbHVlKSB7XG4gICAgaWYgKHRoaXMuc2l6ZSA9PT0gMCkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IHZhbHVlcyA9IHRoaXMuI2xlbnMuZ2V0KGtleSk7XG4gICAgaWYgKCF2YWx1ZXMpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBpbmRleCA9IHZhbHVlcy5pbmRleE9mKHZhbHVlKTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSByZXR1cm4gZmFsc2U7XG4gICAgdmFsdWVzLnNwbGljZShpbmRleCwgMSk7XG4gICAgdGhpcy4jbGlzdC5zcGxpY2UodGhpcy4jbGlzdC5maW5kSW5kZXgoKGl0ZW0pID0+IGl0ZW1bMF0gPT09IGtleSAmJiBpdGVtWzFdID09PSB2YWx1ZSksIDEpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIC8qKlxuICAqIERlbGV0ZSBhbGwgdmFsdWVzIGJlbG9nbmluZyB0byB0aGUgZ2l2ZW4ga2V5LlxuICAqL1xuICBkZWxldGVBbGwoa2V5KSB7XG4gICAgaWYgKHRoaXMuc2l6ZSA9PT0gMCkgcmV0dXJuO1xuICAgIHRoaXMuI2xpc3QgPSB0aGlzLiNsaXN0LmZpbHRlcigoaXRlbSkgPT4gaXRlbVswXSAhPT0ga2V5KTtcbiAgICB0aGlzLiNsZW5zLmRlbGV0ZShrZXkpO1xuICB9XG4gIGdldCBzaXplKCkge1xuICAgIHJldHVybiB0aGlzLiNsaXN0Lmxlbmd0aDtcbiAgfVxuICBjbGVhcigpIHtcbiAgICBpZiAodGhpcy5zaXplID09PSAwKSByZXR1cm47XG4gICAgdGhpcy4jbGlzdC5sZW5ndGggPSAwO1xuICAgIHRoaXMuI2xlbnMuY2xlYXIoKTtcbiAgfVxuICAjb3BlbkxlbnMoa2V5LCBzZXR0ZXIpIHtcbiAgICBzZXR0ZXIodGhpcy4jbGVucy5nZXQoa2V5KSB8fCB0aGlzLiNsZW5zLnNldChrZXksIFtdKS5nZXQoa2V5KSk7XG4gIH1cbn07XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9yZXR0aW1lQDAuMTEuMTEvbm9kZV9tb2R1bGVzL3JldHRpbWUvYnVpbGQvaW5kZXgubWpzXG52YXIga0RlZmF1bHRQcmV2ZW50ZWQyID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImtEZWZhdWx0UHJldmVudGVkXCIpO1xudmFyIGtQcm9wYWdhdGlvblN0b3BwZWQgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwia1Byb3BhZ2F0aW9uU3RvcHBlZFwiKTtcbnZhciBrSW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcImtJbW1lZGlhdGVQcm9wYWdhdGlvblN0b3BwZWRcIik7XG52YXIgVHlwZWRFdmVudCA9IGNsYXNzIGV4dGVuZHMgTWVzc2FnZUV2ZW50IHtcbiAgLyoqXG4gICogQG5vdGUgS2VlcCBhIHBsYWNlaG9sZGVyIHByb3BlcnR5IHdpdGggdGhlIHJldHVybiB0eXBlXG4gICogYmVjYXVzZSB0aGUgdHlwZSBtdXN0IGJlIHNldCBzb21ld2hlcmUgaW4gb3JkZXIgdG8gYmVcbiAgKiBjb3JyZWN0bHkgYXNzb2NpYXRlZCBhbmQgaW5mZXJyZWQgZnJvbSB0aGUgZXZlbnQuXG4gICovXG4gICNyZXR1cm5UeXBlO1xuICBba0RlZmF1bHRQcmV2ZW50ZWQyXTtcbiAgW2tQcm9wYWdhdGlvblN0b3BwZWRdO1xuICBba0ltbWVkaWF0ZVByb3BhZ2F0aW9uU3RvcHBlZF07XG4gIGNvbnN0cnVjdG9yKC4uLmFyZ3MpIHtcbiAgICBzdXBlcihhcmdzWzBdLCBhcmdzWzFdKTtcbiAgICB0aGlzW2tEZWZhdWx0UHJldmVudGVkMl0gPSBmYWxzZTtcbiAgfVxuICBnZXQgZGVmYXVsdFByZXZlbnRlZCgpIHtcbiAgICByZXR1cm4gdGhpc1trRGVmYXVsdFByZXZlbnRlZDJdO1xuICB9XG4gIHByZXZlbnREZWZhdWx0KCkge1xuICAgIHN1cGVyLnByZXZlbnREZWZhdWx0KCk7XG4gICAgdGhpc1trRGVmYXVsdFByZXZlbnRlZDJdID0gdHJ1ZTtcbiAgfVxuICBzdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKSB7XG4gICAgc3VwZXIuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgdGhpc1trSW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkXSA9IHRydWU7XG4gIH1cbn07XG52YXIgRW1pdHRlcjIgPSBjbGFzcyB7XG4gICNsaXN0ZW5lcnM7XG4gICNsaXN0ZW5lck9wdGlvbnM7XG4gICNsaXN0ZW5lckFib3J0Q2xlYW51cHM7XG4gICN0eXBlbGVzc0xpc3RlbmVycztcbiAgI2hvb2tMaXN0ZW5lcnM7XG4gICNob29rTGlzdGVuZXJPcHRpb25zO1xuICAjaG9va0xpc3RlbmVyQWJvcnRDbGVhbnVwcztcbiAgaG9va3M7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuI2xpc3RlbmVycyA9IG5ldyBMZW5zTGlzdCgpO1xuICAgIHRoaXMuI2xpc3RlbmVyT3B0aW9ucyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuICAgIHRoaXMuI2xpc3RlbmVyQWJvcnRDbGVhbnVwcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuICAgIHRoaXMuI3R5cGVsZXNzTGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrU2V0KCk7XG4gICAgdGhpcy4jaG9va0xpc3RlbmVycyA9IG5ldyBMZW5zTGlzdCgpO1xuICAgIHRoaXMuI2hvb2tMaXN0ZW5lck9wdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbiAgICB0aGlzLiNob29rTGlzdGVuZXJBYm9ydENsZWFudXBzID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG4gICAgdGhpcy5ob29rcyA9IHtcbiAgICAgIG9uOiAoaG9vaywgY2FsbGJhY2ssIG9wdGlvbnMpID0+IHtcbiAgICAgICAgaWYgKG9wdGlvbnM/LnNpZ25hbD8uYWJvcnRlZCkgcmV0dXJuO1xuICAgICAgICBpZiAob3B0aW9ucz8ub25jZSkge1xuICAgICAgICAgIGNvbnN0IG9yaWdpbmFsID0gY2FsbGJhY2s7XG4gICAgICAgICAgY29uc3Qgd3JhcHBlciA9ICgoLi4uYXJncykgPT4ge1xuICAgICAgICAgICAgdGhpcy4jZGVsZXRlSG9va0xpc3RlbmVyKGhvb2ssIHdyYXBwZXIpO1xuICAgICAgICAgICAgcmV0dXJuIG9yaWdpbmFsKC4uLmFyZ3MpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNhbGxiYWNrID0gd3JhcHBlcjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLiNob29rTGlzdGVuZXJzLmFwcGVuZChob29rLCBjYWxsYmFjayk7XG4gICAgICAgIGlmIChvcHRpb25zKSB0aGlzLiNob29rTGlzdGVuZXJPcHRpb25zLnNldChjYWxsYmFjaywgb3B0aW9ucyk7XG4gICAgICAgIGlmIChvcHRpb25zPy5zaWduYWwpIHtcbiAgICAgICAgICBjb25zdCB7IHNpZ25hbCB9ID0gb3B0aW9ucztcbiAgICAgICAgICBjb25zdCBvbkFib3J0ID0gKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy4jZGVsZXRlSG9va0xpc3RlbmVyKGhvb2ssIGNhbGxiYWNrKTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25BYm9ydCwgeyBvbmNlOiB0cnVlIH0pO1xuICAgICAgICAgIHRoaXMuI2hvb2tMaXN0ZW5lckFib3J0Q2xlYW51cHMuc2V0KGNhbGxiYWNrLCAoKSA9PiB7XG4gICAgICAgICAgICBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIG9uQWJvcnQpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgcmVtb3ZlTGlzdGVuZXI6IChob29rLCBjYWxsYmFjaykgPT4ge1xuICAgICAgICB0aGlzLiNkZWxldGVIb29rTGlzdGVuZXIoaG9vaywgY2FsbGJhY2spO1xuICAgICAgfVxuICAgIH07XG4gIH1cbiAgI2RlbGV0ZUhvb2tMaXN0ZW5lcihob29rLCBjYWxsYmFjaykge1xuICAgIHRoaXMuI2hvb2tMaXN0ZW5lcnMuZGVsZXRlKGhvb2ssIGNhbGxiYWNrKTtcbiAgICBjb25zdCBjbGVhbnVwID0gdGhpcy4jaG9va0xpc3RlbmVyQWJvcnRDbGVhbnVwcy5nZXQoY2FsbGJhY2spO1xuICAgIGlmIChjbGVhbnVwKSB7XG4gICAgICBjbGVhbnVwKCk7XG4gICAgICB0aGlzLiNob29rTGlzdGVuZXJBYm9ydENsZWFudXBzLmRlbGV0ZShjYWxsYmFjayk7XG4gICAgfVxuICB9XG4gICNkZWxldGVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcikge1xuICAgIGNvbnN0IHJlbW92ZWQgPSB0aGlzLiNsaXN0ZW5lcnMuZGVsZXRlKHR5cGUsIGxpc3RlbmVyKTtcbiAgICBjb25zdCBjbGVhbnVwID0gdGhpcy4jbGlzdGVuZXJBYm9ydENsZWFudXBzLmdldChsaXN0ZW5lcik7XG4gICAgaWYgKGNsZWFudXApIHtcbiAgICAgIGNsZWFudXAoKTtcbiAgICAgIHRoaXMuI2xpc3RlbmVyQWJvcnRDbGVhbnVwcy5kZWxldGUobGlzdGVuZXIpO1xuICAgIH1cbiAgICByZXR1cm4gcmVtb3ZlZDtcbiAgfVxuICAvKipcbiAgKiBBZGRzIGEgbGlzdGVuZXIgZm9yIHRoZSBnaXZlbiBldmVudCB0eXBlLlxuICAqL1xuICBvbih0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucykge1xuICAgIHRoaXMuI2FkZExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgKiBBZGRzIGEgb25lLXRpbWUgbGlzdGVuZXIgZm9yIHRoZSBnaXZlbiBldmVudCB0eXBlLlxuICAqL1xuICBvbmNlKHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMub24odHlwZSwgbGlzdGVuZXIsIHtcbiAgICAgIC4uLm9wdGlvbnMgfHwge30sXG4gICAgICBvbmNlOiB0cnVlXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICogUHJlcGVuZHMgYSBsaXN0ZW5lciBmb3IgdGhlIGdpdmVuIGV2ZW50IHR5cGUuXG4gICovXG4gIGVhcmx5T24odHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcbiAgICB0aGlzLiNhZGRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucywgXCJwcmVwZW5kXCIpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAqIFByZXBlbmRzIGEgb25lLXRpbWUgbGlzdGVuZXIgZm9yIHRoZSBnaXZlbiBldmVudCB0eXBlLlxuICAqL1xuICBlYXJseU9uY2UodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5lYXJseU9uKHR5cGUsIGxpc3RlbmVyLCB7XG4gICAgICAuLi5vcHRpb25zIHx8IHt9LFxuICAgICAgb25jZTogdHJ1ZVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAqIEVtaXRzIHRoZSBnaXZlbiB0eXBlZCBldmVudC5cbiAgKlxuICAqIEByZXR1cm5zIHtib29sZWFufSBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgZXZlbnQgaGFkIGFueSBsaXN0ZW5lcnMsIGBmYWxzZWAgb3RoZXJ3aXNlLlxuICAqL1xuICBlbWl0KGV2ZW50KSB7XG4gICAgaWYgKHRoaXMuI2xpc3RlbmVycy5zaXplID09PSAwKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgaGFzTGlzdGVuZXJzID0gdGhpcy5saXN0ZW5lckNvdW50KGV2ZW50LnR5cGUpID4gMDtcbiAgICBjb25zdCBwcm94aWVkRXZlbnQgPSB0aGlzLiNwcm94eUV2ZW50KGV2ZW50KTtcbiAgICBmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIHRoaXMuI21hdGNoTGlzdGVuZXJzKGV2ZW50LnR5cGUpKSB7XG4gICAgICBpZiAocHJveGllZEV2ZW50LmV2ZW50W2tQcm9wYWdhdGlvblN0b3BwZWRdICE9IG51bGwgJiYgcHJveGllZEV2ZW50LmV2ZW50W2tQcm9wYWdhdGlvblN0b3BwZWRdICE9PSB0aGlzKSB7XG4gICAgICAgIHByb3hpZWRFdmVudC5yZXZva2UoKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKHByb3hpZWRFdmVudC5ldmVudFtrSW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkXSkgYnJlYWs7XG4gICAgICB0aGlzLiNjYWxsTGlzdGVuZXIocHJveGllZEV2ZW50LmV2ZW50LCBsaXN0ZW5lcik7XG4gICAgfVxuICAgIHByb3hpZWRFdmVudC5yZXZva2UoKTtcbiAgICByZXR1cm4gaGFzTGlzdGVuZXJzO1xuICB9XG4gIC8qKlxuICAqIEVtaXRzIHRoZSBnaXZlbiB0eXBlZCBldmVudCBhbmQgcmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlc1xuICAqIHdoZW4gYWxsIHRoZSBsaXN0ZW5lcnMgZm9yIHRoYXQgZXZlbnQgaGF2ZSBzZXR0bGVkLlxuICAqXG4gICogQHJldHVybnMge1Byb21pc2U8QXJyYXk8RW1pdHRlci5MaXN0ZW5lclJldHVyblR5cGU+Pn0gQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXNcbiAgKiB3aXRoIHRoZSByZXR1cm4gdmFsdWVzIG9mIGFsbCBsaXN0ZW5lcnMuXG4gICovXG4gIGFzeW5jIGVtaXRBc1Byb21pc2UoZXZlbnQpIHtcbiAgICBpZiAodGhpcy4jbGlzdGVuZXJzLnNpemUgPT09IDApIHJldHVybiBbXTtcbiAgICBjb25zdCBwZW5kaW5nTGlzdGVuZXJzID0gW107XG4gICAgY29uc3QgcHJveGllZEV2ZW50ID0gdGhpcy4jcHJveHlFdmVudChldmVudCk7XG4gICAgZm9yIChjb25zdCBsaXN0ZW5lciBvZiB0aGlzLiNtYXRjaExpc3RlbmVycyhldmVudC50eXBlKSkge1xuICAgICAgaWYgKHByb3hpZWRFdmVudC5ldmVudFtrUHJvcGFnYXRpb25TdG9wcGVkXSAhPSBudWxsICYmIHByb3hpZWRFdmVudC5ldmVudFtrUHJvcGFnYXRpb25TdG9wcGVkXSAhPT0gdGhpcykge1xuICAgICAgICBwcm94aWVkRXZlbnQucmV2b2tlKCk7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICAgIH1cbiAgICAgIGlmIChwcm94aWVkRXZlbnQuZXZlbnRba0ltbWVkaWF0ZVByb3BhZ2F0aW9uU3RvcHBlZF0pIGJyZWFrO1xuICAgICAgY29uc3QgcmV0dXJuVmFsdWUgPSBhd2FpdCBQcm9taXNlLnJlc29sdmUodGhpcy4jY2FsbExpc3RlbmVyKHByb3hpZWRFdmVudC5ldmVudCwgbGlzdGVuZXIpKTtcbiAgICAgIGlmICghdGhpcy4jaXNUeXBlbGVzc0xpc3RlbmVyKGxpc3RlbmVyKSkgcGVuZGluZ0xpc3RlbmVycy5wdXNoKHJldHVyblZhbHVlKTtcbiAgICB9XG4gICAgcHJveGllZEV2ZW50LnJldm9rZSgpO1xuICAgIHJldHVybiBQcm9taXNlLmFsbFNldHRsZWQocGVuZGluZ0xpc3RlbmVycykudGhlbigocmVzdWx0cykgPT4ge1xuICAgICAgcmV0dXJuIHJlc3VsdHMubWFwKChyZXN1bHQpID0+IHJlc3VsdC5zdGF0dXMgPT09IFwiZnVsZmlsbGVkXCIgPyByZXN1bHQudmFsdWUgOiByZXN1bHQucmVhc29uKTtcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgKiBFbWl0cyB0aGUgZ2l2ZW4gZXZlbnQgYW5kIHJldHVybnMgYSBnZW5lcmF0b3IgdGhhdCB5aWVsZHNcbiAgKiB0aGUgcmVzdWx0IG9mIGVhY2ggbGlzdGVuZXIgaW4gdGhlIG9yZGVyIG9mIHRoZWlyIHJlZ2lzdHJhdGlvbi5cbiAgKiBUaGlzIHdheSwgeW91IHN0b3AgZXhoYXVzdGluZyB0aGUgbGlzdGVuZXJzIG9uY2UgeW91IGdldCB0aGUgZXhwZWN0ZWQgdmFsdWUuXG4gICovXG4gICplbWl0QXNHZW5lcmF0b3IoZXZlbnQpIHtcbiAgICBpZiAodGhpcy4jbGlzdGVuZXJzLnNpemUgPT09IDApIHJldHVybjtcbiAgICBjb25zdCBwcm94aWVkRXZlbnQgPSB0aGlzLiNwcm94eUV2ZW50KGV2ZW50KTtcbiAgICBmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIHRoaXMuI21hdGNoTGlzdGVuZXJzKGV2ZW50LnR5cGUpKSB7XG4gICAgICBpZiAocHJveGllZEV2ZW50LmV2ZW50W2tQcm9wYWdhdGlvblN0b3BwZWRdICE9IG51bGwgJiYgcHJveGllZEV2ZW50LmV2ZW50W2tQcm9wYWdhdGlvblN0b3BwZWRdICE9PSB0aGlzKSB7XG4gICAgICAgIHByb3hpZWRFdmVudC5yZXZva2UoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKHByb3hpZWRFdmVudC5ldmVudFtrSW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkXSkgYnJlYWs7XG4gICAgICBjb25zdCByZXR1cm5WYWx1ZSA9IHRoaXMuI2NhbGxMaXN0ZW5lcihwcm94aWVkRXZlbnQuZXZlbnQsIGxpc3RlbmVyKTtcbiAgICAgIGlmICghdGhpcy4jaXNUeXBlbGVzc0xpc3RlbmVyKGxpc3RlbmVyKSkgeWllbGQgcmV0dXJuVmFsdWU7XG4gICAgfVxuICAgIHByb3hpZWRFdmVudC5yZXZva2UoKTtcbiAgfVxuICAvKipcbiAgKiBSZW1vdmVzIGEgbGlzdGVuZXIgZm9yIHRoZSBnaXZlbiBldmVudCB0eXBlLlxuICAqL1xuICByZW1vdmVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcikge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB0aGlzLiNsaXN0ZW5lck9wdGlvbnMuZ2V0KGxpc3RlbmVyKTtcbiAgICBpZiAoIXRoaXMuI2RlbGV0ZUxpc3RlbmVyKHR5cGUsIGxpc3RlbmVyKSkgcmV0dXJuO1xuICAgIGZvciAoY29uc3QgaG9vayBvZiB0aGlzLiNob29rTGlzdGVuZXJzLmdldChcInJlbW92ZUxpc3RlbmVyXCIpLnNsaWNlKCkpIGhvb2sodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpO1xuICB9XG4gIC8qKlxuICAqIFJlbW92ZXMgYWxsIGxpc3RlbmVycyBmb3IgdGhlIGdpdmVuIGV2ZW50IHR5cGUuXG4gICogSWYgbm8gZXZlbnQgdHlwZSBpcyBwcm92aWRlZCwgcmVtb3ZlcyBhbGwgZXhpc3RpbmcgbGlzdGVuZXJzLlxuICAqL1xuICByZW1vdmVBbGxMaXN0ZW5lcnModHlwZSkge1xuICAgIGlmICh0eXBlID09IG51bGwpIHtcbiAgICAgIGZvciAoY29uc3QgW2xpc3RlbmVyVHlwZSwgbGlzdGVuZXJzJDFdIG9mIHRoaXMuI2xpc3RlbmVycy5lbnRyaWVzKCkpIHdoaWxlIChsaXN0ZW5lcnMkMS5sZW5ndGggPiAwKSB0aGlzLnJlbW92ZUxpc3RlbmVyKGxpc3RlbmVyVHlwZSwgbGlzdGVuZXJzJDFbMF0pO1xuICAgICAgZm9yIChjb25zdCBbaG9va1R5cGUsIGhvb2tMaXN0ZW5lcl0gb2YgWy4uLnRoaXMuI2hvb2tMaXN0ZW5lcnNdKSBpZiAoIXRoaXMuI2hvb2tMaXN0ZW5lck9wdGlvbnMuZ2V0KGhvb2tMaXN0ZW5lcik/LnBlcnNpc3QpIHRoaXMuI2RlbGV0ZUhvb2tMaXN0ZW5lcihob29rVHlwZSwgaG9va0xpc3RlbmVyKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5saXN0ZW5lcnModHlwZSk7XG4gICAgd2hpbGUgKGxpc3RlbmVycy5sZW5ndGggPiAwKSB0aGlzLnJlbW92ZUxpc3RlbmVyKHR5cGUsIGxpc3RlbmVyc1swXSk7XG4gIH1cbiAgLyoqXG4gICogUmV0dXJucyB0aGUgbGlzdCBvZiBsaXN0ZW5lcnMgZm9yIHRoZSBnaXZlbiBldmVudCB0eXBlLlxuICAqIElmIG5vIGV2ZW4gdHlwZSBpcyBwcm92aWRlZCwgcmV0dXJucyBhbGwgbGlzdGVuZXJzLlxuICAqL1xuICBsaXN0ZW5lcnModHlwZSkge1xuICAgIGlmICh0eXBlID09IG51bGwpIHJldHVybiB0aGlzLiNsaXN0ZW5lcnMuZ2V0QWxsKCk7XG4gICAgcmV0dXJuIHRoaXMuI2xpc3RlbmVycy5nZXQodHlwZSk7XG4gIH1cbiAgLyoqXG4gICogUmV0dXJucyB0aGUgbnVtYmVyIG9mIGxpc3RlbmVycyBmb3IgdGhlIGdpdmVuIGV2ZW50IHR5cGUuXG4gICogSWYgbm8gZXZlbiB0eXBlIGlzIHByb3ZpZGVkLCByZXR1cm5zIHRoZSB0b3RhbCBudW1iZXIgb2YgbGlzdGVuZXJzLlxuICAqL1xuICBsaXN0ZW5lckNvdW50KHR5cGUpIHtcbiAgICBpZiAodHlwZSA9PSBudWxsKSByZXR1cm4gdGhpcy4jbGlzdGVuZXJzLnNpemU7XG4gICAgcmV0dXJuIHRoaXMubGlzdGVuZXJzKHR5cGUpLmxlbmd0aDtcbiAgfVxuICAjYWRkTGlzdGVuZXIodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMsIGluc2VydE1vZGUgPSBcImFwcGVuZFwiKSB7XG4gICAgaWYgKG9wdGlvbnM/LnNpZ25hbD8uYWJvcnRlZCkgcmV0dXJuO1xuICAgIGZvciAoY29uc3QgaG9vayBvZiB0aGlzLiNob29rTGlzdGVuZXJzLmdldChcIm5ld0xpc3RlbmVyXCIpLnNsaWNlKCkpIGhvb2sodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpO1xuICAgIGlmICh0eXBlID09PSBcIipcIikgdGhpcy4jdHlwZWxlc3NMaXN0ZW5lcnMuYWRkKGxpc3RlbmVyKTtcbiAgICBpZiAoaW5zZXJ0TW9kZSA9PT0gXCJwcmVwZW5kXCIpIHRoaXMuI2xpc3RlbmVycy5wcmVwZW5kKHR5cGUsIGxpc3RlbmVyKTtcbiAgICBlbHNlIHRoaXMuI2xpc3RlbmVycy5hcHBlbmQodHlwZSwgbGlzdGVuZXIpO1xuICAgIGlmIChvcHRpb25zKSB7XG4gICAgICB0aGlzLiNsaXN0ZW5lck9wdGlvbnMuc2V0KGxpc3RlbmVyLCBvcHRpb25zKTtcbiAgICAgIGlmIChvcHRpb25zLnNpZ25hbCkge1xuICAgICAgICBjb25zdCB7IHNpZ25hbCB9ID0gb3B0aW9ucztcbiAgICAgICAgY29uc3Qgb25BYm9ydCA9ICgpID0+IHtcbiAgICAgICAgICB0aGlzLnJlbW92ZUxpc3RlbmVyKHR5cGUsIGxpc3RlbmVyKTtcbiAgICAgICAgfTtcbiAgICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBvbkFib3J0LCB7IG9uY2U6IHRydWUgfSk7XG4gICAgICAgIHRoaXMuI2xpc3RlbmVyQWJvcnRDbGVhbnVwcy5zZXQobGlzdGVuZXIsICgpID0+IHtcbiAgICAgICAgICBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIG9uQWJvcnQpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgI3Byb3h5RXZlbnQoZXZlbnQpIHtcbiAgICBjb25zdCB7IHN0b3BQcm9wYWdhdGlvbiB9ID0gZXZlbnQ7XG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uID0gKCkgPT4ge1xuICAgICAgZXZlbnRba1Byb3BhZ2F0aW9uU3RvcHBlZF0gPSB0aGlzO1xuICAgICAgc3RvcFByb3BhZ2F0aW9uLmNhbGwoZXZlbnQpO1xuICAgIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGV2ZW50LFxuICAgICAgcmV2b2tlKCkge1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24gPSBzdG9wUHJvcGFnYXRpb247XG4gICAgICB9XG4gICAgfTtcbiAgfVxuICAjY2FsbExpc3RlbmVyKGV2ZW50LCBsaXN0ZW5lcikge1xuICAgIGZvciAoY29uc3QgaG9vayBvZiB0aGlzLiNob29rTGlzdGVuZXJzLmdldChcImJlZm9yZUVtaXRcIikuc2xpY2UoKSkgaWYgKGhvb2soZXZlbnQpID09PSBmYWxzZSkgcmV0dXJuO1xuICAgIGNvbnN0IHJldHVyblZhbHVlID0gbGlzdGVuZXIuY2FsbCh0aGlzLCBldmVudCk7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMuI2xpc3RlbmVyT3B0aW9ucy5nZXQobGlzdGVuZXIpO1xuICAgIGlmIChvcHRpb25zPy5vbmNlKSB7XG4gICAgICBjb25zdCB0eXBlID0gdGhpcy4jaXNUeXBlbGVzc0xpc3RlbmVyKGxpc3RlbmVyKSA/IFwiKlwiIDogZXZlbnQudHlwZTtcbiAgICAgIGlmICh0aGlzLiNkZWxldGVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcikpIGZvciAoY29uc3QgaG9vayBvZiB0aGlzLiNob29rTGlzdGVuZXJzLmdldChcInJlbW92ZUxpc3RlbmVyXCIpLnNsaWNlKCkpIGhvb2sodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpO1xuICAgIH1cbiAgICByZXR1cm4gcmV0dXJuVmFsdWU7XG4gIH1cbiAgLyoqXG4gICogUmV0dXJuIGEgbGlzdCBvZiBhbGwgZXZlbnQgbGlzdGVuZXJzIHJlbGV2YW50IGZvciB0aGUgZ2l2ZW4gZXZlbnQgdHlwZS5cbiAgKiBUaGlzIGluY2x1ZGVzIHRoZSBleHBsaWNpdCBldmVudCBsaXN0ZW5lcnMgYW5kIGFsc28gdHlwZWxlc3MgZXZlbnQgbGlzdGVuZXJzLlxuICAqXG4gICogQG5vdGUgU25hcHNob3QgdGhlIG1hdGNoaW5nIGxpc3RlbmVycyBiZWZvcmUgeWllbGRpbmcuIExpc3RlbmVycyBjYW4gYWRkIG9yXG4gICogcmVtb3ZlIG90aGVyIGxpc3RlbmVycyBkdXJpbmcgZW1pc3Npb24gKGUuZy4gYGVhcmx5T25gIHVuc2hpZnRzIGAjbGlzdGApLFxuICAqIHdoaWNoIHdvdWxkIG90aGVyd2lzZSBzaGlmdCB0aGUgbGl2ZSBpdGVyYXRvciBhbmQgcmUteWllbGQgcHJpb3IgZW50cmllcy5cbiAgKi9cbiAgKiNtYXRjaExpc3RlbmVycyh0eXBlKSB7XG4gICAgY29uc3Qgc25hcHNob3QgPSBbXTtcbiAgICBmb3IgKGNvbnN0IFtrZXksIGxpc3RlbmVyXSBvZiB0aGlzLiNsaXN0ZW5lcnMpIGlmIChrZXkgPT09IFwiKlwiIHx8IGtleSA9PT0gdHlwZSkgc25hcHNob3QucHVzaChsaXN0ZW5lcik7XG4gICAgeWllbGQqIHNuYXBzaG90O1xuICB9XG4gICNpc1R5cGVsZXNzTGlzdGVuZXIobGlzdGVuZXIpIHtcbiAgICByZXR1cm4gdGhpcy4jdHlwZWxlc3NMaXN0ZW5lcnMuaGFzKGxpc3RlbmVyKTtcbiAgfVxufTtcblxuLy8gc3JjL2Jyb3dzZXIvdXRpbHMvd29ya2VyQ2hhbm5lbC50c1xuaW1wb3J0IHsgaXNPYmplY3QgfSBmcm9tICcuLi9jb3JlL3V0aWxzL2ludGVybmFsL2lzT2JqZWN0Lm1qcyc7XG52YXIgU1VQUE9SVFNfU0VSVklDRV9XT1JLRVIgPSBzdXBwb3J0c1NlcnZpY2VXb3JrZXIoKTtcbnZhciBXb3JrZXJFdmVudCA9IGNsYXNzIGV4dGVuZHMgVHlwZWRFdmVudCB7XG4gICN3b3JrZXJFdmVudDtcbiAgY29uc3RydWN0b3Iod29ya2VyRXZlbnQpIHtcbiAgICBjb25zdCB0eXBlID0gd29ya2VyRXZlbnQuZGF0YS50eXBlO1xuICAgIGNvbnN0IGRhdGEgPSB3b3JrZXJFdmVudC5kYXRhLnBheWxvYWQ7XG4gICAgc3VwZXIoXG4gICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIFRyb3VibGVzb21lIGBUeXBlZEV2ZW50YCBleHRlbnNpb24uXG4gICAgICB0eXBlLFxuICAgICAgeyBkYXRhIH1cbiAgICApO1xuICAgIHRoaXMuI3dvcmtlckV2ZW50ID0gd29ya2VyRXZlbnQ7XG4gIH1cbiAgZ2V0IHBvcnRzKCkge1xuICAgIHJldHVybiB0aGlzLiN3b3JrZXJFdmVudC5wb3J0cztcbiAgfVxuICAvKipcbiAgICogUmVwbHkgZGlyZWN0bHkgdG8gdGhpcyBldmVudCB1c2luZyBpdHMgYE1lc3NhZ2VQb3J0YC5cbiAgICovXG4gIHBvc3RNZXNzYWdlKHR5cGUsIC4uLnJlc3QpIHtcbiAgICB0aGlzLiN3b3JrZXJFdmVudC5wb3J0c1swXS5wb3N0TWVzc2FnZShcbiAgICAgIHsgdHlwZSwgZGF0YTogcmVzdFswXSB9LFxuICAgICAgeyB0cmFuc2ZlcjogcmVzdFsxXSB9XG4gICAgKTtcbiAgfVxufTtcbnZhciBXb3JrZXJDaGFubmVsID0gY2xhc3MgZXh0ZW5kcyBFbWl0dGVyMiB7XG4gICNnZXRXb3JrZXI7XG4gICNjb250cm9sbGVyO1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgc3VwZXIoKTtcbiAgICBpbnZhcmlhbnQoXG4gICAgICBTVVBQT1JUU19TRVJWSUNFX1dPUktFUixcbiAgICAgIFwiRmFpbGVkIHRvIG9wZW4gYSBXb3JrZXJDaGFubmVsOiBTZXJ2aWNlIFdvcmtlciBpcyBub3Qgc3VwcG9ydGVkIGluIHRoaXMgZW52aXJvbm1lbnQuXCJcbiAgICApO1xuICAgIHRoaXMuI2dldFdvcmtlciA9IG9wdGlvbnMuZ2V0V29ya2VyO1xuICAgIHRoaXMuI2NvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgbmF2aWdhdG9yLnNlcnZpY2VXb3JrZXIuYWRkRXZlbnRMaXN0ZW5lcihcbiAgICAgIFwibWVzc2FnZVwiLFxuICAgICAgYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IHdvcmtlciA9IGF3YWl0IHRoaXMuI2dldFdvcmtlcigpO1xuICAgICAgICBpZiAoZXZlbnQuc291cmNlICE9IG51bGwgJiYgZXZlbnQuc291cmNlICE9PSB3b3JrZXIpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGV2ZW50LmRhdGEgJiYgaXNPYmplY3QoZXZlbnQuZGF0YSkgJiYgXCJ0eXBlXCIgaW4gZXZlbnQuZGF0YSkge1xuICAgICAgICAgIHRoaXMuZW1pdChuZXcgV29ya2VyRXZlbnQoZXZlbnQpKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgc2lnbmFsOiB0aGlzLiNjb250cm9sbGVyLnNpZ25hbFxuICAgICAgfVxuICAgICk7XG4gIH1cbiAgLyoqXG4gICAqIFNlbmQgZGF0YSB0byB0aGUgU2VydmljZSBXb3JrZXIgY29udHJvbGxpbmcgdGhpcyBjbGllbnQuXG4gICAqIFRoaXMgdHJpZ2dlcnMgdGhlIGBtZXNzYWdlYCBldmVudCBsaXN0ZW5lciBvbiBTZXJ2aWNlV29ya2VyR2xvYmFsU2NvcGUuXG4gICAqL1xuICBwb3N0TWVzc2FnZSh0eXBlKSB7XG4gICAgaW52YXJpYW50KFxuICAgICAgU1VQUE9SVFNfU0VSVklDRV9XT1JLRVIsXG4gICAgICBcIkZhaWxlZCB0byBwb3N0IG1lc3NhZ2Ugb24gYSBXb3JrZXJDaGFubmVsOiB0aGUgU2VydmljZSBXb3JrZXIgQVBJIGlzIHVuYXZhaWxhYmxlIGluIHRoaXMgZW52aXJvbm1lbnQuIFRoaXMgaXMgbGlrZWx5IGFuIGlzc3VlIHdpdGggTVNXLiBQbGVhc2UgcmVwb3J0IGl0IG9uIEdpdEh1YjogaHR0cHM6Ly9naXRodWIuY29tL21zd2pzL21zdy9pc3N1ZXNcIlxuICAgICk7XG4gICAgdGhpcy4jZ2V0V29ya2VyKCkudGhlbigod29ya2VyKSA9PiB7XG4gICAgICB3b3JrZXIucG9zdE1lc3NhZ2UodHlwZSk7XG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFRlcm1pbmFsIHRlYXJkb3duLiBSZW1vdmVzIHRoZSBgbmF2aWdhdG9yLnNlcnZpY2VXb3JrZXJgIG1lc3NhZ2UgbGlzdGVuZXJcbiAgICogYW5kIGFsbCBlbWl0dGVyIHN1YnNjcmlwdGlvbnMuIFRoZSBjaGFubmVsIGlzIG5vdCB1c2FibGUgYWZ0ZXJ3YXJkcy5cbiAgICovXG4gIHRlcm1pbmF0ZSgpIHtcbiAgICB0aGlzLiNjb250cm9sbGVyLmFib3J0KCk7XG4gICAgdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcbiAgfVxufTtcblxuLy8gc3JjL2Jyb3dzZXIvdXRpbHMvcHJ1bmVHZXRSZXF1ZXN0Qm9keS50c1xuZnVuY3Rpb24gcHJ1bmVHZXRSZXF1ZXN0Qm9keShyZXF1ZXN0KSB7XG4gIGlmIChbXCJIRUFEXCIsIFwiR0VUXCJdLmluY2x1ZGVzKHJlcXVlc3QubWV0aG9kKSkge1xuICAgIHJldHVybiB2b2lkIDA7XG4gIH1cbiAgcmV0dXJuIHJlcXVlc3QuYm9keTtcbn1cblxuLy8gc3JjL2Jyb3dzZXIvdXRpbHMvZGVzZXJpYWxpemVSZXF1ZXN0LnRzXG5mdW5jdGlvbiBkZXNlcmlhbGl6ZVJlcXVlc3Qoc2VyaWFsaXplZFJlcXVlc3QpIHtcbiAgcmV0dXJuIG5ldyBSZXF1ZXN0KHNlcmlhbGl6ZWRSZXF1ZXN0LnVybCwge1xuICAgIC4uLnNlcmlhbGl6ZWRSZXF1ZXN0LFxuICAgIGJvZHk6IHBydW5lR2V0UmVxdWVzdEJvZHkoc2VyaWFsaXplZFJlcXVlc3QpXG4gIH0pO1xufVxuXG4vLyBzcmMvYnJvd3Nlci91dGlscy92YWxpZGF0ZS13b3JrZXItc2NvcGUudHNcbmltcG9ydCB7IGRldlV0aWxzIGFzIGRldlV0aWxzMiB9IGZyb20gJy4uL2NvcmUvdXRpbHMvaW50ZXJuYWwvZGV2VXRpbHMubWpzJztcbmZ1bmN0aW9uIHZhbGlkYXRlV29ya2VyU2NvcGUocmVnaXN0cmF0aW9uKSB7XG4gIGlmICghbG9jYXRpb24uaHJlZi5zdGFydHNXaXRoKHJlZ2lzdHJhdGlvbi5zY29wZSkpIHtcbiAgICBkZXZVdGlsczIud2FybihcbiAgICAgIGBDYW5ub3QgaW50ZXJjZXB0IHJlcXVlc3RzIG9uIHRoaXMgcGFnZSBiZWNhdXNlIGl0J3Mgb3V0c2lkZSBvZiB0aGUgd29ya2VyJ3Mgc2NvcGUgKFwiJHtyZWdpc3RyYXRpb24uc2NvcGV9XCIpLiBJZiB5b3Ugd2lzaCB0byBtb2NrIEFQSSByZXF1ZXN0cyBvbiB0aGlzIHBhZ2UsIHlvdSBtdXN0IHJlc29sdmUgdGhpcyBzY29wZSBpc3N1ZS5cblxuLSAoUmVjb21tZW5kZWQpIFJlZ2lzdGVyIHRoZSB3b3JrZXIgYXQgdGhlIHJvb3QgbGV2ZWwgKFwiL1wiKSBvZiB5b3VyIGFwcGxpY2F0aW9uLlxuLSBTZXQgdGhlIFwiU2VydmljZS1Xb3JrZXItQWxsb3dlZFwiIHJlc3BvbnNlIGhlYWRlciB0byBhbGxvdyBvdXQtb2Ytc2NvcGUgd29ya2Vycy5gXG4gICAgKTtcbiAgfVxufVxuXG4vLyBzcmMvYnJvd3Nlci91dGlscy9zaG91bGQtaW52YWxpZGF0ZS13b3JrZXIudHNcbmZ1bmN0aW9uIHNob3VsZEludmFsaWRhdGVXb3JrZXIocHJldk9wdGlvbnMsIG5leHRPcHRpb25zKSB7XG4gIHJldHVybiBwcmV2T3B0aW9ucy5maW5kV29ya2VyICE9PSBuZXh0T3B0aW9ucy5maW5kV29ya2VyIHx8IHByZXZPcHRpb25zLnNlcnZpY2VXb3JrZXIudXJsICE9PSBuZXh0T3B0aW9ucy5zZXJ2aWNlV29ya2VyLnVybCB8fCBKU09OLnN0cmluZ2lmeShwcmV2T3B0aW9ucy5zZXJ2aWNlV29ya2VyLm9wdGlvbnMpICE9PSBKU09OLnN0cmluZ2lmeShuZXh0T3B0aW9ucy5zZXJ2aWNlV29ya2VyLm9wdGlvbnMpO1xufVxuXG4vLyBzcmMvYnJvd3Nlci9zb3VyY2VzL3NlcnZpY2Utd29ya2VyLXNvdXJjZS50c1xudmFyIFNlcnZpY2VXb3JrZXJTb3VyY2UgPSBjbGFzcyBfU2VydmljZVdvcmtlclNvdXJjZSBleHRlbmRzIE5ldHdvcmtTb3VyY2Uge1xuICBzdGF0aWMgI2N1cnJlbnQ7XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBuZXcgU2VydmljZSBXb3JrZXIgc291cmNlIG9yIHJldXNlIGFuIGV4aXN0aW5nIG9uZS5cbiAgICogVGhlc2Ugc291cmNlcyBhY3QgYXMgYSBzaW5nbGV0b24gYW5kIG9ubHkgZ2V0IHJlY3JlYXRlZCBpZiB0aGUgb3B0aW9ucyBjaGFuZ2UuXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgZnJvbShvcHRpb25zKSB7XG4gICAgaWYgKF9TZXJ2aWNlV29ya2VyU291cmNlLiNjdXJyZW50ID09IG51bGwpIHtcbiAgICAgIF9TZXJ2aWNlV29ya2VyU291cmNlLiNjdXJyZW50ID0gbmV3IF9TZXJ2aWNlV29ya2VyU291cmNlKG9wdGlvbnMpO1xuICAgIH0gZWxzZSBpZiAoc2hvdWxkSW52YWxpZGF0ZVdvcmtlcihfU2VydmljZVdvcmtlclNvdXJjZS4jY3VycmVudC4jb3B0aW9ucywgb3B0aW9ucykpIHtcbiAgICAgIGF3YWl0IF9TZXJ2aWNlV29ya2VyU291cmNlLiNjdXJyZW50LnRlcm1pbmF0ZSgpO1xuICAgICAgX1NlcnZpY2VXb3JrZXJTb3VyY2UuI2N1cnJlbnQgPSBuZXcgX1NlcnZpY2VXb3JrZXJTb3VyY2Uob3B0aW9ucyk7XG4gICAgfVxuICAgIHJldHVybiBfU2VydmljZVdvcmtlclNvdXJjZS4jY3VycmVudDtcbiAgfVxuICAjb3B0aW9ucztcbiAgI2ZyYW1lcztcbiAgI2NoYW5uZWw7XG4gICNsaXN0ZW5lckNvbnRyb2xsZXI7XG4gICNjbGllbnRQcm9taXNlO1xuICAja2VlcEFsaXZlSW50ZXJ2YWw7XG4gICNzdG9wcGVkQXQ7XG4gIHdvcmtlclByb21pc2U7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICBzdXBlcigpO1xuICAgIGludmFyaWFudChcbiAgICAgIHN1cHBvcnRzU2VydmljZVdvcmtlcigpLFxuICAgICAgXCJGYWlsZWQgdG8gdXNlIFNlcnZpY2UgV29ya2VyIGFzIHRoZSBuZXR3b3JrIHNvdXJjZTogdGhlIFNlcnZpY2UgV29ya2VyIEFQSSBpcyBub3Qgc3VwcG9ydGVkIGluIHRoaXMgZW52aXJvbm1lbnRcIlxuICAgICk7XG4gICAgdGhpcy4jb3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy4jZnJhbWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICB0aGlzLndvcmtlclByb21pc2UgPSBuZXcgRGVmZXJyZWRQcm9taXNlMigpO1xuICAgIHRoaXMuI2NoYW5uZWwgPSBuZXcgV29ya2VyQ2hhbm5lbCh7XG4gICAgICBnZXRXb3JrZXI6ICgpID0+IHRoaXMud29ya2VyUHJvbWlzZS50aGVuKChbd29ya2VyXSkgPT4gd29ya2VyKVxuICAgIH0pO1xuICB9XG4gIGFzeW5jIGVuYWJsZSgpIHtcbiAgICBpZiAodGhpcy53b3JrZXJQcm9taXNlLnN0YXRlID09PSBcImZ1bGZpbGxlZFwiICYmIHR5cGVvZiB0aGlzLiNzdG9wcGVkQXQgPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgZGV2VXRpbHMzLndhcm4oXG4gICAgICAgICdGb3VuZCBhIHJlZHVuZGFudCBcIndvcmtlci5zdGFydCgpXCIgY2FsbC4gTm90ZSB0aGF0IHN0YXJ0aW5nIHRoZSB3b3JrZXIgd2hpbGUgbW9ja2luZyBpcyBhbHJlYWR5IGVuYWJsZWQgd2lsbCBoYXZlIG5vIGVmZmVjdC4gQ29uc2lkZXIgcmVtb3ZpbmcgdGhpcyBcIndvcmtlci5zdGFydCgpXCIgY2FsbC4nXG4gICAgICApO1xuICAgICAgcmV0dXJuIHRoaXMud29ya2VyUHJvbWlzZS50aGVuKChbLCByZWdpc3RyYXRpb24yXSkgPT4gcmVnaXN0cmF0aW9uMik7XG4gICAgfVxuICAgIHRoaXMuI3N0b3BwZWRBdCA9IHZvaWQgMDtcbiAgICB0aGlzLiNjaGFubmVsLnJlbW92ZUFsbExpc3RlbmVycygpO1xuICAgIHRoaXMuI2ZyYW1lcy5jbGVhcigpO1xuICAgIHRoaXMuI2xpc3RlbmVyQ29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBjb25zdCBbd29ya2VyLCByZWdpc3RyYXRpb25dID0gYXdhaXQgdGhpcy4jc3RhcnRXb3JrZXIoKTtcbiAgICBpZiAod29ya2VyLnN0YXRlICE9PSBcImFjdGl2YXRlZFwiKSB7XG4gICAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgY29uc3QgYWN0aXZhdGlvblByb21pc2UgPSBuZXcgRGVmZXJyZWRQcm9taXNlMigpO1xuICAgICAgYWN0aXZhdGlvblByb21pc2UudGhlbigoKSA9PiBjb250cm9sbGVyLmFib3J0KCkpO1xuICAgICAgd29ya2VyLmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgICAgIFwic3RhdGVjaGFuZ2VcIixcbiAgICAgICAgKCkgPT4ge1xuICAgICAgICAgIGlmICh3b3JrZXIuc3RhdGUgPT09IFwiYWN0aXZhdGVkXCIpIHtcbiAgICAgICAgICAgIGFjdGl2YXRpb25Qcm9taXNlLnJlc29sdmUoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgICBhd2FpdCBhY3RpdmF0aW9uUHJvbWlzZTtcbiAgICB9XG4gICAgdGhpcy4jY2hhbm5lbC5wb3N0TWVzc2FnZShcIk1PQ0tfQUNUSVZBVEVcIik7XG4gICAgY29uc3QgY2xpZW50Q29uZmlybWF0aW9uUHJvbWlzZSA9IG5ldyBEZWZlcnJlZFByb21pc2UyKCk7XG4gICAgdGhpcy4jY2xpZW50UHJvbWlzZSA9IGNsaWVudENvbmZpcm1hdGlvblByb21pc2U7XG4gICAgdGhpcy4jY2hhbm5lbC5vbmNlKFwiTU9DS0lOR19FTkFCTEVEXCIsIChldmVudCkgPT4ge1xuICAgICAgY2xpZW50Q29uZmlybWF0aW9uUHJvbWlzZS5yZXNvbHZlKGV2ZW50LmRhdGEuY2xpZW50KTtcbiAgICB9KTtcbiAgICBhd2FpdCBjbGllbnRDb25maXJtYXRpb25Qcm9taXNlO1xuICAgIGlmICghdGhpcy4jb3B0aW9ucy5xdWlldCkge1xuICAgICAgdGhpcy4jcHJpbnRTdGFydE1lc3NhZ2UoKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlZ2lzdHJhdGlvbjtcbiAgfVxuICBkaXNhYmxlKCkge1xuICAgIGlmICh0eXBlb2YgdGhpcy4jc3RvcHBlZEF0ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBkZXZVdGlsczMud2FybihcbiAgICAgICAgYEZvdW5kIGEgcmVkdW5kYW50IFwid29ya2VyLnN0b3AoKVwiIGNhbGwuIE5vdGljZSB0aGF0IHN0b3BwaW5nIHRoZSB3b3JrZXIgYWZ0ZXIgaXQgaGFzIGFscmVhZHkgYmVlbiBzdG9wcGVkIGhhcyBubyBlZmZlY3QuIENvbnNpZGVyIHJlbW92aW5nIHRoaXMgXCJ3b3JrZXIuc3RvcCgpXCIgY2FsbC5gXG4gICAgICApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLiNzdG9wcGVkQXQgPSBEYXRlLm5vdygpO1xuICAgIHRoaXMuI2xpc3RlbmVyQ29udHJvbGxlcj8uYWJvcnQoKTtcbiAgICB0aGlzLiNsaXN0ZW5lckNvbnRyb2xsZXIgPSB2b2lkIDA7XG4gICAgdGhpcy4jY2hhbm5lbC5wb3N0TWVzc2FnZShcIkNMSUVOVF9DTE9TRURcIik7XG4gICAgaWYgKCF0aGlzLiNvcHRpb25zLnF1aWV0KSB7XG4gICAgICB0aGlzLiNwcmludFN0b3BNZXNzYWdlKCk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBUZXJtaW5hbCB0ZWFyZG93bi4gVW5yZWdpc3RlcnMgdGhlIFNlcnZpY2UgV29ya2VyLCB0ZWFycyBkb3duIHRoZSBjaGFubmVsLFxuICAgKiBhbmQgY2xlYXJzIHRpbWVycy4gQ2FsbGVkIHdoZW4gdGhlIHNpbmdsZXRvbiBpcyBiZWluZyByZXBsYWNlZCB3aXRoIG9uZVxuICAgKiB0aGF0IGhhcyBkaWZmZXJlbnQgb3B0aW9ucy4gVGhlIGluc3RhbmNlIGlzIG5vdCB1c2FibGUgYWZ0ZXJ3YXJkcy5cbiAgICovXG4gIGFzeW5jIHRlcm1pbmF0ZSgpIHtcbiAgICBpZiAodGhpcy4ja2VlcEFsaXZlSW50ZXJ2YWwgIT0gbnVsbCkge1xuICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLiNrZWVwQWxpdmVJbnRlcnZhbCk7XG4gICAgICB0aGlzLiNrZWVwQWxpdmVJbnRlcnZhbCA9IHZvaWQgMDtcbiAgICB9XG4gICAgdGhpcy4jZnJhbWVzLmNsZWFyKCk7XG4gICAgdGhpcy4jY2hhbm5lbC50ZXJtaW5hdGUoKTtcbiAgICB0aGlzLiNsaXN0ZW5lckNvbnRyb2xsZXI/LmFib3J0KCk7XG4gICAgdGhpcy4jbGlzdGVuZXJDb250cm9sbGVyID0gdm9pZCAwO1xuICAgIGlmICh0aGlzLndvcmtlclByb21pc2Uuc3RhdGUgPT09IFwiZnVsZmlsbGVkXCIpIHtcbiAgICAgIGNvbnN0IFssIHJlZ2lzdHJhdGlvbl0gPSBhd2FpdCB0aGlzLndvcmtlclByb21pc2U7XG4gICAgICBhd2FpdCByZWdpc3RyYXRpb24udW5yZWdpc3RlcigpO1xuICAgIH1cbiAgICBpZiAoX1NlcnZpY2VXb3JrZXJTb3VyY2UuI2N1cnJlbnQgPT09IHRoaXMpIHtcbiAgICAgIF9TZXJ2aWNlV29ya2VyU291cmNlLiNjdXJyZW50ID0gdm9pZCAwO1xuICAgIH1cbiAgfVxuICBhc3luYyAjc3RhcnRXb3JrZXIoKSB7XG4gICAgaWYgKHRoaXMuI2tlZXBBbGl2ZUludGVydmFsKSB7XG4gICAgICBjbGVhckludGVydmFsKHRoaXMuI2tlZXBBbGl2ZUludGVydmFsKTtcbiAgICB9XG4gICAgY29uc3Qgd29ya2VyVXJsID0gdGhpcy4jb3B0aW9ucy5zZXJ2aWNlV29ya2VyLnVybDtcbiAgICBjb25zdCBbd29ya2VyLCByZWdpc3RyYXRpb25dID0gYXdhaXQgZ2V0V29ya2VySW5zdGFuY2UoXG4gICAgICB3b3JrZXJVcmwsXG4gICAgICB0aGlzLiNvcHRpb25zLnNlcnZpY2VXb3JrZXIub3B0aW9ucyxcbiAgICAgIHRoaXMuI29wdGlvbnMuZmluZFdvcmtlciB8fCB0aGlzLiNkZWZhdWx0RmluZFdvcmtlclxuICAgICk7XG4gICAgaWYgKHdvcmtlciA9PSBudWxsKSB7XG4gICAgICBjb25zdCBtaXNzaW5nV29ya2VyTWVzc2FnZSA9IHRoaXMuI29wdGlvbnM/LmZpbmRXb3JrZXIgPyBkZXZVdGlsczMuZm9ybWF0TWVzc2FnZShcbiAgICAgICAgYEZhaWxlZCB0byBsb2NhdGUgdGhlIFNlcnZpY2UgV29ya2VyIHJlZ2lzdHJhdGlvbiB1c2luZyBhIGN1c3RvbSBcImZpbmRXb3JrZXJcIiBwcmVkaWNhdGUuXG5cblBsZWFzZSBlbnN1cmUgdGhhdCB0aGUgY3VzdG9tIHByZWRpY2F0ZSBwcm9wZXJseSBsb2NhdGVzIHRoZSBTZXJ2aWNlIFdvcmtlciByZWdpc3RyYXRpb24gYXQgXCIlc1wiLlxuTW9yZSBkZXRhaWxzOiBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL3NldHVwLXdvcmtlci9zdGFydCNmaW5kd29ya2VyXG4gICAgIGAsXG4gICAgICAgIHdvcmtlclVybFxuICAgICAgKSA6IGRldlV0aWxzMy5mb3JtYXRNZXNzYWdlKFxuICAgICAgICBgRmFpbGVkIHRvIGxvY2F0ZSB0aGUgU2VydmljZSBXb3JrZXIgcmVnaXN0cmF0aW9uLlxuXG5UaGlzIG1vc3QgbGlrZWx5IG1lYW5zIHRoYXQgdGhlIHdvcmtlciBzY3JpcHQgVVJMIFwiJXNcIiBjYW5ub3QgcmVzb2x2ZSBhZ2FpbnN0IHRoZSBhY3R1YWwgcHVibGljIGhvc3RuYW1lICglcykuIFRoaXMgbWF5IGhhcHBlbiBpZiB5b3VyIGFwcGxpY2F0aW9uIHJ1bnMgYmVoaW5kIGEgcHJveHksIG9yIGhhcyBhIGR5bmFtaWMgaG9zdG5hbWUuXG5cblBsZWFzZSBjb25zaWRlciB1c2luZyBhIGN1c3RvbSBcInNlcnZpY2VXb3JrZXIudXJsXCIgb3B0aW9uIHRvIHBvaW50IHRvIHRoZSBhY3R1YWwgd29ya2VyIHNjcmlwdCBsb2NhdGlvbiwgb3IgYSBjdXN0b20gXCJmaW5kV29ya2VyXCIgb3B0aW9uIHRvIHJlc29sdmUgdGhlIFNlcnZpY2UgV29ya2VyIHJlZ2lzdHJhdGlvbiBtYW51YWxseS4gTW9yZSBkZXRhaWxzOiBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL3NldHVwLXdvcmtlci9zdGFydGAsXG4gICAgICAgIHdvcmtlclVybCxcbiAgICAgICAgbG9jYXRpb24uaG9zdFxuICAgICAgKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihtaXNzaW5nV29ya2VyTWVzc2FnZSk7XG4gICAgfVxuICAgIGlmICh0aGlzLndvcmtlclByb21pc2Uuc3RhdGUgPT09IFwicGVuZGluZ1wiKSB7XG4gICAgICB0aGlzLndvcmtlclByb21pc2UucmVzb2x2ZShbd29ya2VyLCByZWdpc3RyYXRpb25dKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy53b3JrZXJQcm9taXNlID0gbmV3IERlZmVycmVkUHJvbWlzZTIoKHJlc29sdmUpID0+IHtcbiAgICAgICAgcmVzb2x2ZShbd29ya2VyLCByZWdpc3RyYXRpb25dKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICB0aGlzLiNjaGFubmVsLm9uKFwiUkVRVUVTVFwiLCB0aGlzLiNoYW5kbGVSZXF1ZXN0LmJpbmQodGhpcykpO1xuICAgIHRoaXMuI2NoYW5uZWwub24oXCJSRVNQT05TRVwiLCB0aGlzLiNoYW5kbGVSZXNwb25zZS5iaW5kKHRoaXMpKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcbiAgICAgIFwiYmVmb3JldW5sb2FkXCIsXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmICh3b3JrZXIuc3RhdGUgIT09IFwicmVkdW5kYW50XCIpIHtcbiAgICAgICAgICB0aGlzLiNjaGFubmVsLnBvc3RNZXNzYWdlKFwiQ0xJRU5UX0NMT1NFRFwiKTtcbiAgICAgICAgfVxuICAgICAgICBjbGVhckludGVydmFsKHRoaXMuI2tlZXBBbGl2ZUludGVydmFsKTtcbiAgICAgICAgd2luZG93LnBvc3RNZXNzYWdlKHsgdHlwZTogXCJtc3cvd29ya2VyOnN0b3BcIiB9KTtcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHNpZ25hbDogdGhpcy4jbGlzdGVuZXJDb250cm9sbGVyPy5zaWduYWxcbiAgICAgIH1cbiAgICApO1xuICAgIGF3YWl0IHRoaXMuI2NoZWNrV29ya2VySW50ZWdyaXR5KCkuY2F0Y2goKGVycm9yMikgPT4ge1xuICAgICAgZGV2VXRpbHMzLmVycm9yKFxuICAgICAgICBcIkVycm9yIHdoaWxlIGNoZWNraW5nIHRoZSB3b3JrZXIgc2NyaXB0IGludGVncml0eS4gUGxlYXNlIHJlcG9ydCB0aGlzIG9uIEdpdEh1YiAoaHR0cHM6Ly9naXRodWIuY29tL21zd2pzL21zdy9pc3N1ZXMpIGFuZCBpbmNsdWRlIHRoZSBvcmlnaW5hbCBlcnJvciBiZWxvdy5cIlxuICAgICAgKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IyKTtcbiAgICB9KTtcbiAgICB0aGlzLiNrZWVwQWxpdmVJbnRlcnZhbCA9IHdpbmRvdy5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICB0aGlzLiNjaGFubmVsLnBvc3RNZXNzYWdlKFwiS0VFUEFMSVZFX1JFUVVFU1RcIik7XG4gICAgfSwgNWUzKTtcbiAgICBpZiAoIXRoaXMuI29wdGlvbnMucXVpZXQpIHtcbiAgICAgIHZhbGlkYXRlV29ya2VyU2NvcGUocmVnaXN0cmF0aW9uKTtcbiAgICB9XG4gICAgcmV0dXJuIFt3b3JrZXIsIHJlZ2lzdHJhdGlvbl07XG4gIH1cbiAgYXN5bmMgI2hhbmRsZVJlcXVlc3QoZXZlbnQpIHtcbiAgICBpZiAodGhpcy4jc3RvcHBlZEF0ICYmIGV2ZW50LmRhdGEuaW50ZXJjZXB0ZWRBdCA+IHRoaXMuI3N0b3BwZWRBdCkge1xuICAgICAgcmV0dXJuIGV2ZW50LnBvc3RNZXNzYWdlKFwiUEFTU1RIUk9VR0hcIik7XG4gICAgfVxuICAgIGNvbnN0IHJlcXVlc3QgPSBkZXNlcmlhbGl6ZVJlcXVlc3QoZXZlbnQuZGF0YSk7XG4gICAgUmVxdWVzdEhhbmRsZXIuY2FjaGUuc2V0KHJlcXVlc3QsIHJlcXVlc3QuY2xvbmUoKSk7XG4gICAgY29uc3QgZnJhbWUgPSBuZXcgU2VydmljZVdvcmtlckh0dHBOZXR3b3JrRnJhbWUoe1xuICAgICAgZXZlbnQsXG4gICAgICByZXF1ZXN0XG4gICAgfSk7XG4gICAgdGhpcy4jZnJhbWVzLnNldChldmVudC5kYXRhLmlkLCBmcmFtZSk7XG4gICAgYXdhaXQgdGhpcy5xdWV1ZShmcmFtZSk7XG4gIH1cbiAgYXN5bmMgI2hhbmRsZVJlc3BvbnNlKGV2ZW50KSB7XG4gICAgY29uc3QgeyByZXF1ZXN0LCByZXNwb25zZSwgaXNNb2NrZWRSZXNwb25zZSB9ID0gZXZlbnQuZGF0YTtcbiAgICBjb25zdCBmcmFtZSA9IHRoaXMuI2ZyYW1lcy5nZXQocmVxdWVzdC5pZCk7XG4gICAgaWYgKHJlc3BvbnNlLnR5cGU/LmluY2x1ZGVzKFwib3BhcXVlXCIpKSB7XG4gICAgICB0aGlzLiNmcmFtZXMuZGVsZXRlKHJlcXVlc3QuaWQpO1xuICAgICAgZnJhbWU/LmV2ZW50cy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy4jZnJhbWVzLmRlbGV0ZShyZXF1ZXN0LmlkKTtcbiAgICBpZiAoZnJhbWUgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBmZXRjaFJlcXVlc3QgPSBkZXNlcmlhbGl6ZVJlcXVlc3QocmVxdWVzdCk7XG4gICAgY29uc3QgZmV0Y2hSZXNwb25zZSA9IHJlc3BvbnNlLnN0YXR1cyA9PT0gMCA/IFJlc3BvbnNlLmVycm9yKCkgOiBuZXcgRmV0Y2hSZXNwb25zZShcbiAgICAgIC8qKlxuICAgICAgICogUmVzcG9uc2VzIG1heSBiZSBzdHJlYW1zIGhlcmUsIGJ1dCB3aGVuIHdlIGNyZWF0ZSBhIHJlc3BvbnNlIG9iamVjdFxuICAgICAgICogd2l0aCBudWxsLWJvZHkgc3RhdHVzIGNvZGVzLCBsaWtlIDIwNCwgMjA1LCAzMDQgUmVzcG9uc2Ugd2lsbFxuICAgICAgICogdGhyb3cgd2hlbiBwYXNzZWQgYSBub24tbnVsbCBib2R5LCBzbyBlbnN1cmUgaXQncyBudWxsIGhlcmVcbiAgICAgICAqIGZvciB0aG9zZSBjb2Rlc1xuICAgICAgICovXG4gICAgICBGZXRjaFJlc3BvbnNlLmlzUmVzcG9uc2VXaXRoQm9keShyZXNwb25zZS5zdGF0dXMpID8gcmVzcG9uc2UuYm9keSA6IG51bGwsXG4gICAgICB7XG4gICAgICAgIC4uLnJlc3BvbnNlLFxuICAgICAgICAvKipcbiAgICAgICAgICogU2V0IHJlc3BvbnNlIFVSTCBpZiBpdCdzIG5vdCBzZXQgYWxyZWFkeS5cbiAgICAgICAgICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvbXN3L2lzc3Vlcy8yMDMwXG4gICAgICAgICAqIEBzZWUgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1Jlc3BvbnNlL3VybFxuICAgICAgICAgKi9cbiAgICAgICAgdXJsOiByZXF1ZXN0LnVybFxuICAgICAgfVxuICAgICk7XG4gICAgdHJ5IHtcbiAgICAgIGZyYW1lLmV2ZW50cy5lbWl0KFxuICAgICAgICBuZXcgUmVzcG9uc2VFdmVudChcbiAgICAgICAgICBpc01vY2tlZFJlc3BvbnNlID8gXCJyZXNwb25zZTptb2NrZWRcIiA6IFwicmVzcG9uc2U6YnlwYXNzXCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgcmVxdWVzdElkOiBmcmFtZS5kYXRhLmlkLFxuICAgICAgICAgICAgcmVxdWVzdDogZmV0Y2hSZXF1ZXN0LFxuICAgICAgICAgICAgcmVzcG9uc2U6IGZldGNoUmVzcG9uc2UsXG4gICAgICAgICAgICBpc01vY2tlZFJlc3BvbnNlXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICApO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBmcmFtZS5ldmVudHMucmVtb3ZlQWxsTGlzdGVuZXJzKCk7XG4gICAgfVxuICB9XG4gICNkZWZhdWx0RmluZFdvcmtlciA9ICh3b3JrZXJVcmwsIG1vY2tTZXJ2aWNlV29ya2VyVXJsKSA9PiB7XG4gICAgcmV0dXJuIHdvcmtlclVybCA9PT0gbW9ja1NlcnZpY2VXb3JrZXJVcmw7XG4gIH07XG4gIGFzeW5jICNjaGVja1dvcmtlckludGVncml0eSgpIHtcbiAgICBjb25zdCBpbnRlZ3JpdHlDaGVja1Byb21pc2UgPSBuZXcgRGVmZXJyZWRQcm9taXNlMigpO1xuICAgIHRoaXMuI2NoYW5uZWwucG9zdE1lc3NhZ2UoXCJJTlRFR1JJVFlfQ0hFQ0tfUkVRVUVTVFwiKTtcbiAgICB0aGlzLiNjaGFubmVsLm9uY2UoXCJJTlRFR1JJVFlfQ0hFQ0tfUkVTUE9OU0VcIiwgKGV2ZW50KSA9PiB7XG4gICAgICBjb25zdCB7IGNoZWNrc3VtLCBwYWNrYWdlVmVyc2lvbiB9ID0gZXZlbnQuZGF0YTtcbiAgICAgIGlmIChjaGVja3N1bSAhPT0gXCIwM2NiNjdhYzg0MTI4ZTYzZDdjZDcyMmE2ZTViN2YxZVwiKSB7XG4gICAgICAgIGRldlV0aWxzMy53YXJuKFxuICAgICAgICAgIGBUaGUgY3VycmVudGx5IHJlZ2lzdGVyZWQgU2VydmljZSBXb3JrZXIgaGFzIGJlZW4gZ2VuZXJhdGVkIGJ5IGEgZGlmZmVyZW50IHZlcnNpb24gb2YgTVNXICgke3BhY2thZ2VWZXJzaW9ufSkgYW5kIG1heSBub3QgYmUgZnVsbHkgY29tcGF0aWJsZSB3aXRoIHRoZSBpbnN0YWxsZWQgdmVyc2lvbi5cblxuSXQncyByZWNvbW1lbmRlZCB5b3UgdXBkYXRlIHlvdXIgd29ya2VyIHNjcmlwdCBieSBydW5uaW5nIHRoaXMgY29tbWFuZDpcblxuICBcXHUyMDIyIG5weCBtc3cgaW5pdCA8UFVCTElDX0RJUj5cblxuWW91IGNhbiBhbHNvIGF1dG9tYXRlIHRoaXMgcHJvY2VzcyBhbmQgbWFrZSB0aGUgd29ya2VyIHNjcmlwdCB1cGRhdGUgYXV0b21hdGljYWxseSB1cG9uIHRoZSBsaWJyYXJ5IGluc3RhbGxhdGlvbnMuIFJlYWQgbW9yZTogaHR0cHM6Ly9tc3dqcy5pby9kb2NzL2NsaS9pbml0LmBcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGludGVncml0eUNoZWNrUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGludGVncml0eUNoZWNrUHJvbWlzZTtcbiAgfVxuICBhc3luYyAjcHJpbnRTdGFydE1lc3NhZ2UoKSB7XG4gICAgaWYgKHRoaXMud29ya2VyUHJvbWlzZS5zdGF0ZSA9PT0gXCJyZWplY3RlZFwiKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGludmFyaWFudChcbiAgICAgIHRoaXMuI2NsaWVudFByb21pc2UgIT0gbnVsbCxcbiAgICAgIFwiW1NlcnZpY2VXb3JrZXJTb3VyY2VdIEZhaWxlZCB0byBwcmludCBhIHN0YXJ0IG1lc3NhZ2U6IGNsaWVudCBjb25maXJtYXRpb24gbm90IHJlY2VpdmVkXCJcbiAgICApO1xuICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IHRoaXMuI2NsaWVudFByb21pc2U7XG4gICAgY29uc3QgW3dvcmtlciwgcmVnaXN0cmF0aW9uXSA9IGF3YWl0IHRoaXMud29ya2VyUHJvbWlzZTtcbiAgICBjb25zb2xlLmdyb3VwQ29sbGFwc2VkKFxuICAgICAgYCVjJHtkZXZVdGlsczMuZm9ybWF0TWVzc2FnZShcIk1vY2tpbmcgZW5hYmxlZC5cIil9YCxcbiAgICAgIFwiY29sb3I6b3JhbmdlcmVkO2ZvbnQtd2VpZ2h0OmJvbGQ7XCJcbiAgICApO1xuICAgIGNvbnNvbGUubG9nKFxuICAgICAgXCIlY0RvY3VtZW50YXRpb246ICVjaHR0cHM6Ly9tc3dqcy5pby9kb2NzXCIsXG4gICAgICBcImZvbnQtd2VpZ2h0OmJvbGRcIixcbiAgICAgIFwiZm9udC13ZWlnaHQ6bm9ybWFsXCJcbiAgICApO1xuICAgIGNvbnNvbGUubG9nKFwiRm91bmQgYW4gaXNzdWU/IGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzXCIpO1xuICAgIGNvbnNvbGUubG9nKFwiV29ya2VyIHNjcmlwdCBVUkw6XCIsIHdvcmtlci5zY3JpcHRVUkwpO1xuICAgIGNvbnNvbGUubG9nKFwiV29ya2VyIHNjb3BlOlwiLCByZWdpc3RyYXRpb24uc2NvcGUpO1xuICAgIGlmIChjbGllbnQpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiQ2xpZW50IElEOiAlcyAoJXMpXCIsIGNsaWVudC5pZCwgY2xpZW50LmZyYW1lVHlwZSk7XG4gICAgfVxuICAgIGNvbnNvbGUuZ3JvdXBFbmQoKTtcbiAgfVxuICAjcHJpbnRTdG9wTWVzc2FnZSgpIHtcbiAgICBjb25zb2xlLmxvZyhcbiAgICAgIGAlYyR7ZGV2VXRpbHMzLmZvcm1hdE1lc3NhZ2UoXCJNb2NraW5nIGRpc2FibGVkLlwiKX1gLFxuICAgICAgXCJjb2xvcjpvcmFuZ2VyZWQ7Zm9udC13ZWlnaHQ6Ym9sZDtcIlxuICAgICk7XG4gIH1cbn07XG52YXIgU2VydmljZVdvcmtlckh0dHBOZXR3b3JrRnJhbWUgPSBjbGFzcyBleHRlbmRzIEh0dHBOZXR3b3JrRnJhbWUge1xuICAjZXZlbnQ7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICBzdXBlcih7IHJlcXVlc3Q6IG9wdGlvbnMucmVxdWVzdCB9KTtcbiAgICB0aGlzLiNldmVudCA9IG9wdGlvbnMuZXZlbnQ7XG4gIH1cbiAgcGFzc3Rocm91Z2goKSB7XG4gICAgdGhpcy4jZXZlbnQucG9zdE1lc3NhZ2UoXCJQQVNTVEhST1VHSFwiKTtcbiAgfVxuICByZXNwb25kV2l0aChyZXNwb25zZSkge1xuICAgIGlmIChyZXNwb25zZSkge1xuICAgICAgdGhpcy4jcmVzcG9uZFdpdGgocmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuICBlcnJvcldpdGgocmVhc29uKSB7XG4gICAgaWYgKHJlYXNvbiBpbnN0YW5jZW9mIFJlc3BvbnNlKSB7XG4gICAgICByZXR1cm4gdGhpcy5yZXNwb25kV2l0aChyZWFzb24pO1xuICAgIH1cbiAgICBkZXZVdGlsczMud2FybihcbiAgICAgIGBVbmNhdWdodCBleGNlcHRpb24gaW4gdGhlIHJlcXVlc3QgaGFuZGxlciBmb3IgXCIlcyAlc1wiLiBUaGlzIGV4Y2VwdGlvbiBoYXMgYmVlbiBncmFjZWZ1bGx5IGhhbmRsZWQgYXMgYSA1MDAgcmVzcG9uc2UsIGhvd2V2ZXIsIGl0J3Mgc3Ryb25nbHkgcmVjb21tZW5kZWQgdG8gcmVzb2x2ZSB0aGlzIGVycm9yLCBhcyBpdCBpbmRpY2F0ZXMgYSBtaXN0YWtlIGluIHlvdXIgY29kZS4gSWYgeW91IHdpc2ggdG8gbW9jayBhbiBlcnJvciByZXNwb25zZSwgcGxlYXNlIHNlZSB0aGlzIGd1aWRlOiBodHRwczovL21zd2pzLmlvL2RvY3MvaHR0cC9tb2NraW5nLXJlc3BvbnNlcy9lcnJvci1yZXNwb25zZXNgLFxuICAgICAgdGhpcy5kYXRhLnJlcXVlc3QubWV0aG9kLFxuICAgICAgdGhpcy5kYXRhLnJlcXVlc3QudXJsXG4gICAgKTtcbiAgICBjb25zdCBlcnJvcjIgPSByZWFzb24gaW5zdGFuY2VvZiBFcnJvciA/IHJlYXNvbiA6IG5ldyBFcnJvcihyZWFzb24/LnRvU3RyaW5nKCkgfHwgXCJSZXF1ZXN0IGZhaWx1cmVcIik7XG4gICAgdGhpcy5yZXNwb25kV2l0aChcbiAgICAgIEh0dHBSZXNwb25zZS5qc29uKFxuICAgICAgICB7XG4gICAgICAgICAgbmFtZTogZXJyb3IyLm5hbWUsXG4gICAgICAgICAgbWVzc2FnZTogZXJyb3IyLm1lc3NhZ2UsXG4gICAgICAgICAgc3RhY2s6IGVycm9yMi5zdGFja1xuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgc3RhdHVzOiA1MDAsXG4gICAgICAgICAgc3RhdHVzVGV4dDogXCJSZXF1ZXN0IEhhbmRsZXIgRXJyb3JcIlxuICAgICAgICB9XG4gICAgICApXG4gICAgKTtcbiAgfVxuICBhc3luYyAjcmVzcG9uZFdpdGgocmVzcG9uc2UpIHtcbiAgICBsZXQgcmVzcG9uc2VCb2R5O1xuICAgIGxldCB0cmFuc2ZlcjtcbiAgICBjb25zdCByZXNwb25zZUluaXQgPSB0b1Jlc3BvbnNlSW5pdChyZXNwb25zZSk7XG4gICAgaWYgKHN1cHBvcnRzUmVhZGFibGVTdHJlYW1UcmFuc2ZlcigpKSB7XG4gICAgICByZXNwb25zZUJvZHkgPSByZXNwb25zZS5ib2R5O1xuICAgICAgdHJhbnNmZXIgPSByZXNwb25zZS5ib2R5ID09IG51bGwgPyB2b2lkIDAgOiBbcmVzcG9uc2UuYm9keV07XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3BvbnNlQm9keSA9IHJlc3BvbnNlLmJvZHkgPT0gbnVsbCA/IG51bGwgOiBhd2FpdCByZXNwb25zZS5jbG9uZSgpLmFycmF5QnVmZmVyKCk7XG4gICAgfVxuICAgIHRoaXMuI2V2ZW50LnBvc3RNZXNzYWdlKFxuICAgICAgXCJNT0NLX1JFU1BPTlNFXCIsXG4gICAgICB7XG4gICAgICAgIC4uLnJlc3BvbnNlSW5pdCxcbiAgICAgICAgYm9keTogcmVzcG9uc2VCb2R5XG4gICAgICB9LFxuICAgICAgdHJhbnNmZXJcbiAgICApO1xuICB9XG59O1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vQG9wZW4tZHJhZnQrdW50aWxAMi4xLjAvbm9kZV9tb2R1bGVzL0BvcGVuLWRyYWZ0L3VudGlsL2xpYi9pbmRleC5tanNcbnZhciB1bnRpbDIgPSBhc3luYyAocHJvbWlzZSkgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwcm9taXNlKCkuY2F0Y2goKGVycm9yMikgPT4ge1xuICAgICAgdGhyb3cgZXJyb3IyO1xuICAgIH0pO1xuICAgIHJldHVybiB7IGVycm9yOiBudWxsLCBkYXRhIH07XG4gIH0gY2F0Y2ggKGVycm9yMikge1xuICAgIHJldHVybiB7IGVycm9yOiBlcnJvcjIsIGRhdGE6IG51bGwgfTtcbiAgfVxufTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0Btc3dqcytpbnRlcmNlcHRvcnNAMC40MS45L25vZGVfbW9kdWxlcy9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL2hhbmRsZVJlcXVlc3QtQ1BQZ3NHN3MubWpzXG5mdW5jdGlvbiBpc09iamVjdDIodmFsdWUsIGxvb3NlID0gZmFsc2UpIHtcbiAgcmV0dXJuIGxvb3NlID8gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKS5zdGFydHNXaXRoKFwiW29iamVjdCBcIikgOiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpID09PSBcIltvYmplY3QgT2JqZWN0XVwiO1xufVxuZnVuY3Rpb24gaXNQcm9wZXJ0eUFjY2Vzc2libGUob2JqLCBrZXkpIHtcbiAgdHJ5IHtcbiAgICBvYmpba2V5XTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5mdW5jdGlvbiBjcmVhdGVTZXJ2ZXJFcnJvclJlc3BvbnNlKGJvZHkpIHtcbiAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeShib2R5IGluc3RhbmNlb2YgRXJyb3IgPyB7XG4gICAgbmFtZTogYm9keS5uYW1lLFxuICAgIG1lc3NhZ2U6IGJvZHkubWVzc2FnZSxcbiAgICBzdGFjazogYm9keS5zdGFja1xuICB9IDogYm9keSksIHtcbiAgICBzdGF0dXM6IDUwMCxcbiAgICBzdGF0dXNUZXh0OiBcIlVuaGFuZGxlZCBFeGNlcHRpb25cIixcbiAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH1cbiAgfSk7XG59XG5mdW5jdGlvbiBpc1Jlc3BvbnNlRXJyb3IocmVzcG9uc2UpIHtcbiAgcmV0dXJuIHJlc3BvbnNlICE9IG51bGwgJiYgcmVzcG9uc2UgaW5zdGFuY2VvZiBSZXNwb25zZSAmJiBpc1Byb3BlcnR5QWNjZXNzaWJsZShyZXNwb25zZSwgXCJ0eXBlXCIpICYmIHJlc3BvbnNlLnR5cGUgPT09IFwiZXJyb3JcIjtcbn1cbmZ1bmN0aW9uIGlzUmVzcG9uc2VMaWtlKHZhbHVlKSB7XG4gIHJldHVybiBpc09iamVjdDIodmFsdWUsIHRydWUpICYmIGlzUHJvcGVydHlBY2Nlc3NpYmxlKHZhbHVlLCBcInN0YXR1c1wiKSAmJiBpc1Byb3BlcnR5QWNjZXNzaWJsZSh2YWx1ZSwgXCJzdGF0dXNUZXh0XCIpICYmIGlzUHJvcGVydHlBY2Nlc3NpYmxlKHZhbHVlLCBcImJvZHlVc2VkXCIpO1xufVxuZnVuY3Rpb24gaXNOb2RlTGlrZUVycm9yKGVycm9yMikge1xuICBpZiAoZXJyb3IyID09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgaWYgKCEoZXJyb3IyIGluc3RhbmNlb2YgRXJyb3IpKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiBcImNvZGVcIiBpbiBlcnJvcjIgJiYgXCJlcnJub1wiIGluIGVycm9yMjtcbn1cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZVJlcXVlc3Qob3B0aW9ucykge1xuICBjb25zdCBoYW5kbGVSZXNwb25zZSA9IGFzeW5jIChyZXNwb25zZSkgPT4ge1xuICAgIGlmIChyZXNwb25zZSBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICBhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIuZXJyb3JXaXRoKHJlc3BvbnNlKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoaXNSZXNwb25zZUVycm9yKHJlc3BvbnNlKSkge1xuICAgICAgYXdhaXQgb3B0aW9ucy5jb250cm9sbGVyLnJlc3BvbmRXaXRoKHJlc3BvbnNlKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoaXNSZXNwb25zZUxpa2UocmVzcG9uc2UpKSB7XG4gICAgICBhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIucmVzcG9uZFdpdGgocmVzcG9uc2UpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChpc09iamVjdDIocmVzcG9uc2UpKSB7XG4gICAgICBhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIuZXJyb3JXaXRoKHJlc3BvbnNlKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH07XG4gIGNvbnN0IGhhbmRsZVJlc3BvbnNlRXJyb3IgPSBhc3luYyAoZXJyb3IyKSA9PiB7XG4gICAgaWYgKGVycm9yMiBpbnN0YW5jZW9mIEludGVyY2VwdG9yRXJyb3IpIHRocm93IHJlc3VsdC5lcnJvcjtcbiAgICBpZiAoaXNOb2RlTGlrZUVycm9yKGVycm9yMikpIHtcbiAgICAgIGF3YWl0IG9wdGlvbnMuY29udHJvbGxlci5lcnJvcldpdGgoZXJyb3IyKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoZXJyb3IyIGluc3RhbmNlb2YgUmVzcG9uc2UpIHJldHVybiBhd2FpdCBoYW5kbGVSZXNwb25zZShlcnJvcjIpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfTtcbiAgY29uc3QgcmVxdWVzdEFib3J0UHJvbWlzZSA9IG5ldyBEZWZlcnJlZFByb21pc2UoKTtcbiAgY29uc3Qgb25BYm9ydCA9ICgpID0+IHtcbiAgICByZXF1ZXN0QWJvcnRQcm9taXNlLnJlamVjdChvcHRpb25zLnJlcXVlc3Quc2lnbmFsPy5yZWFzb24pO1xuICB9O1xuICBpZiAob3B0aW9ucy5yZXF1ZXN0LnNpZ25hbCkge1xuICAgIGlmIChvcHRpb25zLnJlcXVlc3Quc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgIGF3YWl0IG9wdGlvbnMuY29udHJvbGxlci5lcnJvcldpdGgob3B0aW9ucy5yZXF1ZXN0LnNpZ25hbC5yZWFzb24pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBvcHRpb25zLnJlcXVlc3Quc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBvbkFib3J0LCB7IG9uY2U6IHRydWUgfSk7XG4gIH1cbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdW50aWwyKGFzeW5jICgpID0+IHtcbiAgICBjb25zdCByZXF1ZXN0TGlzdGVuZXJzUHJvbWlzZSA9IGVtaXRBc3luYyhvcHRpb25zLmVtaXR0ZXIsIFwicmVxdWVzdFwiLCB7XG4gICAgICByZXF1ZXN0SWQ6IG9wdGlvbnMucmVxdWVzdElkLFxuICAgICAgcmVxdWVzdDogb3B0aW9ucy5yZXF1ZXN0LFxuICAgICAgY29udHJvbGxlcjogb3B0aW9ucy5jb250cm9sbGVyXG4gICAgfSk7XG4gICAgYXdhaXQgUHJvbWlzZS5yYWNlKFtcbiAgICAgIHJlcXVlc3RBYm9ydFByb21pc2UsXG4gICAgICByZXF1ZXN0TGlzdGVuZXJzUHJvbWlzZSxcbiAgICAgIG9wdGlvbnMuY29udHJvbGxlci5oYW5kbGVkXG4gICAgXSk7XG4gIH0pO1xuICBvcHRpb25zLnJlcXVlc3Quc2lnbmFsPy5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25BYm9ydCk7XG4gIGlmIChyZXF1ZXN0QWJvcnRQcm9taXNlLnN0YXRlID09PSBcInJlamVjdGVkXCIpIHtcbiAgICBhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIuZXJyb3JXaXRoKHJlcXVlc3RBYm9ydFByb21pc2UucmVqZWN0aW9uUmVhc29uKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHJlc3VsdC5lcnJvcikge1xuICAgIGlmIChhd2FpdCBoYW5kbGVSZXNwb25zZUVycm9yKHJlc3VsdC5lcnJvcikpIHJldHVybjtcbiAgICBpZiAob3B0aW9ucy5lbWl0dGVyLmxpc3RlbmVyQ291bnQoXCJ1bmhhbmRsZWRFeGNlcHRpb25cIikgPiAwKSB7XG4gICAgICBjb25zdCB1bmhhbmRsZWRFeGNlcHRpb25Db250cm9sbGVyID0gbmV3IFJlcXVlc3RDb250cm9sbGVyKG9wdGlvbnMucmVxdWVzdCwge1xuICAgICAgICBwYXNzdGhyb3VnaCgpIHtcbiAgICAgICAgfSxcbiAgICAgICAgYXN5bmMgcmVzcG9uZFdpdGgocmVzcG9uc2UpIHtcbiAgICAgICAgICBhd2FpdCBoYW5kbGVSZXNwb25zZShyZXNwb25zZSk7XG4gICAgICAgIH0sXG4gICAgICAgIGFzeW5jIGVycm9yV2l0aChyZWFzb24pIHtcbiAgICAgICAgICBhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIuZXJyb3JXaXRoKHJlYXNvbik7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgYXdhaXQgZW1pdEFzeW5jKG9wdGlvbnMuZW1pdHRlciwgXCJ1bmhhbmRsZWRFeGNlcHRpb25cIiwge1xuICAgICAgICBlcnJvcjogcmVzdWx0LmVycm9yLFxuICAgICAgICByZXF1ZXN0OiBvcHRpb25zLnJlcXVlc3QsXG4gICAgICAgIHJlcXVlc3RJZDogb3B0aW9ucy5yZXF1ZXN0SWQsXG4gICAgICAgIGNvbnRyb2xsZXI6IHVuaGFuZGxlZEV4Y2VwdGlvbkNvbnRyb2xsZXJcbiAgICAgIH0pO1xuICAgICAgaWYgKHVuaGFuZGxlZEV4Y2VwdGlvbkNvbnRyb2xsZXIucmVhZHlTdGF0ZSAhPT0gUmVxdWVzdENvbnRyb2xsZXIuUEVORElORykgcmV0dXJuO1xuICAgIH1cbiAgICBhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIucmVzcG9uZFdpdGgoY3JlYXRlU2VydmVyRXJyb3JSZXNwb25zZShyZXN1bHQuZXJyb3IpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKG9wdGlvbnMuY29udHJvbGxlci5yZWFkeVN0YXRlID09PSBSZXF1ZXN0Q29udHJvbGxlci5QRU5ESU5HKSByZXR1cm4gYXdhaXQgb3B0aW9ucy5jb250cm9sbGVyLnBhc3N0aHJvdWdoKCk7XG4gIHJldHVybiBvcHRpb25zLmNvbnRyb2xsZXIuaGFuZGxlZDtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0Btc3dqcytpbnRlcmNlcHRvcnNAMC40MS45L25vZGVfbW9kdWxlcy9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL2ZldGNoLTVJTVBxcjllLm1qc1xuZnVuY3Rpb24gY3JlYXRlTmV0d29ya0Vycm9yKGNhdXNlKSB7XG4gIHJldHVybiBPYmplY3QuYXNzaWduKC8qIEBfX1BVUkVfXyAqLyBuZXcgVHlwZUVycm9yKFwiRmFpbGVkIHRvIGZldGNoXCIpLCB7IGNhdXNlIH0pO1xufVxudmFyIFJFUVVFU1RfQk9EWV9IRUFERVJTID0gW1xuICBcImNvbnRlbnQtZW5jb2RpbmdcIixcbiAgXCJjb250ZW50LWxhbmd1YWdlXCIsXG4gIFwiY29udGVudC1sb2NhdGlvblwiLFxuICBcImNvbnRlbnQtdHlwZVwiLFxuICBcImNvbnRlbnQtbGVuZ3RoXCJcbl07XG52YXIga1JlZGlyZWN0Q291bnQgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwia1JlZGlyZWN0Q291bnRcIik7XG5hc3luYyBmdW5jdGlvbiBmb2xsb3dGZXRjaFJlZGlyZWN0KHJlcXVlc3QsIHJlc3BvbnNlKSB7XG4gIGlmIChyZXNwb25zZS5zdGF0dXMgIT09IDMwMyAmJiByZXF1ZXN0LmJvZHkgIT0gbnVsbCkgcmV0dXJuIFByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcigpKTtcbiAgY29uc3QgcmVxdWVzdFVybCA9IG5ldyBVUkwocmVxdWVzdC51cmwpO1xuICBsZXQgbG9jYXRpb25Vcmw7XG4gIHRyeSB7XG4gICAgbG9jYXRpb25VcmwgPSBuZXcgVVJMKHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwibG9jYXRpb25cIiksIHJlcXVlc3QudXJsKTtcbiAgfSBjYXRjaCAoZXJyb3IyKSB7XG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcihlcnJvcjIpKTtcbiAgfVxuICBpZiAoIShsb2NhdGlvblVybC5wcm90b2NvbCA9PT0gXCJodHRwOlwiIHx8IGxvY2F0aW9uVXJsLnByb3RvY29sID09PSBcImh0dHBzOlwiKSkgcmV0dXJuIFByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcihcIlVSTCBzY2hlbWUgbXVzdCBiZSBhIEhUVFAoUykgc2NoZW1lXCIpKTtcbiAgaWYgKFJlZmxlY3QuZ2V0KHJlcXVlc3QsIGtSZWRpcmVjdENvdW50KSA+IDIwKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoY3JlYXRlTmV0d29ya0Vycm9yKFwicmVkaXJlY3QgY291bnQgZXhjZWVkZWRcIikpO1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkocmVxdWVzdCwga1JlZGlyZWN0Q291bnQsIHsgdmFsdWU6IChSZWZsZWN0LmdldChyZXF1ZXN0LCBrUmVkaXJlY3RDb3VudCkgfHwgMCkgKyAxIH0pO1xuICBpZiAocmVxdWVzdC5tb2RlID09PSBcImNvcnNcIiAmJiAobG9jYXRpb25VcmwudXNlcm5hbWUgfHwgbG9jYXRpb25VcmwucGFzc3dvcmQpICYmICFzYW1lT3JpZ2luKHJlcXVlc3RVcmwsIGxvY2F0aW9uVXJsKSkgcmV0dXJuIFByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcignY3Jvc3Mgb3JpZ2luIG5vdCBhbGxvd2VkIGZvciByZXF1ZXN0IG1vZGUgXCJjb3JzXCInKSk7XG4gIGNvbnN0IHJlcXVlc3RJbml0ID0ge307XG4gIGlmIChbMzAxLCAzMDJdLmluY2x1ZGVzKHJlc3BvbnNlLnN0YXR1cykgJiYgcmVxdWVzdC5tZXRob2QgPT09IFwiUE9TVFwiIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gMzAzICYmICFbXCJIRUFEXCIsIFwiR0VUXCJdLmluY2x1ZGVzKHJlcXVlc3QubWV0aG9kKSkge1xuICAgIHJlcXVlc3RJbml0Lm1ldGhvZCA9IFwiR0VUXCI7XG4gICAgcmVxdWVzdEluaXQuYm9keSA9IG51bGw7XG4gICAgUkVRVUVTVF9CT0RZX0hFQURFUlMuZm9yRWFjaCgoaGVhZGVyTmFtZSkgPT4ge1xuICAgICAgcmVxdWVzdC5oZWFkZXJzLmRlbGV0ZShoZWFkZXJOYW1lKTtcbiAgICB9KTtcbiAgfVxuICBpZiAoIXNhbWVPcmlnaW4ocmVxdWVzdFVybCwgbG9jYXRpb25VcmwpKSB7XG4gICAgcmVxdWVzdC5oZWFkZXJzLmRlbGV0ZShcImF1dGhvcml6YXRpb25cIik7XG4gICAgcmVxdWVzdC5oZWFkZXJzLmRlbGV0ZShcInByb3h5LWF1dGhvcml6YXRpb25cIik7XG4gICAgcmVxdWVzdC5oZWFkZXJzLmRlbGV0ZShcImNvb2tpZVwiKTtcbiAgICByZXF1ZXN0LmhlYWRlcnMuZGVsZXRlKFwiaG9zdFwiKTtcbiAgfVxuICByZXF1ZXN0SW5pdC5oZWFkZXJzID0gcmVxdWVzdC5oZWFkZXJzO1xuICBjb25zdCBmaW5hbFJlc3BvbnNlID0gYXdhaXQgZmV0Y2gobmV3IFJlcXVlc3QobG9jYXRpb25VcmwsIHJlcXVlc3RJbml0KSk7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShmaW5hbFJlc3BvbnNlLCBcInJlZGlyZWN0ZWRcIiwge1xuICAgIHZhbHVlOiB0cnVlLFxuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICB9KTtcbiAgcmV0dXJuIGZpbmFsUmVzcG9uc2U7XG59XG5mdW5jdGlvbiBzYW1lT3JpZ2luKGxlZnQsIHJpZ2h0KSB7XG4gIGlmIChsZWZ0Lm9yaWdpbiA9PT0gcmlnaHQub3JpZ2luICYmIGxlZnQub3JpZ2luID09PSBcIm51bGxcIikgcmV0dXJuIHRydWU7XG4gIGlmIChsZWZ0LnByb3RvY29sID09PSByaWdodC5wcm90b2NvbCAmJiBsZWZ0Lmhvc3RuYW1lID09PSByaWdodC5ob3N0bmFtZSAmJiBsZWZ0LnBvcnQgPT09IHJpZ2h0LnBvcnQpIHJldHVybiB0cnVlO1xuICByZXR1cm4gZmFsc2U7XG59XG52YXIgQnJvdGxpRGVjb21wcmVzc2lvblN0cmVhbSA9IGNsYXNzIGV4dGVuZHMgVHJhbnNmb3JtU3RyZWFtIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgY29uc29sZS53YXJuKFwiW0ludGVyY2VwdG9yc106IEJyb3RsaSBkZWNvbXByZXNzaW9uIG9mIHJlc3BvbnNlIHN0cmVhbXMgaXMgbm90IHN1cHBvcnRlZCBpbiB0aGUgYnJvd3NlclwiKTtcbiAgICBzdXBlcih7IHRyYW5zZm9ybShjaHVuaywgY29udHJvbGxlcikge1xuICAgICAgY29udHJvbGxlci5lbnF1ZXVlKGNodW5rKTtcbiAgICB9IH0pO1xuICB9XG59O1xudmFyIFBpcGVsaW5lU3RyZWFtID0gY2xhc3MgZXh0ZW5kcyBUcmFuc2Zvcm1TdHJlYW0ge1xuICBjb25zdHJ1Y3Rvcih0cmFuc2Zvcm1TdHJlYW1zLCAuLi5zdHJhdGVnaWVzKSB7XG4gICAgc3VwZXIoe30sIC4uLnN0cmF0ZWdpZXMpO1xuICAgIGNvbnN0IHJlYWRhYmxlID0gW3N1cGVyLnJlYWRhYmxlLCAuLi50cmFuc2Zvcm1TdHJlYW1zXS5yZWR1Y2UoKHJlYWRhYmxlJDEsIHRyYW5zZm9ybSkgPT4gcmVhZGFibGUkMS5waXBlVGhyb3VnaCh0cmFuc2Zvcm0pKTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJyZWFkYWJsZVwiLCB7IGdldCgpIHtcbiAgICAgIHJldHVybiByZWFkYWJsZTtcbiAgICB9IH0pO1xuICB9XG59O1xuZnVuY3Rpb24gcGFyc2VDb250ZW50RW5jb2RpbmcoY29udGVudEVuY29kaW5nKSB7XG4gIHJldHVybiBjb250ZW50RW5jb2RpbmcudG9Mb3dlckNhc2UoKS5zcGxpdChcIixcIikubWFwKChjb2RpbmcpID0+IGNvZGluZy50cmltKCkpO1xufVxuZnVuY3Rpb24gY3JlYXRlRGVjb21wcmVzc2lvblN0cmVhbShjb250ZW50RW5jb2RpbmcpIHtcbiAgaWYgKGNvbnRlbnRFbmNvZGluZyA9PT0gXCJcIikgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGNvZGluZ3MgPSBwYXJzZUNvbnRlbnRFbmNvZGluZyhjb250ZW50RW5jb2RpbmcpO1xuICBpZiAoY29kaW5ncy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xuICByZXR1cm4gbmV3IFBpcGVsaW5lU3RyZWFtKGNvZGluZ3MucmVkdWNlUmlnaHQoKHRyYW5zZm9ybWVycywgY29kaW5nKSA9PiB7XG4gICAgaWYgKGNvZGluZyA9PT0gXCJnemlwXCIgfHwgY29kaW5nID09PSBcIngtZ3ppcFwiKSByZXR1cm4gdHJhbnNmb3JtZXJzLmNvbmNhdChuZXcgRGVjb21wcmVzc2lvblN0cmVhbShcImd6aXBcIikpO1xuICAgIGVsc2UgaWYgKGNvZGluZyA9PT0gXCJkZWZsYXRlXCIpIHJldHVybiB0cmFuc2Zvcm1lcnMuY29uY2F0KG5ldyBEZWNvbXByZXNzaW9uU3RyZWFtKFwiZGVmbGF0ZVwiKSk7XG4gICAgZWxzZSBpZiAoY29kaW5nID09PSBcImJyXCIpIHJldHVybiB0cmFuc2Zvcm1lcnMuY29uY2F0KG5ldyBCcm90bGlEZWNvbXByZXNzaW9uU3RyZWFtKCkpO1xuICAgIGVsc2UgdHJhbnNmb3JtZXJzLmxlbmd0aCA9IDA7XG4gICAgcmV0dXJuIHRyYW5zZm9ybWVycztcbiAgfSwgW10pKTtcbn1cbmZ1bmN0aW9uIGRlY29tcHJlc3NSZXNwb25zZShyZXNwb25zZSkge1xuICBpZiAocmVzcG9uc2UuYm9keSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGRlY29tcHJlc3Npb25TdHJlYW0gPSBjcmVhdGVEZWNvbXByZXNzaW9uU3RyZWFtKHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiY29udGVudC1lbmNvZGluZ1wiKSB8fCBcIlwiKTtcbiAgaWYgKCFkZWNvbXByZXNzaW9uU3RyZWFtKSByZXR1cm4gbnVsbDtcbiAgcmVzcG9uc2UuYm9keS5waXBlVG8oZGVjb21wcmVzc2lvblN0cmVhbS53cml0YWJsZSk7XG4gIHJldHVybiBkZWNvbXByZXNzaW9uU3RyZWFtLnJlYWRhYmxlO1xufVxudmFyIEZldGNoSW50ZXJjZXB0b3IgPSBjbGFzcyBGZXRjaEludGVyY2VwdG9yMiBleHRlbmRzIEludGVyY2VwdG9yIHtcbiAgc3RhdGljIHtcbiAgICB0aGlzLnN5bWJvbCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwiZmV0Y2gtaW50ZXJjZXB0b3JcIik7XG4gIH1cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoRmV0Y2hJbnRlcmNlcHRvcjIuc3ltYm9sKTtcbiAgfVxuICBjaGVja0Vudmlyb25tZW50KCkge1xuICAgIHJldHVybiBoYXNDb25maWd1cmFibGVHbG9iYWwoXCJmZXRjaFwiKTtcbiAgfVxuICBhc3luYyBzZXR1cCgpIHtcbiAgICBjb25zdCBsb2dnZXIgPSB0aGlzLmxvZ2dlci5leHRlbmQoXCJzZXR1cFwiKTtcbiAgICBjb25zdCBwdXJlRmV0Y2ggPSBnbG9iYWxUaGlzLmZldGNoO1xuICAgIGNvbnN0IGZldGNoUHJveHkgPSBhc3luYyAoaW5wdXQsIGluaXQpID0+IHtcbiAgICAgIGNvbnN0IHJlcXVlc3RJZCA9IGNyZWF0ZVJlcXVlc3RJZCgpO1xuICAgICAgY29uc3QgcmVxdWVzdCA9IG5ldyBGZXRjaFJlcXVlc3QodHlwZW9mIGlucHV0ID09PSBcInN0cmluZ1wiICYmIHR5cGVvZiBsb2NhdGlvbiAhPT0gXCJ1bmRlZmluZWRcIiAmJiAhY2FuUGFyc2VVcmwoaW5wdXQpID8gbmV3IFVSTChpbnB1dCwgbG9jYXRpb24uaHJlZikgOiBpbnB1dCwgaW5pdCk7XG4gICAgICBpZiAoaW5wdXQgaW5zdGFuY2VvZiBSZXF1ZXN0KSBzZXRSYXdSZXF1ZXN0KHJlcXVlc3QsIGlucHV0KTtcbiAgICAgIGNvbnN0IHJlc3BvbnNlUHJvbWlzZSA9IG5ldyBEZWZlcnJlZFByb21pc2UoKTtcbiAgICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgUmVxdWVzdENvbnRyb2xsZXIocmVxdWVzdCwge1xuICAgICAgICBwYXNzdGhyb3VnaDogYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJyZXF1ZXN0IGhhcyBub3QgYmVlbiBoYW5kbGVkLCBwYXNzdGhyb3VnaC4uLlwiKTtcbiAgICAgICAgICBjb25zdCByZXF1ZXN0Q2xvbmVGb3JSZXNwb25zZUV2ZW50ID0gcmVxdWVzdC5jbG9uZSgpO1xuICAgICAgICAgIGNvbnN0IHsgZXJyb3I6IHJlc3BvbnNlRXJyb3IsIGRhdGE6IG9yaWdpbmFsUmVzcG9uc2UgfSA9IGF3YWl0IHVudGlsMigoKSA9PiBwdXJlRmV0Y2gocmVxdWVzdCkpO1xuICAgICAgICAgIGlmIChyZXNwb25zZUVycm9yKSByZXR1cm4gcmVzcG9uc2VQcm9taXNlLnJlamVjdChyZXNwb25zZUVycm9yKTtcbiAgICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKFwib3JpZ2luYWwgZmV0Y2ggcGVyZm9ybWVkXCIsIG9yaWdpbmFsUmVzcG9uc2UpO1xuICAgICAgICAgIGlmICh0aGlzLmVtaXR0ZXIubGlzdGVuZXJDb3VudChcInJlc3BvbnNlXCIpID4gMCkge1xuICAgICAgICAgICAgdGhpcy5sb2dnZXIuaW5mbygnZW1pdHRpbmcgdGhlIFwicmVzcG9uc2VcIiBldmVudC4uLicpO1xuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2VDbG9uZSA9IEZldGNoUmVzcG9uc2UuY2xvbmUob3JpZ2luYWxSZXNwb25zZSk7XG4gICAgICAgICAgICBhd2FpdCBlbWl0QXN5bmModGhpcy5lbWl0dGVyLCBcInJlc3BvbnNlXCIsIHtcbiAgICAgICAgICAgICAgcmVzcG9uc2U6IHJlc3BvbnNlQ2xvbmUsXG4gICAgICAgICAgICAgIGlzTW9ja2VkUmVzcG9uc2U6IGZhbHNlLFxuICAgICAgICAgICAgICByZXF1ZXN0OiByZXF1ZXN0Q2xvbmVGb3JSZXNwb25zZUV2ZW50LFxuICAgICAgICAgICAgICByZXF1ZXN0SWRcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXNwb25zZVByb21pc2UucmVzb2x2ZShvcmlnaW5hbFJlc3BvbnNlKTtcbiAgICAgICAgfSxcbiAgICAgICAgcmVzcG9uZFdpdGg6IGFzeW5jIChyYXdSZXNwb25zZSkgPT4ge1xuICAgICAgICAgIGlmIChpc1Jlc3BvbnNlRXJyb3IocmF3UmVzcG9uc2UpKSB7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKFwicmVxdWVzdCBoYXMgZXJyb3JlZCFcIiwgeyByZXNwb25zZTogcmF3UmVzcG9uc2UgfSk7XG4gICAgICAgICAgICByZXNwb25zZVByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcihyYXdSZXNwb25zZSkpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKFwicmVjZWl2ZWQgbW9ja2VkIHJlc3BvbnNlIVwiLCB7IHJhd1Jlc3BvbnNlIH0pO1xuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gbmV3IEZldGNoUmVzcG9uc2UoZGVjb21wcmVzc1Jlc3BvbnNlKHJhd1Jlc3BvbnNlKSB8fCByYXdSZXNwb25zZS5ib2R5LCB7XG4gICAgICAgICAgICB1cmw6IHJlcXVlc3QudXJsLFxuICAgICAgICAgICAgc3RhdHVzOiByYXdSZXNwb25zZS5zdGF0dXMsXG4gICAgICAgICAgICBzdGF0dXNUZXh0OiByYXdSZXNwb25zZS5zdGF0dXNUZXh0LFxuICAgICAgICAgICAgaGVhZGVyczogcmF3UmVzcG9uc2UuaGVhZGVyc1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChGZXRjaFJlc3BvbnNlLmlzUmVkaXJlY3RSZXNwb25zZShyZXNwb25zZS5zdGF0dXMpKSB7XG4gICAgICAgICAgICBpZiAocmVxdWVzdC5yZWRpcmVjdCA9PT0gXCJlcnJvclwiKSB7XG4gICAgICAgICAgICAgIHJlc3BvbnNlUHJvbWlzZS5yZWplY3QoY3JlYXRlTmV0d29ya0Vycm9yKFwidW5leHBlY3RlZCByZWRpcmVjdFwiKSk7XG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZXF1ZXN0LnJlZGlyZWN0ID09PSBcImZvbGxvd1wiKSB7XG4gICAgICAgICAgICAgIGZvbGxvd0ZldGNoUmVkaXJlY3QocmVxdWVzdCwgcmVzcG9uc2UpLnRoZW4oKHJlc3BvbnNlJDEpID0+IHtcbiAgICAgICAgICAgICAgICByZXNwb25zZVByb21pc2UucmVzb2x2ZShyZXNwb25zZSQxKTtcbiAgICAgICAgICAgICAgfSwgKHJlYXNvbikgPT4ge1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlUHJvbWlzZS5yZWplY3QocmVhc29uKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHRoaXMuZW1pdHRlci5saXN0ZW5lckNvdW50KFwicmVzcG9uc2VcIikgPiAwKSB7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKCdlbWl0dGluZyB0aGUgXCJyZXNwb25zZVwiIGV2ZW50Li4uJyk7XG4gICAgICAgICAgICBhd2FpdCBlbWl0QXN5bmModGhpcy5lbWl0dGVyLCBcInJlc3BvbnNlXCIsIHtcbiAgICAgICAgICAgICAgcmVzcG9uc2U6IEZldGNoUmVzcG9uc2UuY2xvbmUocmVzcG9uc2UpLFxuICAgICAgICAgICAgICBpc01vY2tlZFJlc3BvbnNlOiB0cnVlLFxuICAgICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgICByZXF1ZXN0SWRcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXNwb25zZVByb21pc2UucmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yV2l0aDogKHJlYXNvbikgPT4ge1xuICAgICAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJyZXF1ZXN0IGhhcyBiZWVuIGFib3J0ZWQhXCIsIHsgcmVhc29uIH0pO1xuICAgICAgICAgIHJlc3BvbnNlUHJvbWlzZS5yZWplY3QocmVhc29uKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICB0aGlzLmxvZ2dlci5pbmZvKFwiWyVzXSAlc1wiLCByZXF1ZXN0Lm1ldGhvZCwgcmVxdWVzdC51cmwpO1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbyhcImF3YWl0aW5nIGZvciB0aGUgbW9ja2VkIHJlc3BvbnNlLi4uXCIpO1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbygnZW1pdHRpbmcgdGhlIFwicmVxdWVzdFwiIGV2ZW50IGZvciAlcyBsaXN0ZW5lcihzKS4uLicsIHRoaXMuZW1pdHRlci5saXN0ZW5lckNvdW50KFwicmVxdWVzdFwiKSk7XG4gICAgICBhd2FpdCBoYW5kbGVSZXF1ZXN0KHtcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgcmVxdWVzdElkLFxuICAgICAgICBlbWl0dGVyOiB0aGlzLmVtaXR0ZXIsXG4gICAgICAgIGNvbnRyb2xsZXJcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlUHJvbWlzZTtcbiAgICB9O1xuICAgIGxvZ2dlci5pbmZvKFwicGF0Y2hpbmcgZ2xvYmFsIGZldGNoLi4uXCIpO1xuICAgIHRoaXMuc3Vic2NyaXB0aW9ucy5wdXNoKHBhdGNoZXNSZWdpc3RyeS5hcHBseVBhdGNoKGdsb2JhbFRoaXMsIFwiZmV0Y2hcIiwgKCkgPT4gZmV0Y2hQcm94eSkpO1xuICAgIGxvZ2dlci5pbmZvKFwiZ2xvYmFsIGZldGNoIHBhdGNoZWQhXCIsIGdsb2JhbFRoaXMuZmV0Y2gubmFtZSk7XG4gIH1cbn07XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9AbXN3anMraW50ZXJjZXB0b3JzQDAuNDEuOS9ub2RlX21vZHVsZXMvQG1zd2pzL2ludGVyY2VwdG9ycy9saWIvYnJvd3Nlci9YTUxIdHRwUmVxdWVzdC1EclpBZjN3Ni5tanNcbmZ1bmN0aW9uIGNvbmNhdEFycmF5QnVmZmVyKGxlZnQsIHJpZ2h0KSB7XG4gIGNvbnN0IHJlc3VsdCA9IG5ldyBVaW50OEFycmF5KGxlZnQuYnl0ZUxlbmd0aCArIHJpZ2h0LmJ5dGVMZW5ndGgpO1xuICByZXN1bHQuc2V0KGxlZnQsIDApO1xuICByZXN1bHQuc2V0KHJpZ2h0LCBsZWZ0LmJ5dGVMZW5ndGgpO1xuICByZXR1cm4gcmVzdWx0O1xufVxudmFyIEV2ZW50UG9seWZpbGwgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKHR5cGUsIG9wdGlvbnMpIHtcbiAgICB0aGlzLk5PTkUgPSAwO1xuICAgIHRoaXMuQ0FQVFVSSU5HX1BIQVNFID0gMTtcbiAgICB0aGlzLkFUX1RBUkdFVCA9IDI7XG4gICAgdGhpcy5CVUJCTElOR19QSEFTRSA9IDM7XG4gICAgdGhpcy50eXBlID0gXCJcIjtcbiAgICB0aGlzLnNyY0VsZW1lbnQgPSBudWxsO1xuICAgIHRoaXMuY3VycmVudFRhcmdldCA9IG51bGw7XG4gICAgdGhpcy5ldmVudFBoYXNlID0gMDtcbiAgICB0aGlzLmlzVHJ1c3RlZCA9IHRydWU7XG4gICAgdGhpcy5jb21wb3NlZCA9IGZhbHNlO1xuICAgIHRoaXMuY2FuY2VsYWJsZSA9IHRydWU7XG4gICAgdGhpcy5kZWZhdWx0UHJldmVudGVkID0gZmFsc2U7XG4gICAgdGhpcy5idWJibGVzID0gdHJ1ZTtcbiAgICB0aGlzLmxlbmd0aENvbXB1dGFibGUgPSB0cnVlO1xuICAgIHRoaXMubG9hZGVkID0gMDtcbiAgICB0aGlzLnRvdGFsID0gMDtcbiAgICB0aGlzLmNhbmNlbEJ1YmJsZSA9IGZhbHNlO1xuICAgIHRoaXMucmV0dXJuVmFsdWUgPSB0cnVlO1xuICAgIHRoaXMudHlwZSA9IHR5cGU7XG4gICAgdGhpcy50YXJnZXQgPSBvcHRpb25zPy50YXJnZXQgfHwgbnVsbDtcbiAgICB0aGlzLmN1cnJlbnRUYXJnZXQgPSBvcHRpb25zPy5jdXJyZW50VGFyZ2V0IHx8IG51bGw7XG4gICAgdGhpcy50aW1lU3RhbXAgPSBEYXRlLm5vdygpO1xuICB9XG4gIGNvbXBvc2VkUGF0aCgpIHtcbiAgICByZXR1cm4gW107XG4gIH1cbiAgaW5pdEV2ZW50KHR5cGUsIGJ1YmJsZXMsIGNhbmNlbGFibGUpIHtcbiAgICB0aGlzLnR5cGUgPSB0eXBlO1xuICAgIHRoaXMuYnViYmxlcyA9ICEhYnViYmxlcztcbiAgICB0aGlzLmNhbmNlbGFibGUgPSAhIWNhbmNlbGFibGU7XG4gIH1cbiAgcHJldmVudERlZmF1bHQoKSB7XG4gICAgdGhpcy5kZWZhdWx0UHJldmVudGVkID0gdHJ1ZTtcbiAgfVxuICBzdG9wUHJvcGFnYXRpb24oKSB7XG4gIH1cbiAgc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCkge1xuICB9XG59O1xudmFyIFByb2dyZXNzRXZlbnRQb2x5ZmlsbCA9IGNsYXNzIGV4dGVuZHMgRXZlbnRQb2x5ZmlsbCB7XG4gIGNvbnN0cnVjdG9yKHR5cGUsIGluaXQpIHtcbiAgICBzdXBlcih0eXBlKTtcbiAgICB0aGlzLmxlbmd0aENvbXB1dGFibGUgPSBpbml0Py5sZW5ndGhDb21wdXRhYmxlIHx8IGZhbHNlO1xuICAgIHRoaXMuY29tcG9zZWQgPSBpbml0Py5jb21wb3NlZCB8fCBmYWxzZTtcbiAgICB0aGlzLmxvYWRlZCA9IGluaXQ/LmxvYWRlZCB8fCAwO1xuICAgIHRoaXMudG90YWwgPSBpbml0Py50b3RhbCB8fCAwO1xuICB9XG59O1xudmFyIFNVUFBPUlRTX1BST0dSRVNTX0VWRU5UID0gdHlwZW9mIFByb2dyZXNzRXZlbnQgIT09IFwidW5kZWZpbmVkXCI7XG5mdW5jdGlvbiBjcmVhdGVFdmVudCh0YXJnZXQsIHR5cGUsIGluaXQpIHtcbiAgY29uc3QgcHJvZ3Jlc3NFdmVudHMgPSBbXG4gICAgXCJlcnJvclwiLFxuICAgIFwicHJvZ3Jlc3NcIixcbiAgICBcImxvYWRzdGFydFwiLFxuICAgIFwibG9hZGVuZFwiLFxuICAgIFwibG9hZFwiLFxuICAgIFwidGltZW91dFwiLFxuICAgIFwiYWJvcnRcIlxuICBdO1xuICBjb25zdCBQcm9ncmVzc0V2ZW50Q2xhc3MgPSBTVVBQT1JUU19QUk9HUkVTU19FVkVOVCA/IFByb2dyZXNzRXZlbnQgOiBQcm9ncmVzc0V2ZW50UG9seWZpbGw7XG4gIHJldHVybiBwcm9ncmVzc0V2ZW50cy5pbmNsdWRlcyh0eXBlKSA/IG5ldyBQcm9ncmVzc0V2ZW50Q2xhc3ModHlwZSwge1xuICAgIGxlbmd0aENvbXB1dGFibGU6IHRydWUsXG4gICAgbG9hZGVkOiBpbml0Py5sb2FkZWQgfHwgMCxcbiAgICB0b3RhbDogaW5pdD8udG90YWwgfHwgMFxuICB9KSA6IG5ldyBFdmVudFBvbHlmaWxsKHR5cGUsIHtcbiAgICB0YXJnZXQsXG4gICAgY3VycmVudFRhcmdldDogdGFyZ2V0XG4gIH0pO1xufVxuZnVuY3Rpb24gZmluZFByb3BlcnR5U291cmNlKHRhcmdldCwgcHJvcGVydHlOYW1lKSB7XG4gIGlmICghKHByb3BlcnR5TmFtZSBpbiB0YXJnZXQpKSByZXR1cm4gbnVsbDtcbiAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh0YXJnZXQsIHByb3BlcnR5TmFtZSkpIHJldHVybiB0YXJnZXQ7XG4gIGNvbnN0IHByb3RvdHlwZSA9IFJlZmxlY3QuZ2V0UHJvdG90eXBlT2YodGFyZ2V0KTtcbiAgcmV0dXJuIHByb3RvdHlwZSA/IGZpbmRQcm9wZXJ0eVNvdXJjZShwcm90b3R5cGUsIHByb3BlcnR5TmFtZSkgOiBudWxsO1xufVxuZnVuY3Rpb24gY3JlYXRlUHJveHkodGFyZ2V0LCBvcHRpb25zKSB7XG4gIHJldHVybiBuZXcgUHJveHkodGFyZ2V0LCBvcHRpb25zVG9Qcm94eUhhbmRsZXIob3B0aW9ucykpO1xufVxuZnVuY3Rpb24gb3B0aW9uc1RvUHJveHlIYW5kbGVyKG9wdGlvbnMpIHtcbiAgY29uc3QgeyBjb25zdHJ1Y3RvckNhbGwsIG1ldGhvZENhbGwsIGdldFByb3BlcnR5LCBzZXRQcm9wZXJ0eSB9ID0gb3B0aW9ucztcbiAgY29uc3QgaGFuZGxlciA9IHt9O1xuICBpZiAodHlwZW9mIGNvbnN0cnVjdG9yQ2FsbCAhPT0gXCJ1bmRlZmluZWRcIikgaGFuZGxlci5jb25zdHJ1Y3QgPSBmdW5jdGlvbih0YXJnZXQsIGFyZ3MsIG5ld1RhcmdldCkge1xuICAgIGNvbnN0IG5leHQgPSBSZWZsZWN0LmNvbnN0cnVjdC5iaW5kKG51bGwsIHRhcmdldCwgYXJncywgbmV3VGFyZ2V0KTtcbiAgICByZXR1cm4gY29uc3RydWN0b3JDYWxsLmNhbGwobmV3VGFyZ2V0LCBhcmdzLCBuZXh0KTtcbiAgfTtcbiAgaGFuZGxlci5zZXQgPSBmdW5jdGlvbih0YXJnZXQsIHByb3BlcnR5TmFtZSwgbmV4dFZhbHVlKSB7XG4gICAgY29uc3QgbmV4dCA9ICgpID0+IHtcbiAgICAgIGNvbnN0IHByb3BlcnR5U291cmNlID0gZmluZFByb3BlcnR5U291cmNlKHRhcmdldCwgcHJvcGVydHlOYW1lKSB8fCB0YXJnZXQ7XG4gICAgICBjb25zdCBvd25EZXNjcmlwdG9ycyA9IFJlZmxlY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHByb3BlcnR5U291cmNlLCBwcm9wZXJ0eU5hbWUpO1xuICAgICAgaWYgKHR5cGVvZiBvd25EZXNjcmlwdG9ycz8uc2V0ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIG93bkRlc2NyaXB0b3JzLnNldC5hcHBseSh0YXJnZXQsIFtuZXh0VmFsdWVdKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gUmVmbGVjdC5kZWZpbmVQcm9wZXJ0eShwcm9wZXJ0eVNvdXJjZSwgcHJvcGVydHlOYW1lLCB7XG4gICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgIHZhbHVlOiBuZXh0VmFsdWVcbiAgICAgIH0pO1xuICAgIH07XG4gICAgaWYgKHR5cGVvZiBzZXRQcm9wZXJ0eSAhPT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIHNldFByb3BlcnR5LmNhbGwodGFyZ2V0LCBbcHJvcGVydHlOYW1lLCBuZXh0VmFsdWVdLCBuZXh0KTtcbiAgICByZXR1cm4gbmV4dCgpO1xuICB9O1xuICBoYW5kbGVyLmdldCA9IGZ1bmN0aW9uKHRhcmdldCwgcHJvcGVydHlOYW1lLCByZWNlaXZlcikge1xuICAgIGNvbnN0IG5leHQgPSAoKSA9PiB0YXJnZXRbcHJvcGVydHlOYW1lXTtcbiAgICBjb25zdCB2YWx1ZSA9IHR5cGVvZiBnZXRQcm9wZXJ0eSAhPT0gXCJ1bmRlZmluZWRcIiA/IGdldFByb3BlcnR5LmNhbGwodGFyZ2V0LCBbcHJvcGVydHlOYW1lLCByZWNlaXZlcl0sIG5leHQpIDogbmV4dCgpO1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zdCBuZXh0JDEgPSB2YWx1ZS5iaW5kKHRhcmdldCwgLi4uYXJncyk7XG4gICAgICBpZiAodHlwZW9mIG1ldGhvZENhbGwgIT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBtZXRob2RDYWxsLmNhbGwodGFyZ2V0LCBbcHJvcGVydHlOYW1lLCBhcmdzXSwgbmV4dCQxKTtcbiAgICAgIHJldHVybiBuZXh0JDEoKTtcbiAgICB9O1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfTtcbiAgcmV0dXJuIGhhbmRsZXI7XG59XG5mdW5jdGlvbiBpc0RvbVBhcnNlclN1cHBvcnRlZFR5cGUodHlwZSkge1xuICByZXR1cm4gW1xuICAgIFwiYXBwbGljYXRpb24veGh0bWwreG1sXCIsXG4gICAgXCJhcHBsaWNhdGlvbi94bWxcIixcbiAgICBcImltYWdlL3N2Zyt4bWxcIixcbiAgICBcInRleHQvaHRtbFwiLFxuICAgIFwidGV4dC94bWxcIlxuICBdLnNvbWUoKHN1cHBvcnRlZFR5cGUpID0+IHtcbiAgICByZXR1cm4gdHlwZS5zdGFydHNXaXRoKHN1cHBvcnRlZFR5cGUpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHBhcnNlSnNvbihkYXRhKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIEpTT04ucGFyc2UoZGF0YSk7XG4gIH0gY2F0Y2ggKF8pIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuZnVuY3Rpb24gY3JlYXRlUmVzcG9uc2UocmVxdWVzdCwgYm9keSkge1xuICByZXR1cm4gbmV3IEZldGNoUmVzcG9uc2UoRmV0Y2hSZXNwb25zZS5pc1Jlc3BvbnNlV2l0aEJvZHkocmVxdWVzdC5zdGF0dXMpID8gYm9keSA6IG51bGwsIHtcbiAgICB1cmw6IHJlcXVlc3QucmVzcG9uc2VVUkwsXG4gICAgc3RhdHVzOiByZXF1ZXN0LnN0YXR1cyxcbiAgICBzdGF0dXNUZXh0OiByZXF1ZXN0LnN0YXR1c1RleHQsXG4gICAgaGVhZGVyczogY3JlYXRlSGVhZGVyc0Zyb21YTUxIdHRwUmVxdWVzdEhlYWRlcnMocmVxdWVzdC5nZXRBbGxSZXNwb25zZUhlYWRlcnMoKSlcbiAgfSk7XG59XG5mdW5jdGlvbiBjcmVhdGVIZWFkZXJzRnJvbVhNTEh0dHBSZXF1ZXN0SGVhZGVycyhoZWFkZXJzU3RyaW5nKSB7XG4gIGNvbnN0IGhlYWRlcnMgPSBuZXcgSGVhZGVycygpO1xuICBjb25zdCBsaW5lcyA9IGhlYWRlcnNTdHJpbmcuc3BsaXQoL1tcXHJcXG5dKy8pO1xuICBmb3IgKGNvbnN0IGxpbmUgb2YgbGluZXMpIHtcbiAgICBpZiAobGluZS50cmltKCkgPT09IFwiXCIpIGNvbnRpbnVlO1xuICAgIGNvbnN0IFtuYW1lLCAuLi5wYXJ0c10gPSBsaW5lLnNwbGl0KFwiOiBcIik7XG4gICAgY29uc3QgdmFsdWUgPSBwYXJ0cy5qb2luKFwiOiBcIik7XG4gICAgaGVhZGVycy5hcHBlbmQobmFtZSwgdmFsdWUpO1xuICB9XG4gIHJldHVybiBoZWFkZXJzO1xufVxuYXN5bmMgZnVuY3Rpb24gZ2V0Qm9keUJ5dGVMZW5ndGgoaW5wdXQpIHtcbiAgY29uc3QgZXhwbGljaXRDb250ZW50TGVuZ3RoID0gaW5wdXQuaGVhZGVycy5nZXQoXCJjb250ZW50LWxlbmd0aFwiKTtcbiAgaWYgKGV4cGxpY2l0Q29udGVudExlbmd0aCAhPSBudWxsICYmIGV4cGxpY2l0Q29udGVudExlbmd0aCAhPT0gXCJcIikgcmV0dXJuIE51bWJlcihleHBsaWNpdENvbnRlbnRMZW5ndGgpO1xuICByZXR1cm4gKGF3YWl0IGlucHV0LmFycmF5QnVmZmVyKCkpLmJ5dGVMZW5ndGg7XG59XG52YXIga0lzUmVxdWVzdEhhbmRsZWQgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwia0lzUmVxdWVzdEhhbmRsZWRcIik7XG52YXIgSVNfTk9ERTIgPSBpc05vZGVQcm9jZXNzKCk7XG52YXIga0ZldGNoUmVxdWVzdCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJrRmV0Y2hSZXF1ZXN0XCIpO1xudmFyIFhNTEh0dHBSZXF1ZXN0Q29udHJvbGxlciA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoaW5pdGlhbFJlcXVlc3QsIGxvZ2dlcikge1xuICAgIHRoaXMuaW5pdGlhbFJlcXVlc3QgPSBpbml0aWFsUmVxdWVzdDtcbiAgICB0aGlzLmxvZ2dlciA9IGxvZ2dlcjtcbiAgICB0aGlzLm1ldGhvZCA9IFwiR0VUXCI7XG4gICAgdGhpcy51cmwgPSBudWxsO1xuICAgIHRoaXNba0lzUmVxdWVzdEhhbmRsZWRdID0gZmFsc2U7XG4gICAgdGhpcy5ldmVudHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIHRoaXMudXBsb2FkRXZlbnRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICB0aGlzLnJlcXVlc3RJZCA9IGNyZWF0ZVJlcXVlc3RJZCgpO1xuICAgIHRoaXMucmVxdWVzdEhlYWRlcnMgPSBuZXcgSGVhZGVycygpO1xuICAgIHRoaXMucmVzcG9uc2VCdWZmZXIgPSBuZXcgVWludDhBcnJheSgpO1xuICAgIHRoaXMucmVxdWVzdCA9IGNyZWF0ZVByb3h5KGluaXRpYWxSZXF1ZXN0LCB7XG4gICAgICBzZXRQcm9wZXJ0eTogKFtwcm9wZXJ0eU5hbWUsIG5leHRWYWx1ZV0sIGludm9rZSkgPT4ge1xuICAgICAgICBzd2l0Y2ggKHByb3BlcnR5TmFtZSkge1xuICAgICAgICAgIGNhc2UgXCJvbnRpbWVvdXRcIjoge1xuICAgICAgICAgICAgY29uc3QgZXZlbnROYW1lID0gcHJvcGVydHlOYW1lLnNsaWNlKDIpO1xuICAgICAgICAgICAgdGhpcy5yZXF1ZXN0LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLCBuZXh0VmFsdWUpO1xuICAgICAgICAgICAgcmV0dXJuIGludm9rZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgcmV0dXJuIGludm9rZSgpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgbWV0aG9kQ2FsbDogKFttZXRob2ROYW1lLCBhcmdzXSwgaW52b2tlKSA9PiB7XG4gICAgICAgIHN3aXRjaCAobWV0aG9kTmFtZSkge1xuICAgICAgICAgIGNhc2UgXCJvcGVuXCI6IHtcbiAgICAgICAgICAgIGNvbnN0IFttZXRob2QsIHVybF0gPSBhcmdzO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB1cmwgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgICAgdGhpcy5tZXRob2QgPSBcIkdFVFwiO1xuICAgICAgICAgICAgICB0aGlzLnVybCA9IHRvQWJzb2x1dGVVcmwobWV0aG9kKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRoaXMubWV0aG9kID0gbWV0aG9kO1xuICAgICAgICAgICAgICB0aGlzLnVybCA9IHRvQWJzb2x1dGVVcmwodXJsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMubG9nZ2VyID0gdGhpcy5sb2dnZXIuZXh0ZW5kKGAke3RoaXMubWV0aG9kfSAke3RoaXMudXJsLmhyZWZ9YCk7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKFwib3BlblwiLCB0aGlzLm1ldGhvZCwgdGhpcy51cmwuaHJlZik7XG4gICAgICAgICAgICByZXR1cm4gaW52b2tlKCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNhc2UgXCJhZGRFdmVudExpc3RlbmVyXCI6IHtcbiAgICAgICAgICAgIGNvbnN0IFtldmVudE5hbWUsIGxpc3RlbmVyXSA9IGFyZ3M7XG4gICAgICAgICAgICB0aGlzLnJlZ2lzdGVyRXZlbnQoZXZlbnROYW1lLCBsaXN0ZW5lcik7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKFwiYWRkRXZlbnRMaXN0ZW5lclwiLCBldmVudE5hbWUsIGxpc3RlbmVyKTtcbiAgICAgICAgICAgIHJldHVybiBpbnZva2UoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY2FzZSBcInNldFJlcXVlc3RIZWFkZXJcIjoge1xuICAgICAgICAgICAgY29uc3QgW25hbWUsIHZhbHVlXSA9IGFyZ3M7XG4gICAgICAgICAgICB0aGlzLnJlcXVlc3RIZWFkZXJzLnNldChuYW1lLCB2YWx1ZSk7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKFwic2V0UmVxdWVzdEhlYWRlclwiLCBuYW1lLCB2YWx1ZSk7XG4gICAgICAgICAgICByZXR1cm4gaW52b2tlKCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNhc2UgXCJzZW5kXCI6IHtcbiAgICAgICAgICAgIGNvbnN0IFtib2R5XSA9IGFyZ3M7XG4gICAgICAgICAgICB0aGlzLnJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcihcImxvYWRcIiwgKCkgPT4ge1xuICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMub25SZXNwb25zZSAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZldGNoUmVzcG9uc2UgPSBjcmVhdGVSZXNwb25zZShcbiAgICAgICAgICAgICAgICAgIHRoaXMucmVxdWVzdCxcbiAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgKiBUaGUgYHJlc3BvbnNlYCBwcm9wZXJ0eSBpcyB0aGUgcmlnaHQgd2F5IHRvIHJlYWRcbiAgICAgICAgICAgICAgICAgICogdGhlIGFtYmlndW91cyByZXNwb25zZSBib2R5LCBhcyB0aGUgcmVxdWVzdCdzIFwicmVzcG9uc2VUeXBlXCIgbWF5IGRpZmZlci5cbiAgICAgICAgICAgICAgICAgICogQHNlZSBodHRwczovL3hoci5zcGVjLndoYXR3Zy5vcmcvI3RoZS1yZXNwb25zZS1hdHRyaWJ1dGVcbiAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICB0aGlzLnJlcXVlc3QucmVzcG9uc2VcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIHRoaXMub25SZXNwb25zZS5jYWxsKHRoaXMsIHtcbiAgICAgICAgICAgICAgICAgIHJlc3BvbnNlOiBmZXRjaFJlc3BvbnNlLFxuICAgICAgICAgICAgICAgICAgaXNNb2NrZWRSZXNwb25zZTogdGhpc1trSXNSZXF1ZXN0SGFuZGxlZF0sXG4gICAgICAgICAgICAgICAgICByZXF1ZXN0OiBmZXRjaFJlcXVlc3QsXG4gICAgICAgICAgICAgICAgICByZXF1ZXN0SWQ6IHRoaXMucmVxdWVzdElkXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY29uc3QgcmVxdWVzdEJvZHkgPSB0eXBlb2YgYm9keSA9PT0gXCJzdHJpbmdcIiA/IGVuY29kZUJ1ZmZlcihib2R5KSA6IGJvZHk7XG4gICAgICAgICAgICBjb25zdCBmZXRjaFJlcXVlc3QgPSB0aGlzLnRvRmV0Y2hBcGlSZXF1ZXN0KHJlcXVlc3RCb2R5KTtcbiAgICAgICAgICAgIHRoaXNba0ZldGNoUmVxdWVzdF0gPSBmZXRjaFJlcXVlc3QuY2xvbmUoKTtcbiAgICAgICAgICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICAgICAgICAgICAgKHRoaXMub25SZXF1ZXN0Py5jYWxsKHRoaXMsIHtcbiAgICAgICAgICAgICAgICByZXF1ZXN0OiBmZXRjaFJlcXVlc3QsXG4gICAgICAgICAgICAgICAgcmVxdWVzdElkOiB0aGlzLnJlcXVlc3RJZFxuICAgICAgICAgICAgICB9KSB8fCBQcm9taXNlLnJlc29sdmUoKSkuZmluYWxseSgoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzW2tJc1JlcXVlc3RIYW5kbGVkXSkge1xuICAgICAgICAgICAgICAgICAgdGhpcy5sb2dnZXIuaW5mbyhcInJlcXVlc3QgY2FsbGJhY2sgc2V0dGxlZCBidXQgcmVxdWVzdCBoYXMgbm90IGJlZW4gaGFuZGxlZCAocmVhZHlzdGF0ZSAlZCksIHBlcmZvcm1pbmcgYXMtaXMuLi5cIiwgdGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUpO1xuICAgICAgICAgICAgICAgICAgaWYgKElTX05PREUyKSB0aGlzLnJlcXVlc3Quc2V0UmVxdWVzdEhlYWRlcihJTlRFUk5BTF9SRVFVRVNUX0lEX0hFQURFUl9OQU1FLCB0aGlzLnJlcXVlc3RJZCk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gaW52b2tlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICByZXR1cm4gaW52b2tlKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgICBkZWZpbmUodGhpcy5yZXF1ZXN0LCBcInVwbG9hZFwiLCBjcmVhdGVQcm94eSh0aGlzLnJlcXVlc3QudXBsb2FkLCB7XG4gICAgICBzZXRQcm9wZXJ0eTogKFtwcm9wZXJ0eU5hbWUsIG5leHRWYWx1ZV0sIGludm9rZSkgPT4ge1xuICAgICAgICBzd2l0Y2ggKHByb3BlcnR5TmFtZSkge1xuICAgICAgICAgIGNhc2UgXCJvbmxvYWRzdGFydFwiOlxuICAgICAgICAgIGNhc2UgXCJvbnByb2dyZXNzXCI6XG4gICAgICAgICAgY2FzZSBcIm9uYWJvYXJ0XCI6XG4gICAgICAgICAgY2FzZSBcIm9uZXJyb3JcIjpcbiAgICAgICAgICBjYXNlIFwib25sb2FkXCI6XG4gICAgICAgICAgY2FzZSBcIm9udGltZW91dFwiOlxuICAgICAgICAgIGNhc2UgXCJvbmxvYWRlbmRcIjoge1xuICAgICAgICAgICAgY29uc3QgZXZlbnROYW1lID0gcHJvcGVydHlOYW1lLnNsaWNlKDIpO1xuICAgICAgICAgICAgdGhpcy5yZWdpc3RlclVwbG9hZEV2ZW50KGV2ZW50TmFtZSwgbmV4dFZhbHVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGludm9rZSgpO1xuICAgICAgfSxcbiAgICAgIG1ldGhvZENhbGw6IChbbWV0aG9kTmFtZSwgYXJnc10sIGludm9rZSkgPT4ge1xuICAgICAgICBzd2l0Y2ggKG1ldGhvZE5hbWUpIHtcbiAgICAgICAgICBjYXNlIFwiYWRkRXZlbnRMaXN0ZW5lclwiOiB7XG4gICAgICAgICAgICBjb25zdCBbZXZlbnROYW1lLCBsaXN0ZW5lcl0gPSBhcmdzO1xuICAgICAgICAgICAgdGhpcy5yZWdpc3RlclVwbG9hZEV2ZW50KGV2ZW50TmFtZSwgbGlzdGVuZXIpO1xuICAgICAgICAgICAgdGhpcy5sb2dnZXIuaW5mbyhcInVwbG9hZC5hZGRFdmVudExpc3RlbmVyXCIsIGV2ZW50TmFtZSwgbGlzdGVuZXIpO1xuICAgICAgICAgICAgcmV0dXJuIGludm9rZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pKTtcbiAgfVxuICByZWdpc3RlckV2ZW50KGV2ZW50TmFtZSwgbGlzdGVuZXIpIHtcbiAgICBjb25zdCBuZXh0RXZlbnRzID0gKHRoaXMuZXZlbnRzLmdldChldmVudE5hbWUpIHx8IFtdKS5jb25jYXQobGlzdGVuZXIpO1xuICAgIHRoaXMuZXZlbnRzLnNldChldmVudE5hbWUsIG5leHRFdmVudHMpO1xuICAgIHRoaXMubG9nZ2VyLmluZm8oJ3JlZ2lzdGVyZWQgZXZlbnQgXCIlc1wiJywgZXZlbnROYW1lLCBsaXN0ZW5lcik7XG4gIH1cbiAgcmVnaXN0ZXJVcGxvYWRFdmVudChldmVudE5hbWUsIGxpc3RlbmVyKSB7XG4gICAgY29uc3QgbmV4dEV2ZW50cyA9ICh0aGlzLnVwbG9hZEV2ZW50cy5nZXQoZXZlbnROYW1lKSB8fCBbXSkuY29uY2F0KGxpc3RlbmVyKTtcbiAgICB0aGlzLnVwbG9hZEV2ZW50cy5zZXQoZXZlbnROYW1lLCBuZXh0RXZlbnRzKTtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKCdyZWdpc3RlcmVkIHVwbG9hZCBldmVudCBcIiVzXCInLCBldmVudE5hbWUsIGxpc3RlbmVyKTtcbiAgfVxuICAvKipcbiAgKiBSZXNwb25kcyB0byB0aGUgY3VycmVudCByZXF1ZXN0IHdpdGggdGhlIGdpdmVuXG4gICogRmV0Y2ggQVBJIGBSZXNwb25zZWAgaW5zdGFuY2UuXG4gICovXG4gIGFzeW5jIHJlc3BvbmRXaXRoKHJlc3BvbnNlKSB7XG4gICAgdGhpc1trSXNSZXF1ZXN0SGFuZGxlZF0gPSB0cnVlO1xuICAgIGlmICh0aGlzW2tGZXRjaFJlcXVlc3RdKSB7XG4gICAgICBjb25zdCB0b3RhbFJlcXVlc3RCb2R5TGVuZ3RoID0gYXdhaXQgZ2V0Qm9keUJ5dGVMZW5ndGgodGhpc1trRmV0Y2hSZXF1ZXN0XSk7XG4gICAgICB0aGlzLnRyaWdnZXIoXCJsb2Fkc3RhcnRcIiwgdGhpcy5yZXF1ZXN0LnVwbG9hZCwge1xuICAgICAgICBsb2FkZWQ6IDAsXG4gICAgICAgIHRvdGFsOiB0b3RhbFJlcXVlc3RCb2R5TGVuZ3RoXG4gICAgICB9KTtcbiAgICAgIHRoaXMudHJpZ2dlcihcInByb2dyZXNzXCIsIHRoaXMucmVxdWVzdC51cGxvYWQsIHtcbiAgICAgICAgbG9hZGVkOiB0b3RhbFJlcXVlc3RCb2R5TGVuZ3RoLFxuICAgICAgICB0b3RhbDogdG90YWxSZXF1ZXN0Qm9keUxlbmd0aFxuICAgICAgfSk7XG4gICAgICB0aGlzLnRyaWdnZXIoXCJsb2FkXCIsIHRoaXMucmVxdWVzdC51cGxvYWQsIHtcbiAgICAgICAgbG9hZGVkOiB0b3RhbFJlcXVlc3RCb2R5TGVuZ3RoLFxuICAgICAgICB0b3RhbDogdG90YWxSZXF1ZXN0Qm9keUxlbmd0aFxuICAgICAgfSk7XG4gICAgICB0aGlzLnRyaWdnZXIoXCJsb2FkZW5kXCIsIHRoaXMucmVxdWVzdC51cGxvYWQsIHtcbiAgICAgICAgbG9hZGVkOiB0b3RhbFJlcXVlc3RCb2R5TGVuZ3RoLFxuICAgICAgICB0b3RhbDogdG90YWxSZXF1ZXN0Qm9keUxlbmd0aFxuICAgICAgfSk7XG4gICAgfVxuICAgIHRoaXMubG9nZ2VyLmluZm8oXCJyZXNwb25kaW5nIHdpdGggYSBtb2NrZWQgcmVzcG9uc2U6ICVkICVzXCIsIHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2Uuc3RhdHVzVGV4dCk7XG4gICAgZGVmaW5lKHRoaXMucmVxdWVzdCwgXCJzdGF0dXNcIiwgcmVzcG9uc2Uuc3RhdHVzKTtcbiAgICBkZWZpbmUodGhpcy5yZXF1ZXN0LCBcInN0YXR1c1RleHRcIiwgcmVzcG9uc2Uuc3RhdHVzVGV4dCk7XG4gICAgZGVmaW5lKHRoaXMucmVxdWVzdCwgXCJyZXNwb25zZVVSTFwiLCB0aGlzLnVybC5ocmVmKTtcbiAgICB0aGlzLnJlcXVlc3QuZ2V0UmVzcG9uc2VIZWFkZXIgPSBuZXcgUHJveHkodGhpcy5yZXF1ZXN0LmdldFJlc3BvbnNlSGVhZGVyLCB7IGFwcGx5OiAoXywgX18sIGFyZ3MpID0+IHtcbiAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJnZXRSZXNwb25zZUhlYWRlclwiLCBhcmdzWzBdKTtcbiAgICAgIGlmICh0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSA8IHRoaXMucmVxdWVzdC5IRUFERVJTX1JFQ0VJVkVEKSB7XG4gICAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJoZWFkZXJzIG5vdCByZWNlaXZlZCB5ZXQsIHJldHVybmluZyBudWxsXCIpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGhlYWRlclZhbHVlID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoYXJnc1swXSk7XG4gICAgICB0aGlzLmxvZ2dlci5pbmZvKCdyZXNvbHZlZCByZXNwb25zZSBoZWFkZXIgXCIlc1wiIHRvJywgYXJnc1swXSwgaGVhZGVyVmFsdWUpO1xuICAgICAgcmV0dXJuIGhlYWRlclZhbHVlO1xuICAgIH0gfSk7XG4gICAgdGhpcy5yZXF1ZXN0LmdldEFsbFJlc3BvbnNlSGVhZGVycyA9IG5ldyBQcm94eSh0aGlzLnJlcXVlc3QuZ2V0QWxsUmVzcG9uc2VIZWFkZXJzLCB7IGFwcGx5OiAoKSA9PiB7XG4gICAgICB0aGlzLmxvZ2dlci5pbmZvKFwiZ2V0QWxsUmVzcG9uc2VIZWFkZXJzXCIpO1xuICAgICAgaWYgKHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlIDwgdGhpcy5yZXF1ZXN0LkhFQURFUlNfUkVDRUlWRUQpIHtcbiAgICAgICAgdGhpcy5sb2dnZXIuaW5mbyhcImhlYWRlcnMgbm90IHJlY2VpdmVkIHlldCwgcmV0dXJuaW5nIGVtcHR5IHN0cmluZ1wiKTtcbiAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICB9XG4gICAgICBjb25zdCBhbGxIZWFkZXJzID0gQXJyYXkuZnJvbShyZXNwb25zZS5oZWFkZXJzLmVudHJpZXMoKSkubWFwKChbaGVhZGVyTmFtZSwgaGVhZGVyVmFsdWVdKSA9PiB7XG4gICAgICAgIHJldHVybiBgJHtoZWFkZXJOYW1lfTogJHtoZWFkZXJWYWx1ZX1gO1xuICAgICAgfSkuam9pbihcIlxcclxcblwiKTtcbiAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJyZXNvbHZlZCBhbGwgcmVzcG9uc2UgaGVhZGVycyB0b1wiLCBhbGxIZWFkZXJzKTtcbiAgICAgIHJldHVybiBhbGxIZWFkZXJzO1xuICAgIH0gfSk7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnRpZXModGhpcy5yZXF1ZXN0LCB7XG4gICAgICByZXNwb25zZToge1xuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IGZhbHNlLFxuICAgICAgICBnZXQ6ICgpID0+IHRoaXMucmVzcG9uc2VcbiAgICAgIH0sXG4gICAgICByZXNwb25zZVRleHQ6IHtcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiBmYWxzZSxcbiAgICAgICAgZ2V0OiAoKSA9PiB0aGlzLnJlc3BvbnNlVGV4dFxuICAgICAgfSxcbiAgICAgIHJlc3BvbnNlWE1MOiB7XG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogZmFsc2UsXG4gICAgICAgIGdldDogKCkgPT4gdGhpcy5yZXNwb25zZVhNTFxuICAgICAgfVxuICAgIH0pO1xuICAgIGNvbnN0IHRvdGFsUmVzcG9uc2VCb2R5TGVuZ3RoID0gYXdhaXQgZ2V0Qm9keUJ5dGVMZW5ndGgocmVzcG9uc2UuY2xvbmUoKSk7XG4gICAgdGhpcy5sb2dnZXIuaW5mbyhcImNhbGN1bGF0ZWQgcmVzcG9uc2UgYm9keSBsZW5ndGhcIiwgdG90YWxSZXNwb25zZUJvZHlMZW5ndGgpO1xuICAgIHRoaXMudHJpZ2dlcihcImxvYWRzdGFydFwiLCB0aGlzLnJlcXVlc3QsIHtcbiAgICAgIGxvYWRlZDogMCxcbiAgICAgIHRvdGFsOiB0b3RhbFJlc3BvbnNlQm9keUxlbmd0aFxuICAgIH0pO1xuICAgIHRoaXMuc2V0UmVhZHlTdGF0ZSh0aGlzLnJlcXVlc3QuSEVBREVSU19SRUNFSVZFRCk7XG4gICAgdGhpcy5zZXRSZWFkeVN0YXRlKHRoaXMucmVxdWVzdC5MT0FESU5HKTtcbiAgICBjb25zdCBmaW5hbGl6ZVJlc3BvbnNlID0gKCkgPT4ge1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbyhcImZpbmFsaXppbmcgdGhlIG1vY2tlZCByZXNwb25zZS4uLlwiKTtcbiAgICAgIHRoaXMuc2V0UmVhZHlTdGF0ZSh0aGlzLnJlcXVlc3QuRE9ORSk7XG4gICAgICB0aGlzLnRyaWdnZXIoXCJsb2FkXCIsIHRoaXMucmVxdWVzdCwge1xuICAgICAgICBsb2FkZWQ6IHRoaXMucmVzcG9uc2VCdWZmZXIuYnl0ZUxlbmd0aCxcbiAgICAgICAgdG90YWw6IHRvdGFsUmVzcG9uc2VCb2R5TGVuZ3RoXG4gICAgICB9KTtcbiAgICAgIHRoaXMudHJpZ2dlcihcImxvYWRlbmRcIiwgdGhpcy5yZXF1ZXN0LCB7XG4gICAgICAgIGxvYWRlZDogdGhpcy5yZXNwb25zZUJ1ZmZlci5ieXRlTGVuZ3RoLFxuICAgICAgICB0b3RhbDogdG90YWxSZXNwb25zZUJvZHlMZW5ndGhcbiAgICAgIH0pO1xuICAgIH07XG4gICAgaWYgKHJlc3BvbnNlLmJvZHkpIHtcbiAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJtb2NrZWQgcmVzcG9uc2UgaGFzIGJvZHksIHN0cmVhbWluZy4uLlwiKTtcbiAgICAgIGNvbnN0IHJlYWRlciA9IHJlc3BvbnNlLmJvZHkuZ2V0UmVhZGVyKCk7XG4gICAgICBjb25zdCByZWFkTmV4dFJlc3BvbnNlQm9keUNodW5rID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCB7IHZhbHVlLCBkb25lIH0gPSBhd2FpdCByZWFkZXIucmVhZCgpO1xuICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJyZXNwb25zZSBib2R5IHN0cmVhbSBkb25lIVwiKTtcbiAgICAgICAgICBmaW5hbGl6ZVJlc3BvbnNlKCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJyZWFkIHJlc3BvbnNlIGJvZHkgY2h1bms6XCIsIHZhbHVlKTtcbiAgICAgICAgICB0aGlzLnJlc3BvbnNlQnVmZmVyID0gY29uY2F0QXJyYXlCdWZmZXIodGhpcy5yZXNwb25zZUJ1ZmZlciwgdmFsdWUpO1xuICAgICAgICAgIHRoaXMudHJpZ2dlcihcInByb2dyZXNzXCIsIHRoaXMucmVxdWVzdCwge1xuICAgICAgICAgICAgbG9hZGVkOiB0aGlzLnJlc3BvbnNlQnVmZmVyLmJ5dGVMZW5ndGgsXG4gICAgICAgICAgICB0b3RhbDogdG90YWxSZXNwb25zZUJvZHlMZW5ndGhcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZWFkTmV4dFJlc3BvbnNlQm9keUNodW5rKCk7XG4gICAgICB9O1xuICAgICAgcmVhZE5leHRSZXNwb25zZUJvZHlDaHVuaygpO1xuICAgIH0gZWxzZSBmaW5hbGl6ZVJlc3BvbnNlKCk7XG4gIH1cbiAgcmVzcG9uc2VCdWZmZXJUb1RleHQoKSB7XG4gICAgcmV0dXJuIGRlY29kZUJ1ZmZlcih0aGlzLnJlc3BvbnNlQnVmZmVyKTtcbiAgfVxuICBnZXQgcmVzcG9uc2UoKSB7XG4gICAgdGhpcy5sb2dnZXIuaW5mbyhcImdldFJlc3BvbnNlIChyZXNwb25zZVR5cGU6ICVzKVwiLCB0aGlzLnJlcXVlc3QucmVzcG9uc2VUeXBlKTtcbiAgICBpZiAodGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUgIT09IHRoaXMucmVxdWVzdC5ET05FKSByZXR1cm4gbnVsbDtcbiAgICBzd2l0Y2ggKHRoaXMucmVxdWVzdC5yZXNwb25zZVR5cGUpIHtcbiAgICAgIGNhc2UgXCJqc29uXCI6IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VKc29uID0gcGFyc2VKc29uKHRoaXMucmVzcG9uc2VCdWZmZXJUb1RleHQoKSk7XG4gICAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJyZXNvbHZlZCByZXNwb25zZSBKU09OXCIsIHJlc3BvbnNlSnNvbik7XG4gICAgICAgIHJldHVybiByZXNwb25zZUpzb247XG4gICAgICB9XG4gICAgICBjYXNlIFwiYXJyYXlidWZmZXJcIjoge1xuICAgICAgICBjb25zdCBhcnJheUJ1ZmZlciA9IHRvQXJyYXlCdWZmZXIodGhpcy5yZXNwb25zZUJ1ZmZlcik7XG4gICAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJyZXNvbHZlZCByZXNwb25zZSBBcnJheUJ1ZmZlclwiLCBhcnJheUJ1ZmZlcik7XG4gICAgICAgIHJldHVybiBhcnJheUJ1ZmZlcjtcbiAgICAgIH1cbiAgICAgIGNhc2UgXCJibG9iXCI6IHtcbiAgICAgICAgY29uc3QgbWltZVR5cGUgPSB0aGlzLnJlcXVlc3QuZ2V0UmVzcG9uc2VIZWFkZXIoXCJDb250ZW50LVR5cGVcIikgfHwgXCJ0ZXh0L3BsYWluXCI7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQmxvYiA9IG5ldyBCbG9iKFt0aGlzLnJlc3BvbnNlQnVmZmVyVG9UZXh0KCldLCB7IHR5cGU6IG1pbWVUeXBlIH0pO1xuICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKFwicmVzb2x2ZWQgcmVzcG9uc2UgQmxvYiAobWltZSB0eXBlOiAlcylcIiwgcmVzcG9uc2VCbG9iLCBtaW1lVHlwZSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZUJsb2I7XG4gICAgICB9XG4gICAgICBkZWZhdWx0OiB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlVGV4dCA9IHRoaXMucmVzcG9uc2VCdWZmZXJUb1RleHQoKTtcbiAgICAgICAgdGhpcy5sb2dnZXIuaW5mbygncmVzb2x2aW5nIFwiJXNcIiByZXNwb25zZSB0eXBlIGFzIHRleHQnLCB0aGlzLnJlcXVlc3QucmVzcG9uc2VUeXBlLCByZXNwb25zZVRleHQpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2VUZXh0O1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBnZXQgcmVzcG9uc2VUZXh0KCkge1xuICAgIGludmFyaWFudCh0aGlzLnJlcXVlc3QucmVzcG9uc2VUeXBlID09PSBcIlwiIHx8IHRoaXMucmVxdWVzdC5yZXNwb25zZVR5cGUgPT09IFwidGV4dFwiLCBcIkludmFsaWRTdGF0ZUVycm9yOiBUaGUgb2JqZWN0IGlzIGluIGludmFsaWQgc3RhdGUuXCIpO1xuICAgIGlmICh0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSAhPT0gdGhpcy5yZXF1ZXN0LkxPQURJTkcgJiYgdGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUgIT09IHRoaXMucmVxdWVzdC5ET05FKSByZXR1cm4gXCJcIjtcbiAgICBjb25zdCByZXNwb25zZVRleHQgPSB0aGlzLnJlc3BvbnNlQnVmZmVyVG9UZXh0KCk7XG4gICAgdGhpcy5sb2dnZXIuaW5mbygnZ2V0UmVzcG9uc2VUZXh0OiBcIiVzXCInLCByZXNwb25zZVRleHQpO1xuICAgIHJldHVybiByZXNwb25zZVRleHQ7XG4gIH1cbiAgZ2V0IHJlc3BvbnNlWE1MKCkge1xuICAgIGludmFyaWFudCh0aGlzLnJlcXVlc3QucmVzcG9uc2VUeXBlID09PSBcIlwiIHx8IHRoaXMucmVxdWVzdC5yZXNwb25zZVR5cGUgPT09IFwiZG9jdW1lbnRcIiwgXCJJbnZhbGlkU3RhdGVFcnJvcjogVGhlIG9iamVjdCBpcyBpbiBpbnZhbGlkIHN0YXRlLlwiKTtcbiAgICBpZiAodGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUgIT09IHRoaXMucmVxdWVzdC5ET05FKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBjb250ZW50VHlwZSA9IHRoaXMucmVxdWVzdC5nZXRSZXNwb25zZUhlYWRlcihcIkNvbnRlbnQtVHlwZVwiKSB8fCBcIlwiO1xuICAgIGlmICh0eXBlb2YgRE9NUGFyc2VyID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJDYW5ub3QgcmV0cmlldmUgWE1MSHR0cFJlcXVlc3QgcmVzcG9uc2UgYm9keSBhcyBYTUw6IERPTVBhcnNlciBpcyBub3QgZGVmaW5lZC4gWW91IGFyZSBsaWtlbHkgdXNpbmcgYW4gZW52aXJvbm1lbnQgdGhhdCBpcyBub3QgYnJvd3NlciBvciBkb2VzIG5vdCBwb2x5ZmlsbCBicm93c2VyIGdsb2JhbHMgY29ycmVjdGx5LlwiKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAoaXNEb21QYXJzZXJTdXBwb3J0ZWRUeXBlKGNvbnRlbnRUeXBlKSkgcmV0dXJuIG5ldyBET01QYXJzZXIoKS5wYXJzZUZyb21TdHJpbmcodGhpcy5yZXNwb25zZUJ1ZmZlclRvVGV4dCgpLCBjb250ZW50VHlwZSk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgZXJyb3JXaXRoKGVycm9yMikge1xuICAgIHRoaXNba0lzUmVxdWVzdEhhbmRsZWRdID0gdHJ1ZTtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKFwicmVzcG9uZGluZyB3aXRoIGFuIGVycm9yXCIpO1xuICAgIHRoaXMuc2V0UmVhZHlTdGF0ZSh0aGlzLnJlcXVlc3QuRE9ORSk7XG4gICAgdGhpcy50cmlnZ2VyKFwiZXJyb3JcIiwgdGhpcy5yZXF1ZXN0KTtcbiAgICB0aGlzLnRyaWdnZXIoXCJsb2FkZW5kXCIsIHRoaXMucmVxdWVzdCk7XG4gIH1cbiAgLyoqXG4gICogVHJhbnNpdGlvbnMgdGhpcyByZXF1ZXN0J3MgYHJlYWR5U3RhdGVgIHRvIHRoZSBnaXZlbiBvbmUuXG4gICovXG4gIHNldFJlYWR5U3RhdGUobmV4dFJlYWR5U3RhdGUpIHtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKFwic2V0UmVhZHlTdGF0ZTogJWQgLT4gJWRcIiwgdGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUsIG5leHRSZWFkeVN0YXRlKTtcbiAgICBpZiAodGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUgPT09IG5leHRSZWFkeVN0YXRlKSB7XG4gICAgICB0aGlzLmxvZ2dlci5pbmZvKFwicmVhZHkgc3RhdGUgaWRlbnRpY2FsLCBza2lwcGluZyB0cmFuc2l0aW9uLi4uXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBkZWZpbmUodGhpcy5yZXF1ZXN0LCBcInJlYWR5U3RhdGVcIiwgbmV4dFJlYWR5U3RhdGUpO1xuICAgIHRoaXMubG9nZ2VyLmluZm8oXCJzZXQgcmVhZHlTdGF0ZSB0bzogJWRcIiwgbmV4dFJlYWR5U3RhdGUpO1xuICAgIGlmIChuZXh0UmVhZHlTdGF0ZSAhPT0gdGhpcy5yZXF1ZXN0LlVOU0VOVCkge1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbygndHJpZ2dlcmluZyBcInJlYWR5c3RhdGVjaGFuZ2VcIiBldmVudC4uLicpO1xuICAgICAgdGhpcy50cmlnZ2VyKFwicmVhZHlzdGF0ZWNoYW5nZVwiLCB0aGlzLnJlcXVlc3QpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgKiBUcmlnZ2VycyBnaXZlbiBldmVudCBvbiB0aGUgYFhNTEh0dHBSZXF1ZXN0YCBpbnN0YW5jZS5cbiAgKi9cbiAgdHJpZ2dlcihldmVudE5hbWUsIHRhcmdldCwgb3B0aW9ucykge1xuICAgIGNvbnN0IGNhbGxiYWNrID0gdGFyZ2V0W2BvbiR7ZXZlbnROYW1lfWBdO1xuICAgIGNvbnN0IGV2ZW50ID0gY3JlYXRlRXZlbnQodGFyZ2V0LCBldmVudE5hbWUsIG9wdGlvbnMpO1xuICAgIHRoaXMubG9nZ2VyLmluZm8oJ3RyaWdnZXIgXCIlc1wiJywgZXZlbnROYW1lLCBvcHRpb25zIHx8IFwiXCIpO1xuICAgIGlmICh0eXBlb2YgY2FsbGJhY2sgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbygnZm91bmQgYSBkaXJlY3QgXCIlc1wiIGNhbGxiYWNrLCBjYWxsaW5nLi4uJywgZXZlbnROYW1lKTtcbiAgICAgIGNhbGxiYWNrLmNhbGwodGFyZ2V0LCBldmVudCk7XG4gICAgfVxuICAgIGNvbnN0IGV2ZW50cyA9IHRhcmdldCBpbnN0YW5jZW9mIFhNTEh0dHBSZXF1ZXN0VXBsb2FkID8gdGhpcy51cGxvYWRFdmVudHMgOiB0aGlzLmV2ZW50cztcbiAgICBmb3IgKGNvbnN0IFtyZWdpc3RlcmVkRXZlbnROYW1lLCBsaXN0ZW5lcnNdIG9mIGV2ZW50cykgaWYgKHJlZ2lzdGVyZWRFdmVudE5hbWUgPT09IGV2ZW50TmFtZSkge1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbygnZm91bmQgJWQgbGlzdGVuZXIocykgZm9yIFwiJXNcIiBldmVudCwgY2FsbGluZy4uLicsIGxpc3RlbmVycy5sZW5ndGgsIGV2ZW50TmFtZSk7XG4gICAgICBsaXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IGxpc3RlbmVyLmNhbGwodGFyZ2V0LCBldmVudCkpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgKiBDb252ZXJ0cyB0aGlzIGBYTUxIdHRwUmVxdWVzdGAgaW5zdGFuY2UgaW50byBhIEZldGNoIEFQSSBgUmVxdWVzdGAgaW5zdGFuY2UuXG4gICovXG4gIHRvRmV0Y2hBcGlSZXF1ZXN0KGJvZHkpIHtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKFwiY29udmVydGluZyByZXF1ZXN0IHRvIGEgRmV0Y2ggQVBJIFJlcXVlc3QuLi5cIik7XG4gICAgY29uc3QgcmVzb2x2ZWRCb2R5ID0gYm9keSBpbnN0YW5jZW9mIERvY3VtZW50ID8gYm9keS5kb2N1bWVudEVsZW1lbnQuaW5uZXJUZXh0IDogYm9keTtcbiAgICBjb25zdCBmZXRjaFJlcXVlc3QgPSBuZXcgRmV0Y2hSZXF1ZXN0KHRoaXMudXJsLmhyZWYsIHtcbiAgICAgIG1ldGhvZDogdGhpcy5tZXRob2QsXG4gICAgICBoZWFkZXJzOiB0aGlzLnJlcXVlc3RIZWFkZXJzLFxuICAgICAgY3JlZGVudGlhbHM6IHRoaXMucmVxdWVzdC53aXRoQ3JlZGVudGlhbHMgPyBcImluY2x1ZGVcIiA6IFwic2FtZS1vcmlnaW5cIixcbiAgICAgIGJvZHk6IFtcIkdFVFwiLCBcIkhFQURcIl0uaW5jbHVkZXModGhpcy5tZXRob2QudG9VcHBlckNhc2UoKSkgPyBudWxsIDogcmVzb2x2ZWRCb2R5XG4gICAgfSk7XG4gICAgZGVmaW5lKGZldGNoUmVxdWVzdCwgXCJoZWFkZXJzXCIsIGNyZWF0ZVByb3h5KGZldGNoUmVxdWVzdC5oZWFkZXJzLCB7IG1ldGhvZENhbGw6IChbbWV0aG9kTmFtZSwgYXJnc10sIGludm9rZSkgPT4ge1xuICAgICAgc3dpdGNoIChtZXRob2ROYW1lKSB7XG4gICAgICAgIGNhc2UgXCJhcHBlbmRcIjpcbiAgICAgICAgY2FzZSBcInNldFwiOiB7XG4gICAgICAgICAgY29uc3QgW2hlYWRlck5hbWUsIGhlYWRlclZhbHVlXSA9IGFyZ3M7XG4gICAgICAgICAgdGhpcy5yZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoaGVhZGVyTmFtZSwgaGVhZGVyVmFsdWUpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgXCJkZWxldGVcIjoge1xuICAgICAgICAgIGNvbnN0IFtoZWFkZXJOYW1lXSA9IGFyZ3M7XG4gICAgICAgICAgY29uc29sZS53YXJuKGBYTUxIdHRwUmVxdWVzdDogQ2Fubm90IHJlbW92ZSBhIFwiJHtoZWFkZXJOYW1lfVwiIGhlYWRlciBmcm9tIHRoZSBGZXRjaCBBUEkgcmVwcmVzZW50YXRpb24gb2YgdGhlIFwiJHtmZXRjaFJlcXVlc3QubWV0aG9kfSAke2ZldGNoUmVxdWVzdC51cmx9XCIgcmVxdWVzdC4gWE1MSHR0cFJlcXVlc3QgaGVhZGVycyBjYW5ub3QgYmUgcmVtb3ZlZC5gKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGludm9rZSgpO1xuICAgIH0gfSkpO1xuICAgIHNldFJhd1JlcXVlc3QoZmV0Y2hSZXF1ZXN0LCB0aGlzLnJlcXVlc3QpO1xuICAgIHRoaXMubG9nZ2VyLmluZm8oXCJjb252ZXJ0ZWQgcmVxdWVzdCB0byBhIEZldGNoIEFQSSBSZXF1ZXN0IVwiLCBmZXRjaFJlcXVlc3QpO1xuICAgIHJldHVybiBmZXRjaFJlcXVlc3Q7XG4gIH1cbn07XG5mdW5jdGlvbiB0b0Fic29sdXRlVXJsKHVybCkge1xuICBpZiAodHlwZW9mIGxvY2F0aW9uID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gbmV3IFVSTCh1cmwpO1xuICByZXR1cm4gbmV3IFVSTCh1cmwudG9TdHJpbmcoKSwgbG9jYXRpb24uaHJlZik7XG59XG5mdW5jdGlvbiBkZWZpbmUodGFyZ2V0LCBwcm9wZXJ0eSwgdmFsdWUpIHtcbiAgUmVmbGVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIHByb3BlcnR5LCB7XG4gICAgd3JpdGFibGU6IHRydWUsXG4gICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICB2YWx1ZVxuICB9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVhNTEh0dHBSZXF1ZXN0UHJveHkoeyBlbWl0dGVyLCBsb2dnZXIgfSkge1xuICByZXR1cm4gbmV3IFByb3h5KGdsb2JhbFRoaXMuWE1MSHR0cFJlcXVlc3QsIHsgY29uc3RydWN0KHRhcmdldCwgYXJncywgbmV3VGFyZ2V0KSB7XG4gICAgbG9nZ2VyLmluZm8oXCJjb25zdHJ1Y3RlZCBuZXcgWE1MSHR0cFJlcXVlc3RcIik7XG4gICAgY29uc3Qgb3JpZ2luYWxSZXF1ZXN0ID0gUmVmbGVjdC5jb25zdHJ1Y3QodGFyZ2V0LCBhcmdzLCBuZXdUYXJnZXQpO1xuICAgIGNvbnN0IHByb3RvdHlwZURlc2NyaXB0b3JzID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModGFyZ2V0LnByb3RvdHlwZSk7XG4gICAgZm9yIChjb25zdCBwcm9wZXJ0eU5hbWUgaW4gcHJvdG90eXBlRGVzY3JpcHRvcnMpIFJlZmxlY3QuZGVmaW5lUHJvcGVydHkob3JpZ2luYWxSZXF1ZXN0LCBwcm9wZXJ0eU5hbWUsIHByb3RvdHlwZURlc2NyaXB0b3JzW3Byb3BlcnR5TmFtZV0pO1xuICAgIGNvbnN0IHhoclJlcXVlc3RDb250cm9sbGVyID0gbmV3IFhNTEh0dHBSZXF1ZXN0Q29udHJvbGxlcihvcmlnaW5hbFJlcXVlc3QsIGxvZ2dlcik7XG4gICAgeGhyUmVxdWVzdENvbnRyb2xsZXIub25SZXF1ZXN0ID0gYXN5bmMgZnVuY3Rpb24oeyByZXF1ZXN0LCByZXF1ZXN0SWQgfSkge1xuICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBSZXF1ZXN0Q29udHJvbGxlcihyZXF1ZXN0LCB7XG4gICAgICAgIHBhc3N0aHJvdWdoOiAoKSA9PiB7XG4gICAgICAgICAgdGhpcy5sb2dnZXIuaW5mbyhcIm5vIG1vY2tlZCByZXNwb25zZSByZWNlaXZlZCwgcGVyZm9ybWluZyByZXF1ZXN0IGFzLWlzLi4uXCIpO1xuICAgICAgICB9LFxuICAgICAgICByZXNwb25kV2l0aDogYXN5bmMgKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgaWYgKGlzUmVzcG9uc2VFcnJvcihyZXNwb25zZSkpIHtcbiAgICAgICAgICAgIHRoaXMuZXJyb3JXaXRoKC8qIEBfX1BVUkVfXyAqLyBuZXcgVHlwZUVycm9yKFwiTmV0d29yayBlcnJvclwiKSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGF3YWl0IHRoaXMucmVzcG9uZFdpdGgocmVzcG9uc2UpO1xuICAgICAgICB9LFxuICAgICAgICBlcnJvcldpdGg6IChyZWFzb24pID0+IHtcbiAgICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKFwicmVxdWVzdCBlcnJvcmVkIVwiLCB7IGVycm9yOiByZWFzb24gfSk7XG4gICAgICAgICAgaWYgKHJlYXNvbiBpbnN0YW5jZW9mIEVycm9yKSB0aGlzLmVycm9yV2l0aChyZWFzb24pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHRoaXMubG9nZ2VyLmluZm8oXCJhd2FpdGluZyBtb2NrZWQgcmVzcG9uc2UuLi5cIik7XG4gICAgICB0aGlzLmxvZ2dlci5pbmZvKCdlbWl0dGluZyB0aGUgXCJyZXF1ZXN0XCIgZXZlbnQgZm9yICVzIGxpc3RlbmVyKHMpLi4uJywgZW1pdHRlci5saXN0ZW5lckNvdW50KFwicmVxdWVzdFwiKSk7XG4gICAgICBhd2FpdCBoYW5kbGVSZXF1ZXN0KHtcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgcmVxdWVzdElkLFxuICAgICAgICBjb250cm9sbGVyLFxuICAgICAgICBlbWl0dGVyXG4gICAgICB9KTtcbiAgICB9O1xuICAgIHhoclJlcXVlc3RDb250cm9sbGVyLm9uUmVzcG9uc2UgPSBhc3luYyBmdW5jdGlvbih7IHJlc3BvbnNlLCBpc01vY2tlZFJlc3BvbnNlLCByZXF1ZXN0LCByZXF1ZXN0SWQgfSkge1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbygnZW1pdHRpbmcgdGhlIFwicmVzcG9uc2VcIiBldmVudCBmb3IgJXMgbGlzdGVuZXIocykuLi4nLCBlbWl0dGVyLmxpc3RlbmVyQ291bnQoXCJyZXNwb25zZVwiKSk7XG4gICAgICBlbWl0dGVyLmVtaXQoXCJyZXNwb25zZVwiLCB7XG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgICBpc01vY2tlZFJlc3BvbnNlLFxuICAgICAgICByZXF1ZXN0LFxuICAgICAgICByZXF1ZXN0SWRcbiAgICAgIH0pO1xuICAgIH07XG4gICAgcmV0dXJuIHhoclJlcXVlc3RDb250cm9sbGVyLnJlcXVlc3Q7XG4gIH0gfSk7XG59XG52YXIgWE1MSHR0cFJlcXVlc3RJbnRlcmNlcHRvciA9IGNsYXNzIFhNTEh0dHBSZXF1ZXN0SW50ZXJjZXB0b3IyIGV4dGVuZHMgSW50ZXJjZXB0b3Ige1xuICBzdGF0aWMge1xuICAgIHRoaXMuc3ltYm9sID0gLyogQF9fUFVSRV9fICovIFN5bWJvbC5mb3IoXCJ4aHItaW50ZXJjZXB0b3JcIik7XG4gIH1cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoWE1MSHR0cFJlcXVlc3RJbnRlcmNlcHRvcjIuc3ltYm9sKTtcbiAgfVxuICBjaGVja0Vudmlyb25tZW50KCkge1xuICAgIHJldHVybiBoYXNDb25maWd1cmFibGVHbG9iYWwoXCJYTUxIdHRwUmVxdWVzdFwiKTtcbiAgfVxuICBzZXR1cCgpIHtcbiAgICBjb25zdCBsb2dnZXIgPSB0aGlzLmxvZ2dlci5leHRlbmQoXCJzZXR1cFwiKTtcbiAgICBsb2dnZXIuaW5mbyhcInBhdGNoaW5nIGdsb2JhbCBYTUxIdHRwUmVxdWVzdC4uLlwiKTtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMucHVzaChwYXRjaGVzUmVnaXN0cnkuYXBwbHlQYXRjaChnbG9iYWxUaGlzLCBcIlhNTEh0dHBSZXF1ZXN0XCIsICgpID0+IHtcbiAgICAgIHJldHVybiBjcmVhdGVYTUxIdHRwUmVxdWVzdFByb3h5KHtcbiAgICAgICAgZW1pdHRlcjogdGhpcy5lbWl0dGVyLFxuICAgICAgICBsb2dnZXI6IHRoaXMubG9nZ2VyXG4gICAgICB9KTtcbiAgICB9KSk7XG4gICAgbG9nZ2VyLmluZm8oXCJnbG9iYWwgWE1MSHR0cFJlcXVlc3QgcGF0Y2hlZCFcIiwgZ2xvYmFsVGhpcy5YTUxIdHRwUmVxdWVzdC5uYW1lKTtcbiAgfVxufTtcblxuLy8gc3JjL2Jyb3dzZXIvc291cmNlcy9mYWxsYmFjay1odHRwLXNvdXJjZS50c1xuaW1wb3J0IHsgSW50ZXJjZXB0b3JTb3VyY2UgfSBmcm9tICcuLi9jb3JlL2V4cGVyaW1lbnRhbC9zb3VyY2VzL2ludGVyY2VwdG9yLXNvdXJjZS5tanMnO1xuaW1wb3J0IHsgZGV2VXRpbHMgYXMgZGV2VXRpbHM0IH0gZnJvbSAnLi4vY29yZS91dGlscy9pbnRlcm5hbC9kZXZVdGlscy5tanMnO1xudmFyIEZhbGxiYWNrSHR0cFNvdXJjZSA9IGNsYXNzIGV4dGVuZHMgSW50ZXJjZXB0b3JTb3VyY2Uge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgc3VwZXIoe1xuICAgICAgaW50ZXJjZXB0b3JzOiBbbmV3IFhNTEh0dHBSZXF1ZXN0SW50ZXJjZXB0b3IoKSwgbmV3IEZldGNoSW50ZXJjZXB0b3IoKV1cbiAgICB9KTtcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICB9XG4gIG9wdGlvbnM7XG4gIGVuYWJsZSgpIHtcbiAgICBzdXBlci5lbmFibGUoKTtcbiAgICBpZiAoIXRoaXMub3B0aW9ucy5xdWlldCkge1xuICAgICAgdGhpcy4jcHJpbnRTdGFydE1lc3NhZ2UoKTtcbiAgICB9XG4gIH1cbiAgZGlzYWJsZSgpIHtcbiAgICBzdXBlci5kaXNhYmxlKCk7XG4gICAgaWYgKCF0aGlzLm9wdGlvbnMucXVpZXQpIHtcbiAgICAgIHRoaXMuI3ByaW50U3RvcE1lc3NhZ2UoKTtcbiAgICB9XG4gIH1cbiAgI3ByaW50U3RhcnRNZXNzYWdlKCkge1xuICAgIGNvbnNvbGUuZ3JvdXBDb2xsYXBzZWQoXG4gICAgICBgJWMke2RldlV0aWxzNC5mb3JtYXRNZXNzYWdlKFwiTW9ja2luZyBlbmFibGVkIChmYWxsYmFjayBtb2RlKS5cIil9YCxcbiAgICAgIFwiY29sb3I6b3JhbmdlcmVkO2ZvbnQtd2VpZ2h0OmJvbGQ7XCJcbiAgICApO1xuICAgIGNvbnNvbGUubG9nKFxuICAgICAgXCIlY0RvY3VtZW50YXRpb246ICVjaHR0cHM6Ly9tc3dqcy5pby9kb2NzXCIsXG4gICAgICBcImZvbnQtd2VpZ2h0OmJvbGRcIixcbiAgICAgIFwiZm9udC13ZWlnaHQ6bm9ybWFsXCJcbiAgICApO1xuICAgIGNvbnNvbGUubG9nKFwiRm91bmQgYW4gaXNzdWU/IGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzXCIpO1xuICAgIGNvbnNvbGUuZ3JvdXBFbmQoKTtcbiAgfVxuICAjcHJpbnRTdG9wTWVzc2FnZSgpIHtcbiAgICBjb25zb2xlLmxvZyhcbiAgICAgIGAlYyR7ZGV2VXRpbHM0LmZvcm1hdE1lc3NhZ2UoXCJNb2NraW5nIGRpc2FibGVkLlwiKX1gLFxuICAgICAgXCJjb2xvcjpvcmFuZ2VyZWQ7Zm9udC13ZWlnaHQ6Ym9sZDtcIlxuICAgICk7XG4gIH1cbn07XG5cbi8vIHNyYy9icm93c2VyL3NldHVwLXdvcmtlci50c1xudmFyIERFRkFVTFRfV09SS0VSX1VSTCA9IFwiL21vY2tTZXJ2aWNlV29ya2VyLmpzXCI7XG5mdW5jdGlvbiBzZXR1cFdvcmtlciguLi5oYW5kbGVycykge1xuICBpbnZhcmlhbnQoXG4gICAgIWlzTm9kZVByb2Nlc3MoKSxcbiAgICBkZXZVdGlsczUuZm9ybWF0TWVzc2FnZShcbiAgICAgIFwiRmFpbGVkIHRvIGV4ZWN1dGUgYHNldHVwV29ya2VyYCBpbiBhIG5vbi1icm93c2VyIGVudmlyb25tZW50XCJcbiAgICApXG4gICk7XG4gIGNvbnN0IG5ldHdvcmsgPSBkZWZpbmVOZXR3b3JrKHtcbiAgICBzb3VyY2VzOiBbXSxcbiAgICBoYW5kbGVyc1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBhc3luYyBzdGFydChvcHRpb25zKSB7XG4gICAgICBpZiAob3B0aW9ucz8ud2FpdFVudGlsUmVhZHkgIT0gbnVsbCkge1xuICAgICAgICBkZXZVdGlsczUud2FybihcbiAgICAgICAgICBgVGhlIFwid2FpdFVudGlsUmVhZHlcIiBvcHRpb24gaGFzIGJlZW4gZGVwcmVjYXRlZC4gUGxlYXNlIHJlbW92ZSBpdCBmcm9tIHRoaXMgXCJ3b3JrZXIuc3RhcnQoKVwiIGNhbGwuIEZvbGxvdyB0aGUgcmVjb21tZW5kZWQgQnJvd3NlciBpbnRlZ3JhdGlvbiAoaHR0cHM6Ly9tc3dqcy5pby9kb2NzL2ludGVncmF0aW9ucy9icm93c2VyKSB0byBlbGltaW5hdGUgYW55IHJhY2UgY29uZGl0aW9ucyBiZXR3ZWVuIHRoZSBTZXJ2aWNlIFdvcmtlciByZWdpc3RyYXRpb24gYW5kIGFueSByZXF1ZXN0cyBtYWRlIGJ5IHlvdXIgYXBwbGljYXRpb24gb24gaW5pdGlhbCByZW5kZXIuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYgKG5ldHdvcmsucmVhZHlTdGF0ZSA9PT0gTmV0d29ya1JlYWR5U3RhdGUuRU5BQkxFRCkge1xuICAgICAgICBkZXZVdGlsczUud2FybihcbiAgICAgICAgICAnRm91bmQgYSByZWR1bmRhbnQgXCJ3b3JrZXIuc3RhcnQoKVwiIGNhbGwuIE5vdGUgdGhhdCBzdGFydGluZyB0aGUgd29ya2VyIHdoaWxlIG1vY2tpbmcgaXMgYWxyZWFkeSBlbmFibGVkIHdpbGwgaGF2ZSBubyBlZmZlY3QuIENvbnNpZGVyIHJlbW92aW5nIHRoaXMgXCJ3b3JrZXIuc3RhcnQoKVwiIGNhbGwuJ1xuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBodHRwU291cmNlID0gc3VwcG9ydHNTZXJ2aWNlV29ya2VyKCkgPyBhd2FpdCBTZXJ2aWNlV29ya2VyU291cmNlLmZyb20oe1xuICAgICAgICBzZXJ2aWNlV29ya2VyOiB7XG4gICAgICAgICAgdXJsOiBvcHRpb25zPy5zZXJ2aWNlV29ya2VyPy51cmw/LnRvU3RyaW5nKCkgfHwgREVGQVVMVF9XT1JLRVJfVVJMLFxuICAgICAgICAgIG9wdGlvbnM6IG9wdGlvbnM/LnNlcnZpY2VXb3JrZXI/Lm9wdGlvbnNcbiAgICAgICAgfSxcbiAgICAgICAgZmluZFdvcmtlcjogb3B0aW9ucz8uZmluZFdvcmtlcixcbiAgICAgICAgcXVpZXQ6IG9wdGlvbnM/LnF1aWV0XG4gICAgICB9KSA6IG5ldyBGYWxsYmFja0h0dHBTb3VyY2Uoe1xuICAgICAgICBxdWlldDogb3B0aW9ucz8ucXVpZXRcbiAgICAgIH0pO1xuICAgICAgbmV0d29yay5jb25maWd1cmUoe1xuICAgICAgICBzb3VyY2VzOiBbXG4gICAgICAgICAgaHR0cFNvdXJjZSxcbiAgICAgICAgICBuZXcgSW50ZXJjZXB0b3JTb3VyY2UyKHtcbiAgICAgICAgICAgIGludGVyY2VwdG9yczogW25ldyBXZWJTb2NrZXRJbnRlcmNlcHRvcigpXVxuICAgICAgICAgIH0pXG4gICAgICAgIF0sXG4gICAgICAgIG9uVW5oYW5kbGVkRnJhbWU6IGZyb21MZWdhY3lPblVuaGFuZGxlZFJlcXVlc3QoKCkgPT4ge1xuICAgICAgICAgIHJldHVybiBvcHRpb25zPy5vblVuaGFuZGxlZFJlcXVlc3QgfHwgXCJ3YXJuXCI7XG4gICAgICAgIH0pLFxuICAgICAgICBjb250ZXh0OiB7XG4gICAgICAgICAgcXVpZXQ6IG9wdGlvbnM/LnF1aWV0XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgYXdhaXQgbmV0d29yay5lbmFibGUoKTtcbiAgICAgIGlmIChodHRwU291cmNlIGluc3RhbmNlb2YgU2VydmljZVdvcmtlclNvdXJjZSkge1xuICAgICAgICBjb25zdCBbLCByZWdpc3RyYXRpb25dID0gYXdhaXQgaHR0cFNvdXJjZS53b3JrZXJQcm9taXNlO1xuICAgICAgICByZXR1cm4gcmVnaXN0cmF0aW9uO1xuICAgICAgfVxuICAgIH0sXG4gICAgc3RvcCgpIHtcbiAgICAgIGlmIChuZXR3b3JrLnJlYWR5U3RhdGUgPT09IE5ldHdvcmtSZWFkeVN0YXRlLkRJU0FCTEVEKSB7XG4gICAgICAgIGRldlV0aWxzNS53YXJuKFxuICAgICAgICAgIGBGb3VuZCBhIHJlZHVuZGFudCBcIndvcmtlci5zdG9wKClcIiBjYWxsLiBOb3RpY2UgdGhhdCBzdG9wcGluZyB0aGUgd29ya2VyIGFmdGVyIGl0IGhhcyBhbHJlYWR5IGJlZW4gc3RvcHBlZCBoYXMgbm8gZWZmZWN0LiBDb25zaWRlciByZW1vdmluZyB0aGlzIFwid29ya2VyLnN0b3AoKVwiIGNhbGwuYFxuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBuZXR3b3JrLmRpc2FibGUoKTtcbiAgICAgIHdpbmRvdy5wb3N0TWVzc2FnZSh7IHR5cGU6IFwibXN3L3dvcmtlcjpzdG9wXCIgfSk7XG4gICAgfSxcbiAgICBldmVudHM6IG5ldHdvcmsuZXZlbnRzLFxuICAgIHVzZTogbmV0d29yay51c2UuYmluZChuZXR3b3JrKSxcbiAgICByZXNldEhhbmRsZXJzOiBuZXR3b3JrLnJlc2V0SGFuZGxlcnMuYmluZChuZXR3b3JrKSxcbiAgICByZXN0b3JlSGFuZGxlcnM6IG5ldHdvcmsucmVzdG9yZUhhbmRsZXJzLmJpbmQobmV0d29yayksXG4gICAgbGlzdEhhbmRsZXJzOiBuZXR3b3JrLmxpc3RIYW5kbGVycy5iaW5kKG5ldHdvcmspXG4gIH07XG59XG52YXIgU2V0dXBXb3JrZXJBcGkgPSBjbGFzcyB7XG4gIHN0YXJ0O1xuICBzdG9wO1xuICB1c2U7XG4gIHJlc2V0SGFuZGxlcnM7XG4gIHJlc3RvcmVIYW5kbGVycztcbiAgbGlzdEhhbmRsZXJzO1xuICBldmVudHM7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIGNvbnN0IHdvcmtlciA9IHNldHVwV29ya2VyKCk7XG4gICAgdGhpcy5zdGFydCA9IHdvcmtlci5zdGFydC5iaW5kKHdvcmtlcik7XG4gICAgdGhpcy5zdG9wID0gd29ya2VyLnN0b3AuYmluZCh3b3JrZXIpO1xuICAgIHRoaXMudXNlID0gd29ya2VyLnVzZS5iaW5kKHdvcmtlcik7XG4gICAgdGhpcy5yZXNldEhhbmRsZXJzID0gd29ya2VyLnJlc2V0SGFuZGxlcnMuYmluZCh3b3JrZXIpO1xuICAgIHRoaXMucmVzdG9yZUhhbmRsZXJzID0gd29ya2VyLnJlc3RvcmVIYW5kbGVycy5iaW5kKHdvcmtlcik7XG4gICAgdGhpcy5saXN0SGFuZGxlcnMgPSB3b3JrZXIubGlzdEhhbmRsZXJzLmJpbmQod29ya2VyKTtcbiAgICB0aGlzLmV2ZW50cyA9IHdvcmtlci5ldmVudHM7XG4gIH1cbn07XG5leHBvcnQge1xuICBTZXR1cFdvcmtlckFwaSxcbiAgc2V0dXBXb3JrZXJcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyXSwibWFwcGluZ3MiOiI7O0FBQ0EsSUFBTSxlQUFOLE1BQW1CO0NBQ2pCLFlBQVksVUFBVSxNQUFNO0VBQzFCLEtBQUssV0FBVztFQUNoQixLQUFLLE9BQU87RUFDWixLQUFLLFNBQVMsSUFBSUEsVUFBUTtDQUM1QjtDQUNBO0NBQ0E7Q0FDQTtBQUNGOzs7QUNQQSxJQUFNLG9CQUFOLGNBQWdDQyxhQUFXO0NBQ3pDO0NBQ0EsWUFBWSxNQUFNLE9BQU87RUFDdkIsTUFBTSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNuQixLQUFLLFFBQVE7Q0FDZjtBQUNGO0FBQ0EsSUFBTSxnQkFBTixNQUFvQjtDQUNsQjtDQUNBLGNBQWM7RUFDWixLQUFLLFVBQVUsSUFBSUMsVUFBUTtDQUM3QjtDQUNBLE1BQU0sTUFBTSxPQUFPO0VBQ2pCLE1BQU0sS0FBSyxRQUFRLGNBRWpCLElBQUksa0JBQWtCLFNBQVMsS0FBSyxDQUN0QztDQUNGO0NBQ0EsR0FBRyxNQUFNLFVBQVUsU0FBUztFQUMxQixLQUFLLFFBQVEsR0FBRyxNQUFNLFVBQVUsT0FBTztDQUN6QztDQUNBLFVBQVU7RUFDUixLQUFLLFFBQVEsbUJBQW1CO0NBQ2xDO0FBQ0Y7QUN0QkEsU0FBUyxvQkFBb0IsU0FBUztDQUNwQyxPQUFPLENBQUMsQ0FBQyxRQUFRLFFBQVEsSUFBSSxRQUFRLENBQUMsRUFBRSxTQUFTLGlCQUFpQjtBQUNwRTtBQUNBLFNBQVMsc0JBQXNCLFVBQVU7Q0FDdkMsT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTLFFBQVEsSUFBQSxpQkFBaUMsTUFBTTtBQUM1RjtBQUNBLFNBQVMsK0JBQStCLFNBQVM7Q0FDL0MsTUFBTSxlQUFlLFFBQVEsUUFBUSxJQUFJLFFBQVE7Q0FDakQsSUFBSSxjQUFjO0VBQ2hCLE1BQU0sbUJBQW1CLGFBQWEsUUFBUSwyQkFBMkIsRUFBRTtFQUMzRSxJQUFJLGtCQUNGLFFBQVEsUUFBUSxJQUFJLFVBQVUsZ0JBQWdCO09BRTlDLFFBQVEsUUFBUSxPQUFPLFFBQVE7Q0FFbkM7QUFDRjs7O0FDTEEsSUFBTSxlQUFOLGNBQTJCQyxhQUFXO0NBQ3BDO0NBQ0E7Q0FDQSxZQUFZLE1BQU0sTUFBTTtFQUN0QixNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ25CLEtBQUssWUFBWSxLQUFLO0VBQ3RCLEtBQUssVUFBVSxLQUFLO0NBQ3RCO0FBQ0Y7QUFDQSxJQUFNLGdCQUFOLGNBQTRCQSxhQUFXO0NBQ3JDO0NBQ0E7Q0FDQTtDQUNBLFlBQVksTUFBTSxNQUFNO0VBQ3RCLE1BQU0sR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDbkIsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxVQUFVLEtBQUs7RUFDcEIsS0FBSyxXQUFXLEtBQUs7Q0FDdkI7QUFDRjtBQUNBLElBQU0sMEJBQU4sY0FBc0NBLGFBQVc7Q0FDL0M7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxNQUFNLE1BQU07RUFDdEIsTUFBTSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNuQixLQUFLLFFBQVEsS0FBSztFQUNsQixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLFVBQVUsS0FBSztDQUN0QjtBQUNGO0FBQ0EsSUFBTSxtQkFBTixjQUErQixhQUFhO0NBQzFDLFlBQVksU0FBUztFQUNuQixNQUFNLEtBQUssUUFBUSxNQUFNQyxrQkFBZ0I7RUFDekMsTUFBTSxRQUFRO0dBQUU7R0FBSSxTQUFTLFFBQVE7RUFBUSxDQUFDO0NBQ2hEO0NBQ0EsWUFBWSxZQUFZO0VBQ3RCLE9BQU8sV0FBVyxrQkFBa0IsU0FBUztDQUMvQztDQUNBLE1BQU0sc0JBQXNCO0VBQzFCLE1BQU0sRUFBRSxZQUFZLEtBQUs7RUFDekIsTUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLEdBQUc7RUFDL0IsTUFBTSxZQUFZLFlBQVksR0FBRyxJQUFJLElBQUk7RUFDekMsTUFBTSxjQUFjLFFBQVEsUUFBUSxPQUFPLE9BQU8sTUFBTSxRQUFRLE1BQU0sQ0FBQyxDQUFDLEtBQUs7RUFVN0UsT0FBTyw0REFGcUU7O1dBTHJFLFFBQVEsT0FBTyxHQUFHLFVBQVU7O0VBRXJDLGNBQWMsMEJBQTBCLFlBQVk7O0lBRWxELEtBQ29GOztDQUd0RjtDQUNBLE1BQU0sUUFBUSxVQUFVLGtCQUFrQixtQkFBbUI7RUFDM0QsTUFBTSxFQUFFLElBQUksV0FBVyxZQUFZLEtBQUs7RUFDeEMsTUFBTSxzQkFBc0IsbUJBQW1CLFFBQVEsT0FBTyxRQUFRLE1BQU07RUFDNUUsS0FBSyxPQUFPLEtBQUssSUFBSSxhQUFhLGlCQUFpQjtHQUFFO0dBQVc7RUFBUSxDQUFDLENBQUM7RUFDMUUsSUFBSSxvQkFBb0IsT0FBTyxHQUFHO0dBQ2hDLEtBQUssT0FBTyxLQUFLLElBQUksYUFBYSxlQUFlO0lBQUU7SUFBVztHQUFRLENBQUMsQ0FBQztHQUN4RSxLQUFLLFlBQVk7R0FDakIsT0FBTztFQUNUO0VBQ0EsTUFBTSxDQUFDLGFBQWEsZ0JBQWdCLE1BQU1DLGNBQVk7R0FDcEQsT0FBTyxnQkFBZ0I7SUFDckI7SUFDQTtJQUNBO0lBQ0EsbUJBQW1CO0tBQ2pCLFNBQVMsbUJBQW1CLFNBQVMsU0FBUztLQUM5QyxPQUFPLG1CQUFtQjtJQUM1QjtHQUNGLENBQUM7RUFDSCxDQUFDO0VBQ0QsSUFBSSxlQUFlLE1BQU07R0FDdkIsSUFBSSxDQUFDLEtBQUssT0FBTyxLQUNmLElBQUksd0JBQXdCLHNCQUFzQjtJQUNoRCxPQUFPO0lBQ1A7SUFDQTtHQUNGLENBQUMsQ0FDSCxHQUFHO0lBQ0QsUUFBUSxNQUFNLFdBQVc7SUFDekIsU0FBUyxNQUNQLG9IQUNBLFFBQVEsUUFDUixRQUFRLEdBQ1Y7R0FDRjtHQUNBLEtBQUssVUFBVSxXQUFXO0dBQzFCLE9BQU87RUFDVDtFQUNBLElBQUksZ0JBQWdCLE1BQU07R0FDeEIsS0FBSyxPQUFPLEtBQ1YsSUFBSSxhQUFhLHFCQUFxQjtJQUNwQztJQUNBO0dBQ0YsQ0FBQyxDQUNIO0dBQ0EsTUFBTSw0QkFBNEIsTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLFdBQ2xELEtBQUssWUFBWSxJQUN0QixVQUFVLEtBQUssVUFBVSxLQUFLLENBQ2pDO0dBQ0EsS0FBSyxPQUFPLEtBQ1YsSUFBSSxhQUFhLGVBQWU7SUFDOUI7SUFDQTtHQUNGLENBQUMsQ0FDSDtHQUNBLE9BQU87RUFDVDtFQUNBLE1BQU0sRUFBRSxVQUFVLFNBQVMsaUJBQWlCO0VBQzVDLEtBQUssT0FBTyxLQUNWLElBQUksYUFBYSxpQkFBaUI7R0FDaEM7R0FDQTtFQUNGLENBQUMsQ0FDSDtFQUNBLElBQUksWUFBWSxNQUFNO0dBQ3BCLEtBQUssT0FBTyxLQUNWLElBQUksYUFBYSxlQUFlO0lBQzlCO0lBQ0E7R0FDRixDQUFDLENBQ0g7R0FDQSxLQUFLLFlBQVk7R0FDakIsT0FBTztFQUNUO0VBQ0EsSUFBSSxzQkFBc0IsUUFBUSxHQUFHO0dBQ25DLEtBQUssT0FBTyxLQUNWLElBQUksYUFBYSxlQUFlO0lBQzlCO0lBQ0E7R0FDRixDQUFDLENBQ0g7R0FDQSxLQUFLLFlBQVk7R0FDakIsT0FBTztFQUNUO0VBQ0EsTUFBTSx1QkFBdUIsbUJBQW1CLFFBQVEsT0FBTyxTQUFTLE1BQU07RUFDOUUsTUFBTSxxQkFBcUIsU0FBUyxRQUFRO0VBQzVDLEtBQUssWUFBWSxRQUFRO0VBQ3pCLEtBQUssT0FBTyxLQUNWLElBQUksYUFBYSxlQUFlO0dBQzlCO0dBQ0E7RUFDRixDQUFDLENBQ0g7RUFDQSxJQUFJLENBQUMsbUJBQW1CLE9BQ3RCLFFBQVEsSUFBSTtHQUNWLFNBQVM7R0FDVCxVQUFVO0dBQ1Y7RUFDRixDQUFDO0VBRUgsT0FBTztDQUNUO0FBQ0Y7OztBQ3hLQSxlQUFlLDRCQUE0QixPQUFPLFFBQVE7Q0FDeEQsTUFBTSx1QkFBdUIsT0FBTyxhQUFhO0VBQy9DLElBQUksYUFBYSxVQUNmO0VBRUYsTUFBTSxVQUFVLE1BQU0sTUFBTSxvQkFBb0I7RUFDaEQsUUFBUSxVQUFSO0dBQ0UsS0FBSyxRQUNILE9BQU8sU0FBUyxLQUFLLGVBQWUsT0FBTztHQUU3QyxLQUFLLFNBQ0gsT0FBTyxTQUFTLE1BQU0sYUFBYSxPQUFPO0VBRTlDO0NBQ0Y7Q0FDQSxNQUFNLGdCQUFnQixPQUFPLGFBQWE7RUFDeEMsWUFBVTtHQUNSO0dBQ0EsYUFBYSxZQUFZLGFBQWEsVUFBVSxhQUFhOzs7OztHQUs3RCxTQUFTLGNBQ1AsNk9BQ0EsUUFDRjtFQUNGO0VBQ0EsSUFBSSxhQUFhLFVBQ2Y7RUFFRixNQUFNLHFCQUFxQixRQUFRO0VBQ25DLElBQUksYUFBYSxTQUNmLE9BQU8sUUFBUSxPQUNiLElBQUksY0FDRixTQUFTLGNBQ1Asa0dBQ0YsQ0FDRixDQUNGO0NBRUo7Q0FDQSxJQUFJLE9BQU8sV0FBVyxZQUNwQixPQUFPLE9BQU87RUFDWjtFQUNBLFVBQVU7R0FDUixNQUFNLHFCQUFxQixLQUFLLE1BQU0sTUFBTTs7Ozs7OztHQU81QyxPQUFPLHFCQUFxQixLQUFLLE1BQU0sT0FBTztFQUNoRDtDQUNGLENBQUM7Q0FFSCxJQUFJLGlCQUFpQixvQkFBb0IscUJBQXFCLE1BQU0sS0FBSyxPQUFPLEdBQzlFO0NBRUYsT0FBTyxjQUFjLE1BQU07QUFDN0I7OztBQ3JEQSxTQUFTLG9CQUFvQixRQUFRO0NBQ25DLE1BQU0sV0FBVyxDQUFDO0NBQ2xCLEtBQUssTUFBTSxTQUFTLFFBQ2xCLElBQUksaUJBQWlCLFNBQ25CLFNBQVMsS0FBSyxLQUFLO0NBR3ZCLElBQUksU0FBUyxTQUFTLEdBQ3BCLE9BQU8sUUFBUSxJQUFJLFFBQVEsQ0FBQyxDQUFDLFdBQVcsQ0FDeEMsQ0FBQztBQUVMO0FBQ0EsSUFBSSxvQkFBb0Msa0JBQUUsdUJBQXVCO0NBQy9ELG1CQUFtQixtQkFBbUIsY0FBYyxLQUFLO0NBQ3pELG1CQUFtQixtQkFBbUIsYUFBYSxLQUFLO0NBQ3hELE9BQU87QUFDVCxFQUFBLENBQUcscUJBQXFCLENBQUMsQ0FBQztBQUMxQixTQUFTLGNBQWMsU0FBUztDQUM5QixJQUFJLGFBQWE7Q0FDakIsTUFBTSxTQUFTLElBQUlDLFVBQVE7Q0FDM0IsTUFBTSxhQUFhLElBQUksV0FBVztDQUNsQyxNQUFNLDRCQUE0QixhQUFhO0VBQzdDLE9BQU8sb0JBQW9CLHFCQUFxQixXQUFXLElBQUksMkJBQTJCLFlBQVksQ0FBQyxDQUFDO0NBQzFHO0NBQ0EsSUFBSSxrQkFBa0IsRUFDcEIsR0FBRyxRQUNMO0NBQ0EsSUFBSSxxQkFBcUIseUJBQXlCLGdCQUFnQixRQUFRO0NBQzFFLE9BQU87RUFDTCxJQUFJLGFBQWE7R0FDZixPQUFPO0VBQ1Q7RUFDQTtFQUNBLFVBQVUsVUFBVTtHQUNsQixZQUNFLGVBQWUsR0FDZiw2RkFDRjtHQUNBLElBQUksU0FBUyxZQUFZLENBQUMsT0FBTyxHQUFHLFNBQVMsVUFBVSxnQkFBZ0IsUUFBUSxHQUM3RSxxQkFBcUIseUJBQXlCLFNBQVMsUUFBUTtHQUVqRSxrQkFBa0I7SUFDaEIsR0FBRztJQUNILEdBQUc7R0FDTDtFQUNGO0VBQ0EsU0FBUztHQUNQLFlBQ0UsZUFBZSxHQUNmLDJEQUNGO0dBQ0EsYUFBYTtHQUNiLE1BQU0sVUFBVSxFQUFFLFFBQVEsS0FBSztHQUMvQixXQUFXLGdCQUFnQixDQUFDLFdBQVc7SUFDckMsUUFBUSxTQUFTO0dBQ25CLENBQUM7R0FtQkQsT0FBTyxvQkFsQlEsZ0JBQWdCLFFBQVEsS0FBSyxXQUFXO0lBQ3JELGNBQWMsVUFBVSxRQUFRLEtBQUssTUFBTTtJQUMzQyxPQUFPLEdBQUcsU0FBUyxPQUFPLEVBQUUsWUFBWTtLQUN0QyxNQUFNLE9BQU8sR0FBRyxNQUFNLFVBQVU7TUFDOUIsSUFBSSxDQUFDLFFBQVEsUUFDWDtNQUVGLE9BQU8sS0FBSyxLQUFLO0tBQ25CLENBQUM7S0FDRCxNQUFNLFdBQVcsTUFBTSxZQUFZLGtCQUFrQjtLQUNyRCxNQUFNLE1BQU0sUUFDVixVQUNBLGdCQUFnQixvQkFBb0IsUUFDcEMsZ0JBQWdCLE9BQ2xCO0lBQ0YsQ0FBQztJQUNELE9BQU8sT0FBTyxPQUFPO0dBQ3ZCLENBQ2dDLENBQUM7RUFDbkM7RUFDQSxVQUFVO0dBQ1IsWUFDRSxlQUFlLEdBQ2YsNkRBQ0Y7R0FDQSxhQUFhO0dBQ2IsV0FBVyxRQUFRO0dBQ25CLE9BQU8sb0JBQ0wsZ0JBQWdCLFFBQVEsS0FBSyxXQUFXLE9BQU8sUUFBUSxDQUFDLENBQzFEO0VBQ0Y7RUFDQSxJQUFJLEdBQUcsVUFBVTtHQUNmLG1CQUFtQixJQUFJLFFBQVE7RUFDakM7RUFDQSxjQUFjLEdBQUcsVUFBVTtHQUN6QixtQkFBbUIsTUFBTSxRQUFRO0VBQ25DO0VBQ0Esa0JBQWtCO0dBQ2hCLG1CQUFtQixRQUFRO0VBQzdCO0VBQ0EsZUFBZTtHQUNiLE9BQU8sZ0JBQWdCLG1CQUFtQixnQkFBZ0IsQ0FBQztFQUM3RDtDQUNGO0FBQ0Y7Ozs7Ozs7O0FDekdBLGVBQWVDLFlBQVUsU0FBUyxXQUFXLEdBQUcsTUFBTTtDQUNyRCxNQUFNLFlBQVksUUFBUSxVQUFVLFNBQVM7Q0FDN0MsSUFBSSxVQUFVLFdBQVcsR0FBRztDQUM1QixLQUFLLE1BQU0sWUFBWSxXQUFXLE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtBQUNyRTtBQUlBLElBQUlDLG9CQUFrQixNQUFNO0NBQzNCLGdDQUFnQyxJQUFJLElBQUk7Q0FDeEMsV0FBVyxPQUFPLEtBQUssY0FBYztFQUNwQyxNQUFNLG9CQUFvQixLQUFLQyxjQUFjLElBQUksS0FBSztFQUN0RCxZQUFVLENBQUMsbUJBQW1CLElBQUksR0FBRyxHQUFHLHdDQUF3QyxPQUFPLEdBQUcsRUFBRSxxQkFBcUI7RUFDakgsTUFBTSxRQUFRQyw0QkFBMEIsT0FBTyxHQUFHO0VBQ2xELElBQUksT0FBTyxVQUFVLGFBQWE7R0FDakMsUUFBUSxLQUFLLHdDQUF3QyxPQUFPLEdBQUcsRUFBRSx1QkFBdUI7R0FDeEYsYUFBYSxDQUFDO0VBQ2Y7RUFDQSxJQUFJLE1BQU0sV0FBVyxjQUFjLE9BQU8sZUFBZSxPQUFPLEtBQUs7R0FDcEUsT0FBTyxhQUFhLE1BQU0sSUFBSTtHQUM5QixZQUFZO0dBQ1osY0FBYztFQUNmLENBQUM7T0FDSSxJQUFJLE1BQU0sV0FBVyxVQUFVLE1BQU0sT0FBTyxhQUFhLE1BQU0sSUFBSTtPQUNuRSxNQUFNLElBQUksTUFBTSw2REFBNkQsSUFBSSxTQUFTLEVBQUUsRUFBRTtFQUNuRyxNQUFNLHFCQUFxQjtHQUMxQixNQUFNLHNCQUFzQixLQUFLRCxjQUFjLElBQUksS0FBSztHQUN4RCxJQUFJLENBQUMscUJBQXFCLElBQUksR0FBRyxHQUFHO0dBQ3BDLElBQUksTUFBTSxVQUFVOzs7OztHQUtwQixPQUFPLGVBQWUsTUFBTSxPQUFPLEtBQUssTUFBTSxVQUFVOzs7Ozs7O0dBT3hELFFBQVEsZUFBZSxPQUFPLEdBQUc7R0FDakMsb0JBQW9CLE9BQU8sR0FBRztHQUM5QixJQUFJLG9CQUFvQixTQUFTLEdBQUcsS0FBS0EsY0FBYyxPQUFPLEtBQUs7RUFDcEU7RUFDQSxJQUFJLG1CQUFtQixrQkFBa0IsSUFBSSxLQUFLLFlBQVk7T0FDekQsS0FBS0EsY0FBYyxJQUFJLHVCQUFPLElBQUksSUFBSSxDQUFDLENBQUMsS0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQ2pFLE9BQU87Q0FDUjtDQUNBLG9CQUFvQjtFQUNuQixNQUFNLFNBQVMsQ0FBQztFQUNoQixLQUFLLE1BQU0sR0FBRyxzQkFBc0IsS0FBS0EsZUFBZSxLQUFLLE1BQU0sR0FBRyxpQkFBaUIsbUJBQW1CLElBQUk7R0FDN0csYUFBYTtFQUNkLFNBQVMsT0FBTztHQUNmLElBQUksaUJBQWlCLE9BQU8sT0FBTyxLQUFLLEtBQUs7UUFDeEMsTUFBTTtFQUNaO0VBQ0EsSUFBSSxPQUFPLFNBQVMsR0FBRyxNQUFNLElBQUksZUFBZSxRQUFRLE1BQU07Q0FDL0Q7QUFDRDtBQUNBLElBQU1FLG9CQUFrQixJQUFJSCxrQkFBZ0I7Ozs7Ozs7QUFPNUMsU0FBU0UsNEJBQTBCLE9BQU8sS0FBSztDQUM5QyxJQUFJLGVBQWU7Q0FDbkIsSUFBSTtDQUNKLE9BQU8sY0FBYztFQUNwQixhQUFhLE9BQU8seUJBQXlCLGNBQWMsR0FBRztFQUM5RCxJQUFJLFlBQVksT0FBTztHQUN0QixPQUFPO0dBQ1A7RUFDRDtFQUNBLGVBQWUsT0FBTyxlQUFlLFlBQVk7Q0FDbEQ7QUFDRDs7Ozs7QUFRQSxTQUFTRSx3QkFBc0IsY0FBYztDQUM1QyxNQUFNLFFBQVFGLDRCQUEwQixZQUFZLFlBQVk7Q0FDaEUsSUFBSSxPQUFPLFVBQVUsYUFBYSxPQUFPO0NBQ3pDLE1BQU0sRUFBRSxlQUFlO0NBQ3ZCLElBQUksT0FBTyxXQUFXLFFBQVEsY0FBYyxPQUFPLFdBQVcsSUFBSSxNQUFNLGFBQWEsT0FBTztDQUM1RixJQUFJLE9BQU8sV0FBVyxRQUFRLGVBQWUsV0FBVyxTQUFTLE1BQU0sT0FBTztDQUM5RSxJQUFJLE9BQU8sV0FBVyxRQUFRLGVBQWUsQ0FBQyxXQUFXLGNBQWM7RUFDdEUsUUFBUSxNQUFNLG1EQUFtRCxhQUFhLG1LQUFtSztFQUNqUCxPQUFPO0NBQ1I7Q0FDQSxPQUFPO0FBQ1I7OztBQ2pHQSxTQUFTRyxZQUFVLFFBQVEsT0FBTztDQUNqQyxPQUFPLGlCQUFpQixPQUFPO0VBQzlCLFFBQVE7R0FDUCxPQUFPO0dBQ1AsWUFBWTtHQUNaLFVBQVU7RUFDWDtFQUNBLGVBQWU7R0FDZCxPQUFPO0dBQ1AsWUFBWTtHQUNaLFVBQVU7RUFDWDtDQUNELENBQUM7Q0FDRCxPQUFPO0FBQ1I7QUFJQSxJQUFNQyxnQkFBYyxPQUFPLGFBQWE7QUFDeEMsSUFBTUMsc0JBQW9CLE9BQU8sbUJBQW1COzs7Ozs7OztBQVFwRCxJQUFJQywyQkFBeUIsY0FBYyxhQUFhO0NBQ3ZELFlBQVksTUFBTSxNQUFNO0VBQ3ZCLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLEtBQUtGLGlCQUFlLENBQUMsQ0FBQyxLQUFLO0VBQzNCLEtBQUtDLHVCQUFxQjtDQUMzQjtDQUNBLElBQUksYUFBYTtFQUNoQixPQUFPLEtBQUtEO0NBQ2I7Q0FDQSxJQUFJLFdBQVcsZ0JBQWdCO0VBQzlCLEtBQUtBLGlCQUFlO0NBQ3JCO0NBQ0EsSUFBSSxtQkFBbUI7RUFDdEIsT0FBTyxLQUFLQztDQUNiO0NBQ0EsSUFBSSxpQkFBaUIsc0JBQXNCO0VBQzFDLEtBQUtBLHVCQUFxQjtDQUMzQjtDQUNBLGlCQUFpQjtFQUNoQixJQUFJLEtBQUssY0FBYyxDQUFDLEtBQUtBLHNCQUFvQixLQUFLQSx1QkFBcUI7Q0FDNUU7QUFDRDtBQUNBLElBQUlFLGVBQWEsY0FBYyxNQUFNO0NBQ3BDLFlBQVksTUFBTSxPQUFPLENBQUMsR0FBRztFQUM1QixNQUFNLE1BQU0sSUFBSTtFQUNoQixLQUFLLE9BQU8sS0FBSyxTQUFTLEtBQUssSUFBSSxJQUFJLEtBQUs7RUFDNUMsS0FBSyxTQUFTLEtBQUssV0FBVyxLQUFLLElBQUksS0FBSyxLQUFLO0VBQ2pELEtBQUssV0FBVyxLQUFLLGFBQWEsS0FBSyxJQUFJLFFBQVEsS0FBSztDQUN6RDtBQUNEO0FBQ0EsSUFBSUMseUJBQXVCLGNBQWNELGFBQVc7Q0FDbkQsWUFBWSxNQUFNLE9BQU8sQ0FBQyxHQUFHO0VBQzVCLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLEtBQUtILGlCQUFlLENBQUMsQ0FBQyxLQUFLO0VBQzNCLEtBQUtDLHVCQUFxQjtDQUMzQjtDQUNBLElBQUksYUFBYTtFQUNoQixPQUFPLEtBQUtEO0NBQ2I7Q0FDQSxJQUFJLFdBQVcsZ0JBQWdCO0VBQzlCLEtBQUtBLGlCQUFlO0NBQ3JCO0NBQ0EsSUFBSSxtQkFBbUI7RUFDdEIsT0FBTyxLQUFLQztDQUNiO0NBQ0EsSUFBSSxpQkFBaUIsc0JBQXNCO0VBQzFDLEtBQUtBLHVCQUFxQjtDQUMzQjtDQUNBLGlCQUFpQjtFQUNoQixJQUFJLEtBQUssY0FBYyxDQUFDLEtBQUtBLHNCQUFvQixLQUFLQSx1QkFBcUI7Q0FDNUU7QUFDRDtBQUlBLElBQU1JLGVBQWEsT0FBTyxVQUFVO0FBQ3BDLElBQU1DLHFCQUFtQixPQUFPLGdCQUFnQjs7Ozs7O0FBT2hELElBQUlDLDhCQUE0QixNQUFNO0NBQ3JDLFlBQVksUUFBUSxXQUFXO0VBQzlCLEtBQUssU0FBUztFQUNkLEtBQUssWUFBWTtFQUNqQixLQUFLLEtBQUtDLGtCQUFnQjtFQUMxQixLQUFLLE1BQU0sSUFBSSxJQUFJLE9BQU8sR0FBRztFQUM3QixLQUFLSCxnQkFBYyxJQUFJLFlBQVk7RUFDbkMsS0FBSyxVQUFVLGlCQUFpQixhQUFhLFVBQVU7R0FDdEQsTUFBTSxVQUFVTixZQUFVLEtBQUssUUFBUSxJQUFJRyx5QkFBdUIsV0FBVztJQUM1RSxNQUFNLE1BQU07SUFDWixRQUFRLE1BQU07SUFDZCxZQUFZO0dBQ2IsQ0FBQyxDQUFDO0dBQ0YsS0FBS0csYUFBVyxDQUFDLGNBQWMsT0FBTztHQUN0QyxJQUFJLFFBQVEsa0JBQWtCLE1BQU0sZUFBZTtFQUNwRCxDQUFDOzs7Ozs7Ozs7RUFTRCxLQUFLLFVBQVUsaUJBQWlCLFVBQVUsVUFBVTtHQUNuRCxLQUFLQSxhQUFXLENBQUMsY0FBY04sWUFBVSxLQUFLLFFBQVEsSUFBSUksYUFBVyxTQUFTLEtBQUssQ0FBQyxDQUFDO0VBQ3RGLENBQUM7Q0FDRjs7OztDQUlBLGlCQUFpQixNQUFNLFVBQVUsU0FBUztFQUN6QyxJQUFJLENBQUMsUUFBUSxJQUFJLFVBQVVHLGtCQUFnQixHQUFHO0dBQzdDLE1BQU0sZ0JBQWdCLFNBQVMsS0FBSyxLQUFLLE1BQU07R0FDL0MsT0FBTyxlQUFlLFVBQVVBLG9CQUFrQjtJQUNqRCxPQUFPO0lBQ1AsWUFBWTtJQUNaLGNBQWM7R0FDZixDQUFDO0VBQ0Y7RUFDQSxLQUFLRCxhQUFXLENBQUMsaUJBQWlCLE1BQU0sUUFBUSxJQUFJLFVBQVVDLGtCQUFnQixHQUFHLE9BQU87Q0FDekY7Ozs7Q0FJQSxvQkFBb0IsT0FBTyxVQUFVLFNBQVM7RUFDN0MsS0FBS0QsYUFBVyxDQUFDLG9CQUFvQixPQUFPLFFBQVEsSUFBSSxVQUFVQyxrQkFBZ0IsR0FBRyxPQUFPO0NBQzdGOzs7O0NBSUEsS0FBSyxNQUFNO0VBQ1YsS0FBSyxVQUFVLEtBQUssSUFBSTtDQUN6Qjs7Ozs7O0NBTUEsTUFBTSxNQUFNLFFBQVE7RUFDbkIsS0FBSyxVQUFVLE1BQU0sTUFBTSxNQUFNO0NBQ2xDO0FBQ0Q7QUFJQSxJQUFNRyxxQ0FBbUM7QUFDekMsSUFBTUMsd0JBQXNCLE9BQU8scUJBQXFCO0FBQ3hELElBQU1DLFlBQVUsT0FBTyxTQUFTO0FBQ2hDLElBQU1DLFdBQVMsT0FBTyxRQUFRO0FBQzlCLElBQUlDLHNCQUFvQixjQUFjLFlBQVk7Q0FDakQ7RUFDQyxLQUFLLGFBQWE7Q0FDbkI7Q0FDQTtFQUNDLEtBQUssT0FBTztDQUNiO0NBQ0E7RUFDQyxLQUFLLFVBQVU7Q0FDaEI7Q0FDQTtFQUNDLEtBQUssU0FBUztDQUNmO0NBQ0EsWUFBWSxLQUFLLFdBQVc7RUFDM0IsTUFBTTtFQUNOLEtBQUssYUFBYTtFQUNsQixLQUFLLE9BQU87RUFDWixLQUFLLFVBQVU7RUFDZixLQUFLLFNBQVM7RUFDZCxLQUFLLFVBQVU7RUFDZixLQUFLLGFBQWE7RUFDbEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVztFQUNoQixLQUFLLE1BQU1DLHNCQUFvQixHQUFHO0VBQ2xDLEtBQUssV0FBVztFQUNoQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssYUFBYSxLQUFLO0VBQ3ZCLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUtKLHlCQUF1QixJQUFJSyxrQkFBZ0I7RUFDaEQsZUFBZSxZQUFZO0dBQzFCLElBQUksTUFBTSxLQUFLTCx3QkFBc0I7R0FDckMsS0FBSyxXQUFXLE9BQU8sY0FBYyxXQUFXLFlBQVksTUFBTSxRQUFRLFNBQVMsS0FBSyxVQUFVLFNBQVMsSUFBSSxVQUFVLEtBQUs7Ozs7OztHQU05SCxJQUFJLEtBQUssZUFBZSxLQUFLLFlBQVk7SUFDeEMsS0FBSyxhQUFhLEtBQUs7SUFDdkIsS0FBSyxjQUFjWCxZQUFVLE1BQU0sSUFBSSxNQUFNLE1BQU0sQ0FBQyxDQUFDO0dBQ3REO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsSUFBSSxPQUFPLFVBQVU7RUFDcEIsS0FBSyxvQkFBb0IsUUFBUSxLQUFLLE9BQU87RUFDN0MsS0FBSyxVQUFVO0VBQ2YsSUFBSSxhQUFhLE1BQU0sS0FBSyxpQkFBaUIsUUFBUSxRQUFRO0NBQzlEO0NBQ0EsSUFBSSxTQUFTO0VBQ1osT0FBTyxLQUFLO0NBQ2I7Q0FDQSxJQUFJLFVBQVUsVUFBVTtFQUN2QixLQUFLLG9CQUFvQixXQUFXLEtBQUssVUFBVTtFQUNuRCxLQUFLLGFBQWE7RUFDbEIsSUFBSSxhQUFhLE1BQU0sS0FBSyxpQkFBaUIsV0FBVyxRQUFRO0NBQ2pFO0NBQ0EsSUFBSSxZQUFZO0VBQ2YsT0FBTyxLQUFLO0NBQ2I7Q0FDQSxJQUFJLFFBQVEsVUFBVTtFQUNyQixLQUFLLG9CQUFvQixTQUFTLEtBQUssUUFBUTtFQUMvQyxLQUFLLFdBQVc7RUFDaEIsSUFBSSxhQUFhLE1BQU0sS0FBSyxpQkFBaUIsU0FBUyxRQUFRO0NBQy9EO0NBQ0EsSUFBSSxVQUFVO0VBQ2IsT0FBTyxLQUFLO0NBQ2I7Q0FDQSxJQUFJLFFBQVEsVUFBVTtFQUNyQixLQUFLLG9CQUFvQixTQUFTLEtBQUssUUFBUTtFQUMvQyxLQUFLLFdBQVc7RUFDaEIsSUFBSSxhQUFhLE1BQU0sS0FBSyxpQkFBaUIsU0FBUyxRQUFRO0NBQy9EO0NBQ0EsSUFBSSxVQUFVO0VBQ2IsT0FBTyxLQUFLO0NBQ2I7Ozs7Q0FJQSxLQUFLLE1BQU07RUFDVixJQUFJLEtBQUssZUFBZSxLQUFLLFlBQVk7R0FDeEMsS0FBSyxNQUFNO0dBQ1gsTUFBTSxJQUFJLGFBQWEsbUJBQW1CO0VBQzNDO0VBQ0EsSUFBSSxLQUFLLGVBQWUsS0FBSyxXQUFXLEtBQUssZUFBZSxLQUFLLFFBQVE7RUFDekUsS0FBSyxrQkFBa0JpQixjQUFZLElBQUk7RUFDdkMscUJBQXFCO0dBQ3BCLEtBQUssaUJBQWlCOzs7Ozs7R0FNdEIsS0FBS0wsVUFBUSxHQUFHLElBQUk7RUFDckIsQ0FBQztDQUNGO0NBQ0EsTUFBTSxPQUFPLEtBQUssUUFBUTtFQUN6QixZQUFVLE1BQU1GLGtDQUFnQztFQUNoRCxZQUFVLFNBQVMsT0FBTyxRQUFRLE9BQU8sUUFBUSxNQUFNQSxrQ0FBZ0M7RUFDdkYsS0FBS0csU0FBTyxDQUFDLE1BQU0sTUFBTTtDQUMxQjtDQUNBLENBQUNBLFVBQVEsT0FBTyxLQUFLLFFBQVEsV0FBVyxNQUFNOzs7Ozs7RUFNN0MsSUFBSSxLQUFLLGVBQWUsS0FBSyxXQUFXLEtBQUssZUFBZSxLQUFLLFFBQVE7RUFDekUsS0FBSyxhQUFhLEtBQUs7RUFDdkIscUJBQXFCO0dBQ3BCLEtBQUssYUFBYSxLQUFLO0dBQ3ZCLEtBQUssY0FBY2IsWUFBVSxNQUFNLElBQUlJLGFBQVcsU0FBUztJQUMxRDtJQUNBO0lBQ0E7R0FDRCxDQUFDLENBQUMsQ0FBQztHQUNILEtBQUssVUFBVTtHQUNmLEtBQUssYUFBYTtHQUNsQixLQUFLLFdBQVc7R0FDaEIsS0FBSyxXQUFXO0VBQ2pCLENBQUM7Q0FDRjtDQUNBLGlCQUFpQixNQUFNLFVBQVUsU0FBUztFQUN6QyxPQUFPLE1BQU0saUJBQWlCLE1BQU0sVUFBVSxPQUFPO0NBQ3REO0NBQ0Esb0JBQW9CLE1BQU0sVUFBVSxTQUFTO0VBQzVDLE9BQU8sTUFBTSxvQkFBb0IsTUFBTSxVQUFVLE9BQU87Q0FDekQ7QUFDRDtBQUNBLFNBQVNhLGNBQVksTUFBTTtDQUMxQixJQUFJLE9BQU8sU0FBUyxVQUFVLE9BQU8sS0FBSztDQUMxQyxJQUFJLGdCQUFnQixNQUFNLE9BQU8sS0FBSztDQUN0QyxPQUFPLEtBQUs7QUFDYjtBQUlBLElBQU1DLGFBQVcsT0FBTyxVQUFVO0FBQ2xDLElBQU1DLG1CQUFpQixPQUFPLGdCQUFnQjtBQUM5QyxJQUFNQyxVQUFRLE9BQU8sT0FBTzs7Ozs7O0FBTzVCLElBQUlDLDhCQUE0QixNQUFNO0NBQ3JDLFlBQVksUUFBUSxXQUFXLGtCQUFrQjtFQUNoRCxLQUFLLFNBQVM7RUFDZCxLQUFLLFlBQVk7RUFDakIsS0FBSyxtQkFBbUI7RUFDeEIsS0FBS0gsY0FBWSxJQUFJLFlBQVk7RUFDakMsS0FBSyxzQkFBc0IsSUFBSSxnQkFBZ0I7RUFDL0MsS0FBSyxzQkFBc0IsSUFBSSxnQkFBZ0I7RUFDL0MsS0FBSyxVQUFVLGlCQUFpQixhQUFhLFVBQVU7R0FDdEQsSUFBSSxPQUFPLEtBQUssa0JBQWtCLGFBQWE7R0FDL0MscUJBQXFCO0lBQ3BCLElBQUksQ0FBQyxNQUFNOzs7Ozs7SUFNWCxLQUFLRSxRQUFNLENBQUMsTUFBTSxJQUFJO0dBQ3ZCLENBQUM7RUFDRixDQUFDO0VBQ0QsS0FBSyxVQUFVLGlCQUFpQixZQUFZLEtBQUssc0JBQXNCLEtBQUssSUFBSSxDQUFDO0NBQ2xGOzs7OztDQUtBLElBQUksU0FBUztFQUNaLFlBQVUsS0FBSyxlQUFlLDBJQUEwSTtFQUN4SyxPQUFPLEtBQUs7Q0FDYjs7OztDQUlBLFVBQVU7RUFDVCxZQUFVLENBQUMsS0FBSyxpQkFBaUIsS0FBSyxjQUFjLGVBQWUsVUFBVSxNQUFNLDhGQUE4RjtFQUNqTCxNQUFNLGdCQUFnQixLQUFLLGlCQUFpQjtFQUM1QyxjQUFjLGFBQWEsS0FBSyxPQUFPO0VBQ3ZDLGNBQWMsaUJBQWlCLFNBQVMsVUFBVTtHQUNqRCxLQUFLRixXQUFTLENBQUMsY0FBY2xCLFlBQVUsS0FBSyxlQUFlLElBQUksTUFBTSxRQUFRLEtBQUssQ0FBQyxDQUFDO0VBQ3JGLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztFQUNqQixjQUFjLGlCQUFpQixZQUFZLFVBQVU7R0FDcEQsS0FBSyxVQUFVLGNBQWNBLFlBQVUsS0FBSyxlQUFlLElBQUksYUFBYSxZQUFZO0lBQ3ZGLE1BQU0sTUFBTTtJQUNaLFFBQVEsTUFBTTtHQUNmLENBQUMsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUNELEtBQUssT0FBTyxpQkFBaUIsVUFBVSxVQUFVO0dBQ2hELEtBQUssZ0JBQWdCLEtBQUs7RUFDM0IsR0FBRyxFQUFFLFFBQVEsS0FBSyxvQkFBb0IsT0FBTyxDQUFDO0VBQzlDLGNBQWMsaUJBQWlCLFVBQVUsVUFBVTtHQUNsRCxLQUFLLGdCQUFnQixLQUFLO0VBQzNCLEdBQUcsRUFBRSxRQUFRLEtBQUssb0JBQW9CLE9BQU8sQ0FBQztFQUM5QyxjQUFjLGlCQUFpQixlQUFlO0dBQzdDLE1BQU0sYUFBYUEsWUFBVSxlQUFlLElBQUksTUFBTSxTQUFTLEVBQUUsWUFBWSxLQUFLLENBQUMsQ0FBQztHQUNwRixLQUFLa0IsV0FBUyxDQUFDLGNBQWMsVUFBVTtHQUN2QyxJQUFJLENBQUMsV0FBVyxrQkFBa0IsS0FBSyxPQUFPLGNBQWNsQixZQUFVLEtBQUssUUFBUSxJQUFJLE1BQU0sT0FBTyxDQUFDLENBQUM7RUFDdkcsQ0FBQztFQUNELEtBQUssZ0JBQWdCO0NBQ3RCOzs7O0NBSUEsaUJBQWlCLE9BQU8sVUFBVSxTQUFTO0VBQzFDLElBQUksQ0FBQyxRQUFRLElBQUksVUFBVW1CLGdCQUFjLEdBQUc7R0FDM0MsTUFBTSxnQkFBZ0IsU0FBUyxLQUFLLEtBQUssTUFBTTtHQUMvQyxPQUFPLGVBQWUsVUFBVUEsa0JBQWdCO0lBQy9DLE9BQU87SUFDUCxZQUFZO0dBQ2IsQ0FBQztFQUNGO0VBQ0EsS0FBS0QsV0FBUyxDQUFDLGlCQUFpQixPQUFPLFFBQVEsSUFBSSxVQUFVQyxnQkFBYyxHQUFHLE9BQU87Q0FDdEY7Ozs7Q0FJQSxvQkFBb0IsT0FBTyxVQUFVLFNBQVM7RUFDN0MsS0FBS0QsV0FBUyxDQUFDLG9CQUFvQixPQUFPLFFBQVEsSUFBSSxVQUFVQyxnQkFBYyxHQUFHLE9BQU87Q0FDekY7Ozs7Ozs7O0NBUUEsS0FBSyxNQUFNO0VBQ1YsS0FBS0MsUUFBTSxDQUFDLElBQUk7Q0FDakI7Q0FDQSxDQUFDQSxTQUFPLE1BQU07RUFDYixNQUFNLEVBQUUsa0JBQWtCO0VBQzFCLFlBQVUsZUFBZSx5SEFBeUgsS0FBSyxPQUFPLEdBQUc7RUFDakssSUFBSSxjQUFjLGVBQWUsVUFBVSxXQUFXLGNBQWMsZUFBZSxVQUFVLFFBQVE7RUFDckcsSUFBSSxjQUFjLGVBQWUsVUFBVSxZQUFZO0dBQ3RELGNBQWMsaUJBQWlCLGNBQWM7SUFDNUMsY0FBYyxLQUFLLElBQUk7R0FDeEIsR0FBRyxFQUFFLE1BQU0sS0FBSyxDQUFDO0dBQ2pCO0VBQ0Q7RUFDQSxjQUFjLEtBQUssSUFBSTtDQUN4Qjs7OztDQUlBLFFBQVE7RUFDUCxNQUFNLEVBQUUsa0JBQWtCO0VBQzFCLFlBQVUsZUFBZSwwSEFBMEgsS0FBSyxPQUFPLEdBQUc7RUFDbEssS0FBSyxvQkFBb0IsTUFBTTtFQUMvQixJQUFJLGNBQWMsZUFBZSxVQUFVLFdBQVcsY0FBYyxlQUFlLFVBQVUsUUFBUTtFQUNyRyxjQUFjLE1BQU07RUFDcEIscUJBQXFCO0dBQ3BCLEtBQUtGLFdBQVMsQ0FBQyxjQUFjbEIsWUFBVSxLQUFLLGVBQWUsSUFBSUssdUJBQXFCLFNBQVM7SUFDNUYsTUFBTTtJQUNOLFlBQVk7R0FDYixDQUFDLENBQUMsQ0FBQztFQUNKLENBQUM7Q0FDRjtDQUNBLHNCQUFzQixPQUFPO0VBQzVCLE1BQU0sZUFBZUwsWUFBVSxNQUFNLFFBQVEsSUFBSUcseUJBQXVCLFdBQVc7R0FDbEYsTUFBTSxNQUFNO0dBQ1osUUFBUSxNQUFNO0dBQ2QsWUFBWTtFQUNiLENBQUMsQ0FBQzs7Ozs7Ozs7RUFRRixLQUFLZSxXQUFTLENBQUMsY0FBYyxZQUFZOzs7OztFQUt6QyxJQUFJLENBQUMsYUFBYSxrQkFBa0IsS0FBSyxPQUFPLGNBQWNsQjs7Ozs7O0dBTTdELEtBQUs7R0FDTCxJQUFJLGFBQWEsV0FBVztJQUMzQixNQUFNLE1BQU07SUFDWixRQUFRLE1BQU07R0FDZixDQUFDO0VBQ0YsQ0FBQztDQUNGO0NBQ0EsZ0JBQWdCLFFBQVE7RUFDdkIsSUFBSSxLQUFLLGVBQWUsS0FBSyxjQUFjLE1BQU07Q0FDbEQ7Q0FDQSxnQkFBZ0IsT0FBTztFQUN0QixLQUFLLG9CQUFvQixNQUFNO0VBQy9CLE1BQU0sYUFBYUEsWUFBVSxLQUFLLGVBQWUsSUFBSUssdUJBQXFCLFNBQVM7R0FDbEYsTUFBTSxNQUFNO0dBQ1osUUFBUSxNQUFNO0dBQ2QsVUFBVSxNQUFNO0dBQ2hCLFlBQVk7RUFDYixDQUFDLENBQUM7RUFDRixLQUFLYSxXQUFTLENBQUMsY0FBYyxVQUFVO0VBQ3ZDLElBQUksQ0FBQyxXQUFXLGtCQUFrQixLQUFLLE9BQU9MLFNBQU8sQ0FBQyxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQy9FO0FBQ0Q7Ozs7O0FBUUEsSUFBSVMsNEJBQTBCLGNBQWMsWUFBWTtDQUN2RCxZQUFZLFFBQVE7RUFDbkIsTUFBTTtFQUNOLEtBQUssU0FBUztFQUNkLEtBQUssT0FBTyxpQkFBaUIsVUFBVSxVQUFVO0dBQ2hELEtBQUssY0FBY3RCLFlBQVUsS0FBSyxRQUFRLElBQUlJLGFBQVcsU0FBUyxLQUFLLENBQUMsQ0FBQztFQUMxRSxDQUFDOzs7OztFQUtELEtBQUssT0FBT1EsY0FBWSxTQUFTO0dBQ2hDLEtBQUssY0FBY1osWUFBVSxLQUFLLFFBQVEsSUFBSUcseUJBQXVCLFlBQVk7SUFDaEY7SUFDQSxRQUFRLEtBQUssT0FBTztJQUNwQixZQUFZO0dBQ2IsQ0FBQyxDQUFDLENBQUM7RUFDSjtDQUNEO0NBQ0EsaUJBQWlCLE1BQU0sVUFBVSxTQUFTO0VBQ3pDLE9BQU8sTUFBTSxpQkFBaUIsTUFBTSxVQUFVLE9BQU87Q0FDdEQ7Q0FDQSxjQUFjLE9BQU87RUFDcEIsT0FBTyxNQUFNLGNBQWMsS0FBSztDQUNqQztDQUNBLEtBQUssTUFBTTtFQUNWLHFCQUFxQjtHQUNwQixJQUFJLEtBQUssT0FBTyxlQUFlLEtBQUssT0FBTyxXQUFXLEtBQUssT0FBTyxlQUFlLEtBQUssT0FBTyxRQUFRO0dBQ3JHLE1BQU0sc0JBQXNCO0lBQzNCLEtBQUssT0FBTyxjQUFjSDs7Ozs7Ozs7O0tBU3pCLEtBQUs7S0FDTCxJQUFJLGFBQWEsV0FBVztNQUMzQjtNQUNBLFFBQVEsS0FBSyxPQUFPO0tBQ3JCLENBQUM7SUFDRixDQUFDO0dBQ0Y7R0FDQSxJQUFJLEtBQUssT0FBTyxlQUFlLEtBQUssT0FBTyxZQUFZLEtBQUssT0FBTyxpQkFBaUIsY0FBYztJQUNqRyxjQUFjO0dBQ2YsR0FBRyxFQUFFLE1BQU0sS0FBSyxDQUFDO1FBQ1osY0FBYztFQUNwQixDQUFDO0NBQ0Y7Q0FDQSxNQUFNLE1BQU0sUUFBUTs7Ozs7O0VBTW5CLEtBQUssT0FBT2EsU0FBTyxDQUFDLE1BQU0sTUFBTTtDQUNqQztBQUNEO0NBUTJCLE1BQU0sNkJBQTZCVyxjQUFZO0NBQ3pFO0VBQ0MsS0FBSyxTQUFTLE9BQU8sSUFBSSx1QkFBdUI7Q0FDakQ7Q0FDQSxjQUFjO0VBQ2IsTUFBTSxxQkFBcUIsTUFBTTtDQUNsQztDQUNBLG1CQUFtQjtFQUNsQixPQUFPQyx3QkFBc0IsV0FBVztDQUN6QztDQUNBLFFBQVE7RUFDUCxNQUFNLFNBQVMsS0FBSyxPQUFPLE9BQU8sT0FBTztFQUN6QyxNQUFNLGlCQUFpQixJQUFJLE1BQU0sV0FBVyxXQUFXLEVBQUUsWUFBWSxRQUFRLE1BQU0sY0FBYztHQUNoRyxNQUFNLENBQUMsS0FBSyxhQUFhO0dBQ3pCLE1BQU0seUJBQXlCO0lBQzlCLE9BQU8sUUFBUSxVQUFVLFFBQVEsTUFBTSxTQUFTO0dBQ2pEO0dBQ0EsTUFBTSxTQUFTLElBQUlYLG9CQUFrQixLQUFLLFNBQVM7R0FDbkQsTUFBTSxZQUFZLElBQUlRLDBCQUF3QixNQUFNO0dBQ3BELGVBQWUsWUFBWTtJQUMxQixJQUFJO0tBQ0gsTUFBTSxTQUFTLElBQUlELDRCQUEwQixRQUFRLFdBQVcsZ0JBQWdCO0tBQ2hGLE1BQU0seUJBQXlCLEtBQUssUUFBUSxjQUFjLFlBQVksSUFBSTtLQUMxRSxNQUFNSyxZQUFVLEtBQUssU0FBUyxjQUFjO01BQzNDLFFBQVEsSUFBSWxCLDRCQUEwQixRQUFRLFNBQVM7TUFDdkQ7TUFDQSxNQUFNLEVBQUUsVUFBVTtLQUNuQixDQUFDO0tBQ0QsSUFBSSx3QkFBd0IsT0FBT0csc0JBQW9CLENBQUMsUUFBUSxLQUFLO1VBQ2hFO01BQ0osT0FBT0Esc0JBQW9CLENBQUMsUUFBUSxJQUFJO01BQ3hDLE9BQU8sUUFBUTtNQUNmLE9BQU8saUJBQWlCLGNBQWM7T0FDckMsT0FBTyxjQUFjWCxZQUFVLFFBQVEsSUFBSSxNQUFNLE1BQU0sQ0FBQyxDQUFDO09BQ3pELElBQUksT0FBTyxrQkFBa0IsT0FBTyxXQUFXLE9BQU8sZ0JBQWdCLENBQUM7TUFDeEUsQ0FBQztLQUNGO0lBQ0QsU0FBUyxPQUFPOzs7Ozs7O0tBT2YsSUFBSSxpQkFBaUIsT0FBTztNQUMzQixPQUFPLGNBQWMsSUFBSSxNQUFNLE9BQU8sQ0FBQztNQUN2QyxJQUFJLE9BQU8sZUFBZSxVQUFVLFdBQVcsT0FBTyxlQUFlLFVBQVUsUUFBUSxPQUFPYSxTQUFPLENBQUMsTUFBTSxNQUFNLFNBQVMsS0FBSztNQUNoSSxRQUFRLE1BQU0sS0FBSztLQUNwQjtJQUNEO0dBQ0QsQ0FBQztHQUNELE9BQU87RUFDUixFQUFFLENBQUM7RUFDSCxPQUFPLEtBQUssOEJBQThCO0VBQzFDLEtBQUssY0FBYyxLQUFLYyxrQkFBZ0IsV0FBVyxZQUFZLG1CQUFtQixjQUFjLENBQUM7RUFDakcsT0FBTyxLQUFLLDZCQUE2QixXQUFXLFVBQVUsSUFBSTtDQUNuRTtBQUNEOzs7QUNobEJBLElBQU0sMkJBQU4sY0FBdUNDLGFBQVc7Q0FDaEQ7Q0FDQTtDQUNBLFlBQVksTUFBTSxNQUFNO0VBQ3RCLE1BQU0sR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDbkIsS0FBSyxNQUFNLEtBQUs7RUFDaEIsS0FBSyxZQUFZLEtBQUs7Q0FDeEI7QUFDRjtBQUNBLElBQU0sbUNBQU4sY0FBK0NBLGFBQVc7Q0FDeEQ7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxNQUFNLE1BQU07RUFDdEIsTUFBTSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNuQixLQUFLLE1BQU0sS0FBSztFQUNoQixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLFFBQVEsS0FBSztDQUNwQjtBQUNGO0FBQ0EsSUFBTSx3QkFBTixjQUFvQyxhQUFhO0NBQy9DLFlBQVksU0FBUztFQUNuQixNQUFNLE1BQU0sRUFDVixZQUFZLFFBQVEsV0FDdEIsQ0FBQztDQUNIO0NBQ0EsWUFBWSxZQUFZO0VBQ3RCLE9BQU8sV0FBVyxrQkFBa0IsV0FBVztDQUNqRDtDQUNBLE1BQU0sUUFBUSxVQUFVLGtCQUFrQixtQkFBbUI7RUFDM0QsTUFBTSxFQUFFLGVBQWUsS0FBSztFQUM1QixLQUFLLE9BQU8sS0FDVixJQUFJLHlCQUF5QixjQUFjO0dBQ3pDLEtBQUssV0FBVyxPQUFPO0dBQ3ZCLFdBQVcsV0FBVyxLQUFLO0VBQzdCLENBQUMsQ0FDSDtFQUNBLElBQUksU0FBUyxXQUFXLEdBQUc7R0FDekIsTUFBTSw0QkFBNEIsTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLFdBQ2xELEtBQUssWUFBWSxJQUN0QixVQUFVLEtBQUssVUFBVSxLQUFLLENBQ2pDO0dBQ0EsT0FBTztFQUNUO0VBQ0EsSUFBSSxzQkFBc0I7RUFDMUIsS0FBSyxNQUFNLFdBQVcsVUFBVTtHQUM5QixNQUFNLG9CQUFvQixNQUFNLFFBQVEsSUFBSSxZQUFZO0lBQ3RELFNBQVMsbUJBQW1CLFNBQVMsU0FBUzs7Ozs7S0FLN0MsZUFBZTtHQUNsQixDQUFDO0dBQ0QsSUFBSSxDQUFDLG1CQUNIO0dBRUYsc0JBQXNCO0dBQ3RCLE1BQU0sZUFBZSxDQUFDLG1CQUFtQixRQUFRLFFBQVEsSUFBSSxVQUFVLElBQUksS0FBSztHQUNoRixJQUFJO0lBQ0YsSUFBSSxDQUFDLFFBQVEsU0FBUyxDQUFDLGlCQUFpQixHQUN0QyxlQUFlO0dBRW5CLFNBQVMsT0FBTztJQUNkLElBQUksQ0FBQyxLQUFLLE9BQU8sS0FDZixJQUFJLGlDQUFpQyxzQkFBc0I7S0FDekQ7S0FDQSxLQUFLLFdBQVcsT0FBTztLQUN2QixXQUFXLFdBQVcsS0FBSztJQUM3QixDQUFDLENBQ0gsR0FBRztLQUNELFFBQVEsTUFBTSxLQUFLO0tBQ25CLFNBQVMsTUFDUCxpSEFDQSxXQUFXLE9BQU8sR0FDcEI7SUFDRjtJQUNBLE1BQU07R0FDUjtFQUNGO0VBQ0EsSUFBSSxDQUFDLHFCQUFxQjtHQUN4QixNQUFNLDRCQUE0QixNQUFNLGdCQUFnQixDQUFDLENBQUMsV0FDbEQsS0FBSyxZQUFZLElBQ3RCLFVBQVUsS0FBSyxVQUFVLEtBQUssQ0FDakM7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLHNCQUFzQjtFQUMxQixNQUFNLEVBQUUsZUFBZSxLQUFLO0VBTTVCLE9BQU8sdUVBQXVFOztXQUh2RSxXQUFXLE9BQU8sSUFBSTs7RUFHeUQ7O0NBRXhGO0FBQ0Y7OztBQzNHQSxJQUFNLG9CQUFOLGNBQWdDLGNBQWM7Q0FDNUM7Q0FDQTtDQUNBLFlBQVksU0FBUztFQUNuQixNQUFNO0VBQ04sS0FBS0MsZUFBZSxJQUFJLGlCQUFpQjtHQUN2QyxNQUFNO0dBQ04sY0FBYyxRQUFRO0VBQ3hCLENBQUM7RUFDRCxLQUFLQywwQkFBMEIsSUFBSSxJQUFJO0NBQ3pDO0NBQ0EsU0FBUztFQUNQLEtBQUtELGFBQWEsTUFBTTtFQUN4QixLQUFLQSxhQUFhLEdBQUcsV0FBVyxLQUFLRSxlQUFlLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLFlBQVksS0FBS0MsZ0JBQWdCLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLGNBQWMsS0FBS0MsMkJBQTJCLEtBQUssSUFBSSxDQUFDO0NBQzdLO0NBQ0EsVUFBVTtFQUNSLE1BQU0sUUFBUTtFQUNkLEtBQUtKLGFBQWEsUUFBUTtFQUMxQixLQUFLQyxRQUFRLE1BQU07Q0FDckI7Q0FDQSxNQUFNQyxlQUFlLEVBQ25CLFdBQ0EsU0FDQSxjQUNDO0VBQ0QsTUFBTSxZQUFZLElBQUksNEJBQTRCO0dBQ2hELElBQUk7R0FDSjtHQUNBO0VBQ0YsQ0FBQztFQUNELEtBQUtELFFBQVEsSUFBSSxXQUFXLFNBQVM7RUFDckMsTUFBTSxLQUFLLE1BQU0sU0FBUztDQUM1QjtDQUNBLE1BQU1FLGdCQUFnQixFQUNwQixXQUNBLFNBQ0EsVUFDQSxvQkFDQztFQUNELE1BQU0sWUFBWSxLQUFLRixRQUFRLElBQUksU0FBUztFQUM1QyxLQUFLQSxRQUFRLE9BQU8sU0FBUztFQUM3QixJQUFJLGFBQWEsTUFDZjtFQUVGLHFCQUFxQjtHQUNuQixJQUFJO0lBQ0YsVUFBVSxPQUFPLEtBQ2YsSUFBSSxjQUNGLG1CQUFtQixvQkFBb0IsbUJBQ3ZDO0tBQ0U7S0FDQTtLQUNBO0lBQ0YsQ0FDRixDQUNGO0dBQ0YsVUFBVTtJQUNSLFVBQVUsT0FBTyxtQkFBbUI7R0FDdEM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxNQUFNRywyQkFBMkIsWUFBWTtFQUMzQyxNQUFNLEtBQUssTUFDVCxJQUFJLGlDQUFpQyxFQUNuQyxXQUNGLENBQUMsQ0FDSDtDQUNGO0FBQ0Y7QUFDQSxJQUFNLDhCQUFOLGNBQTBDLGlCQUFpQjtDQUN6RDtDQUNBLFlBQVksU0FBUztFQUNuQixNQUFNO0dBQ0osSUFBSSxRQUFRO0dBQ1osU0FBUyxRQUFRO0VBQ25CLENBQUM7RUFDRCxLQUFLQyxjQUFjLFFBQVE7Q0FDN0I7Q0FDQSxjQUFjO0VBQ1osK0JBQStCLEtBQUssS0FBSyxPQUFPO0NBQ2xEO0NBQ0EsWUFBWSxVQUFVO0VBQ3BCLElBQUksVUFDRixLQUFLQSxZQUFZLFlBQVksUUFBUTtDQUV6QztDQUNBLFVBQVUsUUFBUTtFQUNoQixJQUFJLGtCQUFrQixVQUNwQixPQUFPLEtBQUssWUFBWSxNQUFNO0VBRWhDLElBQUksa0JBQWtCLGVBQ3BCLEtBQUtBLFlBQVksVUFBVSxNQUFNO0VBRW5DLE1BQU07Q0FDUjtBQUNGO0FBQ0EsSUFBTSxtQ0FBTixjQUErQyxzQkFBc0I7Q0FDbkUsWUFBWSxNQUFNO0VBQ2hCLE1BQU0sRUFBRSxZQUFZLEtBQUssV0FBVyxDQUFDO0VBQ3JDLEtBQUssV0FBVyxPQUFPLGlCQUNyQixlQUNNO0dBQ0osS0FBSyxPQUFPLG1CQUFtQjtFQUNqQyxHQUNBLEVBQ0UsTUFBTSxLQUNSLENBQ0Y7Q0FDRjtDQUNBLFVBQVUsUUFBUTtFQUNoQixJQUFJLGtCQUFrQixPQUFPO0dBQzNCLE1BQU0sRUFBRSxXQUFXLEtBQUssS0FBSztHQUM3QixNQUFNLGFBQWEsSUFBSSxNQUFNLE9BQU87R0FDcEMsT0FBTyxlQUFlLFlBQVksU0FBUztJQUN6QyxZQUFZO0lBQ1osY0FBYztJQUNkLE9BQU87R0FDVCxDQUFDO0dBQ0QsT0FBTyxPQUFPLGNBQWMsVUFBVTtFQUN4QztDQUNGO0NBQ0EsY0FBYztFQUNaLEtBQUssS0FBSyxXQUFXLE9BQU8sUUFBUTtDQUN0QztBQUNGOzs7QUMzSEEsU0FBUyw2QkFBNkIsZ0JBQWdCO0NBQ3BELFFBQVEsRUFBRSxPQUFPLGVBQWU7RUFDOUIsTUFBTSxtQ0FBbUMsZUFBZTtFQUN4RCxJQUFJLG9DQUFvQyxNQUN0QztFQUVGLElBQUksT0FBTyxxQ0FBcUMsWUFBWTtHQUMxRCxNQUFNLFVBQVUsaUJBQWlCLG1CQUFtQixNQUFNLEtBQUssVUFBVSxpQkFBaUIsd0JBQXdCLElBQUksUUFBUSxNQUFNLEtBQUssV0FBVyxPQUFPLEtBQUssRUFDOUosU0FBUztJQUNQLFlBQVk7SUFDWixTQUFTO0dBQ1gsRUFDRixDQUFDLElBQUk7R0FDTCxZQUNFLFdBQVcsTUFDWCw2R0FDQSxNQUFNLFFBQ1I7R0FDQSxPQUFPLGlDQUFpQyxTQUFTO0lBQy9DLFNBQVMsU0FBUztJQUNsQixPQUFPLFNBQVM7R0FDbEIsQ0FBQztFQUNIO0VBQ0EsT0FBTyw0QkFBNEIsT0FBTyxnQ0FBZ0M7Q0FDNUU7QUFDRjs7O0FDaENBLFNBQVMsZUFBZSxVQUFVO0NBQ2hDLE9BQU87RUFDTCxRQUFRLFNBQVM7RUFDakIsWUFBWSxTQUFTO0VBQ3JCLFNBQVMsT0FBTyxZQUFZLFNBQVMsUUFBUSxRQUFRLENBQUM7Q0FDeEQ7QUFDRjs7O0FDTEEsSUFBSSxrQkFBa0I7QUFDdEIsU0FBUyxvQkFBb0IsWUFBWSxNQUFNO0NBQzdDLFFBQVEsTUFBUjtFQUNFLEtBQUssS0FDSCxPQUFPO0VBQ1QsS0FBSztFQUNMLEtBQUssS0FDSCxPQUFPLE9BQU8sVUFBVTtFQUMxQixLQUFLLEtBQ0gsT0FBTyxLQUFLLFVBQVUsVUFBVTtFQUNsQyxLQUFLLEtBQUs7R0FDUixJQUFJLE9BQU8sZUFBZSxVQUN4QixPQUFPO0dBRVQsTUFBTSxPQUFPLEtBQUssVUFBVSxVQUFVO0dBQ3RDLElBQUksU0FBUyxRQUFRLFNBQVMsUUFBUSxtQkFBbUIsS0FBSyxJQUFJLEdBQ2hFLE9BQU87R0FFVCxPQUFPO0VBQ1Q7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxPQUFPLFNBQVMsR0FBRyxhQUFhO0NBQ3ZDLElBQUksWUFBWSxXQUFXLEdBQ3pCLE9BQU87Q0FFVCxJQUFJLGtCQUFrQjtDQUN0QixJQUFJLG1CQUFtQixRQUFRLFFBQzdCLGtCQUNDLE9BQU8sV0FBVyxHQUFHLFNBQVM7RUFDN0IsTUFBTSxhQUFhLFlBQVk7RUFDL0IsTUFBTSxRQUFRLG9CQUFvQixZQUFZLElBQUk7RUFDbEQsSUFBSSxDQUFDLFdBQVc7R0FDZDtHQUNBLE9BQU87RUFDVDtFQUNBLE9BQU87Q0FDVCxDQUNGO0NBQ0EsSUFBSSxrQkFBa0IsWUFBWSxRQUNoQyxvQkFBb0IsSUFBSSxZQUFZLE1BQU0sZUFBZSxDQUFDLENBQUMsS0FBSyxHQUFHO0NBRXJFLG1CQUFtQixpQkFBaUIsUUFBUSxXQUFXLEdBQUc7Q0FDMUQsT0FBTztBQUNUO0FBQ0EsSUFBSSx5QkFBeUI7QUFDN0IsU0FBUyxnQkFBZ0IsUUFBUTtDQUMvQixJQUFJLENBQUMsT0FBTyxPQUNWO0NBRUYsTUFBTSxZQUFZLE9BQU8sTUFBTSxNQUFNLElBQUk7Q0FDekMsVUFBVSxPQUFPLEdBQUcsc0JBQXNCO0NBQzFDLE9BQU8sUUFBUSxVQUFVLEtBQUssSUFBSTtBQUNwQztBQUNBLElBQUksaUJBQWlCLGNBQWMsTUFBTTtDQUN2QyxZQUFZLFNBQVMsR0FBRyxhQUFhO0VBQ25DLE1BQU0sT0FBTztFQUNiLEtBQUssVUFBVTtFQUNmLEtBQUssT0FBTztFQUNaLEtBQUssVUFBVSxPQUFPLFNBQVMsR0FBRyxXQUFXO0VBQzdDLGdCQUFnQixJQUFJO0NBQ3RCO0FBQ0Y7QUFDQSxJQUFJLGFBQWEsV0FBVyxTQUFTLEdBQUcsZ0JBQWdCO0NBQ3RELElBQUksQ0FBQyxXQUNILE1BQU0sSUFBSSxlQUFlLFNBQVMsR0FBRyxXQUFXO0FBRXBEO0FBQ0EsVUFBVSxNQUFNLGtCQUFrQixXQUFXLFNBQVMsR0FBRyxnQkFBZ0I7Q0FDdkUsSUFBSSxDQUFDLFdBQVc7RUFDZCxNQUFNLGdCQUFnQixZQUFZLFdBQVcsSUFBSSxVQUFVLE9BQU8sU0FBUyxHQUFHLFdBQVc7RUFDekYsSUFBSTtFQUNKLElBQUk7R0FDRixTQUFTLFFBQVEsVUFBVSxrQkFBa0IsQ0FDM0MsYUFDRixDQUFDO0VBQ0gsU0FBUyxLQUFLO0dBQ1osU0FBUyxpQkFBaUIsYUFBYTtFQUN6QztFQUNBLE1BQU07Q0FDUjtBQUNGO0FBR0EsU0FBUyxnQkFBZ0I7Q0FDdkIsSUFBSSxPQUFPLGNBQWMsZUFBZSxVQUFVLFlBQVksZUFDNUQsT0FBTztDQUVULElBQUksT0FBTyxZQUFZLGFBQWE7RUFDbEMsTUFBTSxPQUFPLFFBQVE7RUFDckIsSUFBSSxTQUFTLGNBQWMsU0FBUyxVQUNsQyxPQUFPO0VBRVQsT0FBTyxDQUFDLEVBQUUsUUFBUSxZQUFZLFFBQVEsU0FBUztDQUNqRDtDQUNBLE9BQU87QUFDVDtBQUdBLElBQUksWUFBWSxPQUFPO0FBQ3ZCLElBQUksWUFBWSxRQUFRLFFBQVE7Q0FDOUIsS0FBSyxJQUFJLFFBQVEsS0FDZixVQUFVLFFBQVEsTUFBTTtFQUFFLEtBQUssSUFBSTtFQUFPLFlBQVk7Q0FBSyxDQUFDO0FBQ2hFO0FBQ0EsSUFBSSxpQkFBaUIsQ0FBQztBQUN0QixTQUFTLGdCQUFnQjtDQUN2QixZQUFZO0NBQ1osWUFBWTtDQUNaLGFBQWE7Q0FDYixXQUFXO0NBQ1gsY0FBYztBQUNoQixDQUFDO0FBQ0QsU0FBUyxPQUFPLE1BQU07Q0FDcEIsT0FBTyxXQUFXLEtBQUs7QUFDekI7QUFDQSxTQUFTLEtBQUssTUFBTTtDQUNsQixPQUFPLFdBQVcsS0FBSztBQUN6QjtBQUNBLFNBQVMsS0FBSyxNQUFNO0NBQ2xCLE9BQU8sV0FBVyxLQUFLO0FBQ3pCO0FBQ0EsU0FBUyxJQUFJLE1BQU07Q0FDakIsT0FBTyxXQUFXLEtBQUs7QUFDekI7QUFDQSxTQUFTLE1BQU0sTUFBTTtDQUNuQixPQUFPLFdBQVcsS0FBSztBQUN6QjtBQUNBLElBQUksVUFBVSxjQUFjO0FBQzVCLElBQUksU0FBUyxNQUFNO0NBQ2pCLFlBQVksTUFBTTtFQUNoQixLQUFLLE9BQU87RUFDWixLQUFLLFNBQVMsSUFBSSxLQUFLLEtBQUs7RUFDNUIsTUFBTSxjQUFjLFlBQVksT0FBTztFQUN2QyxNQUFNLGVBQWUsWUFBWSxXQUFXO0VBRTVDLElBRHlCLGdCQUFnQixPQUFPLGdCQUFnQixVQUFVLE9BQU8sZ0JBQWdCLGVBQWUsS0FBSyxLQUFLLFdBQVcsV0FBVyxHQUMxSDtHQUNwQixLQUFLLFFBQVEsc0JBQXNCLGNBQWMsT0FBTyxJQUFJLE9BQU8sS0FBSztHQUN4RSxLQUFLLE9BQU8sc0JBQXNCLGNBQWMsTUFBTSxJQUFJLE9BQU8sS0FBSztHQUN0RSxLQUFLLFVBQVUsc0JBQXNCLGNBQWMsU0FBUyxJQUFJLE9BQU8sS0FBSztHQUM1RSxLQUFLLFVBQVUsc0JBQXNCLGNBQWMsU0FBUyxJQUFJLE9BQU8sS0FBSztHQUM1RSxLQUFLLFFBQVEsc0JBQXNCLGNBQWMsT0FBTyxJQUFJLE9BQU8sS0FBSztFQUMxRSxPQUFPO0dBQ0wsS0FBSyxPQUFPO0dBQ1osS0FBSyxVQUFVO0dBQ2YsS0FBSyxVQUFVO0dBQ2YsS0FBSyxRQUFRO0dBQ2IsS0FBSyxPQUFPO0VBQ2Q7Q0FDRjtDQUNBO0NBQ0EsT0FBTyxRQUFRO0VBQ2IsT0FBTyxJQUFJLE9BQU8sR0FBRyxLQUFLLEtBQUssR0FBRyxRQUFRO0NBQzVDOzs7Ozs7Q0FNQSxNQUFNLFNBQVMsR0FBRyxhQUFhO0VBQzdCLEtBQUssU0FBUztHQUNaLE9BQU87R0FDUCxTQUFTLEtBQUssT0FBTztHQUNyQjtHQUNBLFFBQVEsS0FBSztHQUNiLFFBQVEsRUFDTixRQUFRLE9BQ1Y7RUFDRixDQUFDO0NBQ0g7Ozs7OztDQU1BLEtBQUssU0FBUyxHQUFHLGFBQWE7RUFDNUIsS0FBSyxTQUFTO0dBQ1osT0FBTztHQUNQO0dBQ0E7R0FDQSxRQUFRLEtBQUs7R0FDYixRQUFRLEVBQ04sUUFBUSxPQUNWO0VBQ0YsQ0FBQztFQUNELE1BQU0sZUFBZSxJQUFJLGlCQUFpQjtFQUMxQyxRQUFRLFVBQVUsR0FBRyxpQkFBaUI7R0FDcEMsYUFBYSxRQUFRO0dBQ3JCLEtBQUssU0FBUztJQUNaLE9BQU87SUFDUCxTQUFTLEdBQUcsU0FBUyxHQUFHLEtBQUssR0FBRyxhQUFhLFVBQVUsR0FBRztJQUMxRCxhQUFhO0lBQ2IsUUFBUSxLQUFLO0lBQ2IsUUFBUSxFQUNOLFFBQVEsT0FDVjtHQUNGLENBQUM7RUFDSDtDQUNGOzs7Ozs7Q0FNQSxRQUFRLFNBQVMsR0FBRyxhQUFhO0VBQy9CLEtBQUssU0FBUztHQUNaLE9BQU87R0FDUDtHQUNBO0dBQ0EsUUFBUSxVQUFVLEtBQUs7R0FDdkIsUUFBUTtJQUNOLFdBQVc7SUFDWCxRQUFRO0dBQ1Y7RUFDRixDQUFDO0NBQ0g7Ozs7OztDQU1BLFFBQVEsU0FBUyxHQUFHLGFBQWE7RUFDL0IsS0FBSyxTQUFTO0dBQ1osT0FBTztHQUNQO0dBQ0E7R0FDQSxRQUFRLFVBQVUsS0FBSztHQUN2QixRQUFRO0lBQ04sV0FBVztJQUNYLFFBQVE7R0FDVjtFQUNGLENBQUM7Q0FDSDs7Ozs7O0NBTUEsTUFBTSxTQUFTLEdBQUcsYUFBYTtFQUM3QixLQUFLLFNBQVM7R0FDWixPQUFPO0dBQ1A7R0FDQTtHQUNBLFFBQVEsVUFBVSxLQUFLO0dBQ3ZCLFFBQVE7SUFDTixXQUFXO0lBQ1gsUUFBUTtHQUNWO0VBQ0YsQ0FBQztDQUNIOzs7Ozs7Ozs7O0NBVUEsS0FBSyxVQUFVO0VBQ2IsU0FBUztDQUNYO0NBQ0EsWUFBWSxPQUFPLFNBQVM7RUFDMUIsT0FBTztHQUNMLDJCQUEyQixJQUFJLEtBQUs7R0FDcEM7R0FDQTtFQUNGO0NBQ0Y7Q0FDQSxTQUFTLE1BQU07RUFDYixNQUFNLEVBQ0osT0FDQSxTQUNBLFFBQ0EsUUFBUSxjQUNSLGNBQWMsQ0FBQyxNQUNiO0VBQ0osTUFBTSxRQUFRLEtBQUssWUFBWSxPQUFPLE9BQU87RUFDN0MsTUFBTSxpQkFBaUIsY0FBYyxhQUFhO0VBQ2xELE1BQU0sY0FBYyxjQUFjLFVBQVU7RUFDNUMsTUFBTSxXQUFXO0dBQ2YsV0FBVyxlQUFlO0dBQzFCLFFBQVEsZUFBZTtFQUN6QjtFQUVBLEtBRG1CLFVBQVUsS0FDekIsQ0FBQyxDQUNILENBQUMsU0FBUyxVQUFVLEtBQUssZ0JBQWdCLE1BQU0sU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sVUFBVSxPQUFPLFNBQVMsT0FBTyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLGVBQWUsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FDMUosR0FBRyxZQUFZLElBQUksY0FBYyxDQUNuQztDQUNGO0NBQ0EsZ0JBQWdCLFdBQVc7RUFDekIsT0FBTyxHQUFHLFVBQVUsbUJBQ2xCLE9BQ0YsRUFBRSxHQUFHLFVBQVUsZ0JBQWdCO0NBQ2pDO0NBQ0EsVUFBVSxPQUFPO0VBQ2YsUUFBUSxPQUFSO0dBQ0UsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLLFFBQ0gsT0FBTztHQUVULEtBQUssV0FDSCxPQUFPO0dBRVQsS0FBSyxTQUNILE9BQU87RUFFWDtDQUNGO0FBQ0Y7QUFDQSxJQUFJLG1CQUFtQixNQUFNO0NBQzNCO0NBQ0E7Q0FDQTtDQUNBLGNBQWM7RUFDWixLQUFLLFlBQVksWUFBWSxJQUFJO0NBQ25DO0NBQ0EsVUFBVTtFQUNSLEtBQUssVUFBVSxZQUFZLElBQUk7RUFDL0IsTUFBTSxZQUFZLEtBQUssVUFBVSxLQUFLO0VBQ3RDLEtBQUssWUFBWSxVQUFVLFFBQVEsQ0FBQztDQUN0QztBQUNGO0FBQ0EsSUFBSSxhQUFhLEtBQUs7QUFDdEIsU0FBUyxJQUFJLFNBQVMsR0FBRyxhQUFhO0NBQ3BDLElBQUksU0FBUztFQUNYLFFBQVEsT0FBTyxNQUFNLE9BQU8sU0FBUyxHQUFHLFdBQVcsSUFBSSxJQUFJO0VBQzNEO0NBQ0Y7Q0FDQSxRQUFRLElBQUksU0FBUyxHQUFHLFdBQVc7QUFDckM7QUFDQSxTQUFTLEtBQUssU0FBUyxHQUFHLGFBQWE7Q0FDckMsSUFBSSxTQUFTO0VBQ1gsUUFBUSxPQUFPLE1BQU0sT0FBTyxTQUFTLEdBQUcsV0FBVyxJQUFJLElBQUk7RUFDM0Q7Q0FDRjtDQUNBLFFBQVEsS0FBSyxTQUFTLEdBQUcsV0FBVztBQUN0QztBQUNBLFNBQVMsTUFBTSxTQUFTLEdBQUcsYUFBYTtDQUN0QyxJQUFJLFNBQVM7RUFDWCxRQUFRLE9BQU8sTUFBTSxPQUFPLFNBQVMsR0FBRyxXQUFXLElBQUksSUFBSTtFQUMzRDtDQUNGO0NBQ0EsUUFBUSxNQUFNLFNBQVMsR0FBRyxXQUFXO0FBQ3ZDO0FBQ0EsU0FBUyxZQUFZLGNBQWM7Q0FDakMsSUFBSSxTQUNGLE9BQU8sUUFBUSxJQUFJO0NBRXJCLE9BQU8sV0FBVyxhQUFhLEVBQUUsU0FBUztBQUM1QztBQUNBLFNBQVMsc0JBQXNCLE9BQU8sVUFBVTtDQUM5QyxPQUFPLFVBQVUsS0FBSyxLQUFLLFVBQVU7QUFDdkM7QUFDQSxTQUFTLGVBQWUsU0FBUztDQUMvQixJQUFJLE9BQU8sWUFBWSxhQUNyQixPQUFPO0NBRVQsSUFBSSxZQUFZLE1BQ2QsT0FBTztDQUVULElBQUksT0FBTyxZQUFZLFVBQ3JCLE9BQU87Q0FFVCxJQUFJLE9BQU8sWUFBWSxVQUNyQixPQUFPLEtBQUssVUFBVSxPQUFPO0NBRS9CLE9BQU8sUUFBUSxTQUFTO0FBQzFCO0FBR0EsSUFBSSxrQkFBa0IsY0FBYyxNQUFNO0NBQ3hDLFlBQVksU0FBUyxNQUFNLE9BQU87RUFDaEMsTUFDRSwrQ0FBK0MsTUFBTSxHQUFHLEtBQUssU0FBUyxFQUFFLGtFQUMxRTtFQUNBLEtBQUssVUFBVTtFQUNmLEtBQUssT0FBTztFQUNaLEtBQUssUUFBUTtFQUNiLEtBQUssT0FBTztDQUNkO0FBQ0Y7QUFDQSxJQUFJLFdBQVcsTUFBTTtDQUNuQixPQUFPLGNBQWMsU0FBUyxXQUFXO0VBQ3ZDLE9BQU8sUUFBUSxjQUFjLFNBQVM7Q0FDeEM7Q0FDQSxjQUFjO0VBQ1osS0FBSyx5QkFBeUIsSUFBSSxJQUFJO0VBQ3RDLEtBQUssZUFBZSxTQUFTO0VBQzdCLEtBQUssb0NBQW9DO0NBQzNDO0NBQ0EsbUJBQW1CLG1CQUFtQixXQUFXLFVBQVU7RUFDekQsS0FBSyxLQUNILG1CQUNBLEdBQUcsQ0FBQyxXQUFXLFFBQVEsQ0FDekI7Q0FDRjtDQUNBLGNBQWMsV0FBVztFQUN2QixPQUFPLE1BQU0sVUFBVSxPQUFPLE1BQU0sQ0FBQyxHQUFHLEtBQUssT0FBTyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUM7Q0FDMUU7Q0FDQSxnQkFBZ0IsV0FBVyxVQUFVO0VBQ25DLE1BQU0sUUFBUSxVQUFVLFFBQVEsUUFBUTtFQUN4QyxJQUFJLFFBQVEsSUFDVixVQUFVLE9BQU8sT0FBTyxDQUFDO0VBRTNCLE9BQU8sQ0FBQztDQUNWO0NBQ0Esa0JBQWtCLFdBQVcsVUFBVTtFQUNyQyxNQUFNLGdCQUFnQixHQUFHLFNBQVM7R0FDaEMsS0FBSyxlQUFlLFdBQVcsWUFBWTtHQUMzQyxPQUFPLFNBQVMsTUFBTSxNQUFNLElBQUk7RUFDbEM7RUFDQSxPQUFPLGVBQWUsY0FBYyxRQUFRLEVBQUUsT0FBTyxTQUFTLEtBQUssQ0FBQztFQUNwRSxPQUFPO0NBQ1Q7Q0FDQSxnQkFBZ0IsY0FBYztFQUM1QixLQUFLLGVBQWU7RUFDcEIsT0FBTztDQUNUOzs7Ozs7Q0FNQSxrQkFBa0I7RUFDaEIsT0FBTyxLQUFLO0NBQ2Q7Ozs7O0NBS0EsYUFBYTtFQUNYLE9BQU8sTUFBTSxLQUFLLEtBQUssT0FBTyxLQUFLLENBQUM7Q0FDdEM7Ozs7Ozs7Ozs7Q0FVQSxLQUFLLFdBQVcsR0FBRyxNQUFNO0VBQ3ZCLE1BQU0sWUFBWSxLQUFLLGNBQWMsU0FBUztFQUM5QyxVQUFVLFNBQVMsYUFBYTtHQUM5QixTQUFTLE1BQU0sTUFBTSxJQUFJO0VBQzNCLENBQUM7RUFDRCxPQUFPLFVBQVUsU0FBUztDQUM1QjtDQUNBLFlBQVksV0FBVyxVQUFVO0VBQy9CLEtBQUssbUJBQW1CLGVBQWUsV0FBVyxRQUFRO0VBQzFELE1BQU0sZ0JBQWdCLEtBQUssY0FBYyxTQUFTLENBQUMsQ0FBQyxPQUFPLFFBQVE7RUFDbkUsS0FBSyxPQUFPLElBQUksV0FBVyxhQUFhO0VBQ3hDLElBQUksS0FBSyxlQUFlLEtBQUssS0FBSyxjQUFjLFNBQVMsSUFBSSxLQUFLLGdCQUFnQixDQUFDLEtBQUssbUNBQW1DO0dBQ3pILEtBQUssb0NBQW9DO0dBQ3pDLE1BQU0sb0JBQW9CLElBQUksZ0JBQzVCLE1BQ0EsV0FDQSxLQUFLLGNBQWMsU0FBUyxDQUM5QjtHQUNBLFFBQVEsS0FBSyxpQkFBaUI7RUFDaEM7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxHQUFHLFdBQVcsVUFBVTtFQUN0QixPQUFPLEtBQUssWUFBWSxXQUFXLFFBQVE7Q0FDN0M7Q0FDQSxLQUFLLFdBQVcsVUFBVTtFQUN4QixPQUFPLEtBQUssWUFDVixXQUNBLEtBQUssa0JBQWtCLFdBQVcsUUFBUSxDQUM1QztDQUNGO0NBQ0EsZ0JBQWdCLFdBQVcsVUFBVTtFQUNuQyxNQUFNLFlBQVksS0FBSyxjQUFjLFNBQVM7RUFDOUMsSUFBSSxVQUFVLFNBQVMsR0FBRztHQUN4QixNQUFNLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sU0FBUztHQUNqRCxLQUFLLE9BQU8sSUFBSSxXQUFXLGFBQWE7RUFDMUMsT0FDRSxLQUFLLE9BQU8sSUFBSSxXQUFXLFVBQVUsT0FBTyxRQUFRLENBQUM7RUFFdkQsT0FBTztDQUNUO0NBQ0Esb0JBQW9CLFdBQVcsVUFBVTtFQUN2QyxPQUFPLEtBQUssZ0JBQ1YsV0FDQSxLQUFLLGtCQUFrQixXQUFXLFFBQVEsQ0FDNUM7Q0FDRjtDQUNBLGVBQWUsV0FBVyxVQUFVO0VBQ2xDLE1BQU0sWUFBWSxLQUFLLGNBQWMsU0FBUztFQUM5QyxJQUFJLFVBQVUsU0FBUyxHQUFHO0dBQ3hCLEtBQUssZ0JBQWdCLFdBQVcsUUFBUTtHQUN4QyxLQUFLLE9BQU8sSUFBSSxXQUFXLFNBQVM7R0FDcEMsS0FBSyxtQkFBbUIsa0JBQWtCLFdBQVcsUUFBUTtFQUMvRDtFQUNBLE9BQU87Q0FDVDs7Ozs7OztDQU9BLElBQUksV0FBVyxVQUFVO0VBQ3ZCLE9BQU8sS0FBSyxlQUFlLFdBQVcsUUFBUTtDQUNoRDtDQUNBLG1CQUFtQixXQUFXO0VBQzVCLElBQUksV0FDRixLQUFLLE9BQU8sT0FBTyxTQUFTO09BRTVCLEtBQUssT0FBTyxNQUFNO0VBRXBCLE9BQU87Q0FDVDs7OztDQUlBLFVBQVUsV0FBVztFQUNuQixPQUFPLE1BQU0sS0FBSyxLQUFLLGNBQWMsU0FBUyxDQUFDO0NBQ2pEOzs7O0NBSUEsY0FBYyxXQUFXO0VBQ3ZCLE9BQU8sS0FBSyxjQUFjLFNBQVMsQ0FBQyxDQUFDO0NBQ3ZDO0NBQ0EsYUFBYSxXQUFXO0VBQ3RCLE9BQU8sS0FBSyxVQUFVLFNBQVM7Q0FDakM7QUFDRjtBQUNBLElBQUksVUFBVTtBQUNkLFFBQVEsc0JBQXNCO0FBRzlCLElBQUksa0NBQWtDO0FBQ3RDLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDL0IsT0FBTyxXQUFXLFdBQVcsS0FBSztBQUNwQztBQUNBLFNBQVMsZ0JBQWdCLFFBQVEsT0FBTztDQUN0QyxXQUFXLFVBQVU7QUFDdkI7QUFDQSxTQUFTLG1CQUFtQixRQUFRO0NBQ2xDLE9BQU8sV0FBVztBQUNwQjtBQUNBLElBQUksd0JBQXdDLGlCQUFDLFNBQVMseUJBQXlCO0NBQzdFLHdCQUF3QixjQUFjO0NBQ3RDLHdCQUF3QixjQUFjO0NBQ3RDLHdCQUF3QixhQUFhO0NBQ3JDLHdCQUF3QixlQUFlO0NBQ3ZDLHdCQUF3QixjQUFjO0NBQ3RDLE9BQU87QUFDVCxFQUFBLENBQUcsQ0FBQyxDQUFDO0FBQ0wsSUFBSSxjQUFjLE1BQU07Q0FDdEIsWUFBWSxRQUFRO0VBQ2xCLEtBQUssU0FBUztFQUNkLEtBQUssYUFBYSxzQkFBc0I7RUFDeEMsS0FBSyxVQUFVLElBQUksUUFBUTtFQUMzQixLQUFLLGdCQUFnQixDQUFDO0VBQ3RCLEtBQUssU0FBUyxJQUFJLE9BQU8sT0FBTyxXQUFXO0VBQzNDLEtBQUssUUFBUSxnQkFBZ0IsQ0FBQztFQUM5QixLQUFLLE9BQU8sS0FBSyxpQ0FBaUM7Q0FDcEQ7Ozs7O0NBS0EsbUJBQW1CO0VBQ2pCLE9BQU87Q0FDVDs7Ozs7Q0FLQSxRQUFRO0VBQ04sTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPLE9BQU87RUFDekMsT0FBTyxLQUFLLDZCQUE2QjtFQUN6QyxJQUFJLEtBQUssZUFBZSxzQkFBc0IsU0FBUztHQUNyRCxPQUFPLEtBQUssOEJBQThCO0dBQzFDO0VBQ0Y7RUFDQSxJQUFJLENBQUMsS0FBSyxpQkFBaUIsR0FBRztHQUM1QixPQUFPLEtBQUssd0RBQXdEO0dBQ3BFO0VBQ0Y7RUFDQSxLQUFLLGFBQWEsc0JBQXNCO0VBQ3hDLE1BQU0sa0JBQWtCLEtBQUssWUFBWTtFQUN6QyxJQUFJLGlCQUFpQjtHQUNuQixPQUFPLEtBQUssc0NBQXNDO0dBQ2xELEtBQUssTUFBTSxPQUFPLGFBQWE7SUFDN0IsT0FBTyxLQUFLLGdDQUE4QixLQUFLO0lBQy9DLGdCQUFnQixRQUFRLFlBQVksT0FBTyxRQUFRO0lBQ25ELEtBQUssY0FBYyxXQUFXO0tBQzVCLGdCQUFnQixRQUFRLGVBQWUsT0FBTyxRQUFRO0tBQ3RELE9BQU8sS0FBSyxvQ0FBa0MsS0FBSztJQUNyRCxDQUFDO0lBQ0QsT0FBTztHQUNUO0dBQ0EsS0FBSyxhQUFhLHNCQUFzQjtHQUN4QztFQUNGO0VBQ0EsT0FBTyxLQUFLLHlEQUF5RDtFQUNyRSxLQUFLLE1BQU07RUFDWCxLQUFLLFlBQVk7RUFDakIsS0FBSyxhQUFhLHNCQUFzQjtDQUMxQzs7Ozs7O0NBTUEsUUFBUSxDQUNSOzs7O0NBSUEsR0FBRyxPQUFPLFVBQVU7RUFDbEIsTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPLElBQUk7RUFDdEMsSUFBSSxLQUFLLGVBQWUsc0JBQXNCLGFBQWEsS0FBSyxlQUFlLHNCQUFzQixVQUFVO0dBQzdHLE9BQU8sS0FBSyw0Q0FBNEM7R0FDeEQsT0FBTztFQUNUO0VBQ0EsT0FBTyxLQUFLLGlDQUErQixPQUFPLFFBQVE7RUFDMUQsS0FBSyxRQUFRLEdBQUcsT0FBTyxRQUFRO0VBQy9CLE9BQU87Q0FDVDtDQUNBLEtBQUssT0FBTyxVQUFVO0VBQ3BCLEtBQUssUUFBUSxLQUFLLE9BQU8sUUFBUTtFQUNqQyxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLE9BQU8sVUFBVTtFQUNuQixLQUFLLFFBQVEsSUFBSSxPQUFPLFFBQVE7RUFDaEMsT0FBTztDQUNUO0NBQ0EsbUJBQW1CLE9BQU87RUFDeEIsS0FBSyxRQUFRLG1CQUFtQixLQUFLO0VBQ3JDLE9BQU87Q0FDVDs7OztDQUlBLFVBQVU7RUFDUixNQUFNLFNBQVMsS0FBSyxPQUFPLE9BQU8sU0FBUztFQUMzQyxJQUFJLEtBQUssZUFBZSxzQkFBc0IsVUFBVTtHQUN0RCxPQUFPLEtBQUssbUNBQW1DO0dBQy9DO0VBQ0Y7RUFDQSxPQUFPLEtBQUssOEJBQThCO0VBQzFDLEtBQUssYUFBYSxzQkFBc0I7RUFDeEMsSUFBSSxDQUFDLEtBQUssWUFBWSxHQUFHO0dBQ3ZCLE9BQU8sS0FBSyw4Q0FBOEM7R0FDMUQ7RUFDRjtFQUNBLEtBQUssY0FBYztFQUNuQixPQUFPLEtBQUssMEJBQTBCLGdCQUFnQixLQUFLLE1BQU0sQ0FBQztFQUNsRSxJQUFJLEtBQUssY0FBYyxTQUFTLEdBQUc7R0FDakMsT0FBTyxLQUFLLG9DQUFvQyxLQUFLLGNBQWMsTUFBTTtHQUN6RSxLQUFLLE1BQU0sV0FBVyxLQUFLLGVBQWUsUUFBUTtHQUNsRCxLQUFLLGdCQUFnQixDQUFDO0dBQ3RCLE9BQU8sS0FBSyxrQ0FBa0MsS0FBSyxjQUFjLE1BQU07RUFDekU7RUFDQSxLQUFLLFFBQVEsbUJBQW1CO0VBQ2hDLE9BQU8sS0FBSyx5QkFBeUI7RUFDckMsS0FBSyxhQUFhLHNCQUFzQjtDQUMxQztDQUNBLGNBQWM7RUFDWixNQUFNLFdBQVcsZ0JBQWdCLEtBQUssTUFBTTtFQUM1QyxLQUFLLE9BQU8sS0FBSyw4QkFBOEIsVUFBVSxhQUFhLElBQUk7RUFDMUUsT0FBTztDQUNUO0NBQ0EsY0FBYztFQUNaLGdCQUFnQixLQUFLLFFBQVEsSUFBSTtFQUNqQyxLQUFLLE9BQU8sS0FBSyx3QkFBd0IsS0FBSyxPQUFPLFdBQVc7Q0FDbEU7Q0FDQSxnQkFBZ0I7RUFDZCxtQkFBbUIsS0FBSyxNQUFNO0VBQzlCLEtBQUssT0FBTyxLQUFLLDRCQUE0QixLQUFLLE9BQU8sV0FBVztDQUN0RTtBQUNGO0FBQ0EsU0FBUyxrQkFBa0I7Q0FDekIsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzNDO0FBR0EsU0FBUyxvQkFBb0IsS0FBSztDQUNoQyxJQUFJLE9BQU8sUUFBUSxVQUFVLE9BQU8sb0JBQW9CLElBQUksSUFBSSxLQUFLLE9BQU8sYUFBYSxjQUFjLFNBQVMsT0FBTyxLQUFLLENBQUMsQ0FBQztDQUM5SCxJQUFJLElBQUksYUFBYSxTQUFTLElBQUksV0FBVztNQUN4QyxJQUFJLElBQUksYUFBYSxVQUFVLElBQUksV0FBVztDQUNuRCxJQUFJLElBQUksYUFBYSxTQUFTLElBQUksYUFBYSxRQUM3QyxNQUFNLElBQUksWUFBWSxzR0FBc0csSUFBSSxTQUFTLGtCQUFrQjtDQUM3SixJQUFJLElBQUksU0FBUyxJQUFJLE1BQU0sSUFBSSxZQUFZLDZFQUE2RSxJQUFJLEtBQUssNERBQTREO0NBQzdMLE9BQU8sSUFBSTtBQUNiO0FBR0EsZUFBZSxVQUFVLFNBQVMsV0FBVyxHQUFHLE1BQU07Q0FDcEQsTUFBTSxZQUFZLFFBQVEsVUFBVSxTQUFTO0NBQzdDLElBQUksVUFBVSxXQUFXLEdBQUc7Q0FDNUIsS0FBSyxNQUFNLFlBQVksV0FBVyxNQUFNLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFDdEU7QUFDQSxJQUFJLGtCQUFrQixNQUFNO0NBQzFCLGdDQUFnQyxJQUFJLElBQUk7Q0FDeEMsV0FBVyxPQUFPLEtBQUssY0FBYztFQUNuQyxNQUFNLG9CQUFvQixLQUFLQyxjQUFjLElBQUksS0FBSztFQUN0RCxVQUFVLENBQUMsbUJBQW1CLElBQUksR0FBRyxHQUFHLHdDQUF3QyxPQUFPLEdBQUcsRUFBRSxxQkFBcUI7RUFDakgsTUFBTSxRQUFRLDBCQUEwQixPQUFPLEdBQUc7RUFDbEQsSUFBSSxPQUFPLFVBQVUsYUFBYTtHQUNoQyxRQUFRLEtBQUssd0NBQXdDLE9BQU8sR0FBRyxFQUFFLHVCQUF1QjtHQUN4RixhQUFhLENBQ2I7RUFDRjtFQUNBLElBQUksTUFBTSxXQUFXLGNBQWMsT0FBTyxlQUFlLE9BQU8sS0FBSztHQUNuRSxPQUFPLGFBQWEsTUFBTSxJQUFJO0dBQzlCLFlBQVk7R0FDWixjQUFjO0VBQ2hCLENBQUM7T0FDSSxJQUFJLE1BQU0sV0FBVyxVQUFVLE1BQU0sT0FBTyxhQUFhLE1BQU0sSUFBSTtPQUNuRSxNQUFNLElBQUksTUFBTSw2REFBNkQsSUFBSSxTQUFTLEVBQUUsRUFBRTtFQUNuRyxNQUFNLHFCQUFxQjtHQUN6QixNQUFNLHNCQUFzQixLQUFLQSxjQUFjLElBQUksS0FBSztHQUN4RCxJQUFJLENBQUMscUJBQXFCLElBQUksR0FBRyxHQUFHO0dBQ3BDLElBQUksTUFBTSxVQUFVLE9BQ2xCLE9BQU8sZUFBZSxNQUFNLE9BQU8sS0FBSyxNQUFNLFVBQVU7UUFFeEQsUUFBUSxlQUFlLE9BQU8sR0FBRztHQUNuQyxvQkFBb0IsT0FBTyxHQUFHO0dBQzlCLElBQUksb0JBQW9CLFNBQVMsR0FBRyxLQUFLQSxjQUFjLE9BQU8sS0FBSztFQUNyRTtFQUNBLElBQUksbUJBQW1CLGtCQUFrQixJQUFJLEtBQUssWUFBWTtPQUN6RCxLQUFLQSxjQUFjLElBQUksdUJBQXVCLElBQUksSUFBSSxDQUFDLENBQUMsS0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQ2pGLE9BQU87Q0FDVDtDQUNBLG9CQUFvQjtFQUNsQixNQUFNLFNBQVMsQ0FBQztFQUNoQixLQUFLLE1BQU0sR0FBRyxzQkFBc0IsS0FBS0EsZUFBZSxLQUFLLE1BQU0sR0FBRyxpQkFBaUIsbUJBQW1CLElBQUk7R0FDNUcsYUFBYTtFQUNmLFNBQVMsUUFBUTtHQUNmLElBQUksa0JBQWtCLE9BQU8sT0FBTyxLQUFLLE1BQU07UUFDMUMsTUFBTTtFQUNiO0VBQ0EsSUFBSSxPQUFPLFNBQVMsR0FBRyxNQUFNLElBQUksZUFBZSxRQUFRLE1BQU07Q0FDaEU7QUFDRjtBQUNBLElBQUksa0JBQWtCLElBQUksZ0JBQWdCO0FBQzFDLFNBQVMsMEJBQTBCLE9BQU8sS0FBSztDQUM3QyxJQUFJLGVBQWU7Q0FDbkIsSUFBSTtDQUNKLE9BQU8sY0FBYztFQUNuQixhQUFhLE9BQU8seUJBQXlCLGNBQWMsR0FBRztFQUM5RCxJQUFJLFlBQVksT0FBTztHQUNyQixPQUFPO0dBQ1A7RUFDRjtFQUNBLGVBQWUsT0FBTyxlQUFlLFlBQVk7Q0FDbkQ7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLGNBQWM7Q0FDM0MsTUFBTSxRQUFRLDBCQUEwQixZQUFZLFlBQVk7Q0FDaEUsSUFBSSxPQUFPLFVBQVUsYUFBYSxPQUFPO0NBQ3pDLE1BQU0sRUFBRSxlQUFlO0NBQ3ZCLElBQUksT0FBTyxXQUFXLFFBQVEsY0FBYyxPQUFPLFdBQVcsSUFBSSxNQUFNLGFBQWEsT0FBTztDQUM1RixJQUFJLE9BQU8sV0FBVyxRQUFRLGVBQWUsV0FBVyxTQUFTLE1BQU0sT0FBTztDQUM5RSxJQUFJLE9BQU8sV0FBVyxRQUFRLGVBQWUsQ0FBQyxXQUFXLGNBQWM7RUFDckUsUUFBUSxNQUFNLG1EQUFtRCxhQUFhLG1LQUFtSztFQUNqUCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0FBQ1Q7QUFHQSxTQUFTLHlCQUF5QjtDQUNoQyxNQUFNLFlBQVksU0FBUyxXQUFXO0VBQ3BDLFNBQVMsUUFBUTtFQUNqQixTQUFTLFdBQVcsU0FBUztHQUMzQixJQUFJLFNBQVMsVUFBVSxXQUNyQjtHQUVGLFNBQVMsU0FBUztHQUNsQixNQUFNLGVBQWUsVUFBVTtJQUM3QixTQUFTLFFBQVE7SUFDakIsT0FBTztHQUNUO0dBQ0EsT0FBTyxRQUNMLGdCQUFnQixVQUFVLE9BQU8sUUFBUSxRQUFRLElBQUksQ0FBQyxDQUFDLEtBQUssV0FBVyxDQUN6RTtFQUNGO0VBQ0EsU0FBUyxVQUFVLFdBQVc7R0FDNUIsSUFBSSxTQUFTLFVBQVUsV0FDckI7R0FFRixxQkFBcUI7SUFDbkIsU0FBUyxRQUFRO0dBQ25CLENBQUM7R0FDRCxPQUFPLE9BQU8sU0FBUyxrQkFBa0IsTUFBTTtFQUNqRDtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBSSxrQkFBa0IsY0FBYyxRQUFRO0NBQzFDO0NBQ0E7Q0FDQTtDQUNBLFlBQVksV0FBVyxNQUFNO0VBQzNCLE1BQU0sbUJBQW1CLHVCQUF1QjtFQUNoRCxPQUFPLGlCQUFpQixtQkFBbUI7R0FDekMsaUJBQWlCLGlCQUFpQixjQUFjO0dBQ2hELFdBQVcsaUJBQWlCLFNBQVMsaUJBQWlCLE1BQU07RUFDOUQsQ0FBQztFQUNELEtBQUtDLFlBQVk7RUFDakIsS0FBSyxVQUFVLEtBQUtBLFVBQVU7RUFDOUIsS0FBSyxTQUFTLEtBQUtBLFVBQVU7Q0FDL0I7Q0FDQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUtBLFVBQVU7Q0FDeEI7Q0FDQSxJQUFJLGtCQUFrQjtFQUNwQixPQUFPLEtBQUtBLFVBQVU7Q0FDeEI7Q0FDQSxLQUFLLGFBQWEsWUFBWTtFQUM1QixPQUFPLEtBQUtDLFVBQVUsTUFBTSxLQUFLLGFBQWEsVUFBVSxDQUFDO0NBQzNEO0NBQ0EsTUFBTSxZQUFZO0VBQ2hCLE9BQU8sS0FBS0EsVUFBVSxNQUFNLE1BQU0sVUFBVSxDQUFDO0NBQy9DO0NBQ0EsUUFBUSxXQUFXO0VBQ2pCLE9BQU8sS0FBS0EsVUFBVSxNQUFNLFFBQVEsU0FBUyxDQUFDO0NBQ2hEO0NBQ0EsVUFBVSxTQUFTO0VBQ2pCLE9BQU8sT0FBTyxpQkFBaUIsU0FBUztHQUN0QyxTQUFTO0lBQUUsY0FBYztJQUFNLE9BQU8sS0FBSztHQUFRO0dBQ25ELFFBQVE7SUFBRSxjQUFjO0lBQU0sT0FBTyxLQUFLO0dBQU87RUFDbkQsQ0FBQztDQUNIO0FBQ0Y7QUFHQSxTQUFTLFVBQVUsUUFBUSxPQUFPO0NBQ2hDLE9BQU8saUJBQWlCLE9BQU87RUFDN0IsUUFBUTtHQUNOLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaO0VBQ0EsZUFBZTtHQUNiLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaO0NBQ0YsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLElBQUksY0FBOEIsdUJBQU8sYUFBYTtBQUN0RCxJQUFJLG9CQUFvQyx1QkFBTyxtQkFBbUI7QUFDbEUsSUFBSSx5QkFBeUIsY0FBYyxhQUFhO0NBQ3RELFlBQVksTUFBTSxNQUFNO0VBQ3RCLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLEtBQUssZUFBZSxDQUFDLENBQUMsS0FBSztFQUMzQixLQUFLLHFCQUFxQjtDQUM1QjtDQUNBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxXQUFXLGdCQUFnQjtFQUM3QixLQUFLLGVBQWU7Q0FDdEI7Q0FDQSxJQUFJLG1CQUFtQjtFQUNyQixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksaUJBQWlCLHNCQUFzQjtFQUN6QyxLQUFLLHFCQUFxQjtDQUM1QjtDQUNBLGlCQUFpQjtFQUNmLElBQUksS0FBSyxjQUFjLENBQUMsS0FBSyxvQkFBb0IsS0FBSyxxQkFBcUI7Q0FDN0U7QUFDRjtBQUNBLElBQUksYUFBYSxjQUFjLE1BQU07Q0FDbkMsWUFBWSxNQUFNLE9BQU8sQ0FBQyxHQUFHO0VBQzNCLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLEtBQUssT0FBTyxLQUFLLFNBQVMsS0FBSyxJQUFJLElBQUksS0FBSztFQUM1QyxLQUFLLFNBQVMsS0FBSyxXQUFXLEtBQUssSUFBSSxLQUFLLEtBQUs7RUFDakQsS0FBSyxXQUFXLEtBQUssYUFBYSxLQUFLLElBQUksUUFBUSxLQUFLO0NBQzFEO0FBQ0Y7QUFDQSxJQUFJLHVCQUF1QixjQUFjLFdBQVc7Q0FDbEQsWUFBWSxNQUFNLE9BQU8sQ0FBQyxHQUFHO0VBQzNCLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLEtBQUssZUFBZSxDQUFDLENBQUMsS0FBSztFQUMzQixLQUFLLHFCQUFxQjtDQUM1QjtDQUNBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxXQUFXLGdCQUFnQjtFQUM3QixLQUFLLGVBQWU7Q0FDdEI7Q0FDQSxJQUFJLG1CQUFtQjtFQUNyQixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksaUJBQWlCLHNCQUFzQjtFQUN6QyxLQUFLLHFCQUFxQjtDQUM1QjtDQUNBLGlCQUFpQjtFQUNmLElBQUksS0FBSyxjQUFjLENBQUMsS0FBSyxvQkFBb0IsS0FBSyxxQkFBcUI7Q0FDN0U7QUFDRjtBQUNBLElBQUksYUFBNkIsdUJBQU8sVUFBVTtBQUNsRCxJQUFJLG1CQUFtQyx1QkFBTyxnQkFBZ0I7QUFDOUQsSUFBSSw0QkFBNEIsTUFBTTtDQUNwQyxZQUFZLFFBQVEsV0FBVztFQUM3QixLQUFLLFNBQVM7RUFDZCxLQUFLLFlBQVk7RUFDakIsS0FBSyxLQUFLLGdCQUFnQjtFQUMxQixLQUFLLE1BQU0sSUFBSSxJQUFJLE9BQU8sR0FBRztFQUM3QixLQUFLLGNBQWMsSUFBSSxZQUFZO0VBQ25DLEtBQUssVUFBVSxpQkFBaUIsYUFBYSxVQUFVO0dBQ3JELE1BQU0sVUFBVSxVQUFVLEtBQUssUUFBUSxJQUFJLHVCQUF1QixXQUFXO0lBQzNFLE1BQU0sTUFBTTtJQUNaLFFBQVEsTUFBTTtJQUNkLFlBQVk7R0FDZCxDQUFDLENBQUM7R0FDRixLQUFLLFdBQVcsQ0FBQyxjQUFjLE9BQU87R0FDdEMsSUFBSSxRQUFRLGtCQUFrQixNQUFNLGVBQWU7RUFDckQsQ0FBQztFQUNELEtBQUssVUFBVSxpQkFBaUIsVUFBVSxVQUFVO0dBQ2xELEtBQUssV0FBVyxDQUFDLGNBQWMsVUFBVSxLQUFLLFFBQVEsSUFBSSxXQUFXLFNBQVMsS0FBSyxDQUFDLENBQUM7RUFDdkYsQ0FBQztDQUNIOzs7O0NBSUEsaUJBQWlCLE1BQU0sVUFBVSxTQUFTO0VBQ3hDLElBQUksQ0FBQyxRQUFRLElBQUksVUFBVSxnQkFBZ0IsR0FBRztHQUM1QyxNQUFNLGdCQUFnQixTQUFTLEtBQUssS0FBSyxNQUFNO0dBQy9DLE9BQU8sZUFBZSxVQUFVLGtCQUFrQjtJQUNoRCxPQUFPO0lBQ1AsWUFBWTtJQUNaLGNBQWM7R0FDaEIsQ0FBQztFQUNIO0VBQ0EsS0FBSyxXQUFXLENBQUMsaUJBQWlCLE1BQU0sUUFBUSxJQUFJLFVBQVUsZ0JBQWdCLEdBQUcsT0FBTztDQUMxRjs7OztDQUlBLG9CQUFvQixPQUFPLFVBQVUsU0FBUztFQUM1QyxLQUFLLFdBQVcsQ0FBQyxvQkFBb0IsT0FBTyxRQUFRLElBQUksVUFBVSxnQkFBZ0IsR0FBRyxPQUFPO0NBQzlGOzs7O0NBSUEsS0FBSyxNQUFNO0VBQ1QsS0FBSyxVQUFVLEtBQUssSUFBSTtDQUMxQjs7Ozs7O0NBTUEsTUFBTSxNQUFNLFFBQVE7RUFDbEIsS0FBSyxVQUFVLE1BQU0sTUFBTSxNQUFNO0NBQ25DO0FBQ0Y7QUFDQSxJQUFJLG1DQUFtQztBQUN2QyxJQUFJLHNCQUFzQyx1QkFBTyxxQkFBcUI7QUFDdEUsSUFBSSxVQUEwQix1QkFBTyxTQUFTO0FBQzlDLElBQUksU0FBeUIsdUJBQU8sUUFBUTtBQUM1QyxJQUFJLG9CQUFvQixjQUFjLFlBQVk7Q0FDaEQ7RUFDRSxLQUFLLGFBQWE7Q0FDcEI7Q0FDQTtFQUNFLEtBQUssT0FBTztDQUNkO0NBQ0E7RUFDRSxLQUFLLFVBQVU7Q0FDakI7Q0FDQTtFQUNFLEtBQUssU0FBUztDQUNoQjtDQUNBLFlBQVksS0FBSyxXQUFXO0VBQzFCLE1BQU07RUFDTixLQUFLLGFBQWE7RUFDbEIsS0FBSyxPQUFPO0VBQ1osS0FBSyxVQUFVO0VBQ2YsS0FBSyxTQUFTO0VBQ2QsS0FBSyxVQUFVO0VBQ2YsS0FBSyxhQUFhO0VBQ2xCLEtBQUssV0FBVztFQUNoQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxNQUFNLG9CQUFvQixHQUFHO0VBQ2xDLEtBQUssV0FBVztFQUNoQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssYUFBYSxLQUFLO0VBQ3ZCLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssdUJBQXVCLElBQUksZ0JBQWdCO0VBQ2hELGVBQWUsWUFBWTtHQUN6QixJQUFJLE1BQU0sS0FBSyxzQkFBc0I7R0FDckMsS0FBSyxXQUFXLE9BQU8sY0FBYyxXQUFXLFlBQVksTUFBTSxRQUFRLFNBQVMsS0FBSyxVQUFVLFNBQVMsSUFBSSxVQUFVLEtBQUs7R0FDOUgsSUFBSSxLQUFLLGVBQWUsS0FBSyxZQUFZO0lBQ3ZDLEtBQUssYUFBYSxLQUFLO0lBQ3ZCLEtBQUssY0FBYyxVQUFVLE1BQU0sSUFBSSxNQUFNLE1BQU0sQ0FBQyxDQUFDO0dBQ3ZEO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsSUFBSSxPQUFPLFVBQVU7RUFDbkIsS0FBSyxvQkFBb0IsUUFBUSxLQUFLLE9BQU87RUFDN0MsS0FBSyxVQUFVO0VBQ2YsSUFBSSxhQUFhLE1BQU0sS0FBSyxpQkFBaUIsUUFBUSxRQUFRO0NBQy9EO0NBQ0EsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFVBQVUsVUFBVTtFQUN0QixLQUFLLG9CQUFvQixXQUFXLEtBQUssVUFBVTtFQUNuRCxLQUFLLGFBQWE7RUFDbEIsSUFBSSxhQUFhLE1BQU0sS0FBSyxpQkFBaUIsV0FBVyxRQUFRO0NBQ2xFO0NBQ0EsSUFBSSxZQUFZO0VBQ2QsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFFBQVEsVUFBVTtFQUNwQixLQUFLLG9CQUFvQixTQUFTLEtBQUssUUFBUTtFQUMvQyxLQUFLLFdBQVc7RUFDaEIsSUFBSSxhQUFhLE1BQU0sS0FBSyxpQkFBaUIsU0FBUyxRQUFRO0NBQ2hFO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFFBQVEsVUFBVTtFQUNwQixLQUFLLG9CQUFvQixTQUFTLEtBQUssUUFBUTtFQUMvQyxLQUFLLFdBQVc7RUFDaEIsSUFBSSxhQUFhLE1BQU0sS0FBSyxpQkFBaUIsU0FBUyxRQUFRO0NBQ2hFO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLO0NBQ2Q7Ozs7Q0FJQSxLQUFLLE1BQU07RUFDVCxJQUFJLEtBQUssZUFBZSxLQUFLLFlBQVk7R0FDdkMsS0FBSyxNQUFNO0dBQ1gsTUFBTSxJQUFJLGFBQWEsbUJBQW1CO0VBQzVDO0VBQ0EsSUFBSSxLQUFLLGVBQWUsS0FBSyxXQUFXLEtBQUssZUFBZSxLQUFLLFFBQVE7RUFDekUsS0FBSyxrQkFBa0IsWUFBWSxJQUFJO0VBQ3ZDLHFCQUFxQjtHQUNuQixLQUFLLGlCQUFpQjtHQUN0QixLQUFLLFFBQVEsR0FBRyxJQUFJO0VBQ3RCLENBQUM7Q0FDSDtDQUNBLE1BQU0sT0FBTyxLQUFLLFFBQVE7RUFDeEIsVUFBVSxNQUFNLGdDQUFnQztFQUNoRCxVQUFVLFNBQVMsT0FBTyxRQUFRLE9BQU8sUUFBUSxNQUFNLGdDQUFnQztFQUN2RixLQUFLLE9BQU8sQ0FBQyxNQUFNLE1BQU07Q0FDM0I7Q0FDQSxDQUFDLFFBQVEsT0FBTyxLQUFLLFFBQVEsV0FBVyxNQUFNO0VBQzVDLElBQUksS0FBSyxlQUFlLEtBQUssV0FBVyxLQUFLLGVBQWUsS0FBSyxRQUFRO0VBQ3pFLEtBQUssYUFBYSxLQUFLO0VBQ3ZCLHFCQUFxQjtHQUNuQixLQUFLLGFBQWEsS0FBSztHQUN2QixLQUFLLGNBQWMsVUFBVSxNQUFNLElBQUksV0FBVyxTQUFTO0lBQ3pEO0lBQ0E7SUFDQTtHQUNGLENBQUMsQ0FBQyxDQUFDO0dBQ0gsS0FBSyxVQUFVO0dBQ2YsS0FBSyxhQUFhO0dBQ2xCLEtBQUssV0FBVztHQUNoQixLQUFLLFdBQVc7RUFDbEIsQ0FBQztDQUNIO0NBQ0EsaUJBQWlCLE1BQU0sVUFBVSxTQUFTO0VBQ3hDLE9BQU8sTUFBTSxpQkFBaUIsTUFBTSxVQUFVLE9BQU87Q0FDdkQ7Q0FDQSxvQkFBb0IsTUFBTSxVQUFVLFNBQVM7RUFDM0MsT0FBTyxNQUFNLG9CQUFvQixNQUFNLFVBQVUsT0FBTztDQUMxRDtBQUNGO0FBQ0EsU0FBUyxZQUFZLE1BQU07Q0FDekIsSUFBSSxPQUFPLFNBQVMsVUFBVSxPQUFPLEtBQUs7Q0FDMUMsSUFBSSxnQkFBZ0IsTUFBTSxPQUFPLEtBQUs7Q0FDdEMsT0FBTyxLQUFLO0FBQ2Q7QUFDQSxJQUFJLFdBQTJCLHVCQUFPLFVBQVU7QUFDaEQsSUFBSSxpQkFBaUMsdUJBQU8sZ0JBQWdCO0FBQzVELElBQUksUUFBd0IsdUJBQU8sT0FBTztBQUMxQyxJQUFJLDRCQUE0QixNQUFNO0NBQ3BDLFlBQVksUUFBUSxXQUFXLGtCQUFrQjtFQUMvQyxLQUFLLFNBQVM7RUFDZCxLQUFLLFlBQVk7RUFDakIsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxZQUFZLElBQUksWUFBWTtFQUNqQyxLQUFLLHNCQUFzQixJQUFJLGdCQUFnQjtFQUMvQyxLQUFLLHNCQUFzQixJQUFJLGdCQUFnQjtFQUMvQyxLQUFLLFVBQVUsaUJBQWlCLGFBQWEsVUFBVTtHQUNyRCxJQUFJLE9BQU8sS0FBSyxrQkFBa0IsYUFBYTtHQUMvQyxxQkFBcUI7SUFDbkIsSUFBSSxDQUFDLE1BQU0sa0JBQ1QsS0FBSyxNQUFNLENBQUMsTUFBTSxJQUFJO0dBQzFCLENBQUM7RUFDSCxDQUFDO0VBQ0QsS0FBSyxVQUFVLGlCQUFpQixZQUFZLEtBQUssc0JBQXNCLEtBQUssSUFBSSxDQUFDO0NBQ25GOzs7OztDQUtBLElBQUksU0FBUztFQUNYLFVBQVUsS0FBSyxlQUFlLDBJQUF3STtFQUN0SyxPQUFPLEtBQUs7Q0FDZDs7OztDQUlBLFVBQVU7RUFDUixVQUFVLENBQUMsS0FBSyxpQkFBaUIsS0FBSyxjQUFjLGVBQWUsVUFBVSxNQUFNLDhGQUE0RjtFQUMvSyxNQUFNLGdCQUFnQixLQUFLLGlCQUFpQjtFQUM1QyxjQUFjLGFBQWEsS0FBSyxPQUFPO0VBQ3ZDLGNBQWMsaUJBQWlCLFNBQVMsVUFBVTtHQUNoRCxLQUFLLFNBQVMsQ0FBQyxjQUFjLFVBQVUsS0FBSyxlQUFlLElBQUksTUFBTSxRQUFRLEtBQUssQ0FBQyxDQUFDO0VBQ3RGLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztFQUNqQixjQUFjLGlCQUFpQixZQUFZLFVBQVU7R0FDbkQsS0FBSyxVQUFVLGNBQWMsVUFBVSxLQUFLLGVBQWUsSUFBSSxhQUFhLFlBQVk7SUFDdEYsTUFBTSxNQUFNO0lBQ1osUUFBUSxNQUFNO0dBQ2hCLENBQUMsQ0FBQyxDQUFDO0VBQ0wsQ0FBQztFQUNELEtBQUssT0FBTyxpQkFBaUIsVUFBVSxVQUFVO0dBQy9DLEtBQUssZ0JBQWdCLEtBQUs7RUFDNUIsR0FBRyxFQUFFLFFBQVEsS0FBSyxvQkFBb0IsT0FBTyxDQUFDO0VBQzlDLGNBQWMsaUJBQWlCLFVBQVUsVUFBVTtHQUNqRCxLQUFLLGdCQUFnQixLQUFLO0VBQzVCLEdBQUcsRUFBRSxRQUFRLEtBQUssb0JBQW9CLE9BQU8sQ0FBQztFQUM5QyxjQUFjLGlCQUFpQixlQUFlO0dBQzVDLE1BQU0sYUFBYSxVQUFVLGVBQWUsSUFBSSxNQUFNLFNBQVMsRUFBRSxZQUFZLEtBQUssQ0FBQyxDQUFDO0dBQ3BGLEtBQUssU0FBUyxDQUFDLGNBQWMsVUFBVTtHQUN2QyxJQUFJLENBQUMsV0FBVyxrQkFBa0IsS0FBSyxPQUFPLGNBQWMsVUFBVSxLQUFLLFFBQVEsSUFBSSxNQUFNLE9BQU8sQ0FBQyxDQUFDO0VBQ3hHLENBQUM7RUFDRCxLQUFLLGdCQUFnQjtDQUN2Qjs7OztDQUlBLGlCQUFpQixPQUFPLFVBQVUsU0FBUztFQUN6QyxJQUFJLENBQUMsUUFBUSxJQUFJLFVBQVUsY0FBYyxHQUFHO0dBQzFDLE1BQU0sZ0JBQWdCLFNBQVMsS0FBSyxLQUFLLE1BQU07R0FDL0MsT0FBTyxlQUFlLFVBQVUsZ0JBQWdCO0lBQzlDLE9BQU87SUFDUCxZQUFZO0dBQ2QsQ0FBQztFQUNIO0VBQ0EsS0FBSyxTQUFTLENBQUMsaUJBQWlCLE9BQU8sUUFBUSxJQUFJLFVBQVUsY0FBYyxHQUFHLE9BQU87Q0FDdkY7Ozs7Q0FJQSxvQkFBb0IsT0FBTyxVQUFVLFNBQVM7RUFDNUMsS0FBSyxTQUFTLENBQUMsb0JBQW9CLE9BQU8sUUFBUSxJQUFJLFVBQVUsY0FBYyxHQUFHLE9BQU87Q0FDMUY7Ozs7Ozs7O0NBUUEsS0FBSyxNQUFNO0VBQ1QsS0FBSyxNQUFNLENBQUMsSUFBSTtDQUNsQjtDQUNBLENBQUMsT0FBTyxNQUFNO0VBQ1osTUFBTSxFQUFFLGtCQUFrQjtFQUMxQixVQUFVLGVBQWUseUhBQW1ILEtBQUssT0FBTyxHQUFHO0VBQzNKLElBQUksY0FBYyxlQUFlLFVBQVUsV0FBVyxjQUFjLGVBQWUsVUFBVSxRQUFRO0VBQ3JHLElBQUksY0FBYyxlQUFlLFVBQVUsWUFBWTtHQUNyRCxjQUFjLGlCQUFpQixjQUFjO0lBQzNDLGNBQWMsS0FBSyxJQUFJO0dBQ3pCLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztHQUNqQjtFQUNGO0VBQ0EsY0FBYyxLQUFLLElBQUk7Q0FDekI7Ozs7Q0FJQSxRQUFRO0VBQ04sTUFBTSxFQUFFLGtCQUFrQjtFQUMxQixVQUFVLGVBQWUsMEhBQXNILEtBQUssT0FBTyxHQUFHO0VBQzlKLEtBQUssb0JBQW9CLE1BQU07RUFDL0IsSUFBSSxjQUFjLGVBQWUsVUFBVSxXQUFXLGNBQWMsZUFBZSxVQUFVLFFBQVE7RUFDckcsY0FBYyxNQUFNO0VBQ3BCLHFCQUFxQjtHQUNuQixLQUFLLFNBQVMsQ0FBQyxjQUFjLFVBQVUsS0FBSyxlQUFlLElBQUkscUJBQXFCLFNBQVM7SUFDM0YsTUFBTTtJQUNOLFlBQVk7R0FDZCxDQUFDLENBQUMsQ0FBQztFQUNMLENBQUM7Q0FDSDtDQUNBLHNCQUFzQixPQUFPO0VBQzNCLE1BQU0sZUFBZSxVQUFVLE1BQU0sUUFBUSxJQUFJLHVCQUF1QixXQUFXO0dBQ2pGLE1BQU0sTUFBTTtHQUNaLFFBQVEsTUFBTTtHQUNkLFlBQVk7RUFDZCxDQUFDLENBQUM7RUFDRixLQUFLLFNBQVMsQ0FBQyxjQUFjLFlBQVk7RUFDekMsSUFBSSxDQUFDLGFBQWEsa0JBQWtCLEtBQUssT0FBTyxjQUFjOzs7Ozs7R0FNNUQsS0FBSztHQUNMLElBQUksYUFBYSxXQUFXO0lBQzFCLE1BQU0sTUFBTTtJQUNaLFFBQVEsTUFBTTtHQUNoQixDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsZ0JBQWdCLFFBQVE7RUFDdEIsSUFBSSxLQUFLLGVBQWUsS0FBSyxjQUFjLE1BQU07Q0FDbkQ7Q0FDQSxnQkFBZ0IsT0FBTztFQUNyQixLQUFLLG9CQUFvQixNQUFNO0VBQy9CLE1BQU0sYUFBYSxVQUFVLEtBQUssZUFBZSxJQUFJLHFCQUFxQixTQUFTO0dBQ2pGLE1BQU0sTUFBTTtHQUNaLFFBQVEsTUFBTTtHQUNkLFVBQVUsTUFBTTtHQUNoQixZQUFZO0VBQ2QsQ0FBQyxDQUFDO0VBQ0YsS0FBSyxTQUFTLENBQUMsY0FBYyxVQUFVO0VBQ3ZDLElBQUksQ0FBQyxXQUFXLGtCQUFrQixLQUFLLE9BQU8sT0FBTyxDQUFDLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDaEY7QUFDRjtBQUNBLElBQUksMEJBQTBCLGNBQWMsWUFBWTtDQUN0RCxZQUFZLFFBQVE7RUFDbEIsTUFBTTtFQUNOLEtBQUssU0FBUztFQUNkLEtBQUssT0FBTyxpQkFBaUIsVUFBVSxVQUFVO0dBQy9DLEtBQUssY0FBYyxVQUFVLEtBQUssUUFBUSxJQUFJLFdBQVcsU0FBUyxLQUFLLENBQUMsQ0FBQztFQUMzRSxDQUFDO0VBQ0QsS0FBSyxPQUFPLFlBQVksU0FBUztHQUMvQixLQUFLLGNBQWMsVUFBVSxLQUFLLFFBQVEsSUFBSSx1QkFBdUIsWUFBWTtJQUMvRTtJQUNBLFFBQVEsS0FBSyxPQUFPO0lBQ3BCLFlBQVk7R0FDZCxDQUFDLENBQUMsQ0FBQztFQUNMO0NBQ0Y7Q0FDQSxpQkFBaUIsTUFBTSxVQUFVLFNBQVM7RUFDeEMsT0FBTyxNQUFNLGlCQUFpQixNQUFNLFVBQVUsT0FBTztDQUN2RDtDQUNBLGNBQWMsT0FBTztFQUNuQixPQUFPLE1BQU0sY0FBYyxLQUFLO0NBQ2xDO0NBQ0EsS0FBSyxNQUFNO0VBQ1QscUJBQXFCO0dBQ25CLElBQUksS0FBSyxPQUFPLGVBQWUsS0FBSyxPQUFPLFdBQVcsS0FBSyxPQUFPLGVBQWUsS0FBSyxPQUFPLFFBQVE7R0FDckcsTUFBTSxzQkFBc0I7SUFDMUIsS0FBSyxPQUFPLGNBQWM7Ozs7Ozs7OztLQVN4QixLQUFLO0tBQ0wsSUFBSSxhQUFhLFdBQVc7TUFDMUI7TUFDQSxRQUFRLEtBQUssT0FBTztLQUN0QixDQUFDO0lBQ0gsQ0FBQztHQUNIO0dBQ0EsSUFBSSxLQUFLLE9BQU8sZUFBZSxLQUFLLE9BQU8sWUFBWSxLQUFLLE9BQU8saUJBQWlCLGNBQWM7SUFDaEcsY0FBYztHQUNoQixHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7UUFDWixjQUFjO0VBQ3JCLENBQUM7Q0FDSDtDQUNBLE1BQU0sTUFBTSxRQUFRO0VBQ2xCLEtBQUssT0FBTyxPQUFPLENBQUMsTUFBTSxNQUFNO0NBQ2xDO0FBQ0Y7QUFDQSxJQUFJLHVCQUF1QixNQUFNLDhCQUE4QixZQUFZO0NBQ3pFO0VBQ0UsS0FBSyxTQUF5Qix1QkFBTyxJQUFJLHVCQUF1QjtDQUNsRTtDQUNBLGNBQWM7RUFDWixNQUFNLHNCQUFzQixNQUFNO0NBQ3BDO0NBQ0EsbUJBQW1CO0VBQ2pCLE9BQU8sc0JBQXNCLFdBQVc7Q0FDMUM7Q0FDQSxRQUFRO0VBQ04sTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPLE9BQU87RUFDekMsTUFBTSxpQkFBaUIsSUFBSSxNQUFNLFdBQVcsV0FBVyxFQUFFLFlBQVksUUFBUSxNQUFNLGNBQWM7R0FDL0YsTUFBTSxDQUFDLEtBQUssYUFBYTtHQUN6QixNQUFNLHlCQUF5QjtJQUM3QixPQUFPLFFBQVEsVUFBVSxRQUFRLE1BQU0sU0FBUztHQUNsRDtHQUNBLE1BQU0sU0FBUyxJQUFJLGtCQUFrQixLQUFLLFNBQVM7R0FDbkQsTUFBTSxZQUFZLElBQUksd0JBQXdCLE1BQU07R0FDcEQsZUFBZSxZQUFZO0lBQ3pCLElBQUk7S0FDRixNQUFNLFNBQVMsSUFBSSwwQkFBMEIsUUFBUSxXQUFXLGdCQUFnQjtLQUNoRixNQUFNLHlCQUF5QixLQUFLLFFBQVEsY0FBYyxZQUFZLElBQUk7S0FDMUUsTUFBTSxVQUFVLEtBQUssU0FBUyxjQUFjO01BQzFDLFFBQVEsSUFBSSwwQkFBMEIsUUFBUSxTQUFTO01BQ3ZEO01BQ0EsTUFBTSxFQUFFLFVBQVU7S0FDcEIsQ0FBQztLQUNELElBQUksd0JBQXdCLE9BQU8sb0JBQW9CLENBQUMsUUFBUSxLQUFLO1VBQ2hFO01BQ0gsT0FBTyxvQkFBb0IsQ0FBQyxRQUFRLElBQUk7TUFDeEMsT0FBTyxRQUFRO01BQ2YsT0FBTyxpQkFBaUIsY0FBYztPQUNwQyxPQUFPLGNBQWMsVUFBVSxRQUFRLElBQUksTUFBTSxNQUFNLENBQUMsQ0FBQztPQUN6RCxJQUFJLE9BQU8sa0JBQWtCLE9BQU8sV0FBVyxPQUFPLGdCQUFnQixDQUFDO01BQ3pFLENBQUM7S0FDSDtJQUNGLFNBQVMsUUFBUTtLQUNmLElBQUksa0JBQWtCLE9BQU87TUFDM0IsT0FBTyxjQUFjLElBQUksTUFBTSxPQUFPLENBQUM7TUFDdkMsSUFBSSxPQUFPLGVBQWUsVUFBVSxXQUFXLE9BQU8sZUFBZSxVQUFVLFFBQVEsT0FBTyxPQUFPLENBQUMsTUFBTSxPQUFPLFNBQVMsS0FBSztNQUNqSSxRQUFRLE1BQU0sTUFBTTtLQUN0QjtJQUNGO0dBQ0YsQ0FBQztHQUNELE9BQU87RUFDVCxFQUFFLENBQUM7RUFDSCxPQUFPLEtBQUssOEJBQThCO0VBQzFDLEtBQUssY0FBYyxLQUFLLGdCQUFnQixXQUFXLFlBQVksbUJBQW1CLGNBQWMsQ0FBQztFQUNqRyxPQUFPLEtBQUssNkJBQTZCLFdBQVcsVUFBVSxJQUFJO0NBQ3BFO0FBQ0Y7QUFZQSxTQUFTLHdCQUF3QjtDQUMvQixPQUFPLE9BQU8sY0FBYyxlQUFlLG1CQUFtQixhQUFhLE9BQU8sYUFBYSxlQUFlLFNBQVMsYUFBYTtBQUN0STtBQUNBLFNBQVMsaUNBQWlDO0NBQ3hDLElBQUk7RUFDRixNQUFNLFNBQVMsSUFBSSxlQUFlLEVBQ2hDLFFBQVEsZUFBZSxXQUFXLE1BQU0sRUFDMUMsQ0FBQztFQUVELElBRG9CLGVBQ2QsQ0FBQyxDQUFDLE1BQU0sWUFBWSxRQUFRLENBQUMsTUFBTSxDQUFDO0VBQzFDLE9BQU87Q0FDVCxRQUFRO0VBQ04sT0FBTztDQUNUO0FBQ0Y7QUFHQSxTQUFTLDBCQUEwQjtDQUNqQyxNQUFNLGFBQWEsU0FBUyxXQUFXO0VBQ3JDLFNBQVMsUUFBUTtFQUNqQixTQUFTLFdBQVcsU0FBUztHQUMzQixJQUFJLFNBQVMsVUFBVSxXQUFXO0dBQ2xDLFNBQVMsU0FBUztHQUNsQixNQUFNLGVBQWUsVUFBVTtJQUM3QixTQUFTLFFBQVE7SUFDakIsT0FBTztHQUNUO0dBQ0EsT0FBTyxRQUFRLGdCQUFnQixVQUFVLE9BQU8sUUFBUSxRQUFRLElBQUksQ0FBQyxDQUFDLEtBQUssV0FBVyxDQUFDO0VBQ3pGO0VBQ0EsU0FBUyxVQUFVLFdBQVc7R0FDNUIsSUFBSSxTQUFTLFVBQVUsV0FBVztHQUNsQyxxQkFBcUI7SUFDbkIsU0FBUyxRQUFRO0dBQ25CLENBQUM7R0FDRCxPQUFPLE9BQU8sU0FBUyxrQkFBa0IsTUFBTTtFQUNqRDtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBSSxtQkFBbUIsY0FBYyxRQUFRO0NBQzNDO0NBQ0E7Q0FDQTtDQUNBLFlBQVksV0FBVyxNQUFNO0VBQzNCLE1BQU0sbUJBQW1CLHdCQUF3QjtFQUNqRCxPQUFPLGlCQUFpQixtQkFBbUI7R0FDekMsaUJBQWlCLGlCQUFpQixjQUFjO0dBQ2hELFdBQVcsaUJBQWlCLFNBQVMsaUJBQWlCLE1BQU07RUFDOUQsQ0FBQztFQUNELEtBQUtELFlBQVk7RUFDakIsS0FBSyxVQUFVLEtBQUtBLFVBQVU7RUFDOUIsS0FBSyxTQUFTLEtBQUtBLFVBQVU7Q0FDL0I7Q0FDQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUtBLFVBQVU7Q0FDeEI7Q0FDQSxJQUFJLGtCQUFrQjtFQUNwQixPQUFPLEtBQUtBLFVBQVU7Q0FDeEI7Q0FDQSxLQUFLLGFBQWEsWUFBWTtFQUM1QixPQUFPLEtBQUtDLFVBQVUsTUFBTSxLQUFLLGFBQWEsVUFBVSxDQUFDO0NBQzNEO0NBQ0EsTUFBTSxZQUFZO0VBQ2hCLE9BQU8sS0FBS0EsVUFBVSxNQUFNLE1BQU0sVUFBVSxDQUFDO0NBQy9DO0NBQ0EsUUFBUSxXQUFXO0VBQ2pCLE9BQU8sS0FBS0EsVUFBVSxNQUFNLFFBQVEsU0FBUyxDQUFDO0NBQ2hEO0NBQ0EsVUFBVSxTQUFTO0VBQ2pCLE9BQU8sT0FBTyxpQkFBaUIsU0FBUztHQUN0QyxTQUFTO0lBQ1AsY0FBYztJQUNkLE9BQU8sS0FBSztHQUNkO0dBQ0EsUUFBUTtJQUNOLGNBQWM7SUFDZCxPQUFPLEtBQUs7R0FDZDtFQUNGLENBQUM7Q0FDSDtBQUNGO0FBR0EsSUFBSSxtQkFBbUIsTUFBTSwwQkFBMEIsTUFBTTtDQUMzRCxZQUFZLFNBQVM7RUFDbkIsTUFBTSxPQUFPO0VBQ2IsS0FBSyxPQUFPO0VBQ1osT0FBTyxlQUFlLE1BQU0sa0JBQWtCLFNBQVM7Q0FDekQ7QUFDRjtBQUNBLElBQUksb0JBQW9CLE1BQU0sbUJBQW1CO0NBQy9DO0VBQ0UsS0FBSyxVQUFVO0NBQ2pCO0NBQ0E7RUFDRSxLQUFLLGNBQWM7Q0FDckI7Q0FDQTtFQUNFLEtBQUssV0FBVztDQUNsQjtDQUNBO0VBQ0UsS0FBSyxRQUFRO0NBQ2Y7Q0FDQSxZQUFZLFNBQVMsUUFBUTtFQUMzQixLQUFLLFVBQVU7RUFDZixLQUFLLFNBQVM7RUFDZCxLQUFLLGFBQWEsbUJBQW1CO0VBQ3JDLEtBQUssVUFBVSxJQUFJLGdCQUFnQjtDQUNyQztDQUNBLElBQUlDLFdBQVc7RUFDYixPQUFPLEtBQUs7Q0FDZDs7OztDQUlBLE1BQU0sY0FBYztFQUNsQixVQUFVLEdBQUcsa0JBQWtCLEtBQUssZUFBZSxtQkFBbUIsU0FBUyxxRkFBbUYsS0FBSyxRQUFRLFFBQVEsS0FBSyxRQUFRLEdBQUc7RUFDdk0sS0FBSyxhQUFhLG1CQUFtQjtFQUNyQyxNQUFNLEtBQUssT0FBTyxZQUFZO0VBQzlCLEtBQUtBLFNBQVMsUUFBUTtDQUN4Qjs7Ozs7Ozs7O0NBU0EsWUFBWSxVQUFVO0VBQ3BCLFVBQVUsR0FBRyxrQkFBa0IsS0FBSyxlQUFlLG1CQUFtQixTQUFTLHdHQUFvRyxLQUFLLFFBQVEsUUFBUSxLQUFLLFFBQVEsS0FBSyxTQUFTLFFBQVEsU0FBUyxjQUFjLE1BQU0sS0FBSyxVQUFVO0VBQ3ZSLEtBQUssYUFBYSxtQkFBbUI7RUFDckMsS0FBS0EsU0FBUyxRQUFRO0VBQ3RCLEtBQUssT0FBTyxZQUFZLFFBQVE7Q0FDbEM7Ozs7Ozs7OztDQVNBLFVBQVUsUUFBUTtFQUNoQixVQUFVLEdBQUcsa0JBQWtCLEtBQUssZUFBZSxtQkFBbUIsU0FBUyxnR0FBNEYsS0FBSyxRQUFRLFFBQVEsS0FBSyxRQUFRLEtBQUssUUFBUSxTQUFTLEdBQUcsS0FBSyxVQUFVO0VBQ3JQLEtBQUssYUFBYSxtQkFBbUI7RUFDckMsS0FBSyxPQUFPLFVBQVUsTUFBTTtFQUM1QixLQUFLQSxTQUFTLFFBQVE7Q0FDeEI7QUFDRjtBQUNBLFNBQVMsWUFBWSxLQUFLO0NBQ3hCLElBQUk7RUFDRixJQUFJLElBQUksR0FBRztFQUNYLE9BQU87Q0FDVCxTQUFTLFFBQVE7RUFDZixPQUFPO0NBQ1Q7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLFlBQVksUUFBUTtDQUM1QyxNQUFNLFNBQVMsT0FBTyxzQkFBc0IsTUFBTSxDQUFDLENBQUMsTUFBTSxhQUFhO0VBQ3JFLE9BQU8sU0FBUyxnQkFBZ0I7Q0FDbEMsQ0FBQztDQUNELElBQUksUUFBUSxPQUFPLFFBQVEsSUFBSSxRQUFRLE1BQU07QUFDL0M7QUFDQSxJQUFJLGVBQWUsTUFBTSxzQkFBc0IsUUFBUTtDQUNyRCxPQUFPQyxpQkFBaUIsT0FBTyxPQUFPLENBQUMsR0FBRyxLQUFLO0VBQzdDLE9BQU8sS0FBSyxTQUFTLGlCQUFpQixVQUFVLE1BQU0sT0FBTyxLQUFLO0NBQ3BFOzs7OztDQUtBLE9BQU8scUJBQXFCLFFBQVE7RUFDbEMsT0FBTyxXQUFXLGFBQWEsV0FBVyxXQUFXLFdBQVc7Q0FDbEU7Q0FDQSxPQUFPLGlCQUFpQixRQUFRO0VBQzlCLE9BQU8sV0FBVyxVQUFVLFdBQVcsU0FBUyxjQUFjLHFCQUFxQixNQUFNO0NBQzNGOzs7OztDQUtBLE9BQU8sbUJBQW1CLE1BQU07RUFDOUIsT0FBTyxTQUFTLGNBQWMsU0FBUyxlQUFlLFNBQVM7Q0FDakU7Q0FDQSxZQUFZLE9BQU8sTUFBTTtFQUN2QixNQUFNLFNBQVMsY0FBY0EsaUJBQWlCLE9BQU8sTUFBTSxRQUFRLEtBQUs7RUFDeEUsTUFBTSxhQUFhLGNBQWMscUJBQXFCLE1BQU0sSUFBSSxTQUFTO0VBQ3pFLE1BQU0sa0JBQWtCLFFBQVEsUUFBUSxVQUFVO0VBQ2xELE1BQU0sV0FBVyxDQUFDLGNBQWMsaUJBQWlCLE1BQU0sSUFBSSxFQUFFLE1BQU0sS0FBSyxFQUFFLElBQUksa0JBQWtCLEVBQUUsTUFBTSxLQUFLLEtBQUssSUFBSSxDQUFDO0VBQ3ZILE1BQU0sT0FBTyxjQUFjQSxpQkFBaUIsT0FBTyxNQUFNLE1BQU0sS0FBSyxLQUFLO0VBQ3pFLE1BQU0sV0FBVyxjQUFjLG1CQUFtQixJQUFJLElBQUksT0FBTyxLQUFLO0VBQ3RFLE1BQU0sT0FBTztHQUNYLEdBQUcsUUFBUSxDQUFDO0dBQ1osUUFBUTtHQUNSLE1BQU07R0FDTixRQUFRLE1BQU0sV0FBVyxjQUFjLGlCQUFpQixNQUFNLElBQUksU0FBUyxLQUFLO0dBQ2hGLEdBQUc7RUFDTCxDQUFDO0VBQ0QsSUFBSSxXQUFXLFlBQVksS0FBS0MscUJBQXFCLFVBQVUsTUFBTTtFQUNyRSxJQUFJLFdBQVcsV0FBVztHQUN4QixNQUFNLE1BQU0sSUFBSSxJQUFJLGlCQUFpQixVQUFVLE1BQU0sTUFBTSxLQUFLO0dBQ2hFLElBQUk7R0FDSixJQUFJLElBQUksYUFBYSxjQUFjLFlBQVksSUFBSTtRQUM5QyxZQUFZLElBQUksU0FBUyxRQUFRLFFBQVEsRUFBRTtHQUNoRCxPQUFPLGVBQWUsTUFBTSxPQUFPO0lBQ2pDLFdBQVc7SUFDWCxZQUFZO0lBQ1osY0FBYztHQUNoQixDQUFDO0VBQ0g7RUFDQSxJQUFJLFFBQVEsUUFBUSxTQUFTLFVBQVUsS0FBS0EscUJBQXFCLFFBQVEsSUFBSTtDQUMvRTtDQUNBLHFCQUFxQixLQUFLLE9BQU87RUFDL0IsTUFBTSxnQkFBZ0IsaUJBQWlCLFNBQVMsSUFBSTtFQUNwRCxJQUFJLGVBQWUsUUFBUSxJQUFJLGVBQWUsS0FBSyxLQUFLO09BQ25ELE9BQU8sZUFBZSxNQUFNLEtBQUs7R0FDcEM7R0FDQSxZQUFZO0dBQ1osY0FBYztHQUNkLFVBQVU7RUFDWixDQUFDO0NBQ0g7QUFDRjtBQUNBLElBQUksVUFBMEIsdUJBQU8sU0FBUztBQUM5QyxJQUFJLE9BQXVCLHVCQUFPLE1BQU07QUFDeEMsSUFBSSxnQkFBZ0IsTUFBTSx1QkFBdUIsU0FBUztDQUN4RDtFQUNFLEtBQUssNEJBQTRCO0dBQy9CO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtDQUNGO0NBQ0E7RUFDRSxLQUFLLDZCQUE2QjtHQUNoQztHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7Q0FDRjtDQUNBLE9BQU8seUJBQXlCLFFBQVE7RUFDdEMsT0FBTyxVQUFVLE9BQU8sVUFBVTtDQUNwQztDQUNBLE9BQU8sbUJBQW1CLFFBQVE7RUFDaEMsT0FBTyxlQUFlLDJCQUEyQixTQUFTLE1BQU07Q0FDbEU7Ozs7O0NBS0EsT0FBTyxtQkFBbUIsUUFBUTtFQUNoQyxPQUFPLENBQUMsZUFBZSwwQkFBMEIsU0FBUyxNQUFNO0NBQ2xFO0NBQ0EsT0FBTyxVQUFVLFFBQVEsVUFBVTtFQUNqQyxNQUFNLGdCQUFnQixpQkFBaUIsU0FBUyxRQUFRO0VBQ3hELElBQUksZUFBZSxjQUFjLFNBQVM7T0FDckMsT0FBTyxlQUFlLFVBQVUsVUFBVTtHQUM3QyxPQUFPO0dBQ1AsWUFBWTtHQUNaLGNBQWM7R0FDZCxVQUFVO0VBQ1osQ0FBQztFQUNELE9BQU8sZUFBZSxVQUFVLFNBQVM7R0FDdkMsT0FBTztHQUNQLFlBQVk7RUFDZCxDQUFDO0NBQ0g7Q0FDQSxPQUFPLE9BQU8sS0FBSyxVQUFVO0VBQzNCLElBQUksQ0FBQyxPQUFPLFFBQVEsWUFBWSxDQUFDLFlBQVksR0FBRyxHQUFHO0VBQ25ELE1BQU0sUUFBUSxpQkFBaUIsU0FBUyxRQUFRO0VBQ2hELElBQUksT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDO09BQ3JDLE9BQU8sZUFBZSxVQUFVLE9BQU87R0FDMUMsT0FBTztHQUNQLFlBQVk7R0FDWixjQUFjO0dBQ2QsVUFBVTtFQUNaLENBQUM7RUFDRCxPQUFPLGVBQWUsVUFBVSxNQUFNO0dBQ3BDLE9BQU87R0FDUCxZQUFZO0VBQ2QsQ0FBQztDQUNIOzs7O0NBSUEsT0FBTyxnQkFBZ0IsWUFBWTtFQUNqQyxNQUFNLFVBQVUsSUFBSSxRQUFRO0VBQzVCLEtBQUssSUFBSSxPQUFPLEdBQUcsT0FBTyxXQUFXLFFBQVEsUUFBUSxHQUFHLFFBQVEsT0FBTyxXQUFXLE9BQU8sV0FBVyxPQUFPLEVBQUU7RUFDN0csT0FBTztDQUNUOzs7Ozs7OztDQVFBLE9BQU8sTUFBTSxVQUFVO0VBQ3JCLElBQUk7R0FDRixPQUFPLFNBQVMsTUFBTTtFQUN4QixTQUFTLFFBQVE7R0FDZixPQUFPLFNBQVMsS0FBSyxrQkFBa0IsUUFBUTtJQUM3QyxNQUFNLE9BQU87SUFDYixTQUFTLE9BQU87SUFDaEIsT0FBTyxPQUFPO0dBQ2hCLElBQUksQ0FBQyxHQUFHO0lBQ04sUUFBUTtJQUNSLFlBQVk7R0FDZCxDQUFDO0VBQ0g7Q0FDRjtDQUNBLFlBQVksTUFBTSxPQUFPLENBQUMsR0FBRztFQUMzQixNQUFNLFNBQVMsS0FBSyxVQUFVO0VBQzlCLE1BQU0sYUFBYSxlQUFlLHlCQUF5QixNQUFNLElBQUksU0FBUztFQUM5RSxNQUFNLFlBQVksZUFBZSxtQkFBbUIsTUFBTSxJQUFJLE9BQU87RUFDckUsTUFBTSxXQUFXO0dBQ2YsUUFBUTtHQUNSLFlBQVksS0FBSztHQUNqQixTQUFTLEtBQUs7RUFDaEIsQ0FBQztFQUNELElBQUksV0FBVyxZQUFZLGVBQWUsVUFBVSxRQUFRLElBQUk7RUFDaEUsZUFBZSxPQUFPLEtBQUssS0FBSyxJQUFJO0NBQ3RDO0NBQ0EsUUFBUTtFQUNOLE1BQU0saUJBQWlCLE1BQU0sTUFBTTtFQUNuQyxNQUFNLGVBQWUsUUFBUSxJQUFJLE1BQU0sT0FBTztFQUM5QyxJQUFJLGNBQWMsZUFBZSxVQUFVLGNBQWMsY0FBYztFQUN2RSxNQUFNLFlBQVksUUFBUSxJQUFJLE1BQU0sSUFBSTtFQUN4QyxJQUFJLFdBQVcsZUFBZSxPQUFPLFdBQVcsY0FBYztFQUM5RCxPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQUksY0FBOEIsdUJBQU8sYUFBYTtBQUN0RCxTQUFTLGNBQWMsU0FBUyxZQUFZO0NBQzFDLFFBQVEsSUFBSSxTQUFTLGFBQWEsVUFBVTtBQUM5QztBQUdBLElBQUksVUFBVSxJQUFJLFlBQVk7QUFDOUIsU0FBUyxhQUFhLE1BQU07Q0FDMUIsT0FBTyxRQUFRLE9BQU8sSUFBSTtBQUM1QjtBQUNBLFNBQVMsYUFBYSxRQUFRLFVBQVU7Q0FDdEMsT0FBTyxJQUFJLFlBQVksUUFBUSxDQUFDLENBQUMsT0FBTyxNQUFNO0FBQ2hEO0FBQ0EsU0FBUyxjQUFjLE9BQU87Q0FDNUIsT0FBTyxNQUFNLE9BQU8sTUFBTSxNQUFNLFlBQVksTUFBTSxhQUFhLE1BQU0sVUFBVTtBQUNqRjtBQWNBLGVBQWUsTUFBTSxVQUFVO0NBQzdCLElBQUk7RUFDRixPQUFPLENBQUMsTUFBTSxNQUFNLFNBQVMsQ0FBQyxDQUFDLE9BQU8sV0FBVztHQUMvQyxNQUFNO0VBQ1IsQ0FBQyxDQUFDO0NBQ0osU0FBUyxRQUFRO0VBQ2YsT0FBTyxDQUFDLFFBQVEsSUFBSTtDQUN0QjtBQUNGO0FBTUEsU0FBUyxxQkFBcUIsV0FBVztDQUN2QyxPQUFPLElBQUksSUFBSSxXQUFXLFNBQVMsSUFBSSxDQUFDLENBQUM7QUFDM0M7QUFHQSxTQUFTLHdCQUF3QixjQUFjLG1CQUFtQixZQUFZO0NBWTVFLE9BTnVCO0VBSnJCLGFBQWE7RUFDYixhQUFhO0VBQ2IsYUFBYTtDQUVnQixDQUFDLENBQUMsUUFBUSxVQUFVO0VBQ2pELE9BQU8sU0FBUztDQUNsQixDQUM0QixDQUFDLENBQUMsTUFBTSxZQUFZO0VBQzlDLE9BQU8sV0FBVyxRQUFRLFdBQVcsaUJBQWlCO0NBQ3hELENBQ1ksS0FBSztBQUNuQjtBQUdBLElBQUksb0JBQW9CLE9BQU8sS0FBSyxVQUFVLENBQUMsR0FBRyxlQUFlO0NBQy9ELE1BQU0sb0JBQW9CLHFCQUFxQixHQUFHO0NBQ2xELE1BQU0sb0JBQW9CLE1BQU0sVUFBVSxjQUFjLGlCQUFpQixDQUFDLENBQUMsTUFDeEUsa0JBQWtCLGNBQWMsUUFDOUIsaUJBQWlCLHdCQUF3QixjQUFjLG1CQUFtQixVQUFVLENBQ3ZGLENBQ0Y7Q0FDQSxJQUFJLENBQUMsVUFBVSxjQUFjLGNBQWMsa0JBQWtCLFNBQVMsR0FDcEUsU0FBUyxPQUFPO0NBRWxCLE1BQU0sQ0FBQyx3QkFBd0I7Q0FDL0IsSUFBSSxzQkFBc0I7RUFDeEIscUJBQXFCLE9BQU87RUFDNUIsT0FBTyxDQUNMLHdCQUNFLHNCQUNBLG1CQUNBLFVBQ0YsR0FDQSxvQkFDRjtDQUNGO0NBQ0EsTUFBTSxDQUFDLG1CQUFtQixzQkFBc0IsTUFBTSxNQUFNLFlBQVk7RUFDdEUsTUFBTSxlQUFlLE1BQU0sVUFBVSxjQUFjLFNBQVMsS0FBSyxPQUFPO0VBQ3hFLE9BQU8sQ0FHTCx3QkFBd0IsY0FBYyxtQkFBbUIsVUFBVSxHQUNuRSxZQUNGO0NBQ0YsQ0FBQztDQUNELElBQUksbUJBQW1CO0VBRXJCLElBRHdCLGtCQUFrQixRQUFRLFNBQVMsT0FDekMsR0FBRztHQUNuQixNQUFNLFdBQVcsSUFBSSxJQUFJLFNBQVMsU0FBUyxLQUFLLFNBQVMsSUFBSTtHQUM3RCxNQUFNLElBQUksTUFDUixTQUFTLGNBQWMsbURBQW1ELFNBQVMsS0FBSyxtQkFBbUIsa0JBQWtCOzs7O29GQUlqRCxDQUM5RTtFQUNGO0VBQ0EsTUFBTSxJQUFJLE1BQ1IsU0FBUyxjQUNQLGdEQUNBLGtCQUFrQixPQUNwQixDQUNGO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFHQSxJQUFJLFdBQVcsTUFBTTtDQUNuQjtDQUNBO0NBQ0EsY0FBYztFQUNaLEtBQUtDLFFBQVEsQ0FBQztFQUNkLEtBQUtDLHdCQUF3QixJQUFJLElBQUk7Q0FDdkM7Q0FDQSxLQUFLLE9BQU8sWUFBWTtFQUN0QixPQUFPLEtBQUtELE1BQU0sT0FBTyxTQUFTLENBQUMsS0FBSyxLQUFLQSxLQUFLO0NBQ3BEO0NBQ0EsVUFBVTtFQUNSLE9BQU8sS0FBS0MsTUFBTSxRQUFRO0NBQzVCOzs7O0NBSUEsSUFBSSxLQUFLO0VBQ1AsT0FBTyxLQUFLQSxNQUFNLElBQUksR0FBRyxLQUFLLENBQUM7Q0FDakM7Ozs7Q0FJQSxTQUFTO0VBQ1AsT0FBTyxLQUFLRCxNQUFNLEtBQUssR0FBRyxXQUFXLEtBQUs7Q0FDNUM7Ozs7Q0FJQSxPQUFPLEtBQUssT0FBTztFQUNqQixLQUFLQSxNQUFNLEtBQUssQ0FBQyxLQUFLLEtBQUssQ0FBQztFQUM1QixLQUFLRSxVQUFVLE1BQU0sU0FBUyxLQUFLLEtBQUssS0FBSyxDQUFDO0NBQ2hEOzs7O0NBSUEsUUFBUSxLQUFLLE9BQU87RUFDbEIsS0FBS0YsTUFBTSxRQUFRLENBQUMsS0FBSyxLQUFLLENBQUM7RUFDL0IsS0FBS0UsVUFBVSxNQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQztDQUNuRDs7Ozs7Q0FLQSxPQUFPLEtBQUssT0FBTztFQUNqQixJQUFJLEtBQUssU0FBUyxHQUFHLE9BQU87RUFDNUIsTUFBTSxTQUFTLEtBQUtELE1BQU0sSUFBSSxHQUFHO0VBQ2pDLElBQUksQ0FBQyxRQUFRLE9BQU87RUFDcEIsTUFBTSxRQUFRLE9BQU8sUUFBUSxLQUFLO0VBQ2xDLElBQUksVUFBVSxJQUFJLE9BQU87RUFDekIsT0FBTyxPQUFPLE9BQU8sQ0FBQztFQUN0QixLQUFLRCxNQUFNLE9BQU8sS0FBS0EsTUFBTSxXQUFXLFNBQVMsS0FBSyxPQUFPLE9BQU8sS0FBSyxPQUFPLEtBQUssR0FBRyxDQUFDO0VBQ3pGLE9BQU87Q0FDVDs7OztDQUlBLFVBQVUsS0FBSztFQUNiLElBQUksS0FBSyxTQUFTLEdBQUc7RUFDckIsS0FBS0EsUUFBUSxLQUFLQSxNQUFNLFFBQVEsU0FBUyxLQUFLLE9BQU8sR0FBRztFQUN4RCxLQUFLQyxNQUFNLE9BQU8sR0FBRztDQUN2QjtDQUNBLElBQUksT0FBTztFQUNULE9BQU8sS0FBS0QsTUFBTTtDQUNwQjtDQUNBLFFBQVE7RUFDTixJQUFJLEtBQUssU0FBUyxHQUFHO0VBQ3JCLEtBQUtBLE1BQU0sU0FBUztFQUNwQixLQUFLQyxNQUFNLE1BQU07Q0FDbkI7Q0FDQSxVQUFVLEtBQUssUUFBUTtFQUNyQixPQUFPLEtBQUtBLE1BQU0sSUFBSSxHQUFHLEtBQUssS0FBS0EsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQztDQUNoRTtBQUNGO0FBR0EsSUFBSSxxQkFBcUMsdUJBQU8sbUJBQW1CO0FBQ25FLElBQUksc0JBQXNDLHVCQUFPLHFCQUFxQjtBQUN0RSxJQUFJLCtCQUErQyx1QkFBTyw4QkFBOEI7QUFDeEYsSUFBSSxhQUFhLGNBQWMsYUFBYTs7Ozs7O0NBTTFDO0NBQ0EsQ0FBQztDQUNELENBQUM7Q0FDRCxDQUFDO0NBQ0QsWUFBWSxHQUFHLE1BQU07RUFDbkIsTUFBTSxLQUFLLElBQUksS0FBSyxFQUFFO0VBQ3RCLEtBQUssc0JBQXNCO0NBQzdCO0NBQ0EsSUFBSSxtQkFBbUI7RUFDckIsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxpQkFBaUI7RUFDZixNQUFNLGVBQWU7RUFDckIsS0FBSyxzQkFBc0I7Q0FDN0I7Q0FDQSwyQkFBMkI7RUFDekIsTUFBTSx5QkFBeUI7RUFDL0IsS0FBSyxnQ0FBZ0M7Q0FDdkM7QUFDRjtBQUNBLElBQUksV0FBVyxNQUFNO0NBQ25CO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxjQUFjO0VBQ1osS0FBS0UsYUFBYSxJQUFJLFNBQVM7RUFDL0IsS0FBS0MsbUNBQW1DLElBQUksUUFBUTtFQUNwRCxLQUFLQyx5Q0FBeUMsSUFBSSxRQUFRO0VBQzFELEtBQUtDLHFDQUFxQyxJQUFJLFFBQVE7RUFDdEQsS0FBS0MsaUJBQWlCLElBQUksU0FBUztFQUNuQyxLQUFLQyx1Q0FBdUMsSUFBSSxRQUFRO0VBQ3hELEtBQUtDLDZDQUE2QyxJQUFJLFFBQVE7RUFDOUQsS0FBSyxRQUFRO0dBQ1gsS0FBSyxNQUFNLFVBQVUsWUFBWTtJQUMvQixJQUFJLFNBQVMsUUFBUSxTQUFTO0lBQzlCLElBQUksU0FBUyxNQUFNO0tBQ2pCLE1BQU0sV0FBVztLQUNqQixNQUFNLFlBQVksR0FBRyxTQUFTO01BQzVCLEtBQUtDLG9CQUFvQixNQUFNLE9BQU87TUFDdEMsT0FBTyxTQUFTLEdBQUcsSUFBSTtLQUN6QjtLQUNBLFdBQVc7SUFDYjtJQUNBLEtBQUtILGVBQWUsT0FBTyxNQUFNLFFBQVE7SUFDekMsSUFBSSxTQUFTLEtBQUtDLHFCQUFxQixJQUFJLFVBQVUsT0FBTztJQUM1RCxJQUFJLFNBQVMsUUFBUTtLQUNuQixNQUFNLEVBQUUsV0FBVztLQUNuQixNQUFNLGdCQUFnQjtNQUNwQixLQUFLRSxvQkFBb0IsTUFBTSxRQUFRO0tBQ3pDO0tBQ0EsT0FBTyxpQkFBaUIsU0FBUyxTQUFTLEVBQUUsTUFBTSxLQUFLLENBQUM7S0FDeEQsS0FBS0QsMkJBQTJCLElBQUksZ0JBQWdCO01BQ2xELE9BQU8sb0JBQW9CLFNBQVMsT0FBTztLQUM3QyxDQUFDO0lBQ0g7R0FDRjtHQUNBLGlCQUFpQixNQUFNLGFBQWE7SUFDbEMsS0FBS0Msb0JBQW9CLE1BQU0sUUFBUTtHQUN6QztFQUNGO0NBQ0Y7Q0FDQSxvQkFBb0IsTUFBTSxVQUFVO0VBQ2xDLEtBQUtILGVBQWUsT0FBTyxNQUFNLFFBQVE7RUFDekMsTUFBTSxVQUFVLEtBQUtFLDJCQUEyQixJQUFJLFFBQVE7RUFDNUQsSUFBSSxTQUFTO0dBQ1gsUUFBUTtHQUNSLEtBQUtBLDJCQUEyQixPQUFPLFFBQVE7RUFDakQ7Q0FDRjtDQUNBLGdCQUFnQixNQUFNLFVBQVU7RUFDOUIsTUFBTSxVQUFVLEtBQUtOLFdBQVcsT0FBTyxNQUFNLFFBQVE7RUFDckQsTUFBTSxVQUFVLEtBQUtFLHVCQUF1QixJQUFJLFFBQVE7RUFDeEQsSUFBSSxTQUFTO0dBQ1gsUUFBUTtHQUNSLEtBQUtBLHVCQUF1QixPQUFPLFFBQVE7RUFDN0M7RUFDQSxPQUFPO0NBQ1Q7Ozs7Q0FJQSxHQUFHLE1BQU0sVUFBVSxTQUFTO0VBQzFCLEtBQUtNLGFBQWEsTUFBTSxVQUFVLE9BQU87RUFDekMsT0FBTztDQUNUOzs7O0NBSUEsS0FBSyxNQUFNLFVBQVUsU0FBUztFQUM1QixPQUFPLEtBQUssR0FBRyxNQUFNLFVBQVU7R0FDN0IsR0FBRyxXQUFXLENBQUM7R0FDZixNQUFNO0VBQ1IsQ0FBQztDQUNIOzs7O0NBSUEsUUFBUSxNQUFNLFVBQVUsU0FBUztFQUMvQixLQUFLQSxhQUFhLE1BQU0sVUFBVSxTQUFTLFNBQVM7RUFDcEQsT0FBTztDQUNUOzs7O0NBSUEsVUFBVSxNQUFNLFVBQVUsU0FBUztFQUNqQyxPQUFPLEtBQUssUUFBUSxNQUFNLFVBQVU7R0FDbEMsR0FBRyxXQUFXLENBQUM7R0FDZixNQUFNO0VBQ1IsQ0FBQztDQUNIOzs7Ozs7Q0FNQSxLQUFLLE9BQU87RUFDVixJQUFJLEtBQUtSLFdBQVcsU0FBUyxHQUFHLE9BQU87RUFDdkMsTUFBTSxlQUFlLEtBQUssY0FBYyxNQUFNLElBQUksSUFBSTtFQUN0RCxNQUFNLGVBQWUsS0FBS1MsWUFBWSxLQUFLO0VBQzNDLEtBQUssTUFBTSxZQUFZLEtBQUtDLGdCQUFnQixNQUFNLElBQUksR0FBRztHQUN2RCxJQUFJLGFBQWEsTUFBTSx3QkFBd0IsUUFBUSxhQUFhLE1BQU0seUJBQXlCLE1BQU07SUFDdkcsYUFBYSxPQUFPO0lBQ3BCLE9BQU87R0FDVDtHQUNBLElBQUksYUFBYSxNQUFNLCtCQUErQjtHQUN0RCxLQUFLQyxjQUFjLGFBQWEsT0FBTyxRQUFRO0VBQ2pEO0VBQ0EsYUFBYSxPQUFPO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FRQSxNQUFNLGNBQWMsT0FBTztFQUN6QixJQUFJLEtBQUtYLFdBQVcsU0FBUyxHQUFHLE9BQU8sQ0FBQztFQUN4QyxNQUFNLG1CQUFtQixDQUFDO0VBQzFCLE1BQU0sZUFBZSxLQUFLUyxZQUFZLEtBQUs7RUFDM0MsS0FBSyxNQUFNLFlBQVksS0FBS0MsZ0JBQWdCLE1BQU0sSUFBSSxHQUFHO0dBQ3ZELElBQUksYUFBYSxNQUFNLHdCQUF3QixRQUFRLGFBQWEsTUFBTSx5QkFBeUIsTUFBTTtJQUN2RyxhQUFhLE9BQU87SUFDcEIsT0FBTyxDQUFDO0dBQ1Y7R0FDQSxJQUFJLGFBQWEsTUFBTSwrQkFBK0I7R0FDdEQsTUFBTSxjQUFjLE1BQU0sUUFBUSxRQUFRLEtBQUtDLGNBQWMsYUFBYSxPQUFPLFFBQVEsQ0FBQztHQUMxRixJQUFJLENBQUMsS0FBS0Msb0JBQW9CLFFBQVEsR0FBRyxpQkFBaUIsS0FBSyxXQUFXO0VBQzVFO0VBQ0EsYUFBYSxPQUFPO0VBQ3BCLE9BQU8sUUFBUSxXQUFXLGdCQUFnQixDQUFDLENBQUMsTUFBTSxZQUFZO0dBQzVELE9BQU8sUUFBUSxLQUFLLFdBQVcsT0FBTyxXQUFXLGNBQWMsT0FBTyxRQUFRLE9BQU8sTUFBTTtFQUM3RixDQUFDO0NBQ0g7Ozs7OztDQU1BLENBQUMsZ0JBQWdCLE9BQU87RUFDdEIsSUFBSSxLQUFLWixXQUFXLFNBQVMsR0FBRztFQUNoQyxNQUFNLGVBQWUsS0FBS1MsWUFBWSxLQUFLO0VBQzNDLEtBQUssTUFBTSxZQUFZLEtBQUtDLGdCQUFnQixNQUFNLElBQUksR0FBRztHQUN2RCxJQUFJLGFBQWEsTUFBTSx3QkFBd0IsUUFBUSxhQUFhLE1BQU0seUJBQXlCLE1BQU07SUFDdkcsYUFBYSxPQUFPO0lBQ3BCO0dBQ0Y7R0FDQSxJQUFJLGFBQWEsTUFBTSwrQkFBK0I7R0FDdEQsTUFBTSxjQUFjLEtBQUtDLGNBQWMsYUFBYSxPQUFPLFFBQVE7R0FDbkUsSUFBSSxDQUFDLEtBQUtDLG9CQUFvQixRQUFRLEdBQUcsTUFBTTtFQUNqRDtFQUNBLGFBQWEsT0FBTztDQUN0Qjs7OztDQUlBLGVBQWUsTUFBTSxVQUFVO0VBQzdCLE1BQU0sVUFBVSxLQUFLWCxpQkFBaUIsSUFBSSxRQUFRO0VBQ2xELElBQUksQ0FBQyxLQUFLWSxnQkFBZ0IsTUFBTSxRQUFRLEdBQUc7RUFDM0MsS0FBSyxNQUFNLFFBQVEsS0FBS1QsZUFBZSxJQUFJLGdCQUFnQixDQUFDLENBQUMsTUFBTSxHQUFHLEtBQUssTUFBTSxVQUFVLE9BQU87Q0FDcEc7Ozs7O0NBS0EsbUJBQW1CLE1BQU07RUFDdkIsSUFBSSxRQUFRLE1BQU07R0FDaEIsS0FBSyxNQUFNLENBQUMsY0FBYyxnQkFBZ0IsS0FBS0osV0FBVyxRQUFRLEdBQUcsT0FBTyxZQUFZLFNBQVMsR0FBRyxLQUFLLGVBQWUsY0FBYyxZQUFZLEVBQUU7R0FDcEosS0FBSyxNQUFNLENBQUMsVUFBVSxpQkFBaUIsQ0FBQyxHQUFHLEtBQUtJLGNBQWMsR0FBRyxJQUFJLENBQUMsS0FBS0MscUJBQXFCLElBQUksWUFBWSxDQUFDLEVBQUUsU0FBUyxLQUFLRSxvQkFBb0IsVUFBVSxZQUFZO0dBQzNLO0VBQ0Y7RUFDQSxNQUFNLFlBQVksS0FBSyxVQUFVLElBQUk7RUFDckMsT0FBTyxVQUFVLFNBQVMsR0FBRyxLQUFLLGVBQWUsTUFBTSxVQUFVLEVBQUU7Q0FDckU7Ozs7O0NBS0EsVUFBVSxNQUFNO0VBQ2QsSUFBSSxRQUFRLE1BQU0sT0FBTyxLQUFLUCxXQUFXLE9BQU87RUFDaEQsT0FBTyxLQUFLQSxXQUFXLElBQUksSUFBSTtDQUNqQzs7Ozs7Q0FLQSxjQUFjLE1BQU07RUFDbEIsSUFBSSxRQUFRLE1BQU0sT0FBTyxLQUFLQSxXQUFXO0VBQ3pDLE9BQU8sS0FBSyxVQUFVLElBQUksQ0FBQyxDQUFDO0NBQzlCO0NBQ0EsYUFBYSxNQUFNLFVBQVUsU0FBUyxhQUFhLFVBQVU7RUFDM0QsSUFBSSxTQUFTLFFBQVEsU0FBUztFQUM5QixLQUFLLE1BQU0sUUFBUSxLQUFLSSxlQUFlLElBQUksYUFBYSxDQUFDLENBQUMsTUFBTSxHQUFHLEtBQUssTUFBTSxVQUFVLE9BQU87RUFDL0YsSUFBSSxTQUFTLEtBQUssS0FBS0QsbUJBQW1CLElBQUksUUFBUTtFQUN0RCxJQUFJLGVBQWUsV0FBVyxLQUFLSCxXQUFXLFFBQVEsTUFBTSxRQUFRO09BQy9ELEtBQUtBLFdBQVcsT0FBTyxNQUFNLFFBQVE7RUFDMUMsSUFBSSxTQUFTO0dBQ1gsS0FBS0MsaUJBQWlCLElBQUksVUFBVSxPQUFPO0dBQzNDLElBQUksUUFBUSxRQUFRO0lBQ2xCLE1BQU0sRUFBRSxXQUFXO0lBQ25CLE1BQU0sZ0JBQWdCO0tBQ3BCLEtBQUssZUFBZSxNQUFNLFFBQVE7SUFDcEM7SUFDQSxPQUFPLGlCQUFpQixTQUFTLFNBQVMsRUFBRSxNQUFNLEtBQUssQ0FBQztJQUN4RCxLQUFLQyx1QkFBdUIsSUFBSSxnQkFBZ0I7S0FDOUMsT0FBTyxvQkFBb0IsU0FBUyxPQUFPO0lBQzdDLENBQUM7R0FDSDtFQUNGO0NBQ0Y7Q0FDQSxZQUFZLE9BQU87RUFDakIsTUFBTSxFQUFFLG9CQUFvQjtFQUM1QixNQUFNLHdCQUF3QjtHQUM1QixNQUFNLHVCQUF1QjtHQUM3QixnQkFBZ0IsS0FBSyxLQUFLO0VBQzVCO0VBQ0EsT0FBTztHQUNMO0dBQ0EsU0FBUztJQUNQLE1BQU0sa0JBQWtCO0dBQzFCO0VBQ0Y7Q0FDRjtDQUNBLGNBQWMsT0FBTyxVQUFVO0VBQzdCLEtBQUssTUFBTSxRQUFRLEtBQUtFLGVBQWUsSUFBSSxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxLQUFLLEtBQUssTUFBTSxPQUFPO0VBQzdGLE1BQU0sY0FBYyxTQUFTLEtBQUssTUFBTSxLQUFLO0VBQzdDLE1BQU0sVUFBVSxLQUFLSCxpQkFBaUIsSUFBSSxRQUFRO0VBQ2xELElBQUksU0FBUyxNQUFNO0dBQ2pCLE1BQU0sT0FBTyxLQUFLVyxvQkFBb0IsUUFBUSxJQUFJLE1BQU0sTUFBTTtHQUM5RCxJQUFJLEtBQUtDLGdCQUFnQixNQUFNLFFBQVEsR0FBRyxLQUFLLE1BQU0sUUFBUSxLQUFLVCxlQUFlLElBQUksZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLEdBQUcsS0FBSyxNQUFNLFVBQVUsT0FBTztFQUM5STtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7O0NBU0EsQ0FBQ00sZ0JBQWdCLE1BQU07RUFDckIsTUFBTSxXQUFXLENBQUM7RUFDbEIsS0FBSyxNQUFNLENBQUMsS0FBSyxhQUFhLEtBQUtWLFlBQVksSUFBSSxRQUFRLE9BQU8sUUFBUSxNQUFNLFNBQVMsS0FBSyxRQUFRO0VBQ3RHLE9BQU87Q0FDVDtDQUNBLG9CQUFvQixVQUFVO0VBQzVCLE9BQU8sS0FBS0csbUJBQW1CLElBQUksUUFBUTtDQUM3QztBQUNGO0FBSUEsSUFBSSwwQkFBMEIsc0JBQXNCO0FBQ3BELElBQUksY0FBYyxjQUFjLFdBQVc7Q0FDekM7Q0FDQSxZQUFZLGFBQWE7RUFDdkIsTUFBTSxPQUFPLFlBQVksS0FBSztFQUM5QixNQUFNLE9BQU8sWUFBWSxLQUFLO0VBQzlCLE1BRUUsTUFDQSxFQUFFLEtBQUssQ0FDVDtFQUNBLEtBQUtXLGVBQWU7Q0FDdEI7Q0FDQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUtBLGFBQWE7Q0FDM0I7Ozs7Q0FJQSxZQUFZLE1BQU0sR0FBRyxNQUFNO0VBQ3pCLEtBQUtBLGFBQWEsTUFBTSxFQUFFLENBQUMsWUFDekI7R0FBRTtHQUFNLE1BQU0sS0FBSztFQUFHLEdBQ3RCLEVBQUUsVUFBVSxLQUFLLEdBQUcsQ0FDdEI7Q0FDRjtBQUNGO0FBQ0EsSUFBSSxnQkFBZ0IsY0FBYyxTQUFTO0NBQ3pDO0NBQ0E7Q0FDQSxZQUFZLFNBQVM7RUFDbkIsTUFBTTtFQUNOLFVBQ0UseUJBQ0Esc0ZBQ0Y7RUFDQSxLQUFLQyxhQUFhLFFBQVE7RUFDMUIsS0FBS0MsY0FBYyxJQUFJLGdCQUFnQjtFQUN2QyxVQUFVLGNBQWMsaUJBQ3RCLFdBQ0EsT0FBTyxVQUFVO0dBQ2YsTUFBTSxTQUFTLE1BQU0sS0FBS0QsV0FBVztHQUNyQyxJQUFJLE1BQU0sVUFBVSxRQUFRLE1BQU0sV0FBVyxRQUMzQztHQUVGLElBQUksTUFBTSxRQUFRLFNBQVMsTUFBTSxJQUFJLEtBQUssVUFBVSxNQUFNLE1BQ3hELEtBQUssS0FBSyxJQUFJLFlBQVksS0FBSyxDQUFDO0VBRXBDLEdBQ0EsRUFDRSxRQUFRLEtBQUtDLFlBQVksT0FDM0IsQ0FDRjtDQUNGOzs7OztDQUtBLFlBQVksTUFBTTtFQUNoQixVQUNFLHlCQUNBLHlNQUNGO0VBQ0EsS0FBS0QsV0FBVyxDQUFDLENBQUMsTUFBTSxXQUFXO0dBQ2pDLE9BQU8sWUFBWSxJQUFJO0VBQ3pCLENBQUM7Q0FDSDs7Ozs7Q0FLQSxZQUFZO0VBQ1YsS0FBS0MsWUFBWSxNQUFNO0VBQ3ZCLEtBQUssbUJBQW1CO0NBQzFCO0FBQ0Y7QUFHQSxTQUFTLG9CQUFvQixTQUFTO0NBQ3BDLElBQUksQ0FBQyxRQUFRLEtBQUssQ0FBQyxDQUFDLFNBQVMsUUFBUSxNQUFNLEdBQ3pDO0NBRUYsT0FBTyxRQUFRO0FBQ2pCO0FBR0EsU0FBUyxtQkFBbUIsbUJBQW1CO0NBQzdDLE9BQU8sSUFBSSxRQUFRLGtCQUFrQixLQUFLO0VBQ3hDLEdBQUc7RUFDSCxNQUFNLG9CQUFvQixpQkFBaUI7Q0FDN0MsQ0FBQztBQUNIO0FBSUEsU0FBUyxvQkFBb0IsY0FBYztDQUN6QyxJQUFJLENBQUMsU0FBUyxLQUFLLFdBQVcsYUFBYSxLQUFLLEdBQzlDLFNBQVUsS0FDUix1RkFBdUYsYUFBYSxNQUFNOzs7a0ZBSTVHO0FBRUo7QUFHQSxTQUFTLHVCQUF1QixhQUFhLGFBQWE7Q0FDeEQsT0FBTyxZQUFZLGVBQWUsWUFBWSxjQUFjLFlBQVksY0FBYyxRQUFRLFlBQVksY0FBYyxPQUFPLEtBQUssVUFBVSxZQUFZLGNBQWMsT0FBTyxNQUFNLEtBQUssVUFBVSxZQUFZLGNBQWMsT0FBTztBQUN2TztBQUdBLElBQUksc0JBQXNCLE1BQU0sNkJBQTZCLGNBQWM7Q0FDekUsT0FBT0M7Ozs7O0NBS1AsYUFBYSxLQUFLLFNBQVM7RUFDekIsSUFBSSxxQkFBcUJBLFlBQVksTUFDbkMscUJBQXFCQSxXQUFXLElBQUkscUJBQXFCLE9BQU87T0FDM0QsSUFBSSx1QkFBdUIscUJBQXFCQSxTQUFTQyxVQUFVLE9BQU8sR0FBRztHQUNsRixNQUFNLHFCQUFxQkQsU0FBUyxVQUFVO0dBQzlDLHFCQUFxQkEsV0FBVyxJQUFJLHFCQUFxQixPQUFPO0VBQ2xFO0VBQ0EsT0FBTyxxQkFBcUJBO0NBQzlCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLFlBQVksU0FBUztFQUNuQixNQUFNO0VBQ04sVUFDRSxzQkFBc0IsR0FDdEIsaUhBQ0Y7RUFDQSxLQUFLQyxXQUFXO0VBQ2hCLEtBQUtDLDBCQUEwQixJQUFJLElBQUk7RUFDdkMsS0FBSyxnQkFBZ0IsSUFBSSxpQkFBaUI7RUFDMUMsS0FBS0MsV0FBVyxJQUFJLGNBQWMsRUFDaEMsaUJBQWlCLEtBQUssY0FBYyxNQUFNLENBQUMsWUFBWSxNQUFNLEVBQy9ELENBQUM7Q0FDSDtDQUNBLE1BQU0sU0FBUztFQUNiLElBQUksS0FBSyxjQUFjLFVBQVUsZUFBZSxPQUFPLEtBQUtDLGNBQWMsYUFBYTtHQUNyRixTQUFVLEtBQ1IsZ0xBQ0Y7R0FDQSxPQUFPLEtBQUssY0FBYyxNQUFNLEdBQUcsbUJBQW1CLGFBQWE7RUFDckU7RUFDQSxLQUFLQSxhQUFhLEtBQUs7RUFDdkIsS0FBS0QsU0FBUyxtQkFBbUI7RUFDakMsS0FBS0QsUUFBUSxNQUFNO0VBQ25CLEtBQUtHLHNCQUFzQixJQUFJLGdCQUFnQjtFQUMvQyxNQUFNLENBQUMsUUFBUSxnQkFBZ0IsTUFBTSxLQUFLQyxhQUFhO0VBQ3ZELElBQUksT0FBTyxVQUFVLGFBQWE7R0FDaEMsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0dBQ3ZDLE1BQU0sb0JBQW9CLElBQUksaUJBQWlCO0dBQy9DLGtCQUFrQixXQUFXLFdBQVcsTUFBTSxDQUFDO0dBQy9DLE9BQU8saUJBQ0wscUJBQ007SUFDSixJQUFJLE9BQU8sVUFBVSxhQUNuQixrQkFBa0IsUUFBUTtHQUU5QixHQUNBLEVBQ0UsUUFBUSxXQUFXLE9BQ3JCLENBQ0Y7R0FDQSxNQUFNO0VBQ1I7RUFDQSxLQUFLSCxTQUFTLFlBQVksZUFBZTtFQUN6QyxNQUFNLDRCQUE0QixJQUFJLGlCQUFpQjtFQUN2RCxLQUFLSSxpQkFBaUI7RUFDdEIsS0FBS0osU0FBUyxLQUFLLG9CQUFvQixVQUFVO0dBQy9DLDBCQUEwQixRQUFRLE1BQU0sS0FBSyxNQUFNO0VBQ3JELENBQUM7RUFDRCxNQUFNO0VBQ04sSUFBSSxDQUFDLEtBQUtGLFNBQVMsT0FDakIsS0FBS08sbUJBQW1CO0VBRTFCLE9BQU87Q0FDVDtDQUNBLFVBQVU7RUFDUixJQUFJLE9BQU8sS0FBS0osZUFBZSxhQUFhO0dBQzFDLFNBQVUsS0FDUix1S0FDRjtHQUNBO0VBQ0Y7RUFDQSxLQUFLQSxhQUFhLEtBQUssSUFBSTtFQUMzQixLQUFLQyxxQkFBcUIsTUFBTTtFQUNoQyxLQUFLQSxzQkFBc0IsS0FBSztFQUNoQyxLQUFLRixTQUFTLFlBQVksZUFBZTtFQUN6QyxJQUFJLENBQUMsS0FBS0YsU0FBUyxPQUNqQixLQUFLUSxrQkFBa0I7Q0FFM0I7Ozs7OztDQU1BLE1BQU0sWUFBWTtFQUNoQixJQUFJLEtBQUtDLHNCQUFzQixNQUFNO0dBQ25DLGNBQWMsS0FBS0Esa0JBQWtCO0dBQ3JDLEtBQUtBLHFCQUFxQixLQUFLO0VBQ2pDO0VBQ0EsS0FBS1IsUUFBUSxNQUFNO0VBQ25CLEtBQUtDLFNBQVMsVUFBVTtFQUN4QixLQUFLRSxxQkFBcUIsTUFBTTtFQUNoQyxLQUFLQSxzQkFBc0IsS0FBSztFQUNoQyxJQUFJLEtBQUssY0FBYyxVQUFVLGFBQWE7R0FDNUMsTUFBTSxHQUFHLGdCQUFnQixNQUFNLEtBQUs7R0FDcEMsTUFBTSxhQUFhLFdBQVc7RUFDaEM7RUFDQSxJQUFJLHFCQUFxQkwsYUFBYSxNQUNwQyxxQkFBcUJBLFdBQVcsS0FBSztDQUV6QztDQUNBLE1BQU1NLGVBQWU7RUFDbkIsSUFBSSxLQUFLSSxvQkFDUCxjQUFjLEtBQUtBLGtCQUFrQjtFQUV2QyxNQUFNLFlBQVksS0FBS1QsU0FBUyxjQUFjO0VBQzlDLE1BQU0sQ0FBQyxRQUFRLGdCQUFnQixNQUFNLGtCQUNuQyxXQUNBLEtBQUtBLFNBQVMsY0FBYyxTQUM1QixLQUFLQSxTQUFTLGNBQWMsS0FBS1Usa0JBQ25DO0VBQ0EsSUFBSSxVQUFVLE1BQU07R0FDbEIsTUFBTSx1QkFBdUIsS0FBS1YsVUFBVSxhQUFhVyxTQUFVLGNBQ2pFOzs7O1FBS0EsU0FDRixJQUFJQSxTQUFVLGNBQ1o7Ozs7MlBBS0EsV0FDQSxTQUFTLElBQ1g7R0FDQSxNQUFNLElBQUksTUFBTSxvQkFBb0I7RUFDdEM7RUFDQSxJQUFJLEtBQUssY0FBYyxVQUFVLFdBQy9CLEtBQUssY0FBYyxRQUFRLENBQUMsUUFBUSxZQUFZLENBQUM7T0FFakQsS0FBSyxnQkFBZ0IsSUFBSSxrQkFBa0IsWUFBWTtHQUNyRCxRQUFRLENBQUMsUUFBUSxZQUFZLENBQUM7RUFDaEMsQ0FBQztFQUVILEtBQUtULFNBQVMsR0FBRyxXQUFXLEtBQUtVLGVBQWUsS0FBSyxJQUFJLENBQUM7RUFDMUQsS0FBS1YsU0FBUyxHQUFHLFlBQVksS0FBS1csZ0JBQWdCLEtBQUssSUFBSSxDQUFDO0VBQzVELE9BQU8saUJBQ0wsc0JBQ007R0FDSixJQUFJLE9BQU8sVUFBVSxhQUNuQixLQUFLWCxTQUFTLFlBQVksZUFBZTtHQUUzQyxjQUFjLEtBQUtPLGtCQUFrQjtHQUNyQyxPQUFPLFlBQVksRUFBRSxNQUFNLGtCQUFrQixDQUFDO0VBQ2hELEdBQ0EsRUFDRSxRQUFRLEtBQUtMLHFCQUFxQixPQUNwQyxDQUNGO0VBQ0EsTUFBTSxLQUFLVSxzQkFBc0IsQ0FBQyxDQUFDLE9BQU8sV0FBVztHQUNuRCxTQUFVLE1BQ1IsNEpBQ0Y7R0FDQSxRQUFRLE1BQU0sTUFBTTtFQUN0QixDQUFDO0VBQ0QsS0FBS0wscUJBQXFCLE9BQU8sa0JBQWtCO0dBQ2pELEtBQUtQLFNBQVMsWUFBWSxtQkFBbUI7RUFDL0MsR0FBRyxHQUFHO0VBQ04sSUFBSSxDQUFDLEtBQUtGLFNBQVMsT0FDakIsb0JBQW9CLFlBQVk7RUFFbEMsT0FBTyxDQUFDLFFBQVEsWUFBWTtDQUM5QjtDQUNBLE1BQU1ZLGVBQWUsT0FBTztFQUMxQixJQUFJLEtBQUtULGNBQWMsTUFBTSxLQUFLLGdCQUFnQixLQUFLQSxZQUNyRCxPQUFPLE1BQU0sWUFBWSxhQUFhO0VBRXhDLE1BQU0sVUFBVSxtQkFBbUIsTUFBTSxJQUFJO0VBQzdDLGVBQWUsTUFBTSxJQUFJLFNBQVMsUUFBUSxNQUFNLENBQUM7RUFDakQsTUFBTSxRQUFRLElBQUksOEJBQThCO0dBQzlDO0dBQ0E7RUFDRixDQUFDO0VBQ0QsS0FBS0YsUUFBUSxJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUs7RUFDckMsTUFBTSxLQUFLLE1BQU0sS0FBSztDQUN4QjtDQUNBLE1BQU1ZLGdCQUFnQixPQUFPO0VBQzNCLE1BQU0sRUFBRSxTQUFTLFVBQVUscUJBQXFCLE1BQU07RUFDdEQsTUFBTSxRQUFRLEtBQUtaLFFBQVEsSUFBSSxRQUFRLEVBQUU7RUFDekMsSUFBSSxTQUFTLE1BQU0sU0FBUyxRQUFRLEdBQUc7R0FDckMsS0FBS0EsUUFBUSxPQUFPLFFBQVEsRUFBRTtHQUM5QixPQUFPLE9BQU8sbUJBQW1CO0dBQ2pDO0VBQ0Y7RUFDQSxLQUFLQSxRQUFRLE9BQU8sUUFBUSxFQUFFO0VBQzlCLElBQUksU0FBUyxNQUNYO0VBRUYsTUFBTSxlQUFlLG1CQUFtQixPQUFPO0VBQy9DLE1BQU0sZ0JBQWdCLFNBQVMsV0FBVyxJQUFJLFNBQVMsTUFBTSxJQUFJLElBQUk7Ozs7Ozs7R0FPbkUsY0FBYyxtQkFBbUIsU0FBUyxNQUFNLElBQUksU0FBUyxPQUFPO0dBQ3BFO0lBQ0UsR0FBRzs7Ozs7O0lBTUgsS0FBSyxRQUFRO0dBQ2Y7RUFDRjtFQUNBLElBQUk7R0FDRixNQUFNLE9BQU8sS0FDWCxJQUFJLGNBQ0YsbUJBQW1CLG9CQUFvQixtQkFDdkM7SUFDRSxXQUFXLE1BQU0sS0FBSztJQUN0QixTQUFTO0lBQ1QsVUFBVTtJQUNWO0dBQ0YsQ0FDRixDQUNGO0VBQ0YsVUFBVTtHQUNSLE1BQU0sT0FBTyxtQkFBbUI7RUFDbEM7Q0FDRjtDQUNBLHNCQUFzQixXQUFXLHlCQUF5QjtFQUN4RCxPQUFPLGNBQWM7Q0FDdkI7Q0FDQSxNQUFNYSx3QkFBd0I7RUFDNUIsTUFBTSx3QkFBd0IsSUFBSSxpQkFBaUI7RUFDbkQsS0FBS1osU0FBUyxZQUFZLHlCQUF5QjtFQUNuRCxLQUFLQSxTQUFTLEtBQUssNkJBQTZCLFVBQVU7R0FDeEQsTUFBTSxFQUFFLFVBQVUsbUJBQW1CLE1BQU07R0FDM0MsSUFBSSxhQUFhLG9DQUNmLFNBQVUsS0FDUiw2RkFBNkYsZUFBZTs7Ozs7OzhKQU85RztHQUVGLHNCQUFzQixRQUFRO0VBQ2hDLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxNQUFNSyxxQkFBcUI7RUFDekIsSUFBSSxLQUFLLGNBQWMsVUFBVSxZQUMvQjtFQUVGLFVBQ0UsS0FBS0Qsa0JBQWtCLE1BQ3ZCLHlGQUNGO0VBQ0EsTUFBTSxTQUFTLE1BQU0sS0FBS0E7RUFDMUIsTUFBTSxDQUFDLFFBQVEsZ0JBQWdCLE1BQU0sS0FBSztFQUMxQyxRQUFRLGVBQ04sS0FBS0ssU0FBVSxjQUFjLGtCQUFrQixLQUMvQyxtQ0FDRjtFQUNBLFFBQVEsSUFDTiw0Q0FDQSxvQkFDQSxvQkFDRjtFQUNBLFFBQVEsSUFBSSxxREFBcUQ7RUFDakUsUUFBUSxJQUFJLHNCQUFzQixPQUFPLFNBQVM7RUFDbEQsUUFBUSxJQUFJLGlCQUFpQixhQUFhLEtBQUs7RUFDL0MsSUFBSSxRQUNGLFFBQVEsSUFBSSxzQkFBc0IsT0FBTyxJQUFJLE9BQU8sU0FBUztFQUUvRCxRQUFRLFNBQVM7Q0FDbkI7Q0FDQSxvQkFBb0I7RUFDbEIsUUFBUSxJQUNOLEtBQUtBLFNBQVUsY0FBYyxtQkFBbUIsS0FDaEQsbUNBQ0Y7Q0FDRjtBQUNGO0FBQ0EsSUFBSSxnQ0FBZ0MsY0FBYyxpQkFBaUI7Q0FDakU7Q0FDQSxZQUFZLFNBQVM7RUFDbkIsTUFBTSxFQUFFLFNBQVMsUUFBUSxRQUFRLENBQUM7RUFDbEMsS0FBS0ksU0FBUyxRQUFRO0NBQ3hCO0NBQ0EsY0FBYztFQUNaLEtBQUtBLE9BQU8sWUFBWSxhQUFhO0NBQ3ZDO0NBQ0EsWUFBWSxVQUFVO0VBQ3BCLElBQUksVUFDRixLQUFLQyxhQUFhLFFBQVE7Q0FFOUI7Q0FDQSxVQUFVLFFBQVE7RUFDaEIsSUFBSSxrQkFBa0IsVUFDcEIsT0FBTyxLQUFLLFlBQVksTUFBTTtFQUVoQyxTQUFVLEtBQ1IscVZBQ0EsS0FBSyxLQUFLLFFBQVEsUUFDbEIsS0FBSyxLQUFLLFFBQVEsR0FDcEI7RUFDQSxNQUFNLFNBQVMsa0JBQWtCLFFBQVEsU0FBUyxJQUFJLE1BQU0sUUFBUSxTQUFTLEtBQUssaUJBQWlCO0VBQ25HLEtBQUssWUFDSCxhQUFhLEtBQ1g7R0FDRSxNQUFNLE9BQU87R0FDYixTQUFTLE9BQU87R0FDaEIsT0FBTyxPQUFPO0VBQ2hCLEdBQ0E7R0FDRSxRQUFRO0dBQ1IsWUFBWTtFQUNkLENBQ0YsQ0FDRjtDQUNGO0NBQ0EsTUFBTUEsYUFBYSxVQUFVO0VBQzNCLElBQUk7RUFDSixJQUFJO0VBQ0osTUFBTSxlQUFlLGVBQWUsUUFBUTtFQUM1QyxJQUFJLCtCQUErQixHQUFHO0dBQ3BDLGVBQWUsU0FBUztHQUN4QixXQUFXLFNBQVMsUUFBUSxPQUFPLEtBQUssSUFBSSxDQUFDLFNBQVMsSUFBSTtFQUM1RCxPQUNFLGVBQWUsU0FBUyxRQUFRLE9BQU8sT0FBTyxNQUFNLFNBQVMsTUFBTSxDQUFDLENBQUMsWUFBWTtFQUVuRixLQUFLRCxPQUFPLFlBQ1YsaUJBQ0E7R0FDRSxHQUFHO0dBQ0gsTUFBTTtFQUNSLEdBQ0EsUUFDRjtDQUNGO0FBQ0Y7QUFHQSxJQUFJLFNBQVMsT0FBTyxZQUFZO0NBQzlCLElBQUk7RUFJRixPQUFPO0dBQUUsT0FBTztHQUFNLE1BQUEsTUFISCxRQUFRLENBQUMsQ0FBQyxPQUFPLFdBQVc7SUFDN0MsTUFBTTtHQUNSLENBQUM7RUFDMEI7Q0FDN0IsU0FBUyxRQUFRO0VBQ2YsT0FBTztHQUFFLE9BQU87R0FBUSxNQUFNO0VBQUs7Q0FDckM7QUFDRjtBQUdBLFNBQVMsVUFBVSxPQUFPLFFBQVEsT0FBTztDQUN2QyxPQUFPLFFBQVEsT0FBTyxVQUFVLFNBQVMsS0FBSyxLQUFLLENBQUMsQ0FBQyxXQUFXLFVBQVUsSUFBSSxPQUFPLFVBQVUsU0FBUyxLQUFLLEtBQUssTUFBTTtBQUMxSDtBQUNBLFNBQVMscUJBQXFCLEtBQUssS0FBSztDQUN0QyxJQUFJO0VBQ0YsSUFBSTtFQUNKLE9BQU87Q0FDVCxRQUFRO0VBQ04sT0FBTztDQUNUO0FBQ0Y7QUFDQSxTQUFTLDBCQUEwQixNQUFNO0NBQ3ZDLE9BQU8sSUFBSSxTQUFTLEtBQUssVUFBVSxnQkFBZ0IsUUFBUTtFQUN6RCxNQUFNLEtBQUs7RUFDWCxTQUFTLEtBQUs7RUFDZCxPQUFPLEtBQUs7Q0FDZCxJQUFJLElBQUksR0FBRztFQUNULFFBQVE7RUFDUixZQUFZO0VBQ1osU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7Q0FDaEQsQ0FBQztBQUNIO0FBQ0EsU0FBUyxnQkFBZ0IsVUFBVTtDQUNqQyxPQUFPLFlBQVksUUFBUSxvQkFBb0IsWUFBWSxxQkFBcUIsVUFBVSxNQUFNLEtBQUssU0FBUyxTQUFTO0FBQ3pIO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDN0IsT0FBTyxVQUFVLE9BQU8sSUFBSSxLQUFLLHFCQUFxQixPQUFPLFFBQVEsS0FBSyxxQkFBcUIsT0FBTyxZQUFZLEtBQUsscUJBQXFCLE9BQU8sVUFBVTtBQUMvSjtBQUNBLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDL0IsSUFBSSxVQUFVLE1BQU0sT0FBTztDQUMzQixJQUFJLEVBQUUsa0JBQWtCLFFBQVEsT0FBTztDQUN2QyxPQUFPLFVBQVUsVUFBVSxXQUFXO0FBQ3hDO0FBQ0EsZUFBZSxjQUFjLFNBQVM7Q0FDcEMsTUFBTSxpQkFBaUIsT0FBTyxhQUFhO0VBQ3pDLElBQUksb0JBQW9CLE9BQU87R0FDN0IsTUFBTSxRQUFRLFdBQVcsVUFBVSxRQUFRO0dBQzNDLE9BQU87RUFDVDtFQUNBLElBQUksZ0JBQWdCLFFBQVEsR0FBRztHQUM3QixNQUFNLFFBQVEsV0FBVyxZQUFZLFFBQVE7R0FDN0MsT0FBTztFQUNUO0VBQ0EsSUFBSSxlQUFlLFFBQVEsR0FBRztHQUM1QixNQUFNLFFBQVEsV0FBVyxZQUFZLFFBQVE7R0FDN0MsT0FBTztFQUNUO0VBQ0EsSUFBSSxVQUFVLFFBQVEsR0FBRztHQUN2QixNQUFNLFFBQVEsV0FBVyxVQUFVLFFBQVE7R0FDM0MsT0FBTztFQUNUO0VBQ0EsT0FBTztDQUNUO0NBQ0EsTUFBTSxzQkFBc0IsT0FBTyxXQUFXO0VBQzVDLElBQUksa0JBQWtCLGtCQUFrQixNQUFNLE9BQU87RUFDckQsSUFBSSxnQkFBZ0IsTUFBTSxHQUFHO0dBQzNCLE1BQU0sUUFBUSxXQUFXLFVBQVUsTUFBTTtHQUN6QyxPQUFPO0VBQ1Q7RUFDQSxJQUFJLGtCQUFrQixVQUFVLE9BQU8sTUFBTSxlQUFlLE1BQU07RUFDbEUsT0FBTztDQUNUO0NBQ0EsTUFBTSxzQkFBc0IsSUFBSSxnQkFBZ0I7Q0FDaEQsTUFBTSxnQkFBZ0I7RUFDcEIsb0JBQW9CLE9BQU8sUUFBUSxRQUFRLFFBQVEsTUFBTTtDQUMzRDtDQUNBLElBQUksUUFBUSxRQUFRLFFBQVE7RUFDMUIsSUFBSSxRQUFRLFFBQVEsT0FBTyxTQUFTO0dBQ2xDLE1BQU0sUUFBUSxXQUFXLFVBQVUsUUFBUSxRQUFRLE9BQU8sTUFBTTtHQUNoRTtFQUNGO0VBQ0EsUUFBUSxRQUFRLE9BQU8saUJBQWlCLFNBQVMsU0FBUyxFQUFFLE1BQU0sS0FBSyxDQUFDO0NBQzFFO0NBQ0EsTUFBTSxTQUFTLE1BQU0sT0FBTyxZQUFZO0VBQ3RDLE1BQU0sMEJBQTBCLFVBQVUsUUFBUSxTQUFTLFdBQVc7R0FDcEUsV0FBVyxRQUFRO0dBQ25CLFNBQVMsUUFBUTtHQUNqQixZQUFZLFFBQVE7RUFDdEIsQ0FBQztFQUNELE1BQU0sUUFBUSxLQUFLO0dBQ2pCO0dBQ0E7R0FDQSxRQUFRLFdBQVc7RUFDckIsQ0FBQztDQUNILENBQUM7Q0FDRCxRQUFRLFFBQVEsUUFBUSxvQkFBb0IsU0FBUyxPQUFPO0NBQzVELElBQUksb0JBQW9CLFVBQVUsWUFBWTtFQUM1QyxNQUFNLFFBQVEsV0FBVyxVQUFVLG9CQUFvQixlQUFlO0VBQ3RFO0NBQ0Y7Q0FDQSxJQUFJLE9BQU8sT0FBTztFQUNoQixJQUFJLE1BQU0sb0JBQW9CLE9BQU8sS0FBSyxHQUFHO0VBQzdDLElBQUksUUFBUSxRQUFRLGNBQWMsb0JBQW9CLElBQUksR0FBRztHQUMzRCxNQUFNLCtCQUErQixJQUFJLGtCQUFrQixRQUFRLFNBQVM7SUFDMUUsY0FBYyxDQUNkO0lBQ0EsTUFBTSxZQUFZLFVBQVU7S0FDMUIsTUFBTSxlQUFlLFFBQVE7SUFDL0I7SUFDQSxNQUFNLFVBQVUsUUFBUTtLQUN0QixNQUFNLFFBQVEsV0FBVyxVQUFVLE1BQU07SUFDM0M7R0FDRixDQUFDO0dBQ0QsTUFBTSxVQUFVLFFBQVEsU0FBUyxzQkFBc0I7SUFDckQsT0FBTyxPQUFPO0lBQ2QsU0FBUyxRQUFRO0lBQ2pCLFdBQVcsUUFBUTtJQUNuQixZQUFZO0dBQ2QsQ0FBQztHQUNELElBQUksNkJBQTZCLGVBQWUsa0JBQWtCLFNBQVM7RUFDN0U7RUFDQSxNQUFNLFFBQVEsV0FBVyxZQUFZLDBCQUEwQixPQUFPLEtBQUssQ0FBQztFQUM1RTtDQUNGO0NBQ0EsSUFBSSxRQUFRLFdBQVcsZUFBZSxrQkFBa0IsU0FBUyxPQUFPLE1BQU0sUUFBUSxXQUFXLFlBQVk7Q0FDN0csT0FBTyxRQUFRLFdBQVc7QUFDNUI7QUFHQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2pDLE9BQU8sT0FBTyx1QkFBdUIsSUFBSSxVQUFVLGlCQUFpQixHQUFHLEVBQUUsTUFBTSxDQUFDO0FBQ2xGO0FBQ0EsSUFBSSx1QkFBdUI7Q0FDekI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBQ0EsSUFBSSxpQkFBaUMsdUJBQU8sZ0JBQWdCO0FBQzVELGVBQWUsb0JBQW9CLFNBQVMsVUFBVTtDQUNwRCxJQUFJLFNBQVMsV0FBVyxPQUFPLFFBQVEsUUFBUSxNQUFNLE9BQU8sUUFBUSxPQUFPLG1CQUFtQixDQUFDO0NBQy9GLE1BQU0sYUFBYSxJQUFJLElBQUksUUFBUSxHQUFHO0NBQ3RDLElBQUk7Q0FDSixJQUFJO0VBQ0YsY0FBYyxJQUFJLElBQUksU0FBUyxRQUFRLElBQUksVUFBVSxHQUFHLFFBQVEsR0FBRztDQUNyRSxTQUFTLFFBQVE7RUFDZixPQUFPLFFBQVEsT0FBTyxtQkFBbUIsTUFBTSxDQUFDO0NBQ2xEO0NBQ0EsSUFBSSxFQUFFLFlBQVksYUFBYSxXQUFXLFlBQVksYUFBYSxXQUFXLE9BQU8sUUFBUSxPQUFPLG1CQUFtQixxQ0FBcUMsQ0FBQztDQUM3SixJQUFJLFFBQVEsSUFBSSxTQUFTLGNBQWMsSUFBSSxJQUFJLE9BQU8sUUFBUSxPQUFPLG1CQUFtQix5QkFBeUIsQ0FBQztDQUNsSCxPQUFPLGVBQWUsU0FBUyxnQkFBZ0IsRUFBRSxRQUFRLFFBQVEsSUFBSSxTQUFTLGNBQWMsS0FBSyxLQUFLLEVBQUUsQ0FBQztDQUN6RyxJQUFJLFFBQVEsU0FBUyxXQUFXLFlBQVksWUFBWSxZQUFZLGFBQWEsQ0FBQyxXQUFXLFlBQVksV0FBVyxHQUFHLE9BQU8sUUFBUSxPQUFPLG1CQUFtQixvREFBa0QsQ0FBQztDQUNuTixNQUFNLGNBQWMsQ0FBQztDQUNyQixJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxTQUFTLFNBQVMsTUFBTSxLQUFLLFFBQVEsV0FBVyxVQUFVLFNBQVMsV0FBVyxPQUFPLENBQUMsQ0FBQyxRQUFRLEtBQUssQ0FBQyxDQUFDLFNBQVMsUUFBUSxNQUFNLEdBQUc7RUFDN0ksWUFBWSxTQUFTO0VBQ3JCLFlBQVksT0FBTztFQUNuQixxQkFBcUIsU0FBUyxlQUFlO0dBQzNDLFFBQVEsUUFBUSxPQUFPLFVBQVU7RUFDbkMsQ0FBQztDQUNIO0NBQ0EsSUFBSSxDQUFDLFdBQVcsWUFBWSxXQUFXLEdBQUc7RUFDeEMsUUFBUSxRQUFRLE9BQU8sZUFBZTtFQUN0QyxRQUFRLFFBQVEsT0FBTyxxQkFBcUI7RUFDNUMsUUFBUSxRQUFRLE9BQU8sUUFBUTtFQUMvQixRQUFRLFFBQVEsT0FBTyxNQUFNO0NBQy9CO0NBQ0EsWUFBWSxVQUFVLFFBQVE7Q0FDOUIsTUFBTSxnQkFBZ0IsTUFBTSxNQUFNLElBQUksUUFBUSxhQUFhLFdBQVcsQ0FBQztDQUN2RSxPQUFPLGVBQWUsZUFBZSxjQUFjO0VBQ2pELE9BQU87RUFDUCxjQUFjO0NBQ2hCLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsTUFBTSxPQUFPO0NBQy9CLElBQUksS0FBSyxXQUFXLE1BQU0sVUFBVSxLQUFLLFdBQVcsUUFBUSxPQUFPO0NBQ25FLElBQUksS0FBSyxhQUFhLE1BQU0sWUFBWSxLQUFLLGFBQWEsTUFBTSxZQUFZLEtBQUssU0FBUyxNQUFNLE1BQU0sT0FBTztDQUM3RyxPQUFPO0FBQ1Q7QUFDQSxJQUFJLDRCQUE0QixjQUFjLGdCQUFnQjtDQUM1RCxjQUFjO0VBQ1osUUFBUSxLQUFLLDBGQUEwRjtFQUN2RyxNQUFNLEVBQUUsVUFBVSxPQUFPLFlBQVk7R0FDbkMsV0FBVyxRQUFRLEtBQUs7RUFDMUIsRUFBRSxDQUFDO0NBQ0w7QUFDRjtBQUNBLElBQUksaUJBQWlCLGNBQWMsZ0JBQWdCO0NBQ2pELFlBQVksa0JBQWtCLEdBQUcsWUFBWTtFQUMzQyxNQUFNLENBQUMsR0FBRyxHQUFHLFVBQVU7RUFDdkIsTUFBTSxXQUFXLENBQUMsTUFBTSxVQUFVLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxRQUFRLFlBQVksY0FBYyxXQUFXLFlBQVksU0FBUyxDQUFDO0VBQzFILE9BQU8sZUFBZSxNQUFNLFlBQVksRUFBRSxNQUFNO0dBQzlDLE9BQU87RUFDVCxFQUFFLENBQUM7Q0FDTDtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsaUJBQWlCO0NBQzdDLE9BQU8sZ0JBQWdCLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxXQUFXLE9BQU8sS0FBSyxDQUFDO0FBQy9FO0FBQ0EsU0FBUywwQkFBMEIsaUJBQWlCO0NBQ2xELElBQUksb0JBQW9CLElBQUksT0FBTztDQUNuQyxNQUFNLFVBQVUscUJBQXFCLGVBQWU7Q0FDcEQsSUFBSSxRQUFRLFdBQVcsR0FBRyxPQUFPO0NBQ2pDLE9BQU8sSUFBSSxlQUFlLFFBQVEsYUFBYSxjQUFjLFdBQVc7RUFDdEUsSUFBSSxXQUFXLFVBQVUsV0FBVyxVQUFVLE9BQU8sYUFBYSxPQUFPLElBQUksb0JBQW9CLE1BQU0sQ0FBQztPQUNuRyxJQUFJLFdBQVcsV0FBVyxPQUFPLGFBQWEsT0FBTyxJQUFJLG9CQUFvQixTQUFTLENBQUM7T0FDdkYsSUFBSSxXQUFXLE1BQU0sT0FBTyxhQUFhLE9BQU8sSUFBSSwwQkFBMEIsQ0FBQztPQUMvRSxhQUFhLFNBQVM7RUFDM0IsT0FBTztDQUNULEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDUjtBQUNBLFNBQVMsbUJBQW1CLFVBQVU7Q0FDcEMsSUFBSSxTQUFTLFNBQVMsTUFBTSxPQUFPO0NBQ25DLE1BQU0sc0JBQXNCLDBCQUEwQixTQUFTLFFBQVEsSUFBSSxrQkFBa0IsS0FBSyxFQUFFO0NBQ3BHLElBQUksQ0FBQyxxQkFBcUIsT0FBTztDQUNqQyxTQUFTLEtBQUssT0FBTyxvQkFBb0IsUUFBUTtDQUNqRCxPQUFPLG9CQUFvQjtBQUM3QjtBQUNBLElBQUksbUJBQW1CLE1BQU0sMEJBQTBCLFlBQVk7Q0FDakU7RUFDRSxLQUFLLFNBQXlCLHVCQUFPLElBQUksbUJBQW1CO0NBQzlEO0NBQ0EsY0FBYztFQUNaLE1BQU0sa0JBQWtCLE1BQU07Q0FDaEM7Q0FDQSxtQkFBbUI7RUFDakIsT0FBTyxzQkFBc0IsT0FBTztDQUN0QztDQUNBLE1BQU0sUUFBUTtFQUNaLE1BQU0sU0FBUyxLQUFLLE9BQU8sT0FBTyxPQUFPO0VBQ3pDLE1BQU0sWUFBWSxXQUFXO0VBQzdCLE1BQU0sYUFBYSxPQUFPLE9BQU8sU0FBUztHQUN4QyxNQUFNLFlBQVksZ0JBQWdCO0dBQ2xDLE1BQU0sVUFBVSxJQUFJLGFBQWEsT0FBTyxVQUFVLFlBQVksT0FBTyxhQUFhLGVBQWUsQ0FBQyxZQUFZLEtBQUssSUFBSSxJQUFJLElBQUksT0FBTyxTQUFTLElBQUksSUFBSSxPQUFPLElBQUk7R0FDbEssSUFBSSxpQkFBaUIsU0FBUyxjQUFjLFNBQVMsS0FBSztHQUMxRCxNQUFNLGtCQUFrQixJQUFJLGdCQUFnQjtHQUM1QyxNQUFNLGFBQWEsSUFBSSxrQkFBa0IsU0FBUztJQUNoRCxhQUFhLFlBQVk7S0FDdkIsS0FBSyxPQUFPLEtBQUssOENBQThDO0tBQy9ELE1BQU0sK0JBQStCLFFBQVEsTUFBTTtLQUNuRCxNQUFNLEVBQUUsT0FBTyxlQUFlLE1BQU0scUJBQXFCLE1BQU0sYUFBYSxVQUFVLE9BQU8sQ0FBQztLQUM5RixJQUFJLGVBQWUsT0FBTyxnQkFBZ0IsT0FBTyxhQUFhO0tBQzlELEtBQUssT0FBTyxLQUFLLDRCQUE0QixnQkFBZ0I7S0FDN0QsSUFBSSxLQUFLLFFBQVEsY0FBYyxVQUFVLElBQUksR0FBRztNQUM5QyxLQUFLLE9BQU8sS0FBSyxvQ0FBa0M7TUFDbkQsTUFBTSxnQkFBZ0IsY0FBYyxNQUFNLGdCQUFnQjtNQUMxRCxNQUFNLFVBQVUsS0FBSyxTQUFTLFlBQVk7T0FDeEMsVUFBVTtPQUNWLGtCQUFrQjtPQUNsQixTQUFTO09BQ1Q7TUFDRixDQUFDO0tBQ0g7S0FDQSxnQkFBZ0IsUUFBUSxnQkFBZ0I7SUFDMUM7SUFDQSxhQUFhLE9BQU8sZ0JBQWdCO0tBQ2xDLElBQUksZ0JBQWdCLFdBQVcsR0FBRztNQUNoQyxLQUFLLE9BQU8sS0FBSyx3QkFBd0IsRUFBRSxVQUFVLFlBQVksQ0FBQztNQUNsRSxnQkFBZ0IsT0FBTyxtQkFBbUIsV0FBVyxDQUFDO01BQ3REO0tBQ0Y7S0FDQSxLQUFLLE9BQU8sS0FBSyw2QkFBNkIsRUFBRSxZQUFZLENBQUM7S0FDN0QsTUFBTSxXQUFXLElBQUksY0FBYyxtQkFBbUIsV0FBVyxLQUFLLFlBQVksTUFBTTtNQUN0RixLQUFLLFFBQVE7TUFDYixRQUFRLFlBQVk7TUFDcEIsWUFBWSxZQUFZO01BQ3hCLFNBQVMsWUFBWTtLQUN2QixDQUFDO0tBQ0QsSUFBSSxjQUFjLG1CQUFtQixTQUFTLE1BQU0sR0FBRztNQUNyRCxJQUFJLFFBQVEsYUFBYSxTQUFTO09BQ2hDLGdCQUFnQixPQUFPLG1CQUFtQixxQkFBcUIsQ0FBQztPQUNoRTtNQUNGO01BQ0EsSUFBSSxRQUFRLGFBQWEsVUFBVTtPQUNqQyxvQkFBb0IsU0FBUyxRQUFRLENBQUMsQ0FBQyxNQUFNLGVBQWU7UUFDMUQsZ0JBQWdCLFFBQVEsVUFBVTtPQUNwQyxJQUFJLFdBQVc7UUFDYixnQkFBZ0IsT0FBTyxNQUFNO09BQy9CLENBQUM7T0FDRDtNQUNGO0tBQ0Y7S0FDQSxJQUFJLEtBQUssUUFBUSxjQUFjLFVBQVUsSUFBSSxHQUFHO01BQzlDLEtBQUssT0FBTyxLQUFLLG9DQUFrQztNQUNuRCxNQUFNLFVBQVUsS0FBSyxTQUFTLFlBQVk7T0FDeEMsVUFBVSxjQUFjLE1BQU0sUUFBUTtPQUN0QyxrQkFBa0I7T0FDbEI7T0FDQTtNQUNGLENBQUM7S0FDSDtLQUNBLGdCQUFnQixRQUFRLFFBQVE7SUFDbEM7SUFDQSxZQUFZLFdBQVc7S0FDckIsS0FBSyxPQUFPLEtBQUssNkJBQTZCLEVBQUUsT0FBTyxDQUFDO0tBQ3hELGdCQUFnQixPQUFPLE1BQU07SUFDL0I7R0FDRixDQUFDO0dBQ0QsS0FBSyxPQUFPLEtBQUssV0FBVyxRQUFRLFFBQVEsUUFBUSxHQUFHO0dBQ3ZELEtBQUssT0FBTyxLQUFLLHFDQUFxQztHQUN0RCxLQUFLLE9BQU8sS0FBSyx3REFBc0QsS0FBSyxRQUFRLGNBQWMsU0FBUyxDQUFDO0dBQzVHLE1BQU0sY0FBYztJQUNsQjtJQUNBO0lBQ0EsU0FBUyxLQUFLO0lBQ2Q7R0FDRixDQUFDO0dBQ0QsT0FBTztFQUNUO0VBQ0EsT0FBTyxLQUFLLDBCQUEwQjtFQUN0QyxLQUFLLGNBQWMsS0FBSyxnQkFBZ0IsV0FBVyxZQUFZLGVBQWUsVUFBVSxDQUFDO0VBQ3pGLE9BQU8sS0FBSyx5QkFBeUIsV0FBVyxNQUFNLElBQUk7Q0FDNUQ7QUFDRjtBQUdBLFNBQVMsa0JBQWtCLE1BQU0sT0FBTztDQUN0QyxNQUFNLFNBQVMsSUFBSSxXQUFXLEtBQUssYUFBYSxNQUFNLFVBQVU7Q0FDaEUsT0FBTyxJQUFJLE1BQU0sQ0FBQztDQUNsQixPQUFPLElBQUksT0FBTyxLQUFLLFVBQVU7Q0FDakMsT0FBTztBQUNUO0FBQ0EsSUFBSSxnQkFBZ0IsTUFBTTtDQUN4QixZQUFZLE1BQU0sU0FBUztFQUN6QixLQUFLLE9BQU87RUFDWixLQUFLLGtCQUFrQjtFQUN2QixLQUFLLFlBQVk7RUFDakIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxPQUFPO0VBQ1osS0FBSyxhQUFhO0VBQ2xCLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssYUFBYTtFQUNsQixLQUFLLFlBQVk7RUFDakIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssYUFBYTtFQUNsQixLQUFLLG1CQUFtQjtFQUN4QixLQUFLLFVBQVU7RUFDZixLQUFLLG1CQUFtQjtFQUN4QixLQUFLLFNBQVM7RUFDZCxLQUFLLFFBQVE7RUFDYixLQUFLLGVBQWU7RUFDcEIsS0FBSyxjQUFjO0VBQ25CLEtBQUssT0FBTztFQUNaLEtBQUssU0FBUyxTQUFTLFVBQVU7RUFDakMsS0FBSyxnQkFBZ0IsU0FBUyxpQkFBaUI7RUFDL0MsS0FBSyxZQUFZLEtBQUssSUFBSTtDQUM1QjtDQUNBLGVBQWU7RUFDYixPQUFPLENBQUM7Q0FDVjtDQUNBLFVBQVUsTUFBTSxTQUFTLFlBQVk7RUFDbkMsS0FBSyxPQUFPO0VBQ1osS0FBSyxVQUFVLENBQUMsQ0FBQztFQUNqQixLQUFLLGFBQWEsQ0FBQyxDQUFDO0NBQ3RCO0NBQ0EsaUJBQWlCO0VBQ2YsS0FBSyxtQkFBbUI7Q0FDMUI7Q0FDQSxrQkFBa0IsQ0FDbEI7Q0FDQSwyQkFBMkIsQ0FDM0I7QUFDRjtBQUNBLElBQUksd0JBQXdCLGNBQWMsY0FBYztDQUN0RCxZQUFZLE1BQU0sTUFBTTtFQUN0QixNQUFNLElBQUk7RUFDVixLQUFLLG1CQUFtQixNQUFNLG9CQUFvQjtFQUNsRCxLQUFLLFdBQVcsTUFBTSxZQUFZO0VBQ2xDLEtBQUssU0FBUyxNQUFNLFVBQVU7RUFDOUIsS0FBSyxRQUFRLE1BQU0sU0FBUztDQUM5QjtBQUNGO0FBQ0EsSUFBSSwwQkFBMEIsT0FBTyxrQkFBa0I7QUFDdkQsU0FBUyxZQUFZLFFBQVEsTUFBTSxNQUFNO0NBQ3ZDLE1BQU0saUJBQWlCO0VBQ3JCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7Q0FDQSxNQUFNLHFCQUFxQiwwQkFBMEIsZ0JBQWdCO0NBQ3JFLE9BQU8sZUFBZSxTQUFTLElBQUksSUFBSSxJQUFJLG1CQUFtQixNQUFNO0VBQ2xFLGtCQUFrQjtFQUNsQixRQUFRLE1BQU0sVUFBVTtFQUN4QixPQUFPLE1BQU0sU0FBUztDQUN4QixDQUFDLElBQUksSUFBSSxjQUFjLE1BQU07RUFDM0I7RUFDQSxlQUFlO0NBQ2pCLENBQUM7QUFDSDtBQUNBLFNBQVMsbUJBQW1CLFFBQVEsY0FBYztDQUNoRCxJQUFJLEVBQUUsZ0JBQWdCLFNBQVMsT0FBTztDQUN0QyxJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssUUFBUSxZQUFZLEdBQUcsT0FBTztDQUN2RSxNQUFNLFlBQVksUUFBUSxlQUFlLE1BQU07Q0FDL0MsT0FBTyxZQUFZLG1CQUFtQixXQUFXLFlBQVksSUFBSTtBQUNuRTtBQUNBLFNBQVMsWUFBWSxRQUFRLFNBQVM7Q0FDcEMsT0FBTyxJQUFJLE1BQU0sUUFBUSxzQkFBc0IsT0FBTyxDQUFDO0FBQ3pEO0FBQ0EsU0FBUyxzQkFBc0IsU0FBUztDQUN0QyxNQUFNLEVBQUUsaUJBQWlCLFlBQVksYUFBYSxnQkFBZ0I7Q0FDbEUsTUFBTSxVQUFVLENBQUM7Q0FDakIsSUFBSSxPQUFPLG9CQUFvQixhQUFhLFFBQVEsWUFBWSxTQUFTLFFBQVEsTUFBTSxXQUFXO0VBQ2hHLE1BQU0sT0FBTyxRQUFRLFVBQVUsS0FBSyxNQUFNLFFBQVEsTUFBTSxTQUFTO0VBQ2pFLE9BQU8sZ0JBQWdCLEtBQUssV0FBVyxNQUFNLElBQUk7Q0FDbkQ7Q0FDQSxRQUFRLE1BQU0sU0FBUyxRQUFRLGNBQWMsV0FBVztFQUN0RCxNQUFNLGFBQWE7R0FDakIsTUFBTSxpQkFBaUIsbUJBQW1CLFFBQVEsWUFBWSxLQUFLO0dBQ25FLE1BQU0saUJBQWlCLFFBQVEseUJBQXlCLGdCQUFnQixZQUFZO0dBQ3BGLElBQUksT0FBTyxnQkFBZ0IsUUFBUSxhQUFhO0lBQzlDLGVBQWUsSUFBSSxNQUFNLFFBQVEsQ0FBQyxTQUFTLENBQUM7SUFDNUMsT0FBTztHQUNUO0dBQ0EsT0FBTyxRQUFRLGVBQWUsZ0JBQWdCLGNBQWM7SUFDMUQsVUFBVTtJQUNWLFlBQVk7SUFDWixjQUFjO0lBQ2QsT0FBTztHQUNULENBQUM7RUFDSDtFQUNBLElBQUksT0FBTyxnQkFBZ0IsYUFBYSxPQUFPLFlBQVksS0FBSyxRQUFRLENBQUMsY0FBYyxTQUFTLEdBQUcsSUFBSTtFQUN2RyxPQUFPLEtBQUs7Q0FDZDtDQUNBLFFBQVEsTUFBTSxTQUFTLFFBQVEsY0FBYyxVQUFVO0VBQ3JELE1BQU0sYUFBYSxPQUFPO0VBQzFCLE1BQU0sUUFBUSxPQUFPLGdCQUFnQixjQUFjLFlBQVksS0FBSyxRQUFRLENBQUMsY0FBYyxRQUFRLEdBQUcsSUFBSSxJQUFJLEtBQUs7RUFDbkgsSUFBSSxPQUFPLFVBQVUsWUFBWSxRQUFRLEdBQUcsU0FBUztHQUNuRCxNQUFNLFNBQVMsTUFBTSxLQUFLLFFBQVEsR0FBRyxJQUFJO0dBQ3pDLElBQUksT0FBTyxlQUFlLGFBQWEsT0FBTyxXQUFXLEtBQUssUUFBUSxDQUFDLGNBQWMsSUFBSSxHQUFHLE1BQU07R0FDbEcsT0FBTyxPQUFPO0VBQ2hCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyx5QkFBeUIsTUFBTTtDQUN0QyxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUMsQ0FBQyxNQUFNLGtCQUFrQjtFQUN4QixPQUFPLEtBQUssV0FBVyxhQUFhO0NBQ3RDLENBQUM7QUFDSDtBQUNBLFNBQVMsVUFBVSxNQUFNO0NBQ3ZCLElBQUk7RUFDRixPQUFPLEtBQUssTUFBTSxJQUFJO0NBQ3hCLFNBQVMsR0FBRztFQUNWLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxlQUFlLFNBQVMsTUFBTTtDQUNyQyxPQUFPLElBQUksY0FBYyxjQUFjLG1CQUFtQixRQUFRLE1BQU0sSUFBSSxPQUFPLE1BQU07RUFDdkYsS0FBSyxRQUFRO0VBQ2IsUUFBUSxRQUFRO0VBQ2hCLFlBQVksUUFBUTtFQUNwQixTQUFTLHVDQUF1QyxRQUFRLHNCQUFzQixDQUFDO0NBQ2pGLENBQUM7QUFDSDtBQUNBLFNBQVMsdUNBQXVDLGVBQWU7Q0FDN0QsTUFBTSxVQUFVLElBQUksUUFBUTtDQUM1QixNQUFNLFFBQVEsY0FBYyxNQUFNLFNBQVM7Q0FDM0MsS0FBSyxNQUFNLFFBQVEsT0FBTztFQUN4QixJQUFJLEtBQUssS0FBSyxNQUFNLElBQUk7RUFDeEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLEtBQUssTUFBTSxJQUFJO0VBQ3hDLE1BQU0sUUFBUSxNQUFNLEtBQUssSUFBSTtFQUM3QixRQUFRLE9BQU8sTUFBTSxLQUFLO0NBQzVCO0NBQ0EsT0FBTztBQUNUO0FBQ0EsZUFBZSxrQkFBa0IsT0FBTztDQUN0QyxNQUFNLHdCQUF3QixNQUFNLFFBQVEsSUFBSSxnQkFBZ0I7Q0FDaEUsSUFBSSx5QkFBeUIsUUFBUSwwQkFBMEIsSUFBSSxPQUFPLE9BQU8scUJBQXFCO0NBQ3RHLFFBQVEsTUFBTSxNQUFNLFlBQVksRUFBQSxDQUFHO0FBQ3JDO0FBQ0EsSUFBSSxvQkFBb0MsdUJBQU8sbUJBQW1CO0FBQ2xFLElBQUksV0FBVyxjQUFjO0FBQzdCLElBQUksZ0JBQWdDLHVCQUFPLGVBQWU7QUFDMUQsSUFBSSwyQkFBMkIsTUFBTTtDQUNuQyxZQUFZLGdCQUFnQixRQUFRO0VBQ2xDLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssU0FBUztFQUNkLEtBQUssU0FBUztFQUNkLEtBQUssTUFBTTtFQUNYLEtBQUsscUJBQXFCO0VBQzFCLEtBQUsseUJBQXlCLElBQUksSUFBSTtFQUN0QyxLQUFLLCtCQUErQixJQUFJLElBQUk7RUFDNUMsS0FBSyxZQUFZLGdCQUFnQjtFQUNqQyxLQUFLLGlCQUFpQixJQUFJLFFBQVE7RUFDbEMsS0FBSyxpQ0FBaUIsSUFBSSxXQUFXO0VBQ3JDLEtBQUssVUFBVSxZQUFZLGdCQUFnQjtHQUN6QyxjQUFjLENBQUMsY0FBYyxZQUFZLFdBQVc7SUFDbEQsUUFBUSxjQUFSO0tBQ0UsS0FBSyxhQUFhO01BQ2hCLE1BQU0sWUFBWSxhQUFhLE1BQU0sQ0FBQztNQUN0QyxLQUFLLFFBQVEsaUJBQWlCLFdBQVcsU0FBUztNQUNsRCxPQUFPLE9BQU87S0FDaEI7S0FDQSxTQUNFLE9BQU8sT0FBTztJQUNsQjtHQUNGO0dBQ0EsYUFBYSxDQUFDLFlBQVksT0FBTyxXQUFXO0lBQzFDLFFBQVEsWUFBUjtLQUNFLEtBQUssUUFBUTtNQUNYLE1BQU0sQ0FBQyxRQUFRLE9BQU87TUFDdEIsSUFBSSxPQUFPLFFBQVEsYUFBYTtPQUM5QixLQUFLLFNBQVM7T0FDZCxLQUFLLE1BQU0sY0FBYyxNQUFNO01BQ2pDLE9BQU87T0FDTCxLQUFLLFNBQVM7T0FDZCxLQUFLLE1BQU0sY0FBYyxHQUFHO01BQzlCO01BQ0EsS0FBSyxTQUFTLEtBQUssT0FBTyxPQUFPLEdBQUcsS0FBSyxPQUFPLEdBQUcsS0FBSyxJQUFJLE1BQU07TUFDbEUsS0FBSyxPQUFPLEtBQUssUUFBUSxLQUFLLFFBQVEsS0FBSyxJQUFJLElBQUk7TUFDbkQsT0FBTyxPQUFPO0tBQ2hCO0tBQ0EsS0FBSyxvQkFBb0I7TUFDdkIsTUFBTSxDQUFDLFdBQVcsWUFBWTtNQUM5QixLQUFLLGNBQWMsV0FBVyxRQUFRO01BQ3RDLEtBQUssT0FBTyxLQUFLLG9CQUFvQixXQUFXLFFBQVE7TUFDeEQsT0FBTyxPQUFPO0tBQ2hCO0tBQ0EsS0FBSyxvQkFBb0I7TUFDdkIsTUFBTSxDQUFDLE1BQU0sU0FBUztNQUN0QixLQUFLLGVBQWUsSUFBSSxNQUFNLEtBQUs7TUFDbkMsS0FBSyxPQUFPLEtBQUssb0JBQW9CLE1BQU0sS0FBSztNQUNoRCxPQUFPLE9BQU87S0FDaEI7S0FDQSxLQUFLLFFBQVE7TUFDWCxNQUFNLENBQUMsUUFBUTtNQUNmLEtBQUssUUFBUSxpQkFBaUIsY0FBYztPQUMxQyxJQUFJLE9BQU8sS0FBSyxlQUFlLGFBQWE7UUFDMUMsTUFBTSxnQkFBZ0I7U0FDcEIsS0FBSzs7Ozs7O1NBTUwsS0FBSyxRQUFRO1FBQ2Y7UUFDQSxLQUFLLFdBQVcsS0FBSyxNQUFNO1NBQ3pCLFVBQVU7U0FDVixrQkFBa0IsS0FBSztTQUN2QixTQUFTO1NBQ1QsV0FBVyxLQUFLO1FBQ2xCLENBQUM7T0FDSDtNQUNGLENBQUM7TUFDRCxNQUFNLGNBQWMsT0FBTyxTQUFTLFdBQVcsYUFBYSxJQUFJLElBQUk7TUFDcEUsTUFBTSxlQUFlLEtBQUssa0JBQWtCLFdBQVc7TUFDdkQsS0FBSyxpQkFBaUIsYUFBYSxNQUFNO01BQ3pDLHFCQUFxQjtPQUNuQixDQUFDLEtBQUssV0FBVyxLQUFLLE1BQU07UUFDMUIsU0FBUztRQUNULFdBQVcsS0FBSztPQUNsQixDQUFDLEtBQUssUUFBUSxRQUFRLEVBQUEsQ0FBRyxjQUFjO1FBQ3JDLElBQUksQ0FBQyxLQUFLLG9CQUFvQjtTQUM1QixLQUFLLE9BQU8sS0FBSyxrR0FBa0csS0FBSyxRQUFRLFVBQVU7U0FDMUksSUFBSSxVQUFVLEtBQUssUUFBUSxpQkFBaUIsaUNBQWlDLEtBQUssU0FBUztTQUMzRixPQUFPLE9BQU87UUFDaEI7T0FDRixDQUFDO01BQ0gsQ0FBQztNQUNEO0tBQ0Y7S0FDQSxTQUNFLE9BQU8sT0FBTztJQUNsQjtHQUNGO0VBQ0YsQ0FBQztFQUNELE9BQU8sS0FBSyxTQUFTLFVBQVUsWUFBWSxLQUFLLFFBQVEsUUFBUTtHQUM5RCxjQUFjLENBQUMsY0FBYyxZQUFZLFdBQVc7SUFDbEQsUUFBUSxjQUFSO0tBQ0UsS0FBSztLQUNMLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztLQUNMLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSyxhQUFhO01BQ2hCLE1BQU0sWUFBWSxhQUFhLE1BQU0sQ0FBQztNQUN0QyxLQUFLLG9CQUFvQixXQUFXLFNBQVM7S0FDL0M7SUFDRjtJQUNBLE9BQU8sT0FBTztHQUNoQjtHQUNBLGFBQWEsQ0FBQyxZQUFZLE9BQU8sV0FBVztJQUMxQyxRQUFRLFlBQVI7S0FDRSxLQUFLLG9CQUFvQjtNQUN2QixNQUFNLENBQUMsV0FBVyxZQUFZO01BQzlCLEtBQUssb0JBQW9CLFdBQVcsUUFBUTtNQUM1QyxLQUFLLE9BQU8sS0FBSywyQkFBMkIsV0FBVyxRQUFRO01BQy9ELE9BQU8sT0FBTztLQUNoQjtJQUNGO0dBQ0Y7RUFDRixDQUFDLENBQUM7Q0FDSjtDQUNBLGNBQWMsV0FBVyxVQUFVO0VBQ2pDLE1BQU0sY0FBYyxLQUFLLE9BQU8sSUFBSSxTQUFTLEtBQUssQ0FBQyxFQUFBLENBQUcsT0FBTyxRQUFRO0VBQ3JFLEtBQUssT0FBTyxJQUFJLFdBQVcsVUFBVTtFQUNyQyxLQUFLLE9BQU8sS0FBSywyQkFBeUIsV0FBVyxRQUFRO0NBQy9EO0NBQ0Esb0JBQW9CLFdBQVcsVUFBVTtFQUN2QyxNQUFNLGNBQWMsS0FBSyxhQUFhLElBQUksU0FBUyxLQUFLLENBQUMsRUFBQSxDQUFHLE9BQU8sUUFBUTtFQUMzRSxLQUFLLGFBQWEsSUFBSSxXQUFXLFVBQVU7RUFDM0MsS0FBSyxPQUFPLEtBQUssa0NBQWdDLFdBQVcsUUFBUTtDQUN0RTs7Ozs7Q0FLQSxNQUFNLFlBQVksVUFBVTtFQUMxQixLQUFLLHFCQUFxQjtFQUMxQixJQUFJLEtBQUssZ0JBQWdCO0dBQ3ZCLE1BQU0seUJBQXlCLE1BQU0sa0JBQWtCLEtBQUssY0FBYztHQUMxRSxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsUUFBUTtJQUM3QyxRQUFRO0lBQ1IsT0FBTztHQUNULENBQUM7R0FDRCxLQUFLLFFBQVEsWUFBWSxLQUFLLFFBQVEsUUFBUTtJQUM1QyxRQUFRO0lBQ1IsT0FBTztHQUNULENBQUM7R0FDRCxLQUFLLFFBQVEsUUFBUSxLQUFLLFFBQVEsUUFBUTtJQUN4QyxRQUFRO0lBQ1IsT0FBTztHQUNULENBQUM7R0FDRCxLQUFLLFFBQVEsV0FBVyxLQUFLLFFBQVEsUUFBUTtJQUMzQyxRQUFRO0lBQ1IsT0FBTztHQUNULENBQUM7RUFDSDtFQUNBLEtBQUssT0FBTyxLQUFLLDRDQUE0QyxTQUFTLFFBQVEsU0FBUyxVQUFVO0VBQ2pHLE9BQU8sS0FBSyxTQUFTLFVBQVUsU0FBUyxNQUFNO0VBQzlDLE9BQU8sS0FBSyxTQUFTLGNBQWMsU0FBUyxVQUFVO0VBQ3RELE9BQU8sS0FBSyxTQUFTLGVBQWUsS0FBSyxJQUFJLElBQUk7RUFDakQsS0FBSyxRQUFRLG9CQUFvQixJQUFJLE1BQU0sS0FBSyxRQUFRLG1CQUFtQixFQUFFLFFBQVEsR0FBRyxJQUFJLFNBQVM7R0FDbkcsS0FBSyxPQUFPLEtBQUsscUJBQXFCLEtBQUssRUFBRTtHQUM3QyxJQUFJLEtBQUssUUFBUSxhQUFhLEtBQUssUUFBUSxrQkFBa0I7SUFDM0QsS0FBSyxPQUFPLEtBQUssMENBQTBDO0lBQzNELE9BQU87R0FDVDtHQUNBLE1BQU0sY0FBYyxTQUFTLFFBQVEsSUFBSSxLQUFLLEVBQUU7R0FDaEQsS0FBSyxPQUFPLEtBQUssc0NBQW9DLEtBQUssSUFBSSxXQUFXO0dBQ3pFLE9BQU87RUFDVCxFQUFFLENBQUM7RUFDSCxLQUFLLFFBQVEsd0JBQXdCLElBQUksTUFBTSxLQUFLLFFBQVEsdUJBQXVCLEVBQUUsYUFBYTtHQUNoRyxLQUFLLE9BQU8sS0FBSyx1QkFBdUI7R0FDeEMsSUFBSSxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsa0JBQWtCO0lBQzNELEtBQUssT0FBTyxLQUFLLGtEQUFrRDtJQUNuRSxPQUFPO0dBQ1Q7R0FDQSxNQUFNLGFBQWEsTUFBTSxLQUFLLFNBQVMsUUFBUSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLGlCQUFpQjtJQUMzRixPQUFPLEdBQUcsV0FBVyxJQUFJO0dBQzNCLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTTtHQUNkLEtBQUssT0FBTyxLQUFLLG9DQUFvQyxVQUFVO0dBQy9ELE9BQU87RUFDVCxFQUFFLENBQUM7RUFDSCxPQUFPLGlCQUFpQixLQUFLLFNBQVM7R0FDcEMsVUFBVTtJQUNSLFlBQVk7SUFDWixjQUFjO0lBQ2QsV0FBVyxLQUFLO0dBQ2xCO0dBQ0EsY0FBYztJQUNaLFlBQVk7SUFDWixjQUFjO0lBQ2QsV0FBVyxLQUFLO0dBQ2xCO0dBQ0EsYUFBYTtJQUNYLFlBQVk7SUFDWixjQUFjO0lBQ2QsV0FBVyxLQUFLO0dBQ2xCO0VBQ0YsQ0FBQztFQUNELE1BQU0sMEJBQTBCLE1BQU0sa0JBQWtCLFNBQVMsTUFBTSxDQUFDO0VBQ3hFLEtBQUssT0FBTyxLQUFLLG1DQUFtQyx1QkFBdUI7RUFDM0UsS0FBSyxRQUFRLGFBQWEsS0FBSyxTQUFTO0dBQ3RDLFFBQVE7R0FDUixPQUFPO0VBQ1QsQ0FBQztFQUNELEtBQUssY0FBYyxLQUFLLFFBQVEsZ0JBQWdCO0VBQ2hELEtBQUssY0FBYyxLQUFLLFFBQVEsT0FBTztFQUN2QyxNQUFNLHlCQUF5QjtHQUM3QixLQUFLLE9BQU8sS0FBSyxtQ0FBbUM7R0FDcEQsS0FBSyxjQUFjLEtBQUssUUFBUSxJQUFJO0dBQ3BDLEtBQUssUUFBUSxRQUFRLEtBQUssU0FBUztJQUNqQyxRQUFRLEtBQUssZUFBZTtJQUM1QixPQUFPO0dBQ1QsQ0FBQztHQUNELEtBQUssUUFBUSxXQUFXLEtBQUssU0FBUztJQUNwQyxRQUFRLEtBQUssZUFBZTtJQUM1QixPQUFPO0dBQ1QsQ0FBQztFQUNIO0VBQ0EsSUFBSSxTQUFTLE1BQU07R0FDakIsS0FBSyxPQUFPLEtBQUssd0NBQXdDO0dBQ3pELE1BQU0sU0FBUyxTQUFTLEtBQUssVUFBVTtHQUN2QyxNQUFNLDRCQUE0QixZQUFZO0lBQzVDLE1BQU0sRUFBRSxPQUFPLFNBQVMsTUFBTSxPQUFPLEtBQUs7SUFDMUMsSUFBSSxNQUFNO0tBQ1IsS0FBSyxPQUFPLEtBQUssNEJBQTRCO0tBQzdDLGlCQUFpQjtLQUNqQjtJQUNGO0lBQ0EsSUFBSSxPQUFPO0tBQ1QsS0FBSyxPQUFPLEtBQUssNkJBQTZCLEtBQUs7S0FDbkQsS0FBSyxpQkFBaUIsa0JBQWtCLEtBQUssZ0JBQWdCLEtBQUs7S0FDbEUsS0FBSyxRQUFRLFlBQVksS0FBSyxTQUFTO01BQ3JDLFFBQVEsS0FBSyxlQUFlO01BQzVCLE9BQU87S0FDVCxDQUFDO0lBQ0g7SUFDQSwwQkFBMEI7R0FDNUI7R0FDQSwwQkFBMEI7RUFDNUIsT0FBTyxpQkFBaUI7Q0FDMUI7Q0FDQSx1QkFBdUI7RUFDckIsT0FBTyxhQUFhLEtBQUssY0FBYztDQUN6QztDQUNBLElBQUksV0FBVztFQUNiLEtBQUssT0FBTyxLQUFLLGtDQUFrQyxLQUFLLFFBQVEsWUFBWTtFQUM1RSxJQUFJLEtBQUssUUFBUSxlQUFlLEtBQUssUUFBUSxNQUFNLE9BQU87RUFDMUQsUUFBUSxLQUFLLFFBQVEsY0FBckI7R0FDRSxLQUFLLFFBQVE7SUFDWCxNQUFNLGVBQWUsVUFBVSxLQUFLLHFCQUFxQixDQUFDO0lBQzFELEtBQUssT0FBTyxLQUFLLDBCQUEwQixZQUFZO0lBQ3ZELE9BQU87R0FDVDtHQUNBLEtBQUssZUFBZTtJQUNsQixNQUFNLGNBQWMsY0FBYyxLQUFLLGNBQWM7SUFDckQsS0FBSyxPQUFPLEtBQUssaUNBQWlDLFdBQVc7SUFDN0QsT0FBTztHQUNUO0dBQ0EsS0FBSyxRQUFRO0lBQ1gsTUFBTSxXQUFXLEtBQUssUUFBUSxrQkFBa0IsY0FBYyxLQUFLO0lBQ25FLE1BQU0sZUFBZSxJQUFJLEtBQUssQ0FBQyxLQUFLLHFCQUFxQixDQUFDLEdBQUcsRUFBRSxNQUFNLFNBQVMsQ0FBQztJQUMvRSxLQUFLLE9BQU8sS0FBSywwQ0FBMEMsY0FBYyxRQUFRO0lBQ2pGLE9BQU87R0FDVDtHQUNBLFNBQVM7SUFDUCxNQUFNLGVBQWUsS0FBSyxxQkFBcUI7SUFDL0MsS0FBSyxPQUFPLEtBQUssMENBQXdDLEtBQUssUUFBUSxjQUFjLFlBQVk7SUFDaEcsT0FBTztHQUNUO0VBQ0Y7Q0FDRjtDQUNBLElBQUksZUFBZTtFQUNqQixVQUFVLEtBQUssUUFBUSxpQkFBaUIsTUFBTSxLQUFLLFFBQVEsaUJBQWlCLFFBQVEsb0RBQW9EO0VBQ3hJLElBQUksS0FBSyxRQUFRLGVBQWUsS0FBSyxRQUFRLFdBQVcsS0FBSyxRQUFRLGVBQWUsS0FBSyxRQUFRLE1BQU0sT0FBTztFQUM5RyxNQUFNLGVBQWUsS0FBSyxxQkFBcUI7RUFDL0MsS0FBSyxPQUFPLEtBQUssMkJBQXlCLFlBQVk7RUFDdEQsT0FBTztDQUNUO0NBQ0EsSUFBSSxjQUFjO0VBQ2hCLFVBQVUsS0FBSyxRQUFRLGlCQUFpQixNQUFNLEtBQUssUUFBUSxpQkFBaUIsWUFBWSxvREFBb0Q7RUFDNUksSUFBSSxLQUFLLFFBQVEsZUFBZSxLQUFLLFFBQVEsTUFBTSxPQUFPO0VBQzFELE1BQU0sY0FBYyxLQUFLLFFBQVEsa0JBQWtCLGNBQWMsS0FBSztFQUN0RSxJQUFJLE9BQU8sY0FBYyxhQUFhO0dBQ3BDLFFBQVEsS0FBSyx3TEFBd0w7R0FDck0sT0FBTztFQUNUO0VBQ0EsSUFBSSx5QkFBeUIsV0FBVyxHQUFHLE9BQU8sSUFBSSxVQUFVLENBQUMsQ0FBQyxnQkFBZ0IsS0FBSyxxQkFBcUIsR0FBRyxXQUFXO0VBQzFILE9BQU87Q0FDVDtDQUNBLFVBQVUsUUFBUTtFQUNoQixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLE9BQU8sS0FBSywwQkFBMEI7RUFDM0MsS0FBSyxjQUFjLEtBQUssUUFBUSxJQUFJO0VBQ3BDLEtBQUssUUFBUSxTQUFTLEtBQUssT0FBTztFQUNsQyxLQUFLLFFBQVEsV0FBVyxLQUFLLE9BQU87Q0FDdEM7Ozs7Q0FJQSxjQUFjLGdCQUFnQjtFQUM1QixLQUFLLE9BQU8sS0FBSywyQkFBMkIsS0FBSyxRQUFRLFlBQVksY0FBYztFQUNuRixJQUFJLEtBQUssUUFBUSxlQUFlLGdCQUFnQjtHQUM5QyxLQUFLLE9BQU8sS0FBSywrQ0FBK0M7R0FDaEU7RUFDRjtFQUNBLE9BQU8sS0FBSyxTQUFTLGNBQWMsY0FBYztFQUNqRCxLQUFLLE9BQU8sS0FBSyx5QkFBeUIsY0FBYztFQUN4RCxJQUFJLG1CQUFtQixLQUFLLFFBQVEsUUFBUTtHQUMxQyxLQUFLLE9BQU8sS0FBSywwQ0FBd0M7R0FDekQsS0FBSyxRQUFRLG9CQUFvQixLQUFLLE9BQU87RUFDL0M7Q0FDRjs7OztDQUlBLFFBQVEsV0FBVyxRQUFRLFNBQVM7RUFDbEMsTUFBTSxXQUFXLE9BQU8sS0FBSztFQUM3QixNQUFNLFFBQVEsWUFBWSxRQUFRLFdBQVcsT0FBTztFQUNwRCxLQUFLLE9BQU8sS0FBSyxrQkFBZ0IsV0FBVyxXQUFXLEVBQUU7RUFDekQsSUFBSSxPQUFPLGFBQWEsWUFBWTtHQUNsQyxLQUFLLE9BQU8sS0FBSyw4Q0FBNEMsU0FBUztHQUN0RSxTQUFTLEtBQUssUUFBUSxLQUFLO0VBQzdCO0VBQ0EsTUFBTSxTQUFTLGtCQUFrQix1QkFBdUIsS0FBSyxlQUFlLEtBQUs7RUFDakYsS0FBSyxNQUFNLENBQUMscUJBQXFCLGNBQWMsUUFBUSxJQUFJLHdCQUF3QixXQUFXO0dBQzVGLEtBQUssT0FBTyxLQUFLLHFEQUFtRCxVQUFVLFFBQVEsU0FBUztHQUMvRixVQUFVLFNBQVMsYUFBYSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUM7RUFDOUQ7Q0FDRjs7OztDQUlBLGtCQUFrQixNQUFNO0VBQ3RCLEtBQUssT0FBTyxLQUFLLDhDQUE4QztFQUMvRCxNQUFNLGVBQWUsZ0JBQWdCLFdBQVcsS0FBSyxnQkFBZ0IsWUFBWTtFQUNqRixNQUFNLGVBQWUsSUFBSSxhQUFhLEtBQUssSUFBSSxNQUFNO0dBQ25ELFFBQVEsS0FBSztHQUNiLFNBQVMsS0FBSztHQUNkLGFBQWEsS0FBSyxRQUFRLGtCQUFrQixZQUFZO0dBQ3hELE1BQU0sQ0FBQyxPQUFPLE1BQU0sQ0FBQyxDQUFDLFNBQVMsS0FBSyxPQUFPLFlBQVksQ0FBQyxJQUFJLE9BQU87RUFDckUsQ0FBQztFQUNELE9BQU8sY0FBYyxXQUFXLFlBQVksYUFBYSxTQUFTLEVBQUUsYUFBYSxDQUFDLFlBQVksT0FBTyxXQUFXO0dBQzlHLFFBQVEsWUFBUjtJQUNFLEtBQUs7SUFDTCxLQUFLLE9BQU87S0FDVixNQUFNLENBQUMsWUFBWSxlQUFlO0tBQ2xDLEtBQUssUUFBUSxpQkFBaUIsWUFBWSxXQUFXO0tBQ3JEO0lBQ0Y7SUFDQSxLQUFLLFVBQVU7S0FDYixNQUFNLENBQUMsY0FBYztLQUNyQixRQUFRLEtBQUssb0NBQW9DLFdBQVcscURBQXFELGFBQWEsT0FBTyxHQUFHLGFBQWEsSUFBSSxxREFBcUQ7S0FDOU07SUFDRjtHQUNGO0dBQ0EsT0FBTyxPQUFPO0VBQ2hCLEVBQUUsQ0FBQyxDQUFDO0VBQ0osY0FBYyxjQUFjLEtBQUssT0FBTztFQUN4QyxLQUFLLE9BQU8sS0FBSyw2Q0FBNkMsWUFBWTtFQUMxRSxPQUFPO0NBQ1Q7QUFDRjtBQUNBLFNBQVMsY0FBYyxLQUFLO0NBQzFCLElBQUksT0FBTyxhQUFhLGFBQWEsT0FBTyxJQUFJLElBQUksR0FBRztDQUN2RCxPQUFPLElBQUksSUFBSSxJQUFJLFNBQVMsR0FBRyxTQUFTLElBQUk7QUFDOUM7QUFDQSxTQUFTLE9BQU8sUUFBUSxVQUFVLE9BQU87Q0FDdkMsUUFBUSxlQUFlLFFBQVEsVUFBVTtFQUN2QyxVQUFVO0VBQ1YsWUFBWTtFQUNaO0NBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUywwQkFBMEIsRUFBRSxTQUFTLFVBQVU7Q0FDdEQsT0FBTyxJQUFJLE1BQU0sV0FBVyxnQkFBZ0IsRUFBRSxVQUFVLFFBQVEsTUFBTSxXQUFXO0VBQy9FLE9BQU8sS0FBSyxnQ0FBZ0M7RUFDNUMsTUFBTSxrQkFBa0IsUUFBUSxVQUFVLFFBQVEsTUFBTSxTQUFTO0VBQ2pFLE1BQU0sdUJBQXVCLE9BQU8sMEJBQTBCLE9BQU8sU0FBUztFQUM5RSxLQUFLLE1BQU0sZ0JBQWdCLHNCQUFzQixRQUFRLGVBQWUsaUJBQWlCLGNBQWMscUJBQXFCLGFBQWE7RUFDekksTUFBTSx1QkFBdUIsSUFBSSx5QkFBeUIsaUJBQWlCLE1BQU07RUFDakYscUJBQXFCLFlBQVksZUFBZSxFQUFFLFNBQVMsYUFBYTtHQUN0RSxNQUFNLGFBQWEsSUFBSSxrQkFBa0IsU0FBUztJQUNoRCxtQkFBbUI7S0FDakIsS0FBSyxPQUFPLEtBQUssMERBQTBEO0lBQzdFO0lBQ0EsYUFBYSxPQUFPLGFBQWE7S0FDL0IsSUFBSSxnQkFBZ0IsUUFBUSxHQUFHO01BQzdCLEtBQUssMEJBQTBCLElBQUksVUFBVSxlQUFlLENBQUM7TUFDN0Q7S0FDRjtLQUNBLE1BQU0sS0FBSyxZQUFZLFFBQVE7SUFDakM7SUFDQSxZQUFZLFdBQVc7S0FDckIsS0FBSyxPQUFPLEtBQUssb0JBQW9CLEVBQUUsT0FBTyxPQUFPLENBQUM7S0FDdEQsSUFBSSxrQkFBa0IsT0FBTyxLQUFLLFVBQVUsTUFBTTtJQUNwRDtHQUNGLENBQUM7R0FDRCxLQUFLLE9BQU8sS0FBSyw2QkFBNkI7R0FDOUMsS0FBSyxPQUFPLEtBQUssd0RBQXNELFFBQVEsY0FBYyxTQUFTLENBQUM7R0FDdkcsTUFBTSxjQUFjO0lBQ2xCO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsQ0FBQztFQUNIO0VBQ0EscUJBQXFCLGFBQWEsZUFBZSxFQUFFLFVBQVUsa0JBQWtCLFNBQVMsYUFBYTtHQUNuRyxLQUFLLE9BQU8sS0FBSyx5REFBdUQsUUFBUSxjQUFjLFVBQVUsQ0FBQztHQUN6RyxRQUFRLEtBQUssWUFBWTtJQUN2QjtJQUNBO0lBQ0E7SUFDQTtHQUNGLENBQUM7RUFDSDtFQUNBLE9BQU8scUJBQXFCO0NBQzlCLEVBQUUsQ0FBQztBQUNMO0FBQ0EsSUFBSSw0QkFBNEIsTUFBTSxtQ0FBbUMsWUFBWTtDQUNuRjtFQUNFLEtBQUssU0FBeUIsdUJBQU8sSUFBSSxpQkFBaUI7Q0FDNUQ7Q0FDQSxjQUFjO0VBQ1osTUFBTSwyQkFBMkIsTUFBTTtDQUN6QztDQUNBLG1CQUFtQjtFQUNqQixPQUFPLHNCQUFzQixnQkFBZ0I7Q0FDL0M7Q0FDQSxRQUFRO0VBQ04sTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPLE9BQU87RUFDekMsT0FBTyxLQUFLLG1DQUFtQztFQUMvQyxLQUFLLGNBQWMsS0FBSyxnQkFBZ0IsV0FBVyxZQUFZLHdCQUF3QjtHQUNyRixPQUFPLDBCQUEwQjtJQUMvQixTQUFTLEtBQUs7SUFDZCxRQUFRLEtBQUs7R0FDZixDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBQ0YsT0FBTyxLQUFLLGtDQUFrQyxXQUFXLGVBQWUsSUFBSTtDQUM5RTtBQUNGO0FBS0EsSUFBSSxxQkFBcUIsY0FBYyxrQkFBa0I7Q0FDdkQsWUFBWSxTQUFTO0VBQ25CLE1BQU0sRUFDSixjQUFjLENBQUMsSUFBSSwwQkFBMEIsR0FBRyxJQUFJLGlCQUFpQixDQUFDLEVBQ3hFLENBQUM7RUFDRCxLQUFLLFVBQVU7Q0FDakI7Q0FDQTtDQUNBLFNBQVM7RUFDUCxNQUFNLE9BQU87RUFDYixJQUFJLENBQUMsS0FBSyxRQUFRLE9BQ2hCLEtBQUtSLG1CQUFtQjtDQUU1QjtDQUNBLFVBQVU7RUFDUixNQUFNLFFBQVE7RUFDZCxJQUFJLENBQUMsS0FBSyxRQUFRLE9BQ2hCLEtBQUtDLGtCQUFrQjtDQUUzQjtDQUNBLHFCQUFxQjtFQUNuQixRQUFRLGVBQ04sS0FBS1MsU0FBVSxjQUFjLGtDQUFrQyxLQUMvRCxtQ0FDRjtFQUNBLFFBQVEsSUFDTiw0Q0FDQSxvQkFDQSxvQkFDRjtFQUNBLFFBQVEsSUFBSSxxREFBcUQ7RUFDakUsUUFBUSxTQUFTO0NBQ25CO0NBQ0Esb0JBQW9CO0VBQ2xCLFFBQVEsSUFDTixLQUFLQSxTQUFVLGNBQWMsbUJBQW1CLEtBQ2hELG1DQUNGO0NBQ0Y7QUFDRjtBQUdBLElBQUkscUJBQXFCO0FBQ3pCLFNBQVMsWUFBWSxHQUFHLFVBQVU7Q0FDaEMsVUFDRSxDQUFDLGNBQWMsR0FDZkMsU0FBVSxjQUNSLDhEQUNGLENBQ0Y7Q0FDQSxNQUFNLFVBQVUsY0FBYztFQUM1QixTQUFTLENBQUM7RUFDVjtDQUNGLENBQUM7Q0FDRCxPQUFPO0VBQ0wsTUFBTSxNQUFNLFNBQVM7R0FDbkIsSUFBSSxTQUFTLGtCQUFrQixNQUM3QixTQUFVLEtBQ1Isa1VBQ0Y7R0FFRixJQUFJLFFBQVEsZUFBZSxrQkFBa0IsU0FBUztJQUNwRCxTQUFVLEtBQ1IsZ0xBQ0Y7SUFDQTtHQUNGO0dBQ0EsTUFBTSxhQUFhLHNCQUFzQixJQUFJLE1BQU0sb0JBQW9CLEtBQUs7SUFDMUUsZUFBZTtLQUNiLEtBQUssU0FBUyxlQUFlLEtBQUssU0FBUyxLQUFLO0tBQ2hELFNBQVMsU0FBUyxlQUFlO0lBQ25DO0lBQ0EsWUFBWSxTQUFTO0lBQ3JCLE9BQU8sU0FBUztHQUNsQixDQUFDLElBQUksSUFBSSxtQkFBbUIsRUFDMUIsT0FBTyxTQUFTLE1BQ2xCLENBQUM7R0FDRCxRQUFRLFVBQVU7SUFDaEIsU0FBUyxDQUNQLFlBQ0EsSUFBSUMsa0JBQW1CLEVBQ3JCLGNBQWMsQ0FBQyxJQUFJLHFCQUFxQixDQUFDLEVBQzNDLENBQUMsQ0FDSDtJQUNBLGtCQUFrQixtQ0FBbUM7S0FDbkQsT0FBTyxTQUFTLHNCQUFzQjtJQUN4QyxDQUFDO0lBQ0QsU0FBUyxFQUNQLE9BQU8sU0FBUyxNQUNsQjtHQUNGLENBQUM7R0FDRCxNQUFNLFFBQVEsT0FBTztHQUNyQixJQUFJLHNCQUFzQixxQkFBcUI7SUFDN0MsTUFBTSxHQUFHLGdCQUFnQixNQUFNLFdBQVc7SUFDMUMsT0FBTztHQUNUO0VBQ0Y7RUFDQSxPQUFPO0dBQ0wsSUFBSSxRQUFRLGVBQWUsa0JBQWtCLFVBQVU7SUFDckQsU0FBVSxLQUNSLHVLQUNGO0lBQ0E7R0FDRjtHQUNBLFFBQVEsUUFBUTtHQUNoQixPQUFPLFlBQVksRUFBRSxNQUFNLGtCQUFrQixDQUFDO0VBQ2hEO0VBQ0EsUUFBUSxRQUFRO0VBQ2hCLEtBQUssUUFBUSxJQUFJLEtBQUssT0FBTztFQUM3QixlQUFlLFFBQVEsY0FBYyxLQUFLLE9BQU87RUFDakQsaUJBQWlCLFFBQVEsZ0JBQWdCLEtBQUssT0FBTztFQUNyRCxjQUFjLFFBQVEsYUFBYSxLQUFLLE9BQU87Q0FDakQ7QUFDRjtBQUNBLElBQUksaUJBQWlCLE1BQU07Q0FDekI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxjQUFjO0VBQ1osTUFBTSxTQUFTLFlBQVk7RUFDM0IsS0FBSyxRQUFRLE9BQU8sTUFBTSxLQUFLLE1BQU07RUFDckMsS0FBSyxPQUFPLE9BQU8sS0FBSyxLQUFLLE1BQU07RUFDbkMsS0FBSyxNQUFNLE9BQU8sSUFBSSxLQUFLLE1BQU07RUFDakMsS0FBSyxnQkFBZ0IsT0FBTyxjQUFjLEtBQUssTUFBTTtFQUNyRCxLQUFLLGtCQUFrQixPQUFPLGdCQUFnQixLQUFLLE1BQU07RUFDekQsS0FBSyxlQUFlLE9BQU8sYUFBYSxLQUFLLE1BQU07RUFDbkQsS0FBSyxTQUFTLE9BQU87Q0FDdkI7QUFDRiJ9