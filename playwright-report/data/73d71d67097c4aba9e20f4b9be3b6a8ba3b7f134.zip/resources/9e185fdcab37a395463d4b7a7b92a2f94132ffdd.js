import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/UserDetails.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import { useUser } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/hooks.ts";
import { Spinner } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/index.ts";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/UserDetails.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
var _s = $RefreshSig$();
const UserDetails = ({ userId, actions }) => {
	_s();
	const { data: user, isLoading, error } = useUser(userId);
	const formatDate = (dateString) => {
		const date = new Date(dateString);
		return date.toLocaleDateString("en-GB", {
			day: "numeric",
			month: "short",
			year: "numeric"
		});
	};
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV(Spinner, { label: "Loading user details..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 12
		}, this);
	}
	if (error) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "rounded-md border border-destructive/50 bg-destructive/10 p-4",
			children: /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm text-destructive",
				children: error?.message || "Error loading user details. Please try again later."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 7
		}, this);
	}
	if (!user) {
		return /* @__PURE__ */ _jsxDEV("p", { children: "User not found" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex gap-2 items-baseline",
			children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "font-mono text-xs uppercase tracking-widest text-muted-foreground",
				children: "User"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("h1", {
				className: "mt-1 text-2xl font-semibold tracking-tight text-foreground",
				children: user.username
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("dl", {
			className: "mt-6 flex gap-4 flex-wrap justify-between",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
					className: "font-mono text-xs uppercase tracking-widest text-muted-foreground",
					children: "ID"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("dd", {
					className: "mt-1 break-all font-mono text-sm text-foreground",
					children: user.id
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
					className: "font-mono text-xs uppercase tracking-widest text-muted-foreground",
					children: "Created"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("dd", {
					className: "mt-1 text-sm text-foreground",
					children: formatDate(user.createdAt)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", {
					className: "font-mono text-xs uppercase tracking-widest text-muted-foreground",
					children: "Updated"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("dd", {
					className: "mt-1 text-sm text-foreground",
					children: formatDate(user.updatedAt)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 7
		}, this),
		actions && /* @__PURE__ */ _jsxDEV("div", {
			className: "mt-6 flex flex-wrap gap-2",
			children: actions
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 78,
			columnNumber: 19
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 42,
		columnNumber: 5
	}, this);
};
_s(UserDetails, "CLAbsJj7qFF+Uc7UpmdiUiHxYy8=", false, function() {
	return [useUser];
});
_c = UserDetails;
export { UserDetails };
var _c;
$RefreshReg$(_c, "UserDetails");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/UserDetails.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/UserDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/UserDetails.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/users/src/components/UserDetails.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZUFBZTs7OztBQU94QixNQUFNLGVBQWUsRUFBRSxRQUFRLGNBQStCOztDQUM1RCxNQUFNLEVBQUUsTUFBTSxNQUFNLFdBQVcsVUFBVSxRQUFRLE1BQU07Q0FFdkQsTUFBTSxjQUFjLGVBQXFCO0VBQ3ZDLE1BQU0sT0FBTyxJQUFJLEtBQUssVUFBVTtFQUNoQyxPQUFPLEtBQUssbUJBQW1CLFNBQVM7R0FDdEMsS0FBSztHQUNMLE9BQU87R0FDUCxNQUFNO0VBQ1IsQ0FBQztDQUNIO0NBRUEsSUFBSSxXQUFXO0VBQ2IsT0FBTyx3QkFBQyxTQUFELEVBQVMsT0FBTSwwQkFBMkI7Ozs7O0NBQ25EO0NBRUEsSUFBSSxPQUFPO0VBQ1QsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQ1YsT0FBTyxXQUNOO0dBQ0Q7Ozs7O0VBQ0E7Ozs7O0NBRVQ7Q0FFQSxJQUFJLENBQUMsTUFBTTtFQUNULE9BQU8sd0JBQUMsS0FBRCxZQUFHLGlCQUFpQjs7Ozs7Q0FDN0I7Q0FFQSxPQUNFO0VBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQW9FO0dBRTlFOzs7O2FBQ0gsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FDWCxLQUFLO0dBQ0o7Ozs7V0FDRDs7Ozs7O0VBQ0wsd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFBZDtJQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFvRTtJQUU5RTs7OztjQUNKLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQ1gsS0FBSztJQUNKOzs7O1lBQ0Q7Ozs7O0lBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQW9FO0lBRTlFOzs7O2NBQ0osd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFDWCxXQUFXLEtBQUssU0FBUztJQUN4Qjs7OztZQUNEOzs7OztJQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFvRTtJQUU5RTs7OztjQUNKLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQ1gsV0FBVyxLQUFLLFNBQVM7SUFDeEI7Ozs7WUFDRDs7Ozs7R0FDSDs7Ozs7O0VBRUgsV0FBVyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUE2QjtFQUFhOzs7OztDQUNyRTs7Ozs7QUFFTjs7Ozs7QUFFQSxTQUFTIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlVzZXJEZXRhaWxzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlVXNlciB9IGZyb20gXCIuLi9ob29rc1wiO1xuaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gXCJAcmVwby9zaGFyZWRcIjtcblxuaW50ZXJmYWNlIFVzZXJEZXRhaWxzUHJvcCB7XG4gIHVzZXJJZDogc3RyaW5nO1xuICBhY3Rpb25zPzogUmVhY3ROb2RlO1xufVxuXG5jb25zdCBVc2VyRGV0YWlscyA9ICh7IHVzZXJJZCwgYWN0aW9ucyB9OiBVc2VyRGV0YWlsc1Byb3ApID0+IHtcbiAgY29uc3QgeyBkYXRhOiB1c2VyLCBpc0xvYWRpbmcsIGVycm9yIH0gPSB1c2VVc2VyKHVzZXJJZCk7XG5cbiAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlU3RyaW5nOiBEYXRlKSA9PiB7XG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xuICAgIHJldHVybiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUdCXCIsIHtcbiAgICAgIGRheTogXCJudW1lcmljXCIsXG4gICAgICBtb250aDogXCJzaG9ydFwiLFxuICAgICAgeWVhcjogXCJudW1lcmljXCIsXG4gICAgfSk7XG4gIH07XG5cbiAgaWYgKGlzTG9hZGluZykge1xuICAgIHJldHVybiA8U3Bpbm5lciBsYWJlbD1cIkxvYWRpbmcgdXNlciBkZXRhaWxzLi4uXCIgLz47XG4gIH1cblxuICBpZiAoZXJyb3IpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZGVzdHJ1Y3RpdmUvNTAgYmctZGVzdHJ1Y3RpdmUvMTAgcC00XCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1kZXN0cnVjdGl2ZVwiPlxuICAgICAgICAgIHtlcnJvcj8ubWVzc2FnZSB8fFxuICAgICAgICAgICAgXCJFcnJvciBsb2FkaW5nIHVzZXIgZGV0YWlscy4gUGxlYXNlIHRyeSBhZ2FpbiBsYXRlci5cIn1cbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGlmICghdXNlcikge1xuICAgIHJldHVybiA8cD5Vc2VyIG5vdCBmb3VuZDwvcD47XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgaXRlbXMtYmFzZWxpbmVcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICBVc2VyXG4gICAgICAgIDwvcD5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm10LTEgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICB7dXNlci51c2VybmFtZX1cbiAgICAgICAgPC9oMT5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRsIGNsYXNzTmFtZT1cIm10LTYgZmxleCBnYXAtNCBmbGV4LXdyYXAganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGR0IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICBJRFxuICAgICAgICAgIDwvZHQ+XG4gICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgYnJlYWstYWxsIGZvbnQtbW9ubyB0ZXh0LXNtIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAge3VzZXIuaWR9XG4gICAgICAgICAgPC9kZD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGR0IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICBDcmVhdGVkXG4gICAgICAgICAgPC9kdD5cbiAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAge2Zvcm1hdERhdGUodXNlci5jcmVhdGVkQXQpfVxuICAgICAgICAgIDwvZGQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgVXBkYXRlZFxuICAgICAgICAgIDwvZHQ+XG4gICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgIHtmb3JtYXREYXRlKHVzZXIudXBkYXRlZEF0KX1cbiAgICAgICAgICA8L2RkPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGw+XG5cbiAgICAgIHthY3Rpb25zICYmIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPnthY3Rpb25zfTwvZGl2Pn1cbiAgICA8Lz5cbiAgKTtcbn07XG5cbmV4cG9ydCB7IFVzZXJEZXRhaWxzIH07XG4iXX0=