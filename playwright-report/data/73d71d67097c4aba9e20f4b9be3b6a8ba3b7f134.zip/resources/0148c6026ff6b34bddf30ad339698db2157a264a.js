import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Button/Button.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Spinner } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Spinner/Spinner.tsx";
var _jsxFileName = "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Button/Button.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f71da48c";
const Button = ({ loading, disabled, children, className, variant = "primary", ...props }) => {
	return /* @__PURE__ */ _jsxDEV("button", {
		className: `inline-flex cursor-pointer items-center justify-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 
        ${className}
        ${variant === "primary" ? " bg-primary text-primary-foreground hover:bg-primary/90" : ""}
        ${variant === "outline" ? " border border-border bg-transparent text-foreground hover:bg-accent" : ""}
        ${variant === "ghost" ? " text-muted-foreground hover:bg-accent hover:text-foreground" : ""}
      `,
		disabled: disabled || loading,
		...props,
		children: [loading && /* @__PURE__ */ _jsxDEV(Spinner, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 19
		}, this), children]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
};
_c = Button;
export { Button };
var _c;
$RefreshReg$(_c, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Button/Button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Button/Button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Button/Button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/kukkudachi/Documents/Tests/TurboToDo/packages/shared/src/ui/Button/Button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlOzs7QUFPeEIsTUFBTSxVQUFVLEVBQ2QsU0FDQSxVQUNBLFVBQ0EsV0FDQSxVQUFVLFdBQ1YsR0FBRyxZQUNjO0NBQ2pCLE9BQ0Usd0JBQUMsVUFBRDtFQUNFLFdBQVc7VUFDUCxVQUFVO1VBQ1YsWUFBWSxZQUFZLDREQUE0RCxHQUFHO1VBQ3ZGLFlBQVksWUFBWSx5RUFBeUUsR0FBRztVQUNwRyxZQUFZLFVBQVUsaUVBQWlFLEdBQUc7O0VBRTlGLFVBQVUsWUFBWTtFQUN0QixHQUFJO1lBUk4sQ0FVRyxXQUFXLHdCQUFDLFNBQUQsQ0FBVTs7OztZQUNyQixRQUNLOzs7Ozs7QUFFWjs7QUFFQSxTQUFTIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkJ1dHRvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gXCIuLi9TcGlubmVyL1NwaW5uZXJcIjtcbmltcG9ydCB0eXBlIHsgQnV0dG9uSFRNTEF0dHJpYnV0ZXMgfSBmcm9tIFwicmVhY3RcIjtcbmludGVyZmFjZSBCdXR0b25Qcm9wcyBleHRlbmRzIEJ1dHRvbkhUTUxBdHRyaWJ1dGVzPEhUTUxCdXR0b25FbGVtZW50PiB7XG4gIGxvYWRpbmc/OiBib29sZWFuO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIHZhcmlhbnQ/OiBcInByaW1hcnlcIiB8IFwib3V0bGluZVwiIHwgXCJnaG9zdFwiO1xufVxuY29uc3QgQnV0dG9uID0gKHtcbiAgbG9hZGluZyxcbiAgZGlzYWJsZWQsXG4gIGNoaWxkcmVuLFxuICBjbGFzc05hbWUsXG4gIHZhcmlhbnQgPSBcInByaW1hcnlcIixcbiAgLi4ucHJvcHNcbn06IEJ1dHRvblByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggY3Vyc29yLXBvaW50ZXIgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQtbWQgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmcgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC0yIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtYmFja2dyb3VuZCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6b3BhY2l0eS01MCBcbiAgICAgICAgJHtjbGFzc05hbWV9XG4gICAgICAgICR7dmFyaWFudCA9PT0gXCJwcmltYXJ5XCIgPyBcIiBiZy1wcmltYXJ5IHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIGhvdmVyOmJnLXByaW1hcnkvOTBcIiA6IFwiXCJ9XG4gICAgICAgICR7dmFyaWFudCA9PT0gXCJvdXRsaW5lXCIgPyBcIiBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy10cmFuc3BhcmVudCB0ZXh0LWZvcmVncm91bmQgaG92ZXI6YmctYWNjZW50XCIgOiBcIlwifVxuICAgICAgICAke3ZhcmlhbnQgPT09IFwiZ2hvc3RcIiA/IFwiIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3ZlcjpiZy1hY2NlbnQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCIgOiBcIlwifVxuICAgICAgYH1cbiAgICAgIGRpc2FibGVkPXtkaXNhYmxlZCB8fCBsb2FkaW5nfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIHtsb2FkaW5nICYmIDxTcGlubmVyIC8+fVxuICAgICAge2NoaWxkcmVufVxuICAgIDwvYnV0dG9uPlxuICApO1xufTtcblxuZXhwb3J0IHsgQnV0dG9uIH07XG4iXX0=