import { useQuery, useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=f71da48c";
import { todoKeys } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/query-keys.ts";
import { getTodos, createTodo, updateTodoStatus } from "/@fs/Users/kukkudachi/Documents/Tests/TurboToDo/packages/todos/src/api.tsx";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
const useTodos = (userId) => {
	_s();
	return useQuery({
		queryKey: userId ? todoKeys.byUser(userId) : todoKeys.all,
		queryFn: () => getTodos(userId),
		enabled: userId ? !!userId : true
	});
};
_s(useTodos, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function() {
	return [useQuery];
});
const useCreateTodo = () => {
	_s2();
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (data) => createTodo(data),
		onMutate: async (newTodo) => {
			await queryClient.cancelQueries({ queryKey: todoKeys.all });
			const previousTodos = queryClient.getQueryData(todoKeys.all);
			const previousUserTodos = queryClient.getQueryData(todoKeys.byUser(newTodo.userId));
			const optimisticTodo = {
				id: `temp-${Date.now()}`,
				title: newTodo.title,
				description: newTodo.description,
				status: newTodo.status || "pending",
				userId: newTodo.userId,
				createdAt: new Date(),
				updatedAt: new Date()
			};
			// Optimistically update all todos cache
			queryClient.setQueryData(todoKeys.all, (old = []) => {
				return [...old, optimisticTodo];
			});
			// Optimistically update user-specific todos cache
			queryClient.setQueryData(todoKeys.byUser(newTodo.userId), (old = []) => {
				return [...old, optimisticTodo];
			});
			return {
				previousTodos,
				previousUserTodos
			};
		},
		onError: (_err, newTodo, context) => {
			if (context?.previousTodos) {
				queryClient.setQueryData(todoKeys.all, context.previousTodos);
			}
			if (context?.previousUserTodos) {
				queryClient.setQueryData(todoKeys.byUser(newTodo.userId), context.previousUserTodos);
			}
		},
		onSuccess: () => {
			// Invalidate all todo queries to refetch fresh data
			queryClient.invalidateQueries({ queryKey: todoKeys.all });
		}
	});
};
_s2(useCreateTodo, "i+IOhi4najGoOT2n6g5oPWdxN4s=", false, function() {
	return [useQueryClient, useMutation];
});
const useToggleTodoStatus = () => {
	_s3();
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: ({ todoId, status }) => updateTodoStatus(todoId, status),
		onMutate: async ({ todoId, status }) => {
			await queryClient.cancelQueries({ queryKey: todoKeys.all });
			const previousTodos = queryClient.getQueryData(todoKeys.all);
			queryClient.setQueryData(todoKeys.all, (current) => {
				return current?.map((todo) => todo.id === todoId ? {
					...todo,
					status
				} : todo);
			});
			return { previousTodos };
		},
		onError: (_err, _data, context) => {
			if (context?.previousTodos) {
				queryClient.setQueryData(todoKeys.all, context.previousTodos);
			}
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: todoKeys.all });
		}
	});
};
_s3(useToggleTodoStatus, "i+IOhi4najGoOT2n6g5oPWdxN4s=", false, function() {
	return [useQueryClient, useMutation];
});
export { useTodos, useCreateTodo, useToggleTodoStatus };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGFBQWEsc0JBQXNCO0FBQ3RELFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsVUFBVSxZQUFZLHdCQUF3Qjs7QUFHdkQsTUFBTSxZQUFZLFdBQW9COztDQUNwQyxPQUFPLFNBQTRCO0VBQ2pDLFVBQVUsU0FBUyxTQUFTLE9BQU8sTUFBTSxJQUFJLFNBQVM7RUFDdEQsZUFBZSxTQUFTLE1BQU07RUFDOUIsU0FBUyxTQUFTLENBQUMsQ0FBQyxTQUFTO0NBQy9CLENBQUM7QUFDSDs7OztBQUVBLE1BQU0sc0JBQXNCOztDQUMxQixNQUFNLGNBQWMsZUFBZTtDQUVuQyxPQUFPLFlBUUw7RUFDQSxhQUFhLFNBQWdDLFdBQVcsSUFBSTtFQUM1RCxVQUFVLE9BQU8sWUFBWTtHQUMzQixNQUFNLFlBQVksY0FBYyxFQUFFLFVBQVUsU0FBUyxJQUFJLENBQUM7R0FFMUQsTUFBTSxnQkFBZ0IsWUFBWSxhQUF5QixTQUFTLEdBQUc7R0FDdkUsTUFBTSxvQkFBb0IsWUFBWSxhQUNwQyxTQUFTLE9BQU8sUUFBUSxNQUFNLENBQ2hDO0dBRUEsTUFBTSxpQkFBMkI7SUFDL0IsSUFBSSxRQUFRLEtBQUssSUFBSTtJQUNyQixPQUFPLFFBQVE7SUFDZixhQUFhLFFBQVE7SUFDckIsUUFBUSxRQUFRLFVBQVU7SUFDMUIsUUFBUSxRQUFRO0lBQ2hCLFdBQVcsSUFBSSxLQUFLO0lBQ3BCLFdBQVcsSUFBSSxLQUFLO0dBQ3RCOztHQUdBLFlBQVksYUFBeUIsU0FBUyxNQUFNLE1BQU0sQ0FBQyxNQUFNO0lBQy9ELE9BQU8sQ0FBQyxHQUFHLEtBQUssY0FBYztHQUNoQyxDQUFDOztHQUdELFlBQVksYUFDVixTQUFTLE9BQU8sUUFBUSxNQUFNLElBQzdCLE1BQU0sQ0FBQyxNQUFNO0lBQ1osT0FBTyxDQUFDLEdBQUcsS0FBSyxjQUFjO0dBQ2hDLENBQ0Y7R0FFQSxPQUFPO0lBQUU7SUFBZTtHQUFrQjtFQUM1QztFQUVBLFVBQVUsTUFBTSxTQUFTLFlBQVk7R0FDbkMsSUFBSSxTQUFTLGVBQWU7SUFDMUIsWUFBWSxhQUFhLFNBQVMsS0FBSyxRQUFRLGFBQWE7R0FDOUQ7R0FDQSxJQUFJLFNBQVMsbUJBQW1CO0lBQzlCLFlBQVksYUFDVixTQUFTLE9BQU8sUUFBUSxNQUFNLEdBQzlCLFFBQVEsaUJBQ1Y7R0FDRjtFQUNGO0VBRUEsaUJBQWlCOztHQUVmLFlBQVksa0JBQWtCLEVBQUUsVUFBVSxTQUFTLElBQUksQ0FBQztFQUMxRDtDQUNGLENBQUM7QUFDSDs7OztBQUVBLE1BQU0sNEJBQTRCOztDQUNoQyxNQUFNLGNBQWMsZUFBZTtDQUVuQyxPQUFPLFlBT0w7RUFDQSxhQUFhLEVBQUUsUUFBUSxhQUNyQixpQkFBaUIsUUFBUSxNQUFNO0VBQ2pDLFVBQVUsT0FBTyxFQUFFLFFBQVEsYUFBYTtHQUN0QyxNQUFNLFlBQVksY0FBYyxFQUFFLFVBQVUsU0FBUyxJQUFJLENBQUM7R0FFMUQsTUFBTSxnQkFBZ0IsWUFBWSxhQUF5QixTQUFTLEdBQUc7R0FFdkUsWUFBWSxhQUF5QixTQUFTLE1BQU0sWUFBWTtJQUM5RCxPQUFPLFNBQVMsS0FBSyxTQUNuQixLQUFLLE9BQU8sU0FBUztLQUFFLEdBQUc7S0FBTTtJQUFPLElBQUksSUFDN0M7R0FDRixDQUFDO0dBQ0QsT0FBTyxFQUFFLGNBQWM7RUFDekI7RUFFQSxVQUFVLE1BQU0sT0FBTyxZQUFZO0dBQ2pDLElBQUksU0FBUyxlQUFlO0lBQzFCLFlBQVksYUFBYSxTQUFTLEtBQUssUUFBUSxhQUFhO0dBQzlEO0VBQ0Y7RUFFQSxpQkFBaUI7R0FDZixZQUFZLGtCQUFrQixFQUFFLFVBQVUsU0FBUyxJQUFJLENBQUM7RUFDMUQ7Q0FDRixDQUFDO0FBQ0g7Ozs7QUFFQSxTQUFTLFVBQVUsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJob29rcy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnksIHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcbmltcG9ydCB7IHRvZG9LZXlzIH0gZnJvbSBcIi4vcXVlcnkta2V5c1wiO1xuaW1wb3J0IHsgZ2V0VG9kb3MsIGNyZWF0ZVRvZG8sIHVwZGF0ZVRvZG9TdGF0dXMgfSBmcm9tIFwiLi9hcGlcIjtcbmltcG9ydCB0eXBlIHsgVG9Eb0l0ZW0sIENyZWF0ZVRvRG9JdGVtUmVxdWVzdCwgVG9Eb1N0YXR1cyB9IGZyb20gXCJAcmVwby9zaGFyZWRcIjtcblxuY29uc3QgdXNlVG9kb3MgPSAodXNlcklkPzogc3RyaW5nKSA9PiB7XG4gIHJldHVybiB1c2VRdWVyeTxUb0RvSXRlbVtdLCBFcnJvcj4oe1xuICAgIHF1ZXJ5S2V5OiB1c2VySWQgPyB0b2RvS2V5cy5ieVVzZXIodXNlcklkKSA6IHRvZG9LZXlzLmFsbCxcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRUb2Rvcyh1c2VySWQpLFxuICAgIGVuYWJsZWQ6IHVzZXJJZCA/ICEhdXNlcklkIDogdHJ1ZSxcbiAgfSk7XG59O1xuXG5jb25zdCB1c2VDcmVhdGVUb2RvID0gKCkgPT4ge1xuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG5cbiAgcmV0dXJuIHVzZU11dGF0aW9uPFxuICAgIFRvRG9JdGVtLFxuICAgIEVycm9yLFxuICAgIENyZWF0ZVRvRG9JdGVtUmVxdWVzdCxcbiAgICB7XG4gICAgICBwcmV2aW91c1RvZG9zPzogVG9Eb0l0ZW1bXTtcbiAgICAgIHByZXZpb3VzVXNlclRvZG9zPzogVG9Eb0l0ZW1bXTtcbiAgICB9XG4gID4oe1xuICAgIG11dGF0aW9uRm46IChkYXRhOiBDcmVhdGVUb0RvSXRlbVJlcXVlc3QpID0+IGNyZWF0ZVRvZG8oZGF0YSksXG4gICAgb25NdXRhdGU6IGFzeW5jIChuZXdUb2RvKSA9PiB7XG4gICAgICBhd2FpdCBxdWVyeUNsaWVudC5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IHRvZG9LZXlzLmFsbCB9KTtcblxuICAgICAgY29uc3QgcHJldmlvdXNUb2RvcyA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGF0YTxUb0RvSXRlbVtdPih0b2RvS2V5cy5hbGwpO1xuICAgICAgY29uc3QgcHJldmlvdXNVc2VyVG9kb3MgPSBxdWVyeUNsaWVudC5nZXRRdWVyeURhdGE8VG9Eb0l0ZW1bXT4oXG4gICAgICAgIHRvZG9LZXlzLmJ5VXNlcihuZXdUb2RvLnVzZXJJZCksXG4gICAgICApO1xuXG4gICAgICBjb25zdCBvcHRpbWlzdGljVG9kbzogVG9Eb0l0ZW0gPSB7XG4gICAgICAgIGlkOiBgdGVtcC0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgdGl0bGU6IG5ld1RvZG8udGl0bGUsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBuZXdUb2RvLmRlc2NyaXB0aW9uLFxuICAgICAgICBzdGF0dXM6IG5ld1RvZG8uc3RhdHVzIHx8IFwicGVuZGluZ1wiLFxuICAgICAgICB1c2VySWQ6IG5ld1RvZG8udXNlcklkLFxuICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgIH07XG5cbiAgICAgIC8vIE9wdGltaXN0aWNhbGx5IHVwZGF0ZSBhbGwgdG9kb3MgY2FjaGVcbiAgICAgIHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGF0YTxUb0RvSXRlbVtdPih0b2RvS2V5cy5hbGwsIChvbGQgPSBbXSkgPT4ge1xuICAgICAgICByZXR1cm4gWy4uLm9sZCwgb3B0aW1pc3RpY1RvZG9dO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIE9wdGltaXN0aWNhbGx5IHVwZGF0ZSB1c2VyLXNwZWNpZmljIHRvZG9zIGNhY2hlXG4gICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8VG9Eb0l0ZW1bXT4oXG4gICAgICAgIHRvZG9LZXlzLmJ5VXNlcihuZXdUb2RvLnVzZXJJZCksXG4gICAgICAgIChvbGQgPSBbXSkgPT4ge1xuICAgICAgICAgIHJldHVybiBbLi4ub2xkLCBvcHRpbWlzdGljVG9kb107XG4gICAgICAgIH0sXG4gICAgICApO1xuXG4gICAgICByZXR1cm4geyBwcmV2aW91c1RvZG9zLCBwcmV2aW91c1VzZXJUb2RvcyB9O1xuICAgIH0sXG5cbiAgICBvbkVycm9yOiAoX2VyciwgbmV3VG9kbywgY29udGV4dCkgPT4ge1xuICAgICAgaWYgKGNvbnRleHQ/LnByZXZpb3VzVG9kb3MpIHtcbiAgICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKHRvZG9LZXlzLmFsbCwgY29udGV4dC5wcmV2aW91c1RvZG9zKTtcbiAgICAgIH1cbiAgICAgIGlmIChjb250ZXh0Py5wcmV2aW91c1VzZXJUb2Rvcykge1xuICAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoXG4gICAgICAgICAgdG9kb0tleXMuYnlVc2VyKG5ld1RvZG8udXNlcklkKSxcbiAgICAgICAgICBjb250ZXh0LnByZXZpb3VzVXNlclRvZG9zLFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcbiAgICAgIC8vIEludmFsaWRhdGUgYWxsIHRvZG8gcXVlcmllcyB0byByZWZldGNoIGZyZXNoIGRhdGFcbiAgICAgIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHRvZG9LZXlzLmFsbCB9KTtcbiAgICB9LFxuICB9KTtcbn07XG5cbmNvbnN0IHVzZVRvZ2dsZVRvZG9TdGF0dXMgPSAoKSA9PiB7XG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcblxuICByZXR1cm4gdXNlTXV0YXRpb248XG4gICAgVG9Eb0l0ZW0sXG4gICAgRXJyb3IsXG4gICAgeyB0b2RvSWQ6IHN0cmluZzsgc3RhdHVzOiBUb0RvU3RhdHVzIH0sXG4gICAge1xuICAgICAgcHJldmlvdXNUb2Rvcz86IFRvRG9JdGVtW107XG4gICAgfVxuICA+KHtcbiAgICBtdXRhdGlvbkZuOiAoeyB0b2RvSWQsIHN0YXR1cyB9OiB7IHRvZG9JZDogc3RyaW5nOyBzdGF0dXM6IFRvRG9TdGF0dXMgfSkgPT5cbiAgICAgIHVwZGF0ZVRvZG9TdGF0dXModG9kb0lkLCBzdGF0dXMpLFxuICAgIG9uTXV0YXRlOiBhc3luYyAoeyB0b2RvSWQsIHN0YXR1cyB9KSA9PiB7XG4gICAgICBhd2FpdCBxdWVyeUNsaWVudC5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IHRvZG9LZXlzLmFsbCB9KTtcblxuICAgICAgY29uc3QgcHJldmlvdXNUb2RvcyA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGF0YTxUb0RvSXRlbVtdPih0b2RvS2V5cy5hbGwpO1xuXG4gICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8VG9Eb0l0ZW1bXT4odG9kb0tleXMuYWxsLCAoY3VycmVudCkgPT4ge1xuICAgICAgICByZXR1cm4gY3VycmVudD8ubWFwKCh0b2RvKSA9PlxuICAgICAgICAgIHRvZG8uaWQgPT09IHRvZG9JZCA/IHsgLi4udG9kbywgc3RhdHVzIH0gOiB0b2RvLFxuICAgICAgICApO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4geyBwcmV2aW91c1RvZG9zIH07XG4gICAgfSxcblxuICAgIG9uRXJyb3I6IChfZXJyLCBfZGF0YSwgY29udGV4dCkgPT4ge1xuICAgICAgaWYgKGNvbnRleHQ/LnByZXZpb3VzVG9kb3MpIHtcbiAgICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKHRvZG9LZXlzLmFsbCwgY29udGV4dC5wcmV2aW91c1RvZG9zKTtcbiAgICAgIH1cbiAgICB9LFxuXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XG4gICAgICBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiB0b2RvS2V5cy5hbGwgfSk7XG4gICAgfSxcbiAgfSk7XG59O1xuXG5leHBvcnQgeyB1c2VUb2RvcywgdXNlQ3JlYXRlVG9kbywgdXNlVG9nZ2xlVG9kb1N0YXR1cyB9O1xuIl19